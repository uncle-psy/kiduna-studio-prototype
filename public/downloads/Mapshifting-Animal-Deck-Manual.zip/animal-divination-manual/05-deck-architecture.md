# Deck Architecture

## Why 68 cards

The core deck contains **68 animals**. The number emerged from a coverage and redundancy audit rather than numerology. Fewer than 60 left major ecological strategies and invertebrate forms underrepresented; more than 70 began adding animals whose meanings substantially repeated existing cards. Sixty-eight preserves distinct archetypal work while remaining learnable.

## Ecological coverage

| Group | Cards |
|---|---:|
| Mammals | 18 |
| Birds | 13 |
| Reptiles | 6 |
| Amphibians | 4 |
| Fish and rays | 8 |
| Insects | 7 |
| Arachnids | 2 |
| Mollusks | 3 |
| Crustaceans | 2 |
| Other marine invertebrates | 4 |
| Annelids | 1 |

The roster crosses land, air, freshwater, coast, and ocean; multiple continents; wild and domesticated lives; solitary and social strategies; predator, prey, grazer, pollinator, decomposer, ecosystem engineer, migrant, ambush hunter, and cooperative colony.

## Organization

Cards are numbered for reference but not ranked. Taxonomy and habitat are descriptive indexes, not suits. Elemental and seasonal associations are original correspondences used as optional reading aids and never presented as cultural tradition.

## Distinctiveness

Apparent neighbors are intentionally differentiated. Wolf is coordinated belonging; Dog is reciprocal trust across species. Beaver is constructive systems work; Coral is collective habitat-making. Hummingbird is precise energetic exchange; Bee is distributed cooperation. Turtle is patient return across distance; Tortoise is resource-paced endurance on land. Octopus is flexible intelligence; Chameleon is contextual signaling and measured adaptation.

See the [redundancy audit](research/audit-report.md#redundancy-and-coverage) and [relationship index](indexes/relationships-between-cards.md).

Continue to [How to use the deck](06-how-to-use-the-deck.md).
