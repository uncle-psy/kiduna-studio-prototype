# Changelog

## 2026-08-23 — 0.1.0 research draft

- Established a 68-card, behavior-first animal deck.
- Added complete manual chapters and nine reading layouts.
- Added Gift–Wound, balanced/overexpressed/underexpressed, agency, consent, and wildlife-safety frameworks.
- Added source, cultural-attribution, biology, contradiction, open-question, and audit records.
- Added all card files, cross-indexes, glossary, bibliography, manifest, and link/completeness checks.
- Recorded that the complete Andrews and Krans guidebooks were unavailable.
- Generated no images.
