# Manifest

Generated: 2026-08-23  
Release: 0.1.0 complete research draft

## Collection summary

- Core deck: **68 cards**
- Markdown files including this manifest: **102**
- Unique cited external records: **89**
- Manual chapters: **10 numbered chapters**, plus README, glossary, bibliography, and changelog
- Card files: **68**, plus card index README
- Cross-index files: **10**
- Research/audit files: **7**
- Template files: **1**
- Images: **0**

## Directory tree

```text
animal-divination-manual/
├── README.md
├── 00-goal-and-scope.md
├── 01-philosophy.md
├── 02-methodology.md
├── 03-cultural-integrity.md
├── 04-gifts-and-wounds.md
├── 05-deck-architecture.md
├── 06-how-to-use-the-deck.md
├── 07-reading-for-others.md
├── 08-spreads.md
├── 09-integration-practices.md
├── cards/                 68 card files + README
├── indexes/               10 cross-indexes
├── research/              7 ledgers and audits
├── templates/             animal card template
├── glossary.md
├── bibliography.md
├── manifest.md
└── CHANGELOG.md
```

The complete card filenames and every other file appear in the integrity table below.

## Integrity table

SHA-256 values cover every file except this self-referential manifest.

| Relative path | Bytes | SHA-256 |
|---|---:|---|
| `00-goal-and-scope.md` | 1,592 | `cc6de5c393b73f7034638591d485d8337a33a12c61ea9aa9dbab09d68e35fadc` |
| `01-philosophy.md` | 1,934 | `ec9f8a637ebedff6176261e843cebd481be6acd2a037a61690b90b0e92f1cf93` |
| `02-methodology.md` | 2,921 | `b88465216985e276de67d9f8bb47b37887e8950f0d762fba7d8e27065ebecad7` |
| `03-cultural-integrity.md` | 2,333 | `b357d7ead6fbfa46e74a36cb5307b24f3e39844ed9b6125ff7d10f9c272d4649` |
| `04-gifts-and-wounds.md` | 1,649 | `4eea502edbc219f479e553b813c734634185ccfbff27ed34c9e507c5e268c2fe` |
| `05-deck-architecture.md` | 1,876 | `23d18d6ec613b29bc755819997b818c87f2737da88f1c135cd65b711879bc2af` |
| `06-how-to-use-the-deck.md` | 2,242 | `20760fb222f53bb53354e23e437bd6573af34fa66a6cfa0d662d413223b90205` |
| `07-reading-for-others.md` | 1,487 | `e2ffb1e60a5decc141797b65d5eab593d9c3c714218c2752fe20e077a1fd2b55` |
| `08-spreads.md` | 3,722 | `dd22f67cec3a5e46393b859c923831231c0bac90a6392cf8b6d86d94862ae0c4` |
| `09-integration-practices.md` | 1,915 | `0f73fbc27fb736766c6b69fa514ffbc4a89a07dc9e44d6e9d59b24b6200c366f` |
| `CHANGELOG.md` | 573 | `c9a703d0037d797756e59a7e5fc8c406323fc4d2bda946c1e4ab068ad4484113` |
| `README.md` | 2,053 | `3c366524a062eee076c75bb8e81d7da959daedc93bab08b90bbd4652967460f6` |
| `bibliography.md` | 2,771 | `7aa8f79d27f16a5276b534e23b615b76148a32a84a12933f28b9e70169f2a702` |
| `cards/001-gray-wolf.md` | 8,984 | `b905e00e3c14cff4f593c387b5346d329fba82ddb040b6a9608bb10efafb6d98` |
| `cards/002-african-lion.md` | 9,062 | `e5a04017b610262146ae38d6dc03343866f9e5f5603d78443b62efc2bdacce8e` |
| `cards/003-african-elephant.md` | 9,578 | `23a264b4cc0b202db7c13951b0d30fa0e17cba354b1b224d9cad283e8f9259c0` |
| `cards/004-red-fox.md` | 8,905 | `b4149a8f2c96a1e6e5350bae9dbb5358b27ed595f49217a1698fe094459aaf6e` |
| `cards/005-american-black-bear.md` | 9,106 | `47fbb2080424bc6edcfb627a1218c6c5576cdc55b795b72ff940cccc285e61df` |
| `cards/006-white-tailed-deer.md` | 8,944 | `d542030788a1b3af67cc9787ccad1d2b6dc0cbc7680ae88591563bd42280942f` |
| `cards/007-american-bison.md` | 9,062 | `ba425db2ed08ada1079c41abe46bb7d79d6fd2d56cf37eec5224daba643e203c` |
| `cards/008-domestic-horse.md` | 8,816 | `55b2da3effe44ff4bb4aeba24a06abb36c17d64ae85e12557d16639b05226d46` |
| `cards/009-domestic-dog.md` | 9,052 | `de51bf8e2b32b0a226da29d1e394445a970190b6252ef6f4cf52382f12288d1a` |
| `cards/010-domestic-cat.md` | 9,283 | `881a31543bb048c946cfa9bb3f45ef4cfcdf9bbfd05d3b0daffb00987a0c5e4b` |
| `cards/011-north-american-beaver.md` | 8,894 | `7687815eda643c61723100ec01d6837803ed5e06350a26d6942ed47880617e43` |
| `cards/012-north-american-river-otter.md` | 8,768 | `e44375cb842c4102f99ccf8233d16851e567531fd6baa7ca7088cd65a675aa71` |
| `cards/013-little-brown-bat.md` | 9,033 | `e2fbfb6e1ff9a5b42faa85c3157adde082e02f2ed8bbd6e6e3602f3ef6a0c846` |
| `cards/014-bottlenose-dolphin.md` | 9,118 | `ec51b7bc948d30b8092eef0849152eb83776e78e05025a479889abd3da809bd0` |
| `cards/015-humpback-whale.md` | 9,214 | `89063eccc2cacaf0829ff168ba12875a20dfe3af90fd1c7dc5cbc258d627c777` |
| `cards/016-western-gorilla.md` | 8,911 | `6e327805f2d79599fbde8d266cc93fbb12123917bede8345aa2ed0db61b28764` |
| `cards/017-red-kangaroo.md` | 8,724 | `8d1b969aba2f96d9183237f20c9f75cdddd27f4c3ce38703a1500cd75e2ba1a3` |
| `cards/018-platypus.md` | 9,022 | `0566fc6e3503b9276ac4ccb358d50061943f8cb5024095da87cbf44206000fda` |
| `cards/019-bald-eagle.md` | 9,180 | `e8ce841b16f983764f35da7268919379aacd3222f7ffed1cdacde6d40c77ab34` |
| `cards/020-great-horned-owl.md` | 9,424 | `fb63a2e473fc8e5b6165aebc2dfccdb45ed8558dd47c85e695ca339402ba0ae9` |
| `cards/021-common-raven.md` | 8,870 | `b80123f319a54b31c0e9f69569f12b202784bed4497561135d740b1acf0dc998` |
| `cards/022-red-tailed-hawk.md` | 8,596 | `ccfd753c14eec69430fc294339ad8835a37f5dad4a5a9dac0991e5439c70e2dd` |
| `cards/023-ruby-throated-hummingbird.md` | 8,900 | `ff483c1a7290eedf66de4d4f4c4b5136ec9fe3d4557ceba491a887d0c021adee` |
| `cards/024-emperor-penguin.md` | 8,596 | `26e6d2cf278ab6ae5aab756413ee65077ad682c47969973850ce190ecd5167d1` |
| `cards/025-sandhill-crane.md` | 9,428 | `066cc5adc2257383781e836eea5e732fbd8c486040aecc1365aaaeef5db71d1b` |
| `cards/026-peregrine-falcon.md` | 8,672 | `14b48808791c0947fd9dad05d5660725a7bda1a42d9102eb8a9a20ea692324d8` |
| `cards/027-laysan-albatross.md` | 8,968 | `61c47680101f63b9f495115d3d354331ac8e71ed049c1f486fec5bcd32bc4803` |
| `cards/028-wild-turkey.md` | 8,707 | `1aeaebb7a263f90a9d254e026f9b833c09842b6526cfad4ab3601f74f5001790` |
| `cards/029-greater-flamingo.md` | 9,024 | `d6a8d9e175e9a36a70152f78b8f96253016d7aaec6e504d889c9a2c6e6e693d1` |
| `cards/030-indian-peafowl.md` | 8,567 | `38d10c051758254d92da7b47deeb56a4e4851f9f652c9216724cf58ba90993b0` |
| `cards/031-emu.md` | 8,639 | `f7b4ae15963029cf872c467f5aed4484b89164a82903a2b8cb07d757c8012aa8` |
| `cards/032-green-sea-turtle.md` | 9,408 | `6ee7c6249c147413646704d9af2a2b80fa2fc8cc72cda88ed89c7fdbd2b340fd` |
| `cards/033-king-cobra.md` | 9,052 | `133ad4ba0fc01f3f9699464785cec34a620e453efeec91a4469619b914ca23f0` |
| `cards/034-american-alligator.md` | 9,404 | `3dd51e43c09e58be6b979e11513ad7d2bc2a57f30353aefea6680d8e113e0b38` |
| `cards/035-panther-chameleon.md` | 9,204 | `6fe9e380b6e56d9724644d0468577ed857bcb1b9606a834ffc72d918ef44fd74` |
| `cards/036-komodo-dragon.md` | 8,950 | `0d2641b17c24b6ef4b767fe9160db0cf8354f2fbab9016015f898e0122ab5aa0` |
| `cards/037-mojave-desert-tortoise.md` | 9,288 | `9088899978af2e1bf41a8f21c4ff8bd320fbe87cf9e9ded3423ed969f79d548e` |
| `cards/038-axolotl.md` | 8,816 | `708e5c64ba09982840fff4f9cadaac420b33e20a09141add239235db0738b744` |
| `cards/039-dyeing-poison-frog.md` | 9,016 | `391ab03b559e7a05a4d8d867e12ee80430653481a4f067267a35b1101b885182` |
| `cards/040-tiger-salamander.md` | 8,733 | `2bc50ebdb729da84334e9879801a29a2ffc50cc643e06ef43cd8a1a71fbb9496` |
| `cards/041-american-bullfrog.md` | 9,068 | `ae3d8caa7f24101f6fa144e876c99b9b365381d5ca79d480e9d18d1a8155060b` |
| `cards/042-great-white-shark.md` | 8,921 | `615ce31502e99de6055366ba0e0b2bc7e966ece6e28e8586e7722bc85348bab9` |
| `cards/043-atlantic-salmon.md` | 8,647 | `7e2c9589ffb7c406f3aa1054bf72afc302e3d89440df55c0ac7e1b93ddb4958d` |
| `cards/044-ocellaris-clownfish.md` | 8,908 | `de19b143c29cb6e360794a0ca67a7db0c37fd6bf7930d31224d3fc8ead4acd7a` |
| `cards/045-lined-seahorse.md` | 8,633 | `b09bf0bd63059297d906e9142ea6a1b538bba321281b99fe653890ef5b635c28` |
| `cards/046-electric-eel.md` | 8,908 | `0af93f0f4f5950c0255eafd02a6f590e85c82251edd03b6e6d39ddd0ae970e7d` |
| `cards/047-reef-manta-ray.md` | 8,545 | `0b237a1c4428be55221f7f1c63b7bd7f808d298f4383109feb962859b723826c` |
| `cards/048-porcupinefish.md` | 8,913 | `022adb645df150f68ba2dce87f663e8ef9c5a22ef6ac6b668d310ad152ff418a` |
| `cards/049-banded-archerfish.md` | 8,491 | `8fe29f311bcd1a00d659aae66dc77348870447e22b248f889a1bfadbb77a4761` |
| `cards/050-western-honey-bee.md` | 8,911 | `ba94c10da0da0cdaaca00615a0d73ce1f72b0d402d9506652f2ff94aff5d08ab` |
| `cards/051-monarch-butterfly.md` | 9,068 | `d6f4c17dfce896801fba7d35e7727b344802de31d80f92896fc1c917e6786053` |
| `cards/052-common-green-darner.md` | 9,050 | `ac1383b29e8b30a422387587b85ec05132341b9b7eda42b159f9c5ca3b43b5ec` |
| `cards/053-sacred-scarab.md` | 9,303 | `4fa8ea66fddbf4e4e8cc9e7be4ef9fc8f13598543f70a29458ee7eb989dc59f0` |
| `cards/054-european-mantis.md` | 8,654 | `d568e7b5495c8b93978d00cfdfc13614dfefb4125f41290637b8b81881b1ff22` |
| `cards/055-common-eastern-firefly.md` | 9,043 | `249625cadddd55f68c174a5f340d1ee2bd290e2dfc6b94aeba4c332b57404cbe` |
| `cards/056-leafcutter-ant.md` | 9,042 | `f191aaabfadc026848eb2517f2287f3461def615047ae91bf26a6b592cb33e65` |
| `cards/057-cross-orbweaver.md` | 8,717 | `0c12b268594e1db1a14775aa4cb1124de9516016be26cd3dc8d88ce8dacc9ae5` |
| `cards/058-emperor-scorpion.md` | 8,879 | `fc16900da1d24dd516da6981c60a95460248c8df7bc84d086fdaccc5db93bf51` |
| `cards/059-common-octopus.md` | 8,967 | `a5f7232777269fbd5e2eed75a6146e577db97f48fa65a62b689c75d8222b377c` |
| `cards/060-chambered-nautilus.md` | 8,981 | `3e7cb77cd0d8d15f8ea93a8a4dbc7d42539197407e4caf84318622cab8de60ca` |
| `cards/061-garden-snail.md` | 8,817 | `79d6a887bc72e7277d2f33b08e5c0bc765f48d345b7e925c72d8fd8ab16d0c4f` |
| `cards/062-caribbean-hermit-crab.md` | 8,809 | `beaf4c33e2b8e9c94cd37168f658707ebdb23f1b5e680de590c28ff210602059` |
| `cards/063-peacock-mantis-shrimp.md` | 9,004 | `36a4f5a618effd10158b2252370f29309de107e736f71943e2e76e5070d83093` |
| `cards/064-moon-jelly.md` | 8,604 | `7b268c1ee7217b50d99e0598abc59c2e05fc5f3bb9e311ebf720cd7a48f3752f` |
| `cards/065-ochre-sea-star.md` | 8,840 | `c254cab01af5d05b998a03c208ffa01670378064fa4464d3fe904c066f826a76` |
| `cards/066-staghorn-coral.md` | 8,886 | `d2eeb258c8f568ab1cec0e02ec0e1cad8f6fc17dfca347bbc4957f9b368d669b` |
| `cards/067-giant-pacific-sea-cucumber.md` | 8,986 | `208cb08da4d495fc0f188958780dae5e91218b0fed431a4ea7dcc9967e1e62ba` |
| `cards/068-common-earthworm.md` | 8,889 | `9f3b80ea4efd2bd46cd5e6e96bf42719ea827ffbbad331fee4364b25f6b252fb` |
| `cards/README.md` | 7,732 | `b02dae8a6dd915f5e1120d394983dca75f3c5d5bfdde0141a66777ddd798500f` |
| `glossary.md` | 2,339 | `41f0af9c76d443bfb9c360d7766f1242582eb083b68c59cee451fca6178e32a3` |
| `indexes/archetypes-index.md` | 12,804 | `792ccb2a33ed0dc06c0a61fa6f040fe83dc2d85404948b749055570e5694bc4f` |
| `indexes/card-index.md` | 8,810 | `0342ccb1da59ee97906135f6ab1790d53b9ec1dafef2de15bc7b3bb492b1682e` |
| `indexes/cultural-traditions-index.md` | 4,815 | `bc30d95559fff8500a435aac9756ad7541d8317ff7282516e48f5185b773ca18` |
| `indexes/elements-and-correspondences.md` | 10,918 | `d141126703de89d4eca4b481b946e3e44cb2d84cb29e5604f7709500c72a1bb7` |
| `indexes/expansion-candidates.md` | 2,014 | `6a0bcab164ee0f4a3d0298ab0a93f1e50b542102fbefc879600c68bc3bc738fe` |
| `indexes/gifts-index.md` | 14,862 | `fc237c35c401c4b119bfe026002a5256e422dbf4bfe306fcb6b90c2d090540f8` |
| `indexes/habitats-index.md` | 14,584 | `4d3d7b52c444a81562bf45425e02e53a22adde9c0808e21e38d0ff19170e625b` |
| `indexes/relationships-between-cards.md` | 19,896 | `8630953f64461ab6b509be92988ebe4aa593589f3cf79e8ee5fb4b421109c6fe` |
| `indexes/taxonomy-index.md` | 3,795 | `5657db0fc7425eb90d870860df0d657d0e7b69ab951531e826067954837bd05a` |
| `indexes/wounds-index.md` | 14,904 | `122f0e9ad502a665d47466612c48bc5b0e9da9b5191a2cecf56a8771c8e5a6a2` |
| `research/audit-report.md` | 8,469 | `d841bde60921085f6499c75a4a6cb2cba5a12ea649c1bd55d3744b79de839223` |
| `research/biological-fact-check.md` | 16,070 | `5e1e827ed01df244240420c2b9e252c264d4429fc8699e9f49fd10193e62a1d6` |
| `research/contradictions.md` | 1,868 | `4d2a81f788f8e043ddabaddc2299b52a401060a5bb562281659aca290818264b` |
| `research/cultural-attribution-ledger.md` | 2,374 | `a935f5c29dcfbb464bbde77f059ee9e07b573c256c09c7f5798fd80c6069005c` |
| `research/open-questions.md` | 1,633 | `248fde07ad60ffa3bbebe9f0a6c27656669edff9472c3931adae717719c5851a` |
| `research/source-comparison-matrix.md` | 1,540 | `d10d92dbec2f54856530eda179f2ef60a50dd62ba77ab178a41603d2c9233fdb` |
| `research/source-ledger.md` | 4,838 | `9d188026fba65f8497ae8b1dca8b90e327de0a1a49c1864619d5ecc0524be2ae` |
| `templates/animal-card-template.md` | 1,203 | `48ac1d1003aabfb3e345484f3db367a95c2f219a5fdc8d2de96f62bc7bed1d0a` |

## Source-count interpretation

The **89** total counts unique external URLs cited anywhere in the collection, including 68 primary card-level institutional records, requested-reference bibliographic pages, methodology sources, and cultural/historical records. It does not imply that the unavailable commercial guidebooks were read in full; their limitation is explicit throughout the manual.
