# Integration Practices

## The field journal

Record the date, question, animal, first observation, relevant Gift, possible Wound, balance state, chosen action, and later outcome. Note whether a claim came from biology, a documented tradition, a modern author, or deck synthesis.

## Behavior before symbol

Study one verified behavior from the card's source. Write three columns:

1. what the animal actually does;
2. the human analogy the deck proposes; and
3. where the analogy stops being useful.

This protects both accuracy and imagination.

## Gift–Wound dialogue

Write one paragraph in the voice of the Gift and one in the voice of the Wound. Let each state what it protects, wants, and fears. Then write an integrating agreement that keeps the Gift without letting the Wound control the whole response.

## Environmental adjustment

Instead of asking only “How do I change myself?”, ask which habitat conditions are missing: time, safety, privacy, movement, rest, information, tools, companionship, challenge, or clear boundaries. Choose one ethical adjustment.

## Embodied practice

Use posture, pacing, attention, drawing, walking, humming, writing, or breath as a symbolic exploration without impersonating a culture or disturbing an animal. Keep it voluntary, secularizable, and easy to stop.

## Ecological reciprocity

Translate appreciation into a proportionate action: learn a local species' needs, reduce a relevant hazard, support a habitat organization, participate in responsible community science, or improve coexistence practices. Avoid performative claims of “honoring” an animal without material care.

## Closing: thought, word, action

- **Thought:** What new map will I hold lightly?
- **Word:** What will I name, ask, refuse, appreciate, or promise?
- **Action:** What observable step will I take, and when will I review it?

Continue to the [card guide](cards/README.md).
