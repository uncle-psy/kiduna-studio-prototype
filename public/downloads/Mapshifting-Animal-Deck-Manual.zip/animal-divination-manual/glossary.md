# Glossary

**Activity cycle** — When an animal is typically active: diurnal, nocturnal, crepuscular, cathemeral, seasonal, or variable.

**Agency** — Capacity to choose and act within real conditions; not total control over outcomes.

**Archetype** — A recurring symbolic role used by this deck, not a claim that one meaning is universal.

**Author-derived** — A labeled interpretation drawn from a named modern author whose relevant text was consulted.

**Balanced expression** — A Gift used with proportion, context, connection, and flexibility.

**Behavioral** — A symbolic inference anchored in documented animal behavior.

**Confidence** — Assessment of how securely the deck's claim is supported, not a judgment about a culture or animal.

**Cultural** — Attributed to a named living or historical culture/community rather than humanity in general.

**Deck synthesis** — An original interpretation created for this deck from labeled evidence and analogy.

**Divination** — Here, a structured reflective practice for noticing patterns and choices, not deterministic prediction.

**Elemental association** — Optional deck correspondence used as a reading aid; unless otherwise cited, it is not a traditional claim.

**Gift** — A capacity, strength, intelligence, sensitivity, instinct, or medicine available for cultivation.

**Historical** — Documented in a named historical text, object, period, or scholarly record.

**Living animal** — The biological species or defined animal group before symbolic interpretation.

**Overexpression** — A Gift used excessively or rigidly until it becomes costly or controlling.

**Provenance** — Traceable origin of a claim or interpretation.

**Reading** — A conditional exploration of a card in context.

**Reversal** — Optional inverted-card lens indicating overexpression, underexpression, blockage, privacy, or timing—not automatic negativity.

**Social pattern** — Typical relationship structure such as solitary, pair-bonded, fission–fusion, herd, flock, or eusocial colony.

**Underexpression** — Reduced or blocked access to a Gift.

**Uncertain** — Plausible but inadequately verified material that should not be stated as established.

**Wound** — Participant-revisable language for hurt, fear, defense, or imbalance; never a diagnosis.
