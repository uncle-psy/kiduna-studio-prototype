# Research Methodology

## Source order

Research follows this order:

1. requested modern interpretive references, when lawfully available;
2. authoritative zoology and natural history;
3. primary texts, scholarship, museums, and named culture/community sources;
4. clearly identified modern interpretive works; and
5. original deck synthesis.

The [source ledger](research/source-ledger.md) records what was actually available. A cited title is not treated as consulted merely because a bibliographic record exists.

## Card-development method

For each animal:

1. fix a taxonomic referent rather than relying only on a broad common name;
2. record habitat, range, activity, social pattern, diet/ecological role, survival strategies, and notable capacities;
3. identify one behaviorally anchored symbolic tension;
4. articulate Gifts and Wounds as two expressions of that tension;
5. distinguish balanced, overexpressed, and underexpressed forms;
6. write reading possibilities across ten life contexts;
7. design a wildlife-safe practice;
8. include only attributed cultural/historical claims;
9. label modern-author access limits; and
10. link the card to complementary, balancing, similar, and contrasting cards.

## Provenance labels

- `behavioral`: interpretation inferred from verified animal behavior.
- `historical`: association documented in a historical source.
- `cultural`: association attributed to a named living or historical culture.
- `author-derived`: interpretation drawn from a named modern author whose relevant text was consulted.
- `deck-synthesis`: original interpretation adopted by this deck.
- `uncertain`: plausible association not adequately verified.

Every card lists the labels that materially support it. Confidence applies to the synthesis as a whole, not to a culture's validity.

## Confidence

- **High:** the factual basis is directly supported and the interpretation makes a narrow, transparent inference.
- **Medium:** facts are supported but the symbolic synthesis spans several inferences or uses incomplete comparison material.
- **Low:** a claim remains speculative or inadequately sourced; low-confidence material belongs in research notes, not as established tradition.

## Citation practice

Biological statements cite institutional species accounts or reputable natural-history resources. Cultural rows cite a named text, museum object/essay, community, or author. Page numbers appear only where a consulted paginated source provides them. Web pages include direct links and were accessed 2026-08-23 unless otherwise stated.

## Originality

The manual uses no guidebook quotations. It does not recreate another deck's roster, suits, sequence, voice, card composition, or artwork. Product-level observations about existing decks are confined to the [comparison matrix](research/source-comparison-matrix.md).

Continue to [Cultural integrity](03-cultural-integrity.md).
