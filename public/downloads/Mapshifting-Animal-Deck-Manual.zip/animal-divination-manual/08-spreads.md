# Spreads

Every position is a question, not a verdict. Read card relationships—shared Gifts, opposed strategies, ecological links, and productive tension—before combining keywords.

## One-card encounter

1. **Encounter:** What living quality asks for attention now?

Read the card's Gift, Wound, and balance state. Close with thought, word, action.

## Gift and Wound

1. **Gift available:** What capacity can help?
2. **Wound asking care:** What defense or hurt may distort access?
3. **Integration:** What allows the same energy to become proportionate?

Card 3 mediates rather than defeats cards 1 or 2.

## Animal and environment

1. **Animal:** The quality or strategy present.
2. **Habitat:** Conditions that let it function.
3. **Pressure:** What disrupts or threatens those conditions.
4. **Adaptation:** A viable response that preserves integrity.

If Animal and Habitat conflict, ask whether the person is trying to thrive in an unsuitable environment.

## Past, present, emerging possibility

1. **Past:** A pattern or resource that shaped the situation.
2. **Present:** The condition requiring honest attention.
3. **Emerging possibility:** A path available if conditions and choices support it.

The third card is not a forecast; it is a conditional opening.

## Relationship mirror

1. **My position:** How I currently enter the relationship.
2. **Their/other position:** A hypothesis about the other side, to be checked through communication—not mind-reading.
3. **Shared field:** What affects both.
4. **Difference:** A strategy or need that should not be collapsed.
5. **Reciprocal action:** What can be offered or requested clearly.

When reading without the other person, rename position 2 “my perception of the other position.”

## Community or ecosystem

1. **Keystone capacity:** What stabilizes the group.
2. **Understory:** Quiet work or people receiving too little attention.
3. **Edge:** Where innovation or conflict is occurring.
4. **Resource flow:** What is shared, hoarded, depleted, or renewed.
5. **Disturbance:** A pressure the system must acknowledge.
6. **Regeneration:** What supports collective recovery.

Read the cards as an ecology: no single animal is the whole community.

## Crossroads or choice

1. **Choice:** What decision is actually being made.
2. **Path A Gift:** Capacity this path develops.
3. **Path A Cost:** Wound or tradeoff to tend.
4. **Path B Gift:** Capacity this path develops.
5. **Path B Cost:** Wound or tradeoff to tend.
6. **Present resource:** Information, relationship, authority, or support already available.
7. **Next reversible step:** A small action that creates evidence.

This spread compares conditions; it does not choose for the reader.

## Seven-position directional spread

1. **Left—Past:** What remains influential.
2. **Right—Future:** What seems likely or desired, held conditionally.
3. **Below—Done:** Work, commitment, or consequence already embodied.
4. **Above—Possibility:** Imagination, aspiration, or untested opening.
5. **Behind:** What supports, follows, or goes unseen.
6. **Ahead:** What asks direct engagement.
7. **Inside—Transformation:** The choice that changes the map from within the present.

Read opposite positions as axes, then let Inside integrate without erasing their tension.

## Integration and action

1. **What I know:** The clearest insight.
2. **What I feel:** An emotion or body signal to acknowledge, not diagnose.
3. **What I can influence:** The actionable field.
4. **Thought:** A framing to practice.
5. **Word:** A truth, boundary, request, or commitment to articulate.
6. **Action:** A specific next behavior.

Continue to [Integration practices](09-integration-practices.md).
