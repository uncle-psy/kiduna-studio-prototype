# Goal and Scope

## Goal

Create a coherent, auditable animal-divination manual that can serve as:

- a practical reading guide;
- a symbolic reference;
- a tool for self-inquiry;
- a compassionate language for Gifts and Wounds;
- a guide to balancing and applying animal qualities; and
- structured source material for later cards, software, databases, and artwork.

## Deliverable

This collection contains 68 complete card files, ten manual chapters, ten indexes, seven research/audit files, a reusable card template, glossary, bibliography, manifest, and changelog. Every file is Markdown. No card artwork or image placeholder is included.

## Boundaries

This deck does not:

- predict an inevitable future;
- diagnose mental or physical conditions;
- grant cultural, ceremonial, or spiritual authority;
- treat observed animal behavior as proof of a metaphysical claim;
- advise contact with wildlife;
- reproduce or imitate an existing guidebook; or
- conceal uncertainty in the research record.

## Completion level

The collection is a complete **research draft**: all required files and card sections are present, the roster is fully indexed, biological claims have identified institutional checks, and only a small, named set of cultural claims has been adopted. It is not a publication-ready critical edition because two requested commercial guidebooks were unavailable in full and specialist cultural review has not occurred. Those limits are enumerated rather than filled with invented content.

Return to the [README](README.md) or continue to [Philosophy](01-philosophy.md).
