# Card Index

| No. | Card | Scientific name | Group | Archetype | Confidence |
|---:|---|---|---|---|---|
| 1 | [Gray Wolf](../cards/001-gray-wolf.md) | *Canis lupus* | Mammal | coordinated belonging | medium |
| 2 | [African Lion](../cards/002-african-lion.md) | *Panthera leo* | Mammal | courageous presence | medium |
| 3 | [African Elephant](../cards/003-african-elephant.md) | *Loxodonta africana* | Mammal | intergenerational memory | medium |
| 4 | [Red Fox](../cards/004-red-fox.md) | *Vulpes vulpes* | Mammal | adaptive edge-walker | medium |
| 5 | [American Black Bear](../cards/005-american-black-bear.md) | *Ursus americanus* | Mammal | resourceful retreat | medium |
| 6 | [White-tailed Deer](../cards/006-white-tailed-deer.md) | *Odocoileus virginianus* | Mammal | sensitive responsiveness | medium |
| 7 | [American Bison](../cards/007-american-bison.md) | *Bison bison* | Mammal | grounded communal endurance | medium |
| 8 | [Domestic Horse](../cards/008-domestic-horse.md) | *Equus caballus* | Mammal | embodied partnership in motion | medium |
| 9 | [Domestic Dog](../cards/009-domestic-dog.md) | *Canis lupus familiaris* | Mammal | reciprocal trust | medium |
| 10 | [Domestic Cat](../cards/010-domestic-cat.md) | *Felis catus* | Mammal | self-possessed intimacy | medium |
| 11 | [North American Beaver](../cards/011-north-american-beaver.md) | *Castor canadensis* | Mammal | constructive systems work | medium |
| 12 | [North American River Otter](../cards/012-north-american-river-otter.md) | *Lontra canadensis* | Mammal | skillful play | medium |
| 13 | [Little Brown Bat](../cards/013-little-brown-bat.md) | *Myotis lucifugus* | Mammal | discernment in darkness | medium |
| 14 | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md) | *Tursiops truncatus* | Mammal | communicative cooperation | medium |
| 15 | [Humpback Whale](../cards/015-humpback-whale.md) | *Megaptera novaeangliae* | Mammal | long-range voice and return | medium |
| 16 | [Western Gorilla](../cards/016-western-gorilla.md) | *Gorilla gorilla* | Mammal | restrained protective strength | medium |
| 17 | [Red Kangaroo](../cards/017-red-kangaroo.md) | *Osphranter rufus* | Mammal | stored momentum | medium |
| 18 | [Platypus](../cards/018-platypus.md) | *Ornithorhynchus anatinus* | Mammal | integrative originality | medium |
| 19 | [Bald Eagle](../cards/019-bald-eagle.md) | *Haliaeetus leucocephalus* | Bird | wide perspective with accountable descent | medium |
| 20 | [Great Horned Owl](../cards/020-great-horned-owl.md) | *Bubo virginianus* | Bird | silent threshold discernment | medium |
| 21 | [Common Raven](../cards/021-common-raven.md) | *Corvus corax* | Bird | curious memory-maker | medium |
| 22 | [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) | *Buteo jamaicensis* | Bird | patient surveillance | medium |
| 23 | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md) | *Archilochus colubris* | Bird | precise energetic exchange | medium |
| 24 | [Emperor Penguin](../cards/024-emperor-penguin.md) | *Aptenodytes forsteri* | Bird | collective warmth under pressure | medium |
| 25 | [Sandhill Crane](../cards/025-sandhill-crane.md) | *Antigone canadensis* | Bird | attentive fidelity | medium |
| 26 | [Peregrine Falcon](../cards/026-peregrine-falcon.md) | *Falco peregrinus* | Bird | committed velocity | medium |
| 27 | [Laysan Albatross](../cards/027-laysan-albatross.md) | *Phoebastria immutabilis* | Bird | oceanic patience | medium |
| 28 | [Wild Turkey](../cards/028-wild-turkey.md) | *Meleagris gallopavo* | Bird | grounded abundance | medium |
| 29 | [Greater Flamingo](../cards/029-greater-flamingo.md) | *Phoenicopterus roseus* | Bird | selective filtering in company | medium |
| 30 | [Indian Peafowl](../cards/030-indian-peafowl.md) | *Pavo cristatus* | Bird | truthful display | medium |
| 31 | [Emu](../cards/031-emu.md) | *Dromaius novaehollandiae* | Bird | steady adaptive stride | medium |
| 32 | [Green Sea Turtle](../cards/032-green-sea-turtle.md) | *Chelonia mydas* | Reptile | patient navigation and return | medium |
| 33 | [King Cobra](../cards/033-king-cobra.md) | *Ophiophagus hannah* | Reptile | measured warning and power | medium |
| 34 | [American Alligator](../cards/034-american-alligator.md) | *Alligator mississippiensis* | Reptile | patient threshold defense | medium |
| 35 | [Panther Chameleon](../cards/035-panther-chameleon.md) | *Furcifer pardalis* | Reptile | contextual adaptation without disappearance | medium |
| 36 | [Komodo Dragon](../cards/036-komodo-dragon.md) | *Varanus komodoensis* | Reptile | formidable economy | medium |
| 37 | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) | *Gopherus agassizii* | Reptile | resource-paced endurance | medium |
| 38 | [Axolotl](../cards/038-axolotl.md) | *Ambystoma mexicanum* | Amphibian | regenerative openness | medium |
| 39 | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) | *Dendrobates tinctorius* | Amphibian | visible boundary | medium |
| 40 | [Tiger Salamander](../cards/040-tiger-salamander.md) | *Ambystoma tigrinum* | Amphibian | hidden metamorphosis | medium |
| 41 | [American Bullfrog](../cards/041-american-bullfrog.md) | *Lithobates catesbeianus* | Amphibian | amphibious voice | medium |
| 42 | [Great White Shark](../cards/042-great-white-shark.md) | *Carcharodon carcharias* | Fish | decisive sensory clarity | medium |
| 43 | [Atlantic Salmon](../cards/043-atlantic-salmon.md) | *Salmo salar* | Fish | return informed by place-memory | medium |
| 44 | [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md) | *Amphiprion ocellaris* | Fish | mutual belonging | medium |
| 45 | [Lined Seahorse](../cards/045-lined-seahorse.md) | *Hippocampus erectus* | Fish | receptive care | medium |
| 46 | [Electric Eel](../cards/046-electric-eel.md) | *Electrophorus electricus* | Fish | self-generated boundary and perception | medium |
| 47 | [Reef Manta Ray](../cards/047-reef-manta-ray.md) | *Mobula alfredi* | Fish | graceful scale | medium |
| 48 | [Spot-fin Porcupinefish](../cards/048-porcupinefish.md) | *Diodon hystrix* | Fish | adaptive deterrence | medium |
| 49 | [Banded Archerfish](../cards/049-banded-archerfish.md) | *Toxotes jaculatrix* | Fish | calibrated aim | medium |
| 50 | [Western Honey Bee](../cards/050-western-honey-bee.md) | *Apis mellifera* | Insect | distributed cooperation | medium |
| 51 | [Monarch Butterfly](../cards/051-monarch-butterfly.md) | *Danaus plexippus* | Insect | generational transformation | medium |
| 52 | [Common Green Darner](../cards/052-common-green-darner.md) | *Anax junius* | Insect | life-stage agility | medium |
| 53 | [Sacred Scarab](../cards/053-sacred-scarab.md) | *Scarabaeus sacer* | Insect | renewal through what is discarded | medium |
| 54 | [European Mantis](../cards/054-european-mantis.md) | *Mantis religiosa* | Insect | poised response | medium |
| 55 | [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) | *Photinus pyralis* | Insect | timely illumination | medium |
| 56 | [Leafcutter Ant](../cards/056-leafcutter-ant.md) | *Atta cephalotes* | Insect | cultivated infrastructure | medium |
| 57 | [Cross Orbweaver](../cards/057-cross-orbweaver.md) | *Araneus diadematus* | Arachnid | sensitive pattern-maker | medium |
| 58 | [Emperor Scorpion](../cards/058-emperor-scorpion.md) | *Pandinus imperator* | Arachnid | calibrated defense | medium |
| 59 | [Common Octopus](../cards/059-common-octopus.md) | *Octopus vulgaris* | Mollusk | flexible distributed intelligence | medium |
| 60 | [Chambered Nautilus](../cards/060-chambered-nautilus.md) | *Nautilus pompilius* | Mollusk | chambered continuity | medium |
| 61 | [Garden Snail](../cards/061-garden-snail.md) | *Cornu aspersum* | Mollusk | portable pacing | medium |
| 62 | [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) | *Coenobita clypeatus* | Crustacean | adaptive housing | medium |
| 63 | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) | *Odontodactylus scyllarus* | Crustacean | complex perception with rapid force | medium |
| 64 | [Moon Jelly](../cards/064-moon-jelly.md) | *Aurelia aurita* | Other marine invertebrate | rhythmic receptivity | medium |
| 65 | [Ochre Sea Star](../cards/065-ochre-sea-star.md) | *Pisaster ochraceus* | Other marine invertebrate | distributed keystone influence | medium |
| 66 | [Staghorn Coral](../cards/066-staghorn-coral.md) | *Acropora cervicornis* | Other marine invertebrate | collective habitat-making | medium |
| 67 | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) | *Apostichopus californicus* | Other marine invertebrate | quiet recycling | medium |
| 68 | [Common Earthworm](../cards/068-common-earthworm.md) | *Lumbricus terrestris* | Annelid | humble transformation | medium |
