# Wounds Index

| Wound | Cards |
|---|---|
| alienation | [Platypus](../cards/018-platypus.md) |
| aloofness | [Domestic Cat](../cards/010-domestic-cat.md) |
| ambush mindset | [American Alligator](../cards/034-american-alligator.md) |
| appeasement | [White-tailed Deer](../cards/006-white-tailed-deer.md) |
| approval-seeking display | [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) |
| arrested development | [Axolotl](../cards/038-axolotl.md) |
| avoidance | [Garden Snail](../cards/061-garden-snail.md) |
| avoidance of friction | [Reef Manta Ray](../cards/047-reef-manta-ray.md) |
| avoidance of landing | [Laysan Albatross](../cards/027-laysan-albatross.md) |
| avoidance through play | [North American River Otter](../cards/012-north-american-river-otter.md) |
| avoidant dormancy | [Tiger Salamander](../cards/040-tiger-salamander.md) |
| avoidant withdrawal | [American Black Bear](../cards/005-american-black-bear.md) |
| brittleness | [Staghorn Coral](../cards/066-staghorn-coral.md) |
| burden-bearing | [African Elephant](../cards/003-african-elephant.md) |
| burdened return | [Green Sea Turtle](../cards/032-green-sea-turtle.md) |
| burdened wandering | [Laysan Albatross](../cards/027-laysan-albatross.md) |
| buried emotion | [Common Earthworm](../cards/068-common-earthworm.md) |
| camouflage habit | [Panther Chameleon](../cards/035-panther-chameleon.md) |
| carrying too much | [Red Kangaroo](../cards/017-red-kangaroo.md) |
| chasing sweetness | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md) |
| chronic bracing | [Spot-fin Porcupinefish](../cards/048-porcupinefish.md) |
| chronic defensiveness | [Electric Eel](../cards/046-electric-eel.md) |
| clinging | [Ochre Sea Star](../cards/065-ochre-sea-star.md) |
| combative certainty | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) |
| comparison | [Indian Peafowl](../cards/030-indian-peafowl.md) |
| competitive vigilance | [Common Green Darner](../cards/052-common-green-darner.md) |
| complacency | [Wild Turkey](../cards/028-wild-turkey.md) |
| compulsive labor | [Sacred Scarab](../cards/053-sacred-scarab.md) |
| compulsive return | [Atlantic Salmon](../cards/043-atlantic-salmon.md) |
| conformity | [Gray Wolf](../cards/001-gray-wolf.md) |
| confusion through hybridity | [Platypus](../cards/018-platypus.md) |
| contrarian identity | [Platypus](../cards/018-platypus.md) |
| crowd dependence | [Greater Flamingo](../cards/029-greater-flamingo.md) |
| defensive collectivism | [Western Honey Bee](../cards/050-western-honey-bee.md) |
| defensive reactivity | [American Black Bear](../cards/005-american-black-bear.md) |
| defensiveness | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) |
| dependency | [Domestic Dog](../cards/009-domestic-dog.md), [Axolotl](../cards/038-axolotl.md), [Staghorn Coral](../cards/066-staghorn-coral.md) |
| depletion | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md), [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) |
| detachment from origins | [Common Green Darner](../cards/052-common-green-darner.md) |
| deterrence as identity | [Spot-fin Porcupinefish](../cards/048-porcupinefish.md) |
| diffuse boundaries | [Reef Manta Ray](../cards/047-reef-manta-ray.md) |
| disappearing into vastness | [Humpback Whale](../cards/015-humpback-whale.md) |
| distance from consequence | [Bald Eagle](../cards/019-bald-eagle.md) |
| dominance | [Komodo Dragon](../cards/036-komodo-dragon.md) |
| dominance rigidity | [Western Gorilla](../cards/016-western-gorilla.md) |
| domination | [African Lion](../cards/002-african-lion.md), [Great White Shark](../cards/042-great-white-shark.md) |
| drift | [Moon Jelly](../cards/064-moon-jelly.md) |
| emotional armoring | [American Alligator](../cards/034-american-alligator.md) |
| emotional detachment | [European Mantis](../cards/054-european-mantis.md) |
| emotional distance | [Emu](../cards/031-emu.md) |
| emotional flooding | [Humpback Whale](../cards/015-humpback-whale.md) |
| emotional freezing | [Emperor Penguin](../cards/024-emperor-penguin.md) |
| endless transition | [Monarch Butterfly](../cards/051-monarch-butterfly.md) |
| entanglement | [Cross Orbweaver](../cards/057-cross-orbweaver.md) |
| entitlement | [African Lion](../cards/002-african-lion.md) |
| evasion | [Common Octopus](../cards/059-common-octopus.md) |
| evasive habits | [Red Fox](../cards/004-red-fox.md) |
| excessive self-protection | [Garden Snail](../cards/061-garden-snail.md) |
| exclusion | [Gray Wolf](../cards/001-gray-wolf.md) |
| exhaustion | [Atlantic Salmon](../cards/043-atlantic-salmon.md) |
| explosive force | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) |
| false purity | [Sacred Scarab](../cards/053-sacred-scarab.md) |
| fear of change | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) |
| fear of separation | [Sandhill Crane](../cards/025-sandhill-crane.md) |
| fear of the unknown | [Little Brown Bat](../cards/013-little-brown-bat.md) |
| fear projection | [Great White Shark](../cards/042-great-white-shark.md) |
| fear-driven inflation | [Spot-fin Porcupinefish](../cards/048-porcupinefish.md) |
| fleeting focus | [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) |
| flight from necessary conflict | [White-tailed Deer](../cards/006-white-tailed-deer.md) |
| force without direction | [Domestic Horse](../cards/008-domestic-horse.md) |
| fragility | [Lined Seahorse](../cards/045-lined-seahorse.md) |
| fragility idealization | [Monarch Butterfly](../cards/051-monarch-butterfly.md) |
| fragility outside the niche | [Axolotl](../cards/038-axolotl.md) |
| fragmentation | [Ochre Sea Star](../cards/065-ochre-sea-star.md), [Common Earthworm](../cards/068-common-earthworm.md) |
| grief fixation | [African Elephant](../cards/003-african-elephant.md) |
| group panic | [Wild Turkey](../cards/028-wild-turkey.md) |
| group pressure | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md) |
| guardedness | [Emperor Scorpion](../cards/058-emperor-scorpion.md) |
| guarding anxiety | [Domestic Dog](../cards/009-domestic-dog.md) |
| herd conformity | [American Bison](../cards/007-american-bison.md) |
| hidden vulnerability | [Emperor Scorpion](../cards/058-emperor-scorpion.md) |
| hiding | [Little Brown Bat](../cards/013-little-brown-bat.md) |
| hypervigilance | [Gray Wolf](../cards/001-gray-wolf.md), [White-tailed Deer](../cards/006-white-tailed-deer.md) |
| idealization | [Sandhill Crane](../cards/025-sandhill-crane.md) |
| identity bound to origin | [Atlantic Salmon](../cards/043-atlantic-salmon.md) |
| identity confined to one system | [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md) |
| identity shifting | [Common Octopus](../cards/059-common-octopus.md) |
| impact without pause | [Peregrine Falcon](../cards/026-peregrine-falcon.md) |
| impulsive leaps | [Red Kangaroo](../cards/017-red-kangaroo.md) |
| impulsiveness | [North American River Otter](../cards/012-north-american-river-otter.md) |
| inability to retreat | [Red Kangaroo](../cards/017-red-kangaroo.md) |
| indecision | [Panther Chameleon](../cards/035-panther-chameleon.md) |
| inertia | [Garden Snail](../cards/061-garden-snail.md) |
| inflexibility | [Emu](../cards/031-emu.md) |
| insecure borrowing | [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) |
| instrumental thinking | [Banded Archerfish](../cards/049-banded-archerfish.md) |
| intellectual detachment | [Common Raven](../cards/021-common-raven.md) |
| intimidation | [Western Gorilla](../cards/016-western-gorilla.md), [King Cobra](../cards/033-king-cobra.md), [Komodo Dragon](../cards/036-komodo-dragon.md) |
| invasiveness | [American Bullfrog](../cards/041-american-bullfrog.md) |
| invisibility | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) |
| isolation | [Great Horned Owl](../cards/020-great-horned-owl.md), [Laysan Albatross](../cards/027-laysan-albatross.md), [King Cobra](../cards/033-king-cobra.md), [Electric Eel](../cards/046-electric-eel.md), [Common Octopus](../cards/059-common-octopus.md) |
| loss of roots | [Monarch Butterfly](../cards/051-monarch-butterfly.md) |
| loudness without listening | [American Bullfrog](../cards/041-american-bullfrog.md) |
| masking insecurity | [Indian Peafowl](../cards/030-indian-peafowl.md) |
| mistrust | [Red Fox](../cards/004-red-fox.md) |
| morbid fixation | [Common Raven](../cards/021-common-raven.md) |
| nostalgia | [Humpback Whale](../cards/015-humpback-whale.md) |
| opportunistic aggression | [Komodo Dragon](../cards/036-komodo-dragon.md) |
| overattachment | [Lined Seahorse](../cards/045-lined-seahorse.md) |
| overcalculation | [Banded Archerfish](../cards/049-banded-archerfish.md) |
| overconsumption | [American Black Bear](../cards/005-american-black-bear.md) |
| overcontainment | [Chambered Nautilus](../cards/060-chambered-nautilus.md) |
| overdependence | [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md) |
| overdisplay | [Wild Turkey](../cards/028-wild-turkey.md) |
| overengineering | [North American Beaver](../cards/011-north-american-beaver.md) |
| overmonitoring | [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) |
| overprotection | [African Elephant](../cards/003-african-elephant.md) |
| overstimulation | [Domestic Cat](../cards/010-domestic-cat.md) |
| overwork | [Western Honey Bee](../cards/050-western-honey-bee.md) |
| passivity | [Lined Seahorse](../cards/045-lined-seahorse.md), [Moon Jelly](../cards/064-moon-jelly.md) |
| people-pleasing | [Domestic Dog](../cards/009-domestic-dog.md) |
| perfectionism | [Peregrine Falcon](../cards/026-peregrine-falcon.md), [Cross Orbweaver](../cards/057-cross-orbweaver.md) |
| performance | [Sandhill Crane](../cards/025-sandhill-crane.md) |
| performative belonging | [Greater Flamingo](../cards/029-greater-flamingo.md) |
| porous boundaries | [Moon Jelly](../cards/064-moon-jelly.md) |
| possessiveness | [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) |
| predatory certainty | [Great Horned Owl](../cards/020-great-horned-owl.md) |
| predatory entitlement | [Domestic Cat](../cards/010-domestic-cat.md) |
| predatory patience | [European Mantis](../cards/054-european-mantis.md) |
| premature attack | [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) |
| recklessness | [Peregrine Falcon](../cards/026-peregrine-falcon.md) |
| recycling the past without change | [Sacred Scarab](../cards/053-sacred-scarab.md) |
| reductionism | [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) |
| relentless extraction | [Leafcutter Ant](../cards/056-leafcutter-ant.md) |
| relentless pacing | [Emu](../cards/031-emu.md) |
| relentless pursuit | [Great White Shark](../cards/042-great-white-shark.md) |
| restless motion | [Common Green Darner](../cards/052-common-green-darner.md) |
| restlessness | [Domestic Horse](../cards/008-domestic-horse.md) |
| retaliatory posture | [Emperor Scorpion](../cards/058-emperor-scorpion.md) |
| retreat | [Green Sea Turtle](../cards/032-green-sea-turtle.md) |
| retreat into former rooms | [Chambered Nautilus](../cards/060-chambered-nautilus.md) |
| rigid duty | [Emperor Penguin](../cards/024-emperor-penguin.md) |
| rigid hierarchy | [Leafcutter Ant](../cards/056-leafcutter-ant.md) |
| rigidity | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) |
| role confinement | [Western Honey Bee](../cards/050-western-honey-bee.md) |
| scarcity fear | [American Bison](../cards/007-american-bison.md) |
| scattered attention | [North American River Otter](../cards/012-north-american-river-otter.md) |
| secrecy | [Great Horned Owl](../cards/020-great-horned-owl.md), [Tiger Salamander](../cards/040-tiger-salamander.md) |
| self-emptying | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) |
| self-erasure | [Panther Chameleon](../cards/035-panther-chameleon.md) |
| self-erasure in labor | [Leafcutter Ant](../cards/056-leafcutter-ant.md) |
| self-neglect | [Common Earthworm](../cards/068-common-earthworm.md) |
| self-sacrifice | [Emperor Penguin](../cards/024-emperor-penguin.md) |
| self-serving opportunism | [Red Fox](../cards/004-red-fox.md) |
| sensory overload | [Little Brown Bat](../cards/013-little-brown-bat.md) |
| sensory overwhelm | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) |
| serial escape | [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) |
| servitude | [Domestic Horse](../cards/008-domestic-horse.md) |
| shock tactics | [Electric Eel](../cards/046-electric-eel.md) |
| silent collapse | [Staghorn Coral](../cards/066-staghorn-coral.md) |
| slow adaptation | [Chambered Nautilus](../cards/060-chambered-nautilus.md) |
| slow response | [Green Sea Turtle](../cards/032-green-sea-turtle.md) |
| social manipulation | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md) |
| stalled transformation | [Tiger Salamander](../cards/040-tiger-salamander.md) |
| status fixation | [African Lion](../cards/002-african-lion.md), [Bald Eagle](../cards/019-bald-eagle.md) |
| stimulation seeking | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md) |
| stubbornness | [American Bison](../cards/007-american-bison.md) |
| superiority | [Bald Eagle](../cards/019-bald-eagle.md) |
| suppressed anger | [King Cobra](../cards/033-king-cobra.md) |
| suppressed vulnerability | [Western Gorilla](../cards/016-western-gorilla.md) |
| surface emphasis | [Greater Flamingo](../cards/029-greater-flamingo.md) |
| taking too much space | [American Bullfrog](../cards/041-american-bullfrog.md) |
| target fixation | [Banded Archerfish](../cards/049-banded-archerfish.md) |
| territorial aggression | [American Alligator](../cards/034-american-alligator.md) |
| territorial control | [North American Beaver](../cards/011-north-american-beaver.md) |
| territorial irritability | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md) |
| territoriality | [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md) |
| toxic reciprocity | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) |
| trickery | [Common Raven](../cards/021-common-raven.md) |
| underestimating indirect power | [Ochre Sea Star](../cards/065-ochre-sea-star.md) |
| vanity | [Indian Peafowl](../cards/030-indian-peafowl.md) |
| visibility risk | [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) |
| vulnerability to exploitation | [Reef Manta Ray](../cards/047-reef-manta-ray.md) |
| waiting for life | [Cross Orbweaver](../cards/057-cross-orbweaver.md) |
| waiting too long | [European Mantis](../cards/054-european-mantis.md) |
| warning as identity | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) |
| withdrawal | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) |
| work compulsion | [North American Beaver](../cards/011-north-american-beaver.md) |
