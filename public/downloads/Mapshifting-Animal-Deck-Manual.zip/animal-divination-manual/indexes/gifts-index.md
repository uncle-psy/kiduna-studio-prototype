# Gifts Index

| Gift | Cards |
|---|---|
| adaptability | [Red Fox](../cards/004-red-fox.md) |
| adaptive defense | [Spot-fin Porcupinefish](../cards/048-porcupinefish.md) |
| adaptive expression | [Common Octopus](../cards/059-common-octopus.md) |
| adaptive role change | [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md) |
| adaptive shelter | [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) |
| aerial agility | [Common Green Darner](../cards/052-common-green-darner.md) |
| affectionate boundaries | [Domestic Cat](../cards/010-domestic-cat.md) |
| aim | [Banded Archerfish](../cards/049-banded-archerfish.md) |
| ancient rhythm | [Green Sea Turtle](../cards/032-green-sea-turtle.md) |
| apex responsibility | [Great White Shark](../cards/042-great-white-shark.md) |
| attunement | [Domestic Dog](../cards/009-domestic-dog.md) |
| authentic attraction | [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) |
| beauty | [Indian Peafowl](../cards/030-indian-peafowl.md) |
| boundary navigation | [Red Fox](../cards/004-red-fox.md) |
| boundary power | [American Black Bear](../cards/005-american-black-bear.md) |
| boundary signaling | [Electric Eel](../cards/046-electric-eel.md) |
| boundary-crossing | [Platypus](../cards/018-platypus.md) |
| buoyancy regulation | [Chambered Nautilus](../cards/060-chambered-nautilus.md) |
| burrow defense | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) |
| calibrated defense | [Emperor Scorpion](../cards/058-emperor-scorpion.md) |
| ceremonial attention | [Sandhill Crane](../cards/025-sandhill-crane.md) |
| clear boundaries | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) |
| clear warning | [King Cobra](../cards/033-king-cobra.md) |
| climate adaptation | [Emu](../cards/031-emu.md) |
| collective building | [Staghorn Coral](../cards/066-staghorn-coral.md) |
| collective warmth | [Emperor Penguin](../cards/024-emperor-penguin.md) |
| commitment | [Peregrine Falcon](../cards/026-peregrine-falcon.md) |
| commitment to journey | [Laysan Albatross](../cards/027-laysan-albatross.md) |
| communal endurance | [American Bison](../cards/007-american-bison.md) |
| communal shelter | [Little Brown Bat](../cards/013-little-brown-bat.md) |
| communal visibility | [Greater Flamingo](../cards/029-greater-flamingo.md) |
| communication | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md), [Western Honey Bee](../cards/050-western-honey-bee.md) |
| complex perception | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) |
| conservation | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) |
| context awareness | [Panther Chameleon](../cards/035-panther-chameleon.md) |
| continuity | [Chambered Nautilus](../cards/060-chambered-nautilus.md) |
| cooperation | [Western Honey Bee](../cards/050-western-honey-bee.md) |
| cooperative defense | [African Lion](../cards/002-african-lion.md) |
| cooperative intelligence | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md) |
| coordination | [Gray Wolf](../cards/001-gray-wolf.md) |
| courage | [African Lion](../cards/002-african-lion.md) |
| cultivation | [Leafcutter Ant](../cards/056-leafcutter-ant.md) |
| curiosity | [Common Raven](../cards/021-common-raven.md), [Reef Manta Ray](../cards/047-reef-manta-ray.md) |
| decisive focus | [Bald Eagle](../cards/019-bald-eagle.md) |
| decisive movement | [Great White Shark](../cards/042-great-white-shark.md) |
| deliberate adjustment | [Panther Chameleon](../cards/035-panther-chameleon.md) |
| depth-to-surface integration | [Humpback Whale](../cards/015-humpback-whale.md) |
| dexterity | [North American River Otter](../cards/012-north-american-river-otter.md) |
| direct focus | [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) |
| discernment | [Greater Flamingo](../cards/029-greater-flamingo.md) |
| distance judgment | [Banded Archerfish](../cards/049-banded-archerfish.md) |
| distributed sensing | [Ochre Sea Star](../cards/065-ochre-sea-star.md) |
| distributed work | [Leafcutter Ant](../cards/056-leafcutter-ant.md) |
| durable boundaries | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) |
| dynamic balance | [Greater Flamingo](../cards/029-greater-flamingo.md) |
| echolocating discernment | [Little Brown Bat](../cards/013-little-brown-bat.md) |
| effortless range | [Laysan Albatross](../cards/027-laysan-albatross.md) |
| electrical sensing | [Electric Eel](../cards/046-electric-eel.md) |
| electrosensory intuition | [Platypus](../cards/018-platypus.md) |
| embodied attention | [European Mantis](../cards/054-european-mantis.md) |
| embodied power | [Domestic Horse](../cards/008-domestic-horse.md) |
| endurance | [Gray Wolf](../cards/001-gray-wolf.md), [Emperor Penguin](../cards/024-emperor-penguin.md) |
| energy reserve | [Red Kangaroo](../cards/017-red-kangaroo.md) |
| environmental sensitivity | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) |
| escape skill | [Common Octopus](../cards/059-common-octopus.md) |
| expressive confidence | [Indian Peafowl](../cards/030-indian-peafowl.md) |
| fidelity | [Sandhill Crane](../cards/025-sandhill-crane.md) |
| flexible intelligence | [Common Octopus](../cards/059-common-octopus.md) |
| flow | [Reef Manta Ray](../cards/047-reef-manta-ray.md) |
| focused protection | [King Cobra](../cards/033-king-cobra.md) |
| formidable presence | [Komodo Dragon](../cards/036-komodo-dragon.md) |
| forward momentum | [Red Kangaroo](../cards/017-red-kangaroo.md) |
| generational continuity | [Monarch Butterfly](../cards/051-monarch-butterfly.md) |
| gentle alertness | [White-tailed Deer](../cards/006-white-tailed-deer.md) |
| gentle persistence | [Lined Seahorse](../cards/045-lined-seahorse.md) |
| grace | [Reef Manta Ray](../cards/047-reef-manta-ray.md) |
| grounded abundance | [Wild Turkey](../cards/028-wild-turkey.md) |
| grounded provision | [American Bison](../cards/007-american-bison.md) |
| habitat generation | [Staghorn Coral](../cards/066-staghorn-coral.md) |
| habitat stewardship | [North American Beaver](../cards/011-north-american-beaver.md) |
| hidden resilience | [Spot-fin Porcupinefish](../cards/048-porcupinefish.md) |
| home defense | [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md) |
| honest display | [Wild Turkey](../cards/028-wild-turkey.md) |
| humble transformation | [Common Earthworm](../cards/068-common-earthworm.md) |
| infrastructure | [Leafcutter Ant](../cards/056-leafcutter-ant.md) |
| integrative originality | [Platypus](../cards/018-platypus.md) |
| intergenerational care | [African Elephant](../cards/003-african-elephant.md) |
| internal power | [Electric Eel](../cards/046-electric-eel.md) |
| joy | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md) |
| keystone influence | [Ochre Sea Star](../cards/065-ochre-sea-star.md) |
| kin care | [Western Gorilla](../cards/016-western-gorilla.md) |
| layered growth | [Chambered Nautilus](../cards/060-chambered-nautilus.md) |
| learning | [Banded Archerfish](../cards/049-banded-archerfish.md) |
| life-stage transformation | [Common Green Darner](../cards/052-common-green-darner.md) |
| long-distance return | [Sandhill Crane](../cards/025-sandhill-crane.md) |
| long-range expression | [Humpback Whale](../cards/015-humpback-whale.md) |
| low-profile service | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) |
| loyalty | [Domestic Dog](../cards/009-domestic-dog.md) |
| maternal protection | [Emperor Scorpion](../cards/058-emperor-scorpion.md) |
| measured pacing | [Garden Snail](../cards/061-garden-snail.md) |
| measured power | [King Cobra](../cards/033-king-cobra.md) |
| memory | [African Elephant](../cards/003-african-elephant.md), [Common Raven](../cards/021-common-raven.md) |
| metabolic economy | [Komodo Dragon](../cards/036-komodo-dragon.md) |
| metamorphic capacity | [Tiger Salamander](../cards/040-tiger-salamander.md) |
| mid-course recalibration | [Peregrine Falcon](../cards/026-peregrine-falcon.md) |
| migration | [Humpback Whale](../cards/015-humpback-whale.md), [Monarch Butterfly](../cards/051-monarch-butterfly.md) |
| modest illumination | [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) |
| movement | [Domestic Horse](../cards/008-domestic-horse.md) |
| multi-directional perception | [Panther Chameleon](../cards/035-panther-chameleon.md) |
| mutualism | [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md) |
| navigation | [Green Sea Turtle](../cards/032-green-sea-turtle.md) |
| navigation of uncertainty | [Little Brown Bat](../cards/013-little-brown-bat.md) |
| niche adaptation | [Axolotl](../cards/038-axolotl.md) |
| nocturnal discernment | [Great Horned Owl](../cards/020-great-horned-owl.md) |
| nocturnal resilience | [Emperor Scorpion](../cards/058-emperor-scorpion.md) |
| obstacle sense | [African Elephant](../cards/003-african-elephant.md) |
| opportunistic intelligence | [Red Fox](../cards/004-red-fox.md) |
| orientation | [Sacred Scarab](../cards/053-sacred-scarab.md) |
| partnership | [Domestic Horse](../cards/008-domestic-horse.md) |
| paternal care | [Emu](../cards/031-emu.md) |
| patience | [American Alligator](../cards/034-american-alligator.md) |
| patient contact | [Garden Snail](../cards/061-garden-snail.md) |
| patient observation | [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) |
| patient return | [Laysan Albatross](../cards/027-laysan-albatross.md), [Green Sea Turtle](../cards/032-green-sea-turtle.md) |
| pattern construction | [Cross Orbweaver](../cards/057-cross-orbweaver.md) |
| persistence | [North American Beaver](../cards/011-north-american-beaver.md), [Atlantic Salmon](../cards/043-atlantic-salmon.md), [Sacred Scarab](../cards/053-sacred-scarab.md) |
| place-memory | [Atlantic Salmon](../cards/043-atlantic-salmon.md) |
| play | [North American River Otter](../cards/012-north-american-river-otter.md), [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md) |
| pollination | [Western Honey Bee](../cards/050-western-honey-bee.md) |
| portable refuge | [Garden Snail](../cards/061-garden-snail.md) |
| precise response | [European Mantis](../cards/054-european-mantis.md) |
| precision | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md) |
| protective leadership | [Western Gorilla](../cards/016-western-gorilla.md) |
| protective nurture | [Red Kangaroo](../cards/017-red-kangaroo.md) |
| quiet strength | [Western Gorilla](../cards/016-western-gorilla.md) |
| rapid commitment | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) |
| receptive care | [Lined Seahorse](../cards/045-lined-seahorse.md) |
| receptivity | [Moon Jelly](../cards/064-moon-jelly.md) |
| reciprocal exchange | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md) |
| reciprocity | [Domestic Dog](../cards/009-domestic-dog.md) |
| recycling | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) |
| regeneration | [Axolotl](../cards/038-axolotl.md), [Ochre Sea Star](../cards/065-ochre-sea-star.md) |
| renewal | [Indian Peafowl](../cards/030-indian-peafowl.md), [Tiger Salamander](../cards/040-tiger-salamander.md), [Sacred Scarab](../cards/053-sacred-scarab.md) |
| repair | [Cross Orbweaver](../cards/057-cross-orbweaver.md) |
| resource pacing | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) |
| resource reuse | [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) |
| resourcefulness | [American Black Bear](../cards/005-american-black-bear.md) |
| responsive movement | [White-tailed Deer](../cards/006-white-tailed-deer.md) |
| rest and timing | [African Lion](../cards/002-african-lion.md) |
| restorative withdrawal | [American Black Bear](../cards/005-american-black-bear.md) |
| retained openness | [Axolotl](../cards/038-axolotl.md) |
| return | [Atlantic Salmon](../cards/043-atlantic-salmon.md) |
| rhythmic flow | [Moon Jelly](../cards/064-moon-jelly.md) |
| role flexibility | [Lined Seahorse](../cards/045-lined-seahorse.md) |
| seasonal emergence | [Tiger Salamander](../cards/040-tiger-salamander.md) |
| self-possession | [Domestic Cat](../cards/010-domestic-cat.md) |
| sensitivity | [White-tailed Deer](../cards/006-white-tailed-deer.md), [Common Earthworm](../cards/068-common-earthworm.md) |
| sensory clarity | [Great White Shark](../cards/042-great-white-shark.md) |
| sensory discernment | [Domestic Cat](../cards/010-domestic-cat.md) |
| shared care | [Emperor Penguin](../cards/024-emperor-penguin.md) |
| silent focus | [Great Horned Owl](../cards/020-great-horned-owl.md) |
| small-scale potency | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) |
| social awareness | [Wild Turkey](../cards/028-wild-turkey.md) |
| social ease | [North American River Otter](../cards/012-north-american-river-otter.md) |
| social intelligence | [Gray Wolf](../cards/001-gray-wolf.md) |
| social learning | [Common Raven](../cards/021-common-raven.md) |
| soil renewal | [Common Earthworm](../cards/068-common-earthworm.md) |
| speed | [Peregrine Falcon](../cards/026-peregrine-falcon.md) |
| steady movement | [Emu](../cards/031-emu.md) |
| stewardship | [Bald Eagle](../cards/019-bald-eagle.md) |
| stillness | [European Mantis](../cards/054-european-mantis.md) |
| strategic patience | [Komodo Dragon](../cards/036-komodo-dragon.md) |
| substrate renewal | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) |
| survival memory | [American Alligator](../cards/034-american-alligator.md) |
| symbiosis | [Staghorn Coral](../cards/066-staghorn-coral.md) |
| systems building | [North American Beaver](../cards/011-north-american-beaver.md) |
| territorial clarity | [Common Green Darner](../cards/052-common-green-darner.md) |
| territorial confidence | [American Bullfrog](../cards/041-american-bullfrog.md) |
| threshold awareness | [Great Horned Owl](../cards/020-great-horned-owl.md) |
| threshold defense | [American Alligator](../cards/034-american-alligator.md) |
| timely expansion | [Spot-fin Porcupinefish](../cards/048-porcupinefish.md) |
| timely signal | [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) |
| timing | [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) |
| transformation | [Monarch Butterfly](../cards/051-monarch-butterfly.md) |
| transition | [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) |
| transition between elements | [American Bullfrog](../cards/041-american-bullfrog.md) |
| transparency | [Moon Jelly](../cards/064-moon-jelly.md) |
| vibrational sensitivity | [Cross Orbweaver](../cards/057-cross-orbweaver.md) |
| vocal presence | [American Bullfrog](../cards/041-american-bullfrog.md) |
| weather-facing resilience | [American Bison](../cards/007-american-bison.md) |
| wide perspective | [Bald Eagle](../cards/019-bald-eagle.md) |
