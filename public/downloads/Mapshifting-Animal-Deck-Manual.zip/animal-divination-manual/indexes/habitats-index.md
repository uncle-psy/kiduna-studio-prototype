# Habitats Index

| Habitat | Cards |
|---|---|
| Antarctic sea ice | [Emperor Penguin](../cards/024-emperor-penguin.md) |
| North Atlantic ocean | [Atlantic Salmon](../cards/043-atlantic-salmon.md) |
| Southern Ocean | [Emperor Penguin](../cards/024-emperor-penguin.md) |
| agricultural landscape | [Western Honey Bee](../cards/050-western-honey-bee.md) |
| agricultural mosaic | [King Cobra](../cards/033-king-cobra.md), [Leafcutter Ant](../cards/056-leafcutter-ant.md) |
| alluvial fan | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) |
| arid grassland | [Red Kangaroo](../cards/017-red-kangaroo.md) |
| bamboo | [King Cobra](../cards/033-king-cobra.md) |
| bay | [Moon Jelly](../cards/064-moon-jelly.md) |
| bays | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md) |
| brackish river | [Banded Archerfish](../cards/049-banded-archerfish.md) |
| burrow | [Tiger Salamander](../cards/040-tiger-salamander.md), [Emperor Scorpion](../cards/058-emperor-scorpion.md) |
| cave | [Little Brown Bat](../cards/013-little-brown-bat.md) |
| city | [Peregrine Falcon](../cards/026-peregrine-falcon.md) |
| cleaning station | [Reef Manta Ray](../cards/047-reef-manta-ray.md) |
| cliff | [Peregrine Falcon](../cards/026-peregrine-falcon.md) |
| coast | [Bald Eagle](../cards/019-bald-eagle.md), [Common Raven](../cards/021-common-raven.md), [Peregrine Falcon](../cards/026-peregrine-falcon.md), [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) |
| coastal feeding grounds | [Humpback Whale](../cards/015-humpback-whale.md) |
| coastal ocean | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md), [Green Sea Turtle](../cards/032-green-sea-turtle.md), [Great White Shark](../cards/042-great-white-shark.md), [Reef Manta Ray](../cards/047-reef-manta-ray.md), [Spot-fin Porcupinefish](../cards/048-porcupinefish.md), [Common Octopus](../cards/059-common-octopus.md), [Moon Jelly](../cards/064-moon-jelly.md) |
| coastal reef | [Lined Seahorse](../cards/045-lined-seahorse.md) |
| coastal scrub | [Komodo Dragon](../cards/036-komodo-dragon.md) |
| coasts | [North American River Otter](../cards/012-north-american-river-otter.md) |
| continental shelf | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md), [Great White Shark](../cards/042-great-white-shark.md) |
| coral reef | [Green Sea Turtle](../cards/032-green-sea-turtle.md), [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md), [Reef Manta Ray](../cards/047-reef-manta-ray.md), [Spot-fin Porcupinefish](../cards/048-porcupinefish.md) |
| coral rubble | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) |
| deep coral slope | [Chambered Nautilus](../cards/060-chambered-nautilus.md) |
| desert | [Great Horned Owl](../cards/020-great-horned-owl.md), [Common Raven](../cards/021-common-raven.md), [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) |
| desert plain | [Red Kangaroo](../cards/017-red-kangaroo.md) |
| desert scrub | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) |
| dry forest | [Komodo Dragon](../cards/036-komodo-dragon.md) |
| dry forest near sea | [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) |
| dry open country | [Sacred Scarab](../cards/053-sacred-scarab.md) |
| dung-rich grassland | [Sacred Scarab](../cards/053-sacred-scarab.md) |
| estuaries | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md) |
| estuary | [Greater Flamingo](../cards/029-greater-flamingo.md), [Atlantic Salmon](../cards/043-atlantic-salmon.md), [Lined Seahorse](../cards/045-lined-seahorse.md), [Banded Archerfish](../cards/049-banded-archerfish.md), [Moon Jelly](../cards/064-moon-jelly.md) |
| farmland | [Red Fox](../cards/004-red-fox.md), [Indian Peafowl](../cards/030-indian-peafowl.md) |
| farms | [Domestic Cat](../cards/010-domestic-cat.md) |
| feral landscapes | [Domestic Cat](../cards/010-domestic-cat.md) |
| floodplain | [Electric Eel](../cards/046-electric-eel.md) |
| flowering habitat | [Western Honey Bee](../cards/050-western-honey-bee.md) |
| forest | [Gray Wolf](../cards/001-gray-wolf.md), [American Black Bear](../cards/005-american-black-bear.md), [Little Brown Bat](../cards/013-little-brown-bat.md), [Great Horned Owl](../cards/020-great-horned-owl.md), [Wild Turkey](../cards/028-wild-turkey.md), [King Cobra](../cards/033-king-cobra.md) |
| forest edge | [African Elephant](../cards/003-african-elephant.md), [Red Fox](../cards/004-red-fox.md), [White-tailed Deer](../cards/006-white-tailed-deer.md), [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md), [Indian Peafowl](../cards/030-indian-peafowl.md), [Leafcutter Ant](../cards/056-leafcutter-ant.md) |
| forest litter | [Common Earthworm](../cards/068-common-earthworm.md) |
| forest overwintering site | [Monarch Butterfly](../cards/051-monarch-butterfly.md) |
| freshwater canal | [Axolotl](../cards/038-axolotl.md) |
| freshwater river | [Platypus](../cards/018-platypus.md) |
| garden | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md), [Monarch Butterfly](../cards/051-monarch-butterfly.md), [Common Eastern Firefly](../cards/055-common-eastern-firefly.md), [Cross Orbweaver](../cards/057-cross-orbweaver.md), [Garden Snail](../cards/061-garden-snail.md), [Common Earthworm](../cards/068-common-earthworm.md) |
| garden edge | [European Mantis](../cards/054-european-mantis.md) |
| grassland | [Gray Wolf](../cards/001-gray-wolf.md), [African Lion](../cards/002-african-lion.md), [Red Fox](../cards/004-red-fox.md), [White-tailed Deer](../cards/006-white-tailed-deer.md), [American Bison](../cards/007-american-bison.md), [Red-tailed Hawk](../cards/022-red-tailed-hawk.md), [Emu](../cards/031-emu.md), [Tiger Salamander](../cards/040-tiger-salamander.md), [Monarch Butterfly](../cards/051-monarch-butterfly.md), [European Mantis](../cards/054-european-mantis.md), [Cross Orbweaver](../cards/057-cross-orbweaver.md), [Garden Snail](../cards/061-garden-snail.md), [Common Earthworm](../cards/068-common-earthworm.md) |
| grassland mosaic | [Wild Turkey](../cards/028-wild-turkey.md) |
| homes | [Domestic Dog](../cards/009-domestic-dog.md), [Domestic Cat](../cards/010-domestic-cat.md) |
| human edge | [Common Raven](../cards/021-common-raven.md) |
| human settlements | [Domestic Dog](../cards/009-domestic-dog.md) |
| human structures | [Little Brown Bat](../cards/013-little-brown-bat.md) |
| human-altered vegetation | [Panther Chameleon](../cards/035-panther-chameleon.md) |
| kelp forest | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) |
| lake | [Bald Eagle](../cards/019-bald-eagle.md), [American Alligator](../cards/034-american-alligator.md) |
| lake edge | [American Bullfrog](../cards/041-american-bullfrog.md), [Common Green Darner](../cards/052-common-green-darner.md) |
| lake remnant | [Axolotl](../cards/038-axolotl.md) |
| lakes | [North American River Otter](../cards/012-north-american-river-otter.md) |
| leaf litter | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) |
| managed hive | [Western Honey Bee](../cards/050-western-honey-bee.md) |
| mangrove | [Lined Seahorse](../cards/045-lined-seahorse.md), [Banded Archerfish](../cards/049-banded-archerfish.md), [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) |
| marsh | [Sandhill Crane](../cards/025-sandhill-crane.md), [American Alligator](../cards/034-american-alligator.md), [American Bullfrog](../cards/041-american-bullfrog.md), [Common Green Darner](../cards/052-common-green-darner.md) |
| meadow | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md), [Monarch Butterfly](../cards/051-monarch-butterfly.md), [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) |
| moist field | [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) |
| mountain | [Gray Wolf](../cards/001-gray-wolf.md), [American Black Bear](../cards/005-american-black-bear.md), [Common Raven](../cards/021-common-raven.md) |
| mudflat | [Greater Flamingo](../cards/029-greater-flamingo.md) |
| murky freshwater | [Electric Eel](../cards/046-electric-eel.md) |
| near small water | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) |
| nesting beach | [Green Sea Turtle](../cards/032-green-sea-turtle.md) |
| open air corridor | [Common Green Darner](../cards/052-common-green-darner.md) |
| open country | [Peregrine Falcon](../cards/026-peregrine-falcon.md) |
| open ocean | [Humpback Whale](../cards/015-humpback-whale.md), [Laysan Albatross](../cards/027-laysan-albatross.md), [Great White Shark](../cards/042-great-white-shark.md) |
| open woodland | [African Lion](../cards/002-african-lion.md), [American Bison](../cards/007-american-bison.md), [Red-tailed Hawk](../cards/022-red-tailed-hawk.md), [Emu](../cards/031-emu.md) |
| pasture | [Domestic Horse](../cards/008-domestic-horse.md) |
| pond | [American Bullfrog](../cards/041-american-bullfrog.md), [Common Green Darner](../cards/052-common-green-darner.md) |
| ponds | [North American Beaver](../cards/011-north-american-beaver.md) |
| prairie | [American Bison](../cards/007-american-bison.md), [Sandhill Crane](../cards/025-sandhill-crane.md) |
| reef burrow | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) |
| reef drop-off | [Chambered Nautilus](../cards/060-chambered-nautilus.md) |
| remote island nesting ground | [Laysan Albatross](../cards/027-laysan-albatross.md) |
| riparian bank | [Platypus](../cards/018-platypus.md) |
| riparian corridor | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md) |
| river | [Bald Eagle](../cards/019-bald-eagle.md), [American Alligator](../cards/034-american-alligator.md), [Atlantic Salmon](../cards/043-atlantic-salmon.md) |
| river shallows | [Sandhill Crane](../cards/025-sandhill-crane.md) |
| rivers | [North American Beaver](../cards/011-north-american-beaver.md), [North American River Otter](../cards/012-north-american-river-otter.md) |
| roadside edge | [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) |
| rocky intertidal | [Ochre Sea Star](../cards/065-ochre-sea-star.md) |
| rocky reef | [Spot-fin Porcupinefish](../cards/048-porcupinefish.md), [Common Octopus](../cards/059-common-octopus.md) |
| rocky seafloor | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) |
| rocky slope | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) |
| saline lagoon | [Greater Flamingo](../cards/029-greater-flamingo.md) |
| savanna | [African Lion](../cards/002-african-lion.md), [African Elephant](../cards/003-african-elephant.md), [Emu](../cards/031-emu.md), [Komodo Dragon](../cards/036-komodo-dragon.md), [Sacred Scarab](../cards/053-sacred-scarab.md) |
| scrub | [African Elephant](../cards/003-african-elephant.md), [Indian Peafowl](../cards/030-indian-peafowl.md) |
| sea anemone habitat | [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md) |
| seafloor den | [Common Octopus](../cards/059-common-octopus.md) |
| seagrass | [Lined Seahorse](../cards/045-lined-seahorse.md) |
| seagrass meadow | [Green Sea Turtle](../cards/032-green-sea-turtle.md) |
| seasonal pond | [Tiger Salamander](../cards/040-tiger-salamander.md) |
| secondary forest | [Western Gorilla](../cards/016-western-gorilla.md) |
| semi-arid plain | [Emu](../cards/031-emu.md) |
| settlement edge | [Indian Peafowl](../cards/030-indian-peafowl.md) |
| shallow coral reef | [Staghorn Coral](../cards/066-staghorn-coral.md) |
| shallow lake | [Greater Flamingo](../cards/029-greater-flamingo.md) |
| shallow tropical sea | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) |
| shrub | [Panther Chameleon](../cards/035-panther-chameleon.md), [European Mantis](../cards/054-european-mantis.md) |
| shrubland | [American Black Bear](../cards/005-american-black-bear.md), [Red Kangaroo](../cards/017-red-kangaroo.md) |
| slow river | [Electric Eel](../cards/046-electric-eel.md) |
| slow stream | [American Bullfrog](../cards/041-american-bullfrog.md) |
| soft sediment | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) |
| soil | [Common Earthworm](../cards/068-common-earthworm.md) |
| steppe-derived domestic landscapes | [Domestic Horse](../cards/008-domestic-horse.md) |
| stream | [Platypus](../cards/018-platypus.md), [Atlantic Salmon](../cards/043-atlantic-salmon.md) |
| streams | [North American Beaver](../cards/011-north-american-beaver.md) |
| suburban mosaic | [White-tailed Deer](../cards/006-white-tailed-deer.md) |
| swamp | [American Alligator](../cards/034-american-alligator.md) |
| swamp forest | [Western Gorilla](../cards/016-western-gorilla.md) |
| tide pool | [Ochre Sea Star](../cards/065-ochre-sea-star.md) |
| tropical breeding waters | [Humpback Whale](../cards/015-humpback-whale.md) |
| tropical forest | [Western Gorilla](../cards/016-western-gorilla.md), [Leafcutter Ant](../cards/056-leafcutter-ant.md) |
| tropical forest edge | [Panther Chameleon](../cards/035-panther-chameleon.md) |
| tropical forest floor | [Emperor Scorpion](../cards/058-emperor-scorpion.md) |
| tropical rainforest floor | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) |
| tundra | [Gray Wolf](../cards/001-gray-wolf.md), [Red Fox](../cards/004-red-fox.md), [Common Raven](../cards/021-common-raven.md) |
| urban areas | [Domestic Cat](../cards/010-domestic-cat.md) |
| urban edge | [Red Fox](../cards/004-red-fox.md) |
| urban park | [Great Horned Owl](../cards/020-great-horned-owl.md) |
| urban vegetation | [Garden Snail](../cards/061-garden-snail.md) |
| wet meadow | [Sandhill Crane](../cards/025-sandhill-crane.md) |
| wetland | [Little Brown Bat](../cards/013-little-brown-bat.md), [Bald Eagle](../cards/019-bald-eagle.md) |
| wetland edge | [American Black Bear](../cards/005-american-black-bear.md), [White-tailed Deer](../cards/006-white-tailed-deer.md), [Great Horned Owl](../cards/020-great-horned-owl.md), [King Cobra](../cards/033-king-cobra.md) |
| wetlands | [North American Beaver](../cards/011-north-american-beaver.md), [North American River Otter](../cards/012-north-american-river-otter.md) |
| woodland | [African Elephant](../cards/003-african-elephant.md), [Tiger Salamander](../cards/040-tiger-salamander.md) |
| woodland cavity | [Western Honey Bee](../cards/050-western-honey-bee.md) |
| woodland edge | [Wild Turkey](../cards/028-wild-turkey.md), [Common Eastern Firefly](../cards/055-common-eastern-firefly.md), [Cross Orbweaver](../cards/057-cross-orbweaver.md), [Garden Snail](../cards/061-garden-snail.md) |
| working landscapes | [Domestic Dog](../cards/009-domestic-dog.md) |
