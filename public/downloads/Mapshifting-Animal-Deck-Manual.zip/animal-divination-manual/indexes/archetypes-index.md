# Archetypes Index

| Core archetype | Card | Primary Gifts | Primary Wounds |
|---|---|---|---|
| coordinated belonging | [Gray Wolf](../cards/001-gray-wolf.md) | coordination, endurance, social intelligence | conformity, exclusion, hypervigilance |
| courageous presence | [African Lion](../cards/002-african-lion.md) | courage, cooperative defense, rest and timing | domination, status fixation, entitlement |
| intergenerational memory | [African Elephant](../cards/003-african-elephant.md) | memory, intergenerational care, obstacle sense | burden-bearing, grief fixation, overprotection |
| adaptive edge-walker | [Red Fox](../cards/004-red-fox.md) | adaptability, opportunistic intelligence, boundary navigation | evasive habits, self-serving opportunism, mistrust |
| resourceful retreat | [American Black Bear](../cards/005-american-black-bear.md) | resourcefulness, restorative withdrawal, boundary power | avoidant withdrawal, overconsumption, defensive reactivity |
| sensitive responsiveness | [White-tailed Deer](../cards/006-white-tailed-deer.md) | sensitivity, responsive movement, gentle alertness | hypervigilance, appeasement, flight from necessary conflict |
| grounded communal endurance | [American Bison](../cards/007-american-bison.md) | communal endurance, grounded provision, weather-facing resilience | stubbornness, scarcity fear, herd conformity |
| embodied partnership in motion | [Domestic Horse](../cards/008-domestic-horse.md) | partnership, movement, embodied power | restlessness, servitude, force without direction |
| reciprocal trust | [Domestic Dog](../cards/009-domestic-dog.md) | reciprocity, loyalty, attunement | dependency, people-pleasing, guarding anxiety |
| self-possessed intimacy | [Domestic Cat](../cards/010-domestic-cat.md) | self-possession, sensory discernment, affectionate boundaries | aloofness, predatory entitlement, overstimulation |
| constructive systems work | [North American Beaver](../cards/011-north-american-beaver.md) | systems building, persistence, habitat stewardship | work compulsion, overengineering, territorial control |
| skillful play | [North American River Otter](../cards/012-north-american-river-otter.md) | play, dexterity, social ease | avoidance through play, impulsiveness, scattered attention |
| discernment in darkness | [Little Brown Bat](../cards/013-little-brown-bat.md) | echolocating discernment, navigation of uncertainty, communal shelter | fear of the unknown, sensory overload, hiding |
| communicative cooperation | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md) | communication, cooperative intelligence, play | social manipulation, stimulation seeking, group pressure |
| long-range voice and return | [Humpback Whale](../cards/015-humpback-whale.md) | long-range expression, migration, depth-to-surface integration | emotional flooding, nostalgia, disappearing into vastness |
| restrained protective strength | [Western Gorilla](../cards/016-western-gorilla.md) | quiet strength, protective leadership, kin care | intimidation, dominance rigidity, suppressed vulnerability |
| stored momentum | [Red Kangaroo](../cards/017-red-kangaroo.md) | forward momentum, energy reserve, protective nurture | inability to retreat, impulsive leaps, carrying too much |
| integrative originality | [Platypus](../cards/018-platypus.md) | integrative originality, electrosensory intuition, boundary-crossing | alienation, contrarian identity, confusion through hybridity |
| wide perspective with accountable descent | [Bald Eagle](../cards/019-bald-eagle.md) | wide perspective, decisive focus, stewardship | superiority, status fixation, distance from consequence |
| silent threshold discernment | [Great Horned Owl](../cards/020-great-horned-owl.md) | nocturnal discernment, silent focus, threshold awareness | secrecy, predatory certainty, isolation |
| curious memory-maker | [Common Raven](../cards/021-common-raven.md) | curiosity, memory, social learning | trickery, morbid fixation, intellectual detachment |
| patient surveillance | [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) | patient observation, timing, direct focus | overmonitoring, premature attack, reductionism |
| precise energetic exchange | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md) | precision, joy, reciprocal exchange | depletion, territorial irritability, chasing sweetness |
| collective warmth under pressure | [Emperor Penguin](../cards/024-emperor-penguin.md) | endurance, shared care, collective warmth | self-sacrifice, rigid duty, emotional freezing |
| attentive fidelity | [Sandhill Crane](../cards/025-sandhill-crane.md) | fidelity, ceremonial attention, long-distance return | idealization, performance, fear of separation |
| committed velocity | [Peregrine Falcon](../cards/026-peregrine-falcon.md) | commitment, speed, mid-course recalibration | recklessness, perfectionism, impact without pause |
| oceanic patience | [Laysan Albatross](../cards/027-laysan-albatross.md) | effortless range, commitment to journey, patient return | burdened wandering, avoidance of landing, isolation |
| grounded abundance | [Wild Turkey](../cards/028-wild-turkey.md) | grounded abundance, social awareness, honest display | overdisplay, complacency, group panic |
| selective filtering in company | [Greater Flamingo](../cards/029-greater-flamingo.md) | discernment, communal visibility, dynamic balance | performative belonging, crowd dependence, surface emphasis |
| truthful display | [Indian Peafowl](../cards/030-indian-peafowl.md) | beauty, expressive confidence, renewal | vanity, comparison, masking insecurity |
| steady adaptive stride | [Emu](../cards/031-emu.md) | steady movement, paternal care, climate adaptation | relentless pacing, emotional distance, inflexibility |
| patient navigation and return | [Green Sea Turtle](../cards/032-green-sea-turtle.md) | navigation, patient return, ancient rhythm | retreat, burdened return, slow response |
| measured warning and power | [King Cobra](../cards/033-king-cobra.md) | measured power, clear warning, focused protection | intimidation, suppressed anger, isolation |
| patient threshold defense | [American Alligator](../cards/034-american-alligator.md) | patience, survival memory, threshold defense | ambush mindset, emotional armoring, territorial aggression |
| contextual adaptation without disappearance | [Panther Chameleon](../cards/035-panther-chameleon.md) | context awareness, deliberate adjustment, multi-directional perception | self-erasure, indecision, camouflage habit |
| formidable economy | [Komodo Dragon](../cards/036-komodo-dragon.md) | strategic patience, metabolic economy, formidable presence | opportunistic aggression, intimidation, dominance |
| resource-paced endurance | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) | conservation, durable boundaries, resource pacing | rigidity, withdrawal, fear of change |
| regenerative openness | [Axolotl](../cards/038-axolotl.md) | regeneration, retained openness, niche adaptation | arrested development, dependency, fragility outside the niche |
| visible boundary | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) | clear boundaries, small-scale potency, environmental sensitivity | warning as identity, defensiveness, toxic reciprocity |
| hidden metamorphosis | [Tiger Salamander](../cards/040-tiger-salamander.md) | renewal, seasonal emergence, metamorphic capacity | avoidant dormancy, secrecy, stalled transformation |
| amphibious voice | [American Bullfrog](../cards/041-american-bullfrog.md) | vocal presence, territorial confidence, transition between elements | taking too much space, invasiveness, loudness without listening |
| decisive sensory clarity | [Great White Shark](../cards/042-great-white-shark.md) | sensory clarity, decisive movement, apex responsibility | fear projection, relentless pursuit, domination |
| return informed by place-memory | [Atlantic Salmon](../cards/043-atlantic-salmon.md) | return, persistence, place-memory | compulsive return, exhaustion, identity bound to origin |
| mutual belonging | [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md) | mutualism, home defense, adaptive role change | overdependence, territoriality, identity confined to one system |
| receptive care | [Lined Seahorse](../cards/045-lined-seahorse.md) | receptive care, gentle persistence, role flexibility | passivity, fragility, overattachment |
| self-generated boundary and perception | [Electric Eel](../cards/046-electric-eel.md) | internal power, electrical sensing, boundary signaling | shock tactics, isolation, chronic defensiveness |
| graceful scale | [Reef Manta Ray](../cards/047-reef-manta-ray.md) | grace, curiosity, flow | avoidance of friction, diffuse boundaries, vulnerability to exploitation |
| adaptive deterrence | [Spot-fin Porcupinefish](../cards/048-porcupinefish.md) | adaptive defense, hidden resilience, timely expansion | chronic bracing, deterrence as identity, fear-driven inflation |
| calibrated aim | [Banded Archerfish](../cards/049-banded-archerfish.md) | aim, learning, distance judgment | overcalculation, target fixation, instrumental thinking |
| distributed cooperation | [Western Honey Bee](../cards/050-western-honey-bee.md) | cooperation, communication, pollination | overwork, role confinement, defensive collectivism |
| generational transformation | [Monarch Butterfly](../cards/051-monarch-butterfly.md) | transformation, migration, generational continuity | fragility idealization, endless transition, loss of roots |
| life-stage agility | [Common Green Darner](../cards/052-common-green-darner.md) | aerial agility, life-stage transformation, territorial clarity | restless motion, competitive vigilance, detachment from origins |
| renewal through what is discarded | [Sacred Scarab](../cards/053-sacred-scarab.md) | renewal, persistence, orientation | compulsive labor, false purity, recycling the past without change |
| poised response | [European Mantis](../cards/054-european-mantis.md) | stillness, precise response, embodied attention | predatory patience, emotional detachment, waiting too long |
| timely illumination | [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) | timely signal, modest illumination, authentic attraction | approval-seeking display, fleeting focus, visibility risk |
| cultivated infrastructure | [Leafcutter Ant](../cards/056-leafcutter-ant.md) | distributed work, cultivation, infrastructure | self-erasure in labor, rigid hierarchy, relentless extraction |
| sensitive pattern-maker | [Cross Orbweaver](../cards/057-cross-orbweaver.md) | pattern construction, repair, vibrational sensitivity | entanglement, perfectionism, waiting for life |
| calibrated defense | [Emperor Scorpion](../cards/058-emperor-scorpion.md) | calibrated defense, nocturnal resilience, maternal protection | guardedness, retaliatory posture, hidden vulnerability |
| flexible distributed intelligence | [Common Octopus](../cards/059-common-octopus.md) | flexible intelligence, adaptive expression, escape skill | evasion, identity shifting, isolation |
| chambered continuity | [Chambered Nautilus](../cards/060-chambered-nautilus.md) | buoyancy regulation, continuity, layered growth | retreat into former rooms, overcontainment, slow adaptation |
| portable pacing | [Garden Snail](../cards/061-garden-snail.md) | patient contact, portable refuge, measured pacing | avoidance, inertia, excessive self-protection |
| adaptive housing | [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) | resource reuse, adaptive shelter, transition | insecure borrowing, serial escape, possessiveness |
| complex perception with rapid force | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) | complex perception, rapid commitment, burrow defense | explosive force, sensory overwhelm, combative certainty |
| rhythmic receptivity | [Moon Jelly](../cards/064-moon-jelly.md) | receptivity, rhythmic flow, transparency | drift, porous boundaries, passivity |
| distributed keystone influence | [Ochre Sea Star](../cards/065-ochre-sea-star.md) | regeneration, keystone influence, distributed sensing | fragmentation, clinging, underestimating indirect power |
| collective habitat-making | [Staghorn Coral](../cards/066-staghorn-coral.md) | collective building, symbiosis, habitat generation | brittleness, dependency, silent collapse |
| quiet recycling | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) | recycling, low-profile service, substrate renewal | self-emptying, invisibility, depletion |
| humble transformation | [Common Earthworm](../cards/068-common-earthworm.md) | soil renewal, humble transformation, sensitivity | self-neglect, buried emotion, fragmentation |
