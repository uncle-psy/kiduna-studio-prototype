# Expansion Candidates

These animals passed an initial distinctiveness screen but remain outside the learnable 68-card core.

| Candidate | Distinct contribution and review need |
|---|---|
| Polar Bear | Arctic sea-ice dependence and fasting; add only with current climate and Inuit-specific cultural review. |
| Spotted Hyena | Matrilineal social complexity, bone-processing, and misunderstood reputation. |
| Meerkat | Sentinel rotation and cooperative care; audit overlap with Wolf and Prairie Dog. |
| Giant Pangolin | Armor and specialized foraging; requires trade/conservation care. |
| Sloth | Low-energy canopy ecology; distinguish from Tortoise and Nautilus pacing. |
| Orca | Matrilineal culture and prey-specialist communities; requires population-specific treatment. |
| Lyrebird | Vocal learning and environmental acoustic memory. |
| Weaverbird | Nest engineering and display; audit overlap with Beaver and Orbweaver. |
| Vulture | Sanitation, soaring, and death-related stigma; culturally sensitive review required. |
| Kakapo | Nocturnal flightlessness and intensive conservation dependence. |
| Crocodile | Maternal care and ancient river predation; would replace the alligator’s comparative Sobek caveat. |
| Gecko | Adhesion, tail loss, and regeneration; audit overlap with Axolotl and Chameleon. |
| Mudskipper | Amphibious fish behavior and boundary crossing. |
| Cleaner Wrasse | Reciprocity, service markets, and recognition; audit overlap with Manta. |
| Cuttlefish | Dynamic signaling and camouflage; distinguish from Octopus and Chameleon. |
| Bumble Bee | Buzz pollination and thermoregulation; distinguish from Honey Bee colony symbolism. |
| Termite | Collective climate-controlled architecture; audit overlap with Ant and Beaver. |
| Jumping Spider | Visual curiosity and active stalking; distinguish from Orbweaver waiting. |
| Horseshoe Crab | Deep-time continuity and biomedical exploitation. |
| Tardigrade | Microscopic cryptobiosis; avoid exaggerated invincibility myths. |
