---
card_number:
animal:
slug:
scientific_name:
alternate_names: []
taxonomic_group:
habitats: []
geographic_range: []
activity_cycle:
social_pattern:
core_archetype:
primary_gifts: []
primary_wounds: []
elemental_associations: []
seasonal_associations: []
provenance_labels: []
confidence:
status: draft
---

# Animal name

## Essence

## Keywords

## The living animal

### Natural-history facts

### Symbolic bridge

## Core archetype

## Gifts

## Wounds

## Gift–Wound relationship

## Balanced expression

## Overexpression

## Underexpression

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | |
| Relationships | |
| Community | |
| Work and vocation | |
| Creativity | |
| Conflict | |
| Healing and restoration | |
| Decision-making | |
| Change and transition | |
| Leadership and responsibility | |

## Questions for reflection

## Practice

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|

## Modern interpretations

## Deck synthesis

## Relationships to other cards

## Future illustration brief

## Sources

## Research notes
