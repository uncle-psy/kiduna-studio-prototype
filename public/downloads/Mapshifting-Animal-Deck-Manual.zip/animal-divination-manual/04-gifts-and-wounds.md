# Gifts and Wounds

## Gift

A Gift is a capacity, form of intelligence, sensitivity, instinct, or practiced strength that the animal helps a person recognize. A Gift is not a fixed virtue. It becomes useful through timing, proportion, relationship, and choice.

## Wound

A Wound is an unresolved hurt, fear, defense, or distortion connected to the same underlying energy. It is a reflective possibility—not a diagnosis, identity, accusation, or proof of trauma. The reader may accept, reject, rename, or reinterpret it.

## One energy, two expressions

The pair is dynamic:

- A Wound can force the early development of a Gift: hypervigilance may train fine perception.
- A Gift can conceal a Wound: constant competence may hide fear of receiving help.
- A Gift can become distorted through overuse: protection can harden into control.
- A denied Wound can obstruct its Gift: fear of conflict can suppress courage.
- Integration keeps the capacity while loosening the defense.

## Three-expression test

Every card distinguishes:

- **Balanced:** the Gift is available, proportionate, and connected.
- **Overexpressed:** the Gift becomes rigid, dominating, compulsive, or costly.
- **Underexpressed:** the Gift is suppressed, inaccessible, or surrendered.

## Working with a card

Ask:

1. Which Gift is already alive?
2. Which Wound, if any, does the card help me name?
3. Is the quality balanced, overexpressed, or underexpressed?
4. What context changes the answer?
5. What support would allow the Gift without repeating the Wound?
6. What thought, word, and action restore balance?

Continue to [Deck architecture](05-deck-architecture.md).
