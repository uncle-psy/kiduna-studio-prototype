---
card_number: 17
animal: "Red Kangaroo"
slug: "red-kangaroo"
scientific_name: "Osphranter rufus"
alternate_names: ["red kangaroo"]
taxonomic_group: "Mammal"
habitats: ["arid grassland", "shrubland", "desert plain"]
geographic_range: ["Australia"]
activity_cycle: "mostly crepuscular and nocturnal"
social_pattern: "fluid mobs; mothers with young"
core_archetype: "stored momentum"
primary_gifts: ["forward momentum", "energy reserve", "protective nurture"]
primary_wounds: ["inability to retreat", "impulsive leaps", "carrying too much"]
elemental_associations: ["earth", "fire"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Red Kangaroo

## Essence

Red Kangaroo teaches **stored momentum**: forward momentum becomes trustworthy when it stays connected to energy reserve and does not harden into inability to retreat.

## Keywords

forward momentum, energy reserve, protective nurture, inability to retreat, impulsive leaps, carrying too much.

## The living animal

### Natural-history facts

- Red kangaroos use elastic hopping for efficient travel across open, dry country.
- Females can support young at different developmental stages through distinctive reproductive adaptations.
- Groups change with rainfall and forage; heat management includes shade, posture, and reduced daytime activity.
- **Ecological role:** As large grazers, kangaroos respond strongly to variable water, vegetation, and land management.
- **Habitat and range:** arid grassland, shrubland, desert plain; Australia.
- **Activity and social pattern:** mostly crepuscular and nocturnal; fluid mobs; mothers with young.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **stored momentum**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Red Kangaroo occupies the role of **stored momentum**. Unlike Emu, Kangaroo emphasizes elastic leaps and protected development carried close to the body.

## Gifts

- **Forward Momentum:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Energy Reserve:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Protective Nurture:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Inability To Retreat:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Impulsive Leaps:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Carrying Too Much:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **forward momentum** can produce **inability to retreat** when safety, timing, or relationship is lost. **energy reserve** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **protective nurture** available while loosening the demand to live through **impulsive leaps**.

## Balanced expression

A balanced expression combines forward momentum, energy reserve, and protective nurture. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when forward momentum turns into inability to retreat, or when protective nurture dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding forward momentum, distrusting energy reserve, or surrendering protective nurture even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **forward momentum**; ask whether **inability to retreat** is driving or distorting it. |
| Relationships | Practice **energy reserve** without asking another person to absorb **impulsive leaps**. |
| Community | The group may need the **stored momentum** role, with explicit limits against **carrying too much**. |
| Work and vocation | Use **protective nurture** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: females can support young at different developmental stages through distinctive reproductive adaptations. |
| Conflict | Choose the proportionate form of **forward momentum** rather than escalating into **inability to retreat**. |
| Healing and restoration | Restore access to **energy reserve** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **protective nurture** without repeating **impulsive leaps**. |
| Change and transition | Use Red Kangaroo as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **forward momentum** accountable to others and monitor for **carrying too much**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is forward momentum already alive in my situation?
2. When does energy reserve become difficult to receive or sustain?
3. Could inability to retreat be protecting something that needs a safer strategy?
4. Am I overexpressing protective nurture or suppressing it?
5. What does the arid grassland context teach me about the conditions this quality needs?
6. Where does my analogy with Red Kangaroo stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Choose a forward step with a safe landing. Before taking it, identify what you are carrying that needs protection and what can be put down.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Red Kangaroo. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Red Kangaroo represents stored momentum. The synthesis derives from the verified behaviors above and adopts forward momentum as the primary Gift and inability to retreat as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Emu](031-emu.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Green Sea Turtle](032-green-sea-turtle.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Emu](031-emu.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Green Sea Turtle](032-green-sea-turtle.md) can reveal a related defense in another form.
- **Productive tension:** [Green Sea Turtle](032-green-sea-turtle.md) and Red Kangaroo ask for both patient navigation and return and stored momentum.
- **Commonly confused:** [Emu](031-emu.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Red Kangaroo in arid grassland, engaged in the behavior described here: red kangaroos use elastic hopping for efficient travel across open, dry country. Emphasize real anatomy, ecological context, and the tension between forward momentum and inability to retreat. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Macropus_rufus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Current genus often given as Osphranter; ADW may retain Macropus.
- No direct quotation from a commercial guidebook was used.
