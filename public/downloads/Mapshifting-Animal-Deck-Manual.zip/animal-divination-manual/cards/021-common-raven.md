---
card_number: 21
animal: "Common Raven"
slug: "common-raven"
scientific_name: "Corvus corax"
alternate_names: ["raven"]
taxonomic_group: "Bird"
habitats: ["mountain", "coast", "desert", "tundra", "human edge"]
geographic_range: ["Northern Hemisphere"]
activity_cycle: "diurnal"
social_pattern: "pairs, families, and nonbreeding groups"
core_archetype: "curious memory-maker"
primary_gifts: ["curiosity", "memory", "social learning"]
primary_wounds: ["trickery", "morbid fixation", "intellectual detachment"]
elemental_associations: ["air", "earth"]
seasonal_associations: ["autumn"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# Common Raven

## Essence

Common Raven teaches **curious memory-maker**: curiosity becomes trustworthy when it stays connected to memory and does not harden into trickery.

## Keywords

curiosity, memory, social learning, trickery, morbid fixation, intellectual detachment.

## The living animal

### Natural-history facts

- Ravens solve novel problems, cache food, play, and learn from social observation.
- Pairs often hold territories while younger nonbreeders form shifting groups around resources.
- Their varied calls, gestures, and object play reveal flexible communication and exploration.
- **Ecological role:** Ravens scavenge, prey, disperse material, and exploit changing food opportunities.
- **Habitat and range:** mountain, coast, desert, tundra, human edge; Northern Hemisphere.
- **Activity and social pattern:** diurnal; pairs, families, and nonbreeding groups.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **curious memory-maker**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Common Raven occupies the role of **curious memory-maker**. Unlike Red Fox, Raven tests possibilities through social observation, voice, and aerial access rather than ground-level stealth.

## Gifts

- **Curiosity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Memory:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Social Learning:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Trickery:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Morbid Fixation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Intellectual Detachment:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **curiosity** can produce **trickery** when safety, timing, or relationship is lost. **memory** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **social learning** available while loosening the demand to live through **morbid fixation**.

## Balanced expression

A balanced expression combines curiosity, memory, and social learning. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when curiosity turns into trickery, or when social learning dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding curiosity, distrusting memory, or surrendering social learning even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **curiosity**; ask whether **trickery** is driving or distorting it. |
| Relationships | Practice **memory** without asking another person to absorb **morbid fixation**. |
| Community | The group may need the **curious memory-maker** role, with explicit limits against **intellectual detachment**. |
| Work and vocation | Use **social learning** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: pairs often hold territories while younger nonbreeders form shifting groups around resources. |
| Conflict | Choose the proportionate form of **curiosity** rather than escalating into **trickery**. |
| Healing and restoration | Restore access to **memory** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **social learning** without repeating **morbid fixation**. |
| Change and transition | Use Common Raven as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **curiosity** accountable to others and monitor for **intellectual detachment**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is curiosity already alive in my situation?
2. When does memory become difficult to receive or sustain?
3. Could trickery be protecting something that needs a safer strategy?
4. Am I overexpressing social learning or suppressing it?
5. What does the mountain context teach me about the conditions this quality needs?
6. Where does my analogy with Common Raven stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Investigate one assumption playfully: seek a disconfirming fact, tell someone what you learned, and do not use cleverness to avoid feeling.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Old Norse textual tradition | Odin sends Huginn and Muninn across the world to return with tidings; the translated names are connected with thought and memory. | *Gylfaginning* §38; 1916 English translation | historical | medium | [Snorri, *Gylfaginning*](https://www.sacred-texts.com/neu/pre/pre04.htm) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Common Raven. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Common Raven represents curious memory-maker. The synthesis derives from the verified behaviors above and adopts curiosity as the primary Gift and trickery as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Red Fox](004-red-fox.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Domestic Dog](009-domestic-dog.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Reef Manta Ray](047-reef-manta-ray.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Domestic Dog](009-domestic-dog.md) can reveal a related defense in another form.
- **Productive tension:** [Domestic Dog](009-domestic-dog.md) and Common Raven ask for both reciprocal trust and curious memory-maker.
- **Commonly confused:** [Red Fox](004-red-fox.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Common Raven in mountain, engaged in the behavior described here: ravens solve novel problems, cache food, play, and learn from social observation. Emphasize real anatomy, ecological context, and the tension between curiosity and trickery. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.allaboutbirds.org/guide/Common_Raven/lifehistory) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Snorri, *Gylfaginning*](https://www.sacred-texts.com/neu/pre/pre04.htm) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
