---
card_number: 33
animal: "King Cobra"
slug: "king-cobra"
scientific_name: "Ophiophagus hannah"
alternate_names: ["hamadryad"]
taxonomic_group: "Reptile"
habitats: ["forest", "bamboo", "wetland edge", "agricultural mosaic"]
geographic_range: ["South and Southeast Asia"]
activity_cycle: "diurnal"
social_pattern: "mostly solitary"
core_archetype: "measured warning and power"
primary_gifts: ["measured power", "clear warning", "focused protection"]
primary_wounds: ["intimidation", "suppressed anger", "isolation"]
elemental_associations: ["fire", "earth"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# King Cobra

## Essence

King Cobra teaches **measured warning and power**: measured power becomes trustworthy when it stays connected to clear warning and does not harden into intimidation.

## Keywords

measured power, clear warning, focused protection, intimidation, suppressed anger, isolation.

## The living animal

### Natural-history facts

- King cobras are the longest venomous snakes and feed primarily on other snakes.
- They can raise the forebody and spread a hood as a warning display rather than striking without signal.
- Females build and guard nests of vegetation, unusual behavior among snakes.
- **Ecological role:** As specialist predators, king cobras participate in reptile food webs and depend on forested habitat.
- **Habitat and range:** forest, bamboo, wetland edge, agricultural mosaic; South and Southeast Asia.
- **Activity and social pattern:** diurnal; mostly solitary.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **measured warning and power**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

King Cobra occupies the role of **measured warning and power**. Unlike Emperor Scorpion, Cobra brings defense into vertical visibility, warning, and guarded nesting rather than nocturnal armored concealment.

## Gifts

- **Measured Power:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Clear Warning:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Focused Protection:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Intimidation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Suppressed Anger:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Isolation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **measured power** can produce **intimidation** when safety, timing, or relationship is lost. **clear warning** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **focused protection** available while loosening the demand to live through **suppressed anger**.

## Balanced expression

A balanced expression combines measured power, clear warning, and focused protection. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when measured power turns into intimidation, or when focused protection dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding measured power, distrusting clear warning, or surrendering focused protection even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **measured power**; ask whether **intimidation** is driving or distorting it. |
| Relationships | Practice **clear warning** without asking another person to absorb **suppressed anger**. |
| Community | The group may need the **measured warning and power** role, with explicit limits against **isolation**. |
| Work and vocation | Use **focused protection** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they can raise the forebody and spread a hood as a warning display rather than striking without signal. |
| Conflict | Choose the proportionate form of **measured power** rather than escalating into **intimidation**. |
| Healing and restoration | Restore access to **clear warning** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **focused protection** without repeating **suppressed anger**. |
| Change and transition | Use King Cobra as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **measured power** accountable to others and monitor for **isolation**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is measured power already alive in my situation?
2. When does clear warning become difficult to receive or sustain?
3. Could intimidation be protecting something that needs a safer strategy?
4. Am I overexpressing focused protection or suppressing it?
5. What does the forest context teach me about the conditions this quality needs?
6. Where does my analogy with King Cobra stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

State a boundary early, plainly, and without unnecessary threat. Decide in advance what proportionate action follows if it is crossed.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Ancient Egypt | Wadjet appears as a rearing cobra associated in this object record with the pharaoh and royal authority. | New Kingdom, ca. 1300–1080 BCE | historical | high | [Met, *Scarab with Sobek and Wadjet*](https://www.metmuseum.org/art/collection/search/553403) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for King Cobra. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** King Cobra represents measured warning and power. The synthesis derives from the verified behaviors above and adopts measured power as the primary Gift and intimidation as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Emperor Scorpion](058-emperor-scorpion.md) expands the Gift through a different ecological strategy.
- **Balancing:** [White-tailed Deer](006-white-tailed-deer.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Emperor Scorpion](058-emperor-scorpion.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Western Gorilla](016-western-gorilla.md) can reveal a related defense in another form.
- **Productive tension:** [White-tailed Deer](006-white-tailed-deer.md) and King Cobra ask for both sensitive responsiveness and measured warning and power.
- **Commonly confused:** [Emperor Scorpion](058-emperor-scorpion.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show King Cobra in forest, engaged in the behavior described here: king cobras are the longest venomous snakes and feed primarily on other snakes. Emphasize real anatomy, ecological context, and the tension between measured power and intimidation. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Ophiophagus_hannah/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Met, *Scarab with Sobek and Wadjet*](https://www.metmuseum.org/art/collection/search/553403) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Venomous wildlife must never be approached or handled.
- No direct quotation from a commercial guidebook was used.
