---
card_number: 29
animal: "Greater Flamingo"
slug: "greater-flamingo"
scientific_name: "Phoenicopterus roseus"
alternate_names: ["flamingo"]
taxonomic_group: "Bird"
habitats: ["saline lagoon", "shallow lake", "mudflat", "estuary"]
geographic_range: ["Africa", "southern Europe", "southwestern Asia"]
activity_cycle: "diurnal and nocturnal"
social_pattern: "large colonies and feeding flocks"
core_archetype: "selective filtering in company"
primary_gifts: ["discernment", "communal visibility", "dynamic balance"]
primary_wounds: ["performative belonging", "crowd dependence", "surface emphasis"]
elemental_associations: ["water", "air"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Greater Flamingo

## Essence

Greater Flamingo teaches **selective filtering in company**: discernment becomes trustworthy when it stays connected to communal visibility and does not harden into performative belonging.

## Keywords

discernment, communal visibility, dynamic balance, performative belonging, crowd dependence, surface emphasis.

## The living animal

### Natural-history facts

- Greater flamingos filter small organisms and particles from shallow water using specialized bills.
- Their pink coloration reflects dietary pigments rather than an inherent fixed color.
- They breed and display in colonies, with synchronized movement and changing group formations.
- **Ecological role:** Flamingo distribution tracks productive shallow wetlands whose salinity and water levels can change rapidly.
- **Habitat and range:** saline lagoon, shallow lake, mudflat, estuary; Africa, southern Europe, southwestern Asia.
- **Activity and social pattern:** diurnal and nocturnal; large colonies and feeding flocks.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **selective filtering in company**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Greater Flamingo occupies the role of **selective filtering in company**. Unlike Honey Bee, Flamingo participates in mass coordination without the fixed labor roles of a eusocial colony.

## Gifts

- **Discernment:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Communal Visibility:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Dynamic Balance:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Performative Belonging:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Crowd Dependence:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Surface Emphasis:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **discernment** can produce **performative belonging** when safety, timing, or relationship is lost. **communal visibility** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **dynamic balance** available while loosening the demand to live through **crowd dependence**.

## Balanced expression

A balanced expression combines discernment, communal visibility, and dynamic balance. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when discernment turns into performative belonging, or when dynamic balance dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding discernment, distrusting communal visibility, or surrendering dynamic balance even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **discernment**; ask whether **performative belonging** is driving or distorting it. |
| Relationships | Practice **communal visibility** without asking another person to absorb **crowd dependence**. |
| Community | The group may need the **selective filtering in company** role, with explicit limits against **surface emphasis**. |
| Work and vocation | Use **dynamic balance** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: their pink coloration reflects dietary pigments rather than an inherent fixed color. |
| Conflict | Choose the proportionate form of **discernment** rather than escalating into **performative belonging**. |
| Healing and restoration | Restore access to **communal visibility** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **dynamic balance** without repeating **crowd dependence**. |
| Change and transition | Use Greater Flamingo as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **discernment** accountable to others and monitor for **surface emphasis**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is discernment already alive in my situation?
2. When does communal visibility become difficult to receive or sustain?
3. Could performative belonging be protecting something that needs a safer strategy?
4. Am I overexpressing dynamic balance or suppressing it?
5. What does the saline lagoon context teach me about the conditions this quality needs?
6. Where does my analogy with Greater Flamingo stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Filter a flood of input through three explicit criteria. Let yourself remain visible to the group without copying its every movement.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Greater Flamingo. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Greater Flamingo represents selective filtering in company. The synthesis derives from the verified behaviors above and adopts discernment as the primary Gift and performative belonging as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Reef Manta Ray](047-reef-manta-ray.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Great Horned Owl](020-great-horned-owl.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Reef Manta Ray](047-reef-manta-ray.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Great Horned Owl](020-great-horned-owl.md) can reveal a related defense in another form.
- **Productive tension:** [Great Horned Owl](020-great-horned-owl.md) and Greater Flamingo ask for both silent threshold discernment and selective filtering in company.
- **Commonly confused:** [Reef Manta Ray](047-reef-manta-ray.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Greater Flamingo in saline lagoon, engaged in the behavior described here: greater flamingos filter small organisms and particles from shallow water using specialized bills. Emphasize real anatomy, ecological context, and the tension between discernment and performative belonging. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Phoenicopterus_roseus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
