---
card_number: 5
animal: "American Black Bear"
slug: "american-black-bear"
scientific_name: "Ursus americanus"
alternate_names: ["black bear"]
taxonomic_group: "Mammal"
habitats: ["forest", "wetland edge", "mountain", "shrubland"]
geographic_range: ["North America"]
activity_cycle: "often crepuscular; seasonally variable"
social_pattern: "mostly solitary except mothers with young and feeding aggregations"
core_archetype: "resourceful retreat"
primary_gifts: ["resourcefulness", "restorative withdrawal", "boundary power"]
primary_wounds: ["avoidant withdrawal", "overconsumption", "defensive reactivity"]
elemental_associations: ["earth", "water"]
seasonal_associations: ["winter"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# American Black Bear

## Essence

American Black Bear teaches **resourceful retreat**: resourcefulness becomes trustworthy when it stays connected to restorative withdrawal and does not harden into avoidant withdrawal.

## Keywords

resourcefulness, restorative withdrawal, boundary power, avoidant withdrawal, overconsumption, defensive reactivity.

## The living animal

### Natural-history facts

- Black bears are highly flexible omnivores whose diets shift with season and place.
- In colder regions they enter winter dens and markedly reduce metabolism without the deep temperature drop of small hibernators.
- They climb well, use strong smell, and usually avoid people when given space.
- **Ecological role:** Foraging and seed dispersal connect bears with forest succession and seasonal food webs.
- **Habitat and range:** forest, wetland edge, mountain, shrubland; North America.
- **Activity and social pattern:** often crepuscular; seasonally variable; mostly solitary except mothers with young and feeding aggregations.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **resourceful retreat**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

American Black Bear occupies the role of **resourceful retreat**. Unlike Desert Tortoise, Bear alternates expansive foraging with protected seasonal retreat rather than conserving steadily all year.

## Gifts

- **Resourcefulness:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Restorative Withdrawal:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Boundary Power:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Avoidant Withdrawal:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Overconsumption:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Defensive Reactivity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **resourcefulness** can produce **avoidant withdrawal** when safety, timing, or relationship is lost. **restorative withdrawal** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **boundary power** available while loosening the demand to live through **overconsumption**.

## Balanced expression

A balanced expression combines resourcefulness, restorative withdrawal, and boundary power. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when resourcefulness turns into avoidant withdrawal, or when boundary power dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding resourcefulness, distrusting restorative withdrawal, or surrendering boundary power even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **resourcefulness**; ask whether **avoidant withdrawal** is driving or distorting it. |
| Relationships | Practice **restorative withdrawal** without asking another person to absorb **overconsumption**. |
| Community | The group may need the **resourceful retreat** role, with explicit limits against **defensive reactivity**. |
| Work and vocation | Use **boundary power** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: in colder regions they enter winter dens and markedly reduce metabolism without the deep temperature drop of small hibernators. |
| Conflict | Choose the proportionate form of **resourcefulness** rather than escalating into **avoidant withdrawal**. |
| Healing and restoration | Restore access to **restorative withdrawal** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **boundary power** without repeating **overconsumption**. |
| Change and transition | Use American Black Bear as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **resourcefulness** accountable to others and monitor for **defensive reactivity**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is resourcefulness already alive in my situation?
2. When does restorative withdrawal become difficult to receive or sustain?
3. Could avoidant withdrawal be protecting something that needs a safer strategy?
4. Am I overexpressing boundary power or suppressing it?
5. What does the forest context teach me about the conditions this quality needs?
6. Where does my analogy with American Black Bear stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Schedule a bounded period of true retreat, then name the time and condition for re-emergence. A refuge should restore participation, not erase it.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for American Black Bear. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** American Black Bear represents resourceful retreat. The synthesis derives from the verified behaviors above and adopts resourcefulness as the primary Gift and avoidant withdrawal as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Atlantic Salmon](043-atlantic-salmon.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Western Honey Bee](050-western-honey-bee.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Atlantic Salmon](043-atlantic-salmon.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Western Honey Bee](050-western-honey-bee.md) can reveal a related defense in another form.
- **Productive tension:** [Western Honey Bee](050-western-honey-bee.md) and American Black Bear ask for both distributed cooperation and resourceful retreat.
- **Commonly confused:** [Atlantic Salmon](043-atlantic-salmon.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show American Black Bear in forest, engaged in the behavior described here: black bears are highly flexible omnivores whose diets shift with season and place. Emphasize real anatomy, ecological context, and the tension between resourcefulness and avoidant withdrawal. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Ursus_americanus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
