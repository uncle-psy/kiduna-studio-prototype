---
card_number: 8
animal: "Domestic Horse"
slug: "domestic-horse"
scientific_name: "Equus caballus"
alternate_names: ["horse"]
taxonomic_group: "Mammal"
habitats: ["pasture", "steppe-derived domestic landscapes"]
geographic_range: ["worldwide under human care"]
activity_cycle: "diurnal and crepuscular, with distributed rest"
social_pattern: "social bands under free-ranging conditions; human-managed groups"
core_archetype: "embodied partnership in motion"
primary_gifts: ["partnership", "movement", "embodied power"]
primary_wounds: ["restlessness", "servitude", "force without direction"]
elemental_associations: ["earth", "air"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Domestic Horse

## Essence

Domestic Horse teaches **embodied partnership in motion**: partnership becomes trustworthy when it stays connected to movement and does not harden into restlessness.

## Keywords

partnership, movement, embodied power, restlessness, servitude, force without direction.

## The living animal

### Natural-history facts

- Horses are grazing herd animals with strong locomotor capacity and rapid flight responses.
- They communicate through posture, facial expression, vocalization, scent, and spatial pressure.
- Human breeding and management have produced enormous variation in body, work, and behavior.
- **Ecological role:** Domestic and feral horses affect grasslands differently depending on density, water, and management.
- **Habitat and range:** pasture, steppe-derived domestic landscapes; worldwide under human care.
- **Activity and social pattern:** diurnal and crepuscular, with distributed rest; social bands under free-ranging conditions; human-managed groups.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **embodied partnership in motion**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Domestic Horse occupies the role of **embodied partnership in motion**. Unlike Bison, Horse centers negotiated movement and cross-species partnership, including the ethics of power and consent.

## Gifts

- **Partnership:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Movement:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Embodied Power:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Restlessness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Servitude:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Force Without Direction:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **partnership** can produce **restlessness** when safety, timing, or relationship is lost. **movement** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **embodied power** available while loosening the demand to live through **servitude**.

## Balanced expression

A balanced expression combines partnership, movement, and embodied power. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when partnership turns into restlessness, or when embodied power dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding partnership, distrusting movement, or surrendering embodied power even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **partnership**; ask whether **restlessness** is driving or distorting it. |
| Relationships | Practice **movement** without asking another person to absorb **servitude**. |
| Community | The group may need the **embodied partnership in motion** role, with explicit limits against **force without direction**. |
| Work and vocation | Use **embodied power** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they communicate through posture, facial expression, vocalization, scent, and spatial pressure. |
| Conflict | Choose the proportionate form of **partnership** rather than escalating into **restlessness**. |
| Healing and restoration | Restore access to **movement** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **embodied power** without repeating **servitude**. |
| Change and transition | Use Domestic Horse as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **partnership** accountable to others and monitor for **force without direction**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is partnership already alive in my situation?
2. When does movement become difficult to receive or sustain?
3. Could restlessness be protecting something that needs a safer strategy?
4. Am I overexpressing embodied power or suppressing it?
5. What does the pasture context teach me about the conditions this quality needs?
6. Where does my analogy with Domestic Horse stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Walk at a pace you can sustain while attending to breath and surroundings. Name where cooperation is freely chosen and where it has become coercion.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Domestic Horse. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Domestic Horse represents embodied partnership in motion. The synthesis derives from the verified behaviors above and adopts partnership as the primary Gift and restlessness as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Sandhill Crane](025-sandhill-crane.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Mojave Desert Tortoise](037-mojave-desert-tortoise.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Sandhill Crane](025-sandhill-crane.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Mojave Desert Tortoise](037-mojave-desert-tortoise.md) can reveal a related defense in another form.
- **Productive tension:** [Mojave Desert Tortoise](037-mojave-desert-tortoise.md) and Domestic Horse ask for both resource-paced endurance and embodied partnership in motion.
- **Commonly confused:** [Sandhill Crane](025-sandhill-crane.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Domestic Horse in pasture, engaged in the behavior described here: horses are grazing herd animals with strong locomotor capacity and rapid flight responses. Emphasize real anatomy, ecological context, and the tension between partnership and restlessness. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Equus_caballus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Domestic welfare and breed differences need context-specific sources.
- No direct quotation from a commercial guidebook was used.
