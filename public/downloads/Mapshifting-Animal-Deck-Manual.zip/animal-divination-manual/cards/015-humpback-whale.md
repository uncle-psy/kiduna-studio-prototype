---
card_number: 15
animal: "Humpback Whale"
slug: "humpback-whale"
scientific_name: "Megaptera novaeangliae"
alternate_names: ["humpback"]
taxonomic_group: "Mammal"
habitats: ["open ocean", "coastal feeding grounds", "tropical breeding waters"]
geographic_range: ["oceans worldwide"]
activity_cycle: "migratory and seasonally patterned"
social_pattern: "mostly solitary or temporary groups"
core_archetype: "long-range voice and return"
primary_gifts: ["long-range expression", "migration", "depth-to-surface integration"]
primary_wounds: ["emotional flooding", "nostalgia", "disappearing into vastness"]
elemental_associations: ["water", "air"]
seasonal_associations: ["winter"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Humpback Whale

## Essence

Humpback Whale teaches **long-range voice and return**: long-range expression becomes trustworthy when it stays connected to migration and does not harden into emotional flooding.

## Keywords

long-range expression, migration, depth-to-surface integration, emotional flooding, nostalgia, disappearing into vastness.

## The living animal

### Natural-history facts

- Humpbacks migrate between high-latitude feeding areas and lower-latitude breeding grounds.
- They use complex vocalizations, including population-specific songs produced by males, and varied feeding strategies.
- Individuals can travel great distances while forming temporary feeding or social associations.
- **Ecological role:** Large whales move nutrients through feeding, waste, migration, and carcass fall.
- **Habitat and range:** open ocean, coastal feeding grounds, tropical breeding waters; oceans worldwide.
- **Activity and social pattern:** migratory and seasonally patterned; mostly solitary or temporary groups.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **long-range voice and return**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Humpback Whale occupies the role of **long-range voice and return**. Unlike Elephant, Humpback carries memory and communication through ocean-scale movement and sound rather than stable matriarchal land groups.

## Gifts

- **Long-Range Expression:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Migration:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Depth-To-Surface Integration:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Emotional Flooding:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Nostalgia:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Disappearing Into Vastness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **long-range expression** can produce **emotional flooding** when safety, timing, or relationship is lost. **migration** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **depth-to-surface integration** available while loosening the demand to live through **nostalgia**.

## Balanced expression

A balanced expression combines long-range expression, migration, and depth-to-surface integration. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when long-range expression turns into emotional flooding, or when depth-to-surface integration dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding long-range expression, distrusting migration, or surrendering depth-to-surface integration even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **long-range expression**; ask whether **emotional flooding** is driving or distorting it. |
| Relationships | Practice **migration** without asking another person to absorb **nostalgia**. |
| Community | The group may need the **long-range voice and return** role, with explicit limits against **disappearing into vastness**. |
| Work and vocation | Use **depth-to-surface integration** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they use complex vocalizations, including population-specific songs produced by males, and varied feeding strategies. |
| Conflict | Choose the proportionate form of **long-range expression** rather than escalating into **emotional flooding**. |
| Healing and restoration | Restore access to **migration** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **depth-to-surface integration** without repeating **nostalgia**. |
| Change and transition | Use Humpback Whale as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **long-range expression** accountable to others and monitor for **disappearing into vastness**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is long-range expression already alive in my situation?
2. When does migration become difficult to receive or sustain?
3. Could emotional flooding be protecting something that needs a safer strategy?
4. Am I overexpressing depth-to-surface integration or suppressing it?
5. What does the open ocean context teach me about the conditions this quality needs?
6. Where does my analogy with Humpback Whale stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Write the message you would send across a great distance. Reduce it to one honest sentence and decide whether to speak, send, or simply keep it.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Humpback Whale. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Humpback Whale represents long-range voice and return. The synthesis derives from the verified behaviors above and adopts long-range expression as the primary Gift and emotional flooding as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Laysan Albatross](027-laysan-albatross.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Common Eastern Firefly](055-common-eastern-firefly.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Monarch Butterfly](051-monarch-butterfly.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Common Eastern Firefly](055-common-eastern-firefly.md) can reveal a related defense in another form.
- **Productive tension:** [Common Eastern Firefly](055-common-eastern-firefly.md) and Humpback Whale ask for both timely illumination and long-range voice and return.
- **Commonly confused:** [Laysan Albatross](027-laysan-albatross.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Humpback Whale in open ocean, engaged in the behavior described here: humpbacks migrate between high-latitude feeding areas and lower-latitude breeding grounds. Emphasize real anatomy, ecological context, and the tension between long-range expression and emotional flooding. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.fisheries.noaa.gov/species/humpback-whale) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
