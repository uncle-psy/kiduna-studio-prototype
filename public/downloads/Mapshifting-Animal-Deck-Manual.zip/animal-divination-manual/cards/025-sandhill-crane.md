---
card_number: 25
animal: "Sandhill Crane"
slug: "sandhill-crane"
scientific_name: "Antigone canadensis"
alternate_names: ["crane"]
taxonomic_group: "Bird"
habitats: ["marsh", "wet meadow", "prairie", "river shallows"]
geographic_range: ["North America", "northeastern Siberia", "Mexico and southern wintering grounds"]
activity_cycle: "diurnal; migratory populations seasonal"
social_pattern: "long-term pairs, families, and large migratory flocks"
core_archetype: "attentive fidelity"
primary_gifts: ["fidelity", "ceremonial attention", "long-distance return"]
primary_wounds: ["idealization", "performance", "fear of separation"]
elemental_associations: ["air", "water"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# Sandhill Crane

## Essence

Sandhill Crane teaches **attentive fidelity**: fidelity becomes trustworthy when it stays connected to ceremonial attention and does not harden into idealization.

## Keywords

fidelity, ceremonial attention, long-distance return, idealization, performance, fear of separation.

## The living animal

### Natural-history facts

- Sandhill cranes form enduring pair bonds reinforced by coordinated calls and dancing displays.
- Families remain together through migration and winter before young separate.
- Large flocks gather at roosts and staging areas, while breeding pairs defend wetland territories.
- **Ecological role:** Cranes connect wetland and upland habitats and depend on safe migration corridors.
- **Habitat and range:** marsh, wet meadow, prairie, river shallows; North America, northeastern Siberia, Mexico and southern wintering grounds.
- **Activity and social pattern:** diurnal; migratory populations seasonal; long-term pairs, families, and large migratory flocks.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **attentive fidelity**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Sandhill Crane occupies the role of **attentive fidelity**. Unlike Atlantic Salmon, Crane returns through learned social migration and pair/family continuity rather than natal-stream imprinting.

## Gifts

- **Fidelity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Ceremonial Attention:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Long-Distance Return:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Idealization:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Performance:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Fear Of Separation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **fidelity** can produce **idealization** when safety, timing, or relationship is lost. **ceremonial attention** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **long-distance return** available while loosening the demand to live through **performance**.

## Balanced expression

A balanced expression combines fidelity, ceremonial attention, and long-distance return. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when fidelity turns into idealization, or when long-distance return dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding fidelity, distrusting ceremonial attention, or surrendering long-distance return even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **fidelity**; ask whether **idealization** is driving or distorting it. |
| Relationships | Practice **ceremonial attention** without asking another person to absorb **performance**. |
| Community | The group may need the **attentive fidelity** role, with explicit limits against **fear of separation**. |
| Work and vocation | Use **long-distance return** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: families remain together through migration and winter before young separate. |
| Conflict | Choose the proportionate form of **fidelity** rather than escalating into **idealization**. |
| Healing and restoration | Restore access to **ceremonial attention** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **long-distance return** without repeating **performance**. |
| Change and transition | Use Sandhill Crane as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **fidelity** accountable to others and monitor for **fear of separation**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is fidelity already alive in my situation?
2. When does ceremonial attention become difficult to receive or sustain?
3. Could idealization be protecting something that needs a safer strategy?
4. Am I overexpressing long-distance return or suppressing it?
5. What does the marsh context teach me about the conditions this quality needs?
6. Where does my analogy with Sandhill Crane stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Create a small, repeatable gesture that renews a real commitment. Ask whether the gesture supports the relationship or substitutes for honest conversation.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Japanese art | A 1913 Japanese artwork record identifies the red-crowned crane with marital fidelity and longevity. The species differs from the sandhill crane. | Modern Japanese painting using older auspicious imagery | cultural | medium | [Met, Tomioka Tessai, *Nine Auspicious Symbols*](https://www.metmuseum.org/art/collection/search/853226) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Sandhill Crane. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Sandhill Crane represents attentive fidelity. The synthesis derives from the verified behaviors above and adopts fidelity as the primary Gift and idealization as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Domestic Horse](008-domestic-horse.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Caribbean Hermit Crab](062-caribbean-hermit-crab.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Domestic Horse](008-domestic-horse.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Caribbean Hermit Crab](062-caribbean-hermit-crab.md) can reveal a related defense in another form.
- **Productive tension:** [Caribbean Hermit Crab](062-caribbean-hermit-crab.md) and Sandhill Crane ask for both adaptive housing and attentive fidelity.
- **Commonly confused:** [Domestic Horse](008-domestic-horse.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Sandhill Crane in marsh, engaged in the behavior described here: sandhill cranes form enduring pair bonds reinforced by coordinated calls and dancing displays. Emphasize real anatomy, ecological context, and the tension between fidelity and idealization. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.allaboutbirds.org/guide/Sandhill_Crane/lifehistory) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Met, Tomioka Tessai, *Nine Auspicious Symbols*](https://www.metmuseum.org/art/collection/search/853226) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
