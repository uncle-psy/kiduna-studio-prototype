---
card_number: 18
animal: "Platypus"
slug: "platypus"
scientific_name: "Ornithorhynchus anatinus"
alternate_names: ["duck-billed platypus"]
taxonomic_group: "Mammal"
habitats: ["freshwater river", "stream", "riparian bank"]
geographic_range: ["eastern Australia", "Tasmania"]
activity_cycle: "mostly nocturnal or crepuscular"
social_pattern: "mostly solitary"
core_archetype: "integrative originality"
primary_gifts: ["integrative originality", "electrosensory intuition", "boundary-crossing"]
primary_wounds: ["alienation", "contrarian identity", "confusion through hybridity"]
elemental_associations: ["water", "earth"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Platypus

## Essence

Platypus teaches **integrative originality**: integrative originality becomes trustworthy when it stays connected to electrosensory intuition and does not harden into alienation.

## Keywords

integrative originality, electrosensory intuition, boundary-crossing, alienation, contrarian identity, confusion through hybridity.

## The living animal

### Natural-history facts

- Platypuses are egg-laying mammals with dense fur, webbed feet, and a bill rich in sensory receptors.
- Underwater they close eyes, ears, and nostrils and locate prey partly through electroreception and touch.
- They rest and nest in riverbank burrows; males possess venomous ankle spurs.
- **Ecological role:** They forage on aquatic invertebrates and depend on healthy freshwater and bank habitat.
- **Habitat and range:** freshwater river, stream, riparian bank; eastern Australia, Tasmania.
- **Activity and social pattern:** mostly nocturnal or crepuscular; mostly solitary.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **integrative originality**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Platypus occupies the role of **integrative originality**. Unlike Axolotl, Platypus integrates traits that appear contradictory while remaining fully adapted, not developmentally unfinished.

## Gifts

- **Integrative Originality:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Electrosensory Intuition:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Boundary-Crossing:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Alienation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Contrarian Identity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Confusion Through Hybridity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **integrative originality** can produce **alienation** when safety, timing, or relationship is lost. **electrosensory intuition** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **boundary-crossing** available while loosening the demand to live through **contrarian identity**.

## Balanced expression

A balanced expression combines integrative originality, electrosensory intuition, and boundary-crossing. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when integrative originality turns into alienation, or when boundary-crossing dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding integrative originality, distrusting electrosensory intuition, or surrendering boundary-crossing even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **integrative originality**; ask whether **alienation** is driving or distorting it. |
| Relationships | Practice **electrosensory intuition** without asking another person to absorb **contrarian identity**. |
| Community | The group may need the **integrative originality** role, with explicit limits against **confusion through hybridity**. |
| Work and vocation | Use **boundary-crossing** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: underwater they close eyes, ears, and nostrils and locate prey partly through electroreception and touch. |
| Conflict | Choose the proportionate form of **integrative originality** rather than escalating into **alienation**. |
| Healing and restoration | Restore access to **electrosensory intuition** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **boundary-crossing** without repeating **contrarian identity**. |
| Change and transition | Use Platypus as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **integrative originality** accountable to others and monitor for **confusion through hybridity**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is integrative originality already alive in my situation?
2. When does electrosensory intuition become difficult to receive or sustain?
3. Could alienation be protecting something that needs a safer strategy?
4. Am I overexpressing boundary-crossing or suppressing it?
5. What does the freshwater river context teach me about the conditions this quality needs?
6. Where does my analogy with Platypus stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

List three parts of yourself or a project that seem incompatible. Design one small task in which all three become useful rather than requiring a single identity.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Platypus. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Platypus represents integrative originality. The synthesis derives from the verified behaviors above and adopts integrative originality as the primary Gift and alienation as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Axolotl](038-axolotl.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Bald Eagle](019-bald-eagle.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Axolotl](038-axolotl.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Bald Eagle](019-bald-eagle.md) can reveal a related defense in another form.
- **Productive tension:** [Bald Eagle](019-bald-eagle.md) and Platypus ask for both wide perspective with accountable descent and integrative originality.
- **Commonly confused:** [Axolotl](038-axolotl.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Platypus in freshwater river, engaged in the behavior described here: platypuses are egg-laying mammals with dense fur, webbed feet, and a bill rich in sensory receptors. Emphasize real anatomy, ecological context, and the tension between integrative originality and alienation. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Ornithorhynchus_anatinus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
