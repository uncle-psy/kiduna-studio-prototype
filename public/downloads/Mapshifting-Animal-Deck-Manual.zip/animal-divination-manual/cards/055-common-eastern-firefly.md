---
card_number: 55
animal: "Common Eastern Firefly"
slug: "common-eastern-firefly"
scientific_name: "Photinus pyralis"
alternate_names: ["lightning bug", "firefly"]
taxonomic_group: "Insect"
habitats: ["meadow", "woodland edge", "garden", "moist field"]
geographic_range: ["eastern North America"]
activity_cycle: "crepuscular and nocturnal"
social_pattern: "dispersed adults using species-specific signals"
core_archetype: "timely illumination"
primary_gifts: ["timely signal", "modest illumination", "authentic attraction"]
primary_wounds: ["approval-seeking display", "fleeting focus", "visibility risk"]
elemental_associations: ["fire", "air"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Common Eastern Firefly

## Essence

Common Eastern Firefly teaches **timely illumination**: timely signal becomes trustworthy when it stays connected to modest illumination and does not harden into approval-seeking display.

## Keywords

timely signal, modest illumination, authentic attraction, approval-seeking display, fleeting focus, visibility risk.

## The living animal

### Natural-history facts

- Adult fireflies produce species-specific bioluminescent courtship flashes through controlled chemistry.
- Larvae live in or near soil and prey on small invertebrates, while adult feeding varies.
- Artificial light can disrupt signal visibility and mating communication.
- **Ecological role:** Fireflies connect moist ground habitat, nocturnal predation, and light-sensitive reproduction.
- **Habitat and range:** meadow, woodland edge, garden, moist field; eastern North America.
- **Activity and social pattern:** crepuscular and nocturnal; dispersed adults using species-specific signals.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **timely illumination**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Common Eastern Firefly occupies the role of **timely illumination**. Unlike Electric Eel, Firefly sends visible social signals into darkness rather than using electricity to map and subdue nearby space.

## Gifts

- **Timely Signal:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Modest Illumination:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Authentic Attraction:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Approval-Seeking Display:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Fleeting Focus:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Visibility Risk:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **timely signal** can produce **approval-seeking display** when safety, timing, or relationship is lost. **modest illumination** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **authentic attraction** available while loosening the demand to live through **fleeting focus**.

## Balanced expression

A balanced expression combines timely signal, modest illumination, and authentic attraction. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when timely signal turns into approval-seeking display, or when authentic attraction dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding timely signal, distrusting modest illumination, or surrendering authentic attraction even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **timely signal**; ask whether **approval-seeking display** is driving or distorting it. |
| Relationships | Practice **modest illumination** without asking another person to absorb **fleeting focus**. |
| Community | The group may need the **timely illumination** role, with explicit limits against **visibility risk**. |
| Work and vocation | Use **authentic attraction** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: larvae live in or near soil and prey on small invertebrates, while adult feeding varies. |
| Conflict | Choose the proportionate form of **timely signal** rather than escalating into **approval-seeking display**. |
| Healing and restoration | Restore access to **modest illumination** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **authentic attraction** without repeating **fleeting focus**. |
| Change and transition | Use Common Eastern Firefly as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **timely signal** accountable to others and monitor for **visibility risk**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is timely signal already alive in my situation?
2. When does modest illumination become difficult to receive or sustain?
3. Could approval-seeking display be protecting something that needs a safer strategy?
4. Am I overexpressing authentic attraction or suppressing it?
5. What does the meadow context teach me about the conditions this quality needs?
6. Where does my analogy with Common Eastern Firefly stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Craft one brief signal that says what you want without overexplaining. Send it where it can actually be seen, then allow response time.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Common Eastern Firefly. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Common Eastern Firefly represents timely illumination. The synthesis derives from the verified behaviors above and adopts timely signal as the primary Gift and approval-seeking display as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Electric Eel](046-electric-eel.md) expands the Gift through a different ecological strategy.
- **Balancing:** [American Black Bear](005-american-black-bear.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Electric Eel](046-electric-eel.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [American Black Bear](005-american-black-bear.md) can reveal a related defense in another form.
- **Productive tension:** [American Black Bear](005-american-black-bear.md) and Common Eastern Firefly ask for both resourceful retreat and timely illumination.
- **Commonly confused:** [Electric Eel](046-electric-eel.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Common Eastern Firefly in meadow, engaged in the behavior described here: adult fireflies produce species-specific bioluminescent courtship flashes through controlled chemistry. Emphasize real anatomy, ecological context, and the tension between timely signal and approval-seeking display. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Photinus_pyralis/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Regional firefly species differ; light pollution impacts need local evidence.
- No direct quotation from a commercial guidebook was used.
