---
card_number: 44
animal: "Ocellaris Clownfish"
slug: "ocellaris-clownfish"
scientific_name: "Amphiprion ocellaris"
alternate_names: ["clown anemonefish"]
taxonomic_group: "Fish"
habitats: ["coral reef", "sea anemone habitat"]
geographic_range: ["eastern Indian Ocean", "western Pacific Ocean"]
activity_cycle: "diurnal"
social_pattern: "anemone-based social groups with dominance hierarchy"
core_archetype: "mutual belonging"
primary_gifts: ["mutualism", "home defense", "adaptive role change"]
primary_wounds: ["overdependence", "territoriality", "identity confined to one system"]
elemental_associations: ["water", "fire"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Ocellaris Clownfish

## Essence

Ocellaris Clownfish teaches **mutual belonging**: mutualism becomes trustworthy when it stays connected to home defense and does not harden into overdependence.

## Keywords

mutualism, home defense, adaptive role change, overdependence, territoriality, identity confined to one system.

## The living animal

### Natural-history facts

- Clownfish live among host anemone tentacles through a protective mucus relationship.
- Groups have a size-based hierarchy; when the breeding female is lost, the dominant male can change sex and assume the role.
- They tend eggs near the host and defend a small home area.
- **Ecological role:** Fish provide movement, nutrients, and defense around the anemone while receiving refuge.
- **Habitat and range:** coral reef, sea anemone habitat; eastern Indian Ocean, western Pacific Ocean.
- **Activity and social pattern:** diurnal; anemone-based social groups with dominance hierarchy.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **mutual belonging**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Ocellaris Clownfish occupies the role of **mutual belonging**. Unlike Hermit Crab, Clownfish adapts role within a stable living partnership rather than repeatedly changing borrowed shelter.

## Gifts

- **Mutualism:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Home Defense:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Adaptive Role Change:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Overdependence:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Territoriality:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Identity Confined To One System:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **mutualism** can produce **overdependence** when safety, timing, or relationship is lost. **home defense** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **adaptive role change** available while loosening the demand to live through **territoriality**.

## Balanced expression

A balanced expression combines mutualism, home defense, and adaptive role change. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when mutualism turns into overdependence, or when adaptive role change dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding mutualism, distrusting home defense, or surrendering adaptive role change even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **mutualism**; ask whether **overdependence** is driving or distorting it. |
| Relationships | Practice **home defense** without asking another person to absorb **territoriality**. |
| Community | The group may need the **mutual belonging** role, with explicit limits against **identity confined to one system**. |
| Work and vocation | Use **adaptive role change** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: groups have a size-based hierarchy; when the breeding female is lost, the dominant male can change sex and assume the role. |
| Conflict | Choose the proportionate form of **mutualism** rather than escalating into **overdependence**. |
| Healing and restoration | Restore access to **home defense** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **adaptive role change** without repeating **territoriality**. |
| Change and transition | Use Ocellaris Clownfish as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **mutualism** accountable to others and monitor for **identity confined to one system**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is mutualism already alive in my situation?
2. When does home defense become difficult to receive or sustain?
3. Could overdependence be protecting something that needs a safer strategy?
4. Am I overexpressing adaptive role change or suppressing it?
5. What does the coral reef context teach me about the conditions this quality needs?
6. Where does my analogy with Ocellaris Clownfish stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Name what you give and receive in one mutual relationship. Imagine how roles could change if the current structure stopped serving life.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Ocellaris Clownfish. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Ocellaris Clownfish represents mutual belonging. The synthesis derives from the verified behaviors above and adopts mutualism as the primary Gift and overdependence as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Caribbean Hermit Crab](062-caribbean-hermit-crab.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Laysan Albatross](027-laysan-albatross.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Caribbean Hermit Crab](062-caribbean-hermit-crab.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Laysan Albatross](027-laysan-albatross.md) can reveal a related defense in another form.
- **Productive tension:** [Laysan Albatross](027-laysan-albatross.md) and Ocellaris Clownfish ask for both oceanic patience and mutual belonging.
- **Commonly confused:** [Caribbean Hermit Crab](062-caribbean-hermit-crab.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Ocellaris Clownfish in coral reef, engaged in the behavior described here: clownfish live among host anemone tentacles through a protective mucus relationship. Emphasize real anatomy, ecological context, and the tension between mutualism and overdependence. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Amphiprion_ocellaris/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
