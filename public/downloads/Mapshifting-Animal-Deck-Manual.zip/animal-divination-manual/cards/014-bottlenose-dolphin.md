---
card_number: 14
animal: "Common Bottlenose Dolphin"
slug: "bottlenose-dolphin"
scientific_name: "Tursiops truncatus"
alternate_names: ["bottlenose dolphin"]
taxonomic_group: "Mammal"
habitats: ["coastal ocean", "continental shelf", "bays", "estuaries"]
geographic_range: ["temperate and tropical seas worldwide"]
activity_cycle: "day and night"
social_pattern: "fission-fusion societies"
core_archetype: "communicative cooperation"
primary_gifts: ["communication", "cooperative intelligence", "play"]
primary_wounds: ["social manipulation", "stimulation seeking", "group pressure"]
elemental_associations: ["water", "air"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Common Bottlenose Dolphin

## Essence

Common Bottlenose Dolphin teaches **communicative cooperation**: communication becomes trustworthy when it stays connected to cooperative intelligence and does not harden into social manipulation.

## Keywords

communication, cooperative intelligence, play, social manipulation, stimulation seeking, group pressure.

## The living animal

### Natural-history facts

- Bottlenose dolphins use whistles, clicks, body contact, posture, and learned behavior in fluid social networks.
- Echolocation supports navigation and prey detection; cooperative foraging strategies vary by population.
- Individuals form changing alliances and associations rather than one permanent pod structure.
- **Ecological role:** Dolphins are mobile predators whose health is affected by prey, noise, fisheries interaction, pollution, and habitat.
- **Habitat and range:** coastal ocean, continental shelf, bays, estuaries; temperate and tropical seas worldwide.
- **Activity and social pattern:** day and night; fission-fusion societies.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **communicative cooperation**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Common Bottlenose Dolphin occupies the role of **communicative cooperation**. Unlike Otter, Dolphin emphasizes distributed communication, alliance, and wide acoustic space.

## Gifts

- **Communication:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Cooperative Intelligence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Play:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Social Manipulation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Stimulation Seeking:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Group Pressure:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **communication** can produce **social manipulation** when safety, timing, or relationship is lost. **cooperative intelligence** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **play** available while loosening the demand to live through **stimulation seeking**.

## Balanced expression

A balanced expression combines communication, cooperative intelligence, and play. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when communication turns into social manipulation, or when play dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding communication, distrusting cooperative intelligence, or surrendering play even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **communication**; ask whether **social manipulation** is driving or distorting it. |
| Relationships | Practice **cooperative intelligence** without asking another person to absorb **stimulation seeking**. |
| Community | The group may need the **communicative cooperation** role, with explicit limits against **group pressure**. |
| Work and vocation | Use **play** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: echolocation supports navigation and prey detection; cooperative foraging strategies vary by population. |
| Conflict | Choose the proportionate form of **communication** rather than escalating into **social manipulation**. |
| Healing and restoration | Restore access to **cooperative intelligence** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **play** without repeating **stimulation seeking**. |
| Change and transition | Use Common Bottlenose Dolphin as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **communication** accountable to others and monitor for **group pressure**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is communication already alive in my situation?
2. When does cooperative intelligence become difficult to receive or sustain?
3. Could social manipulation be protecting something that needs a safer strategy?
4. Am I overexpressing play or suppressing it?
5. What does the coastal ocean context teach me about the conditions this quality needs?
6. Where does my analogy with Common Bottlenose Dolphin stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Ask one clarifying question in a group instead of relying on social inference. Notice whether play increases trust or avoids a needed truth.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Common Bottlenose Dolphin. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Common Bottlenose Dolphin represents communicative cooperation. The synthesis derives from the verified behaviors above and adopts communication as the primary Gift and social manipulation as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [North American River Otter](012-north-american-river-otter.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Great White Shark](042-great-white-shark.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Western Honey Bee](050-western-honey-bee.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Great White Shark](042-great-white-shark.md) can reveal a related defense in another form.
- **Productive tension:** [Great White Shark](042-great-white-shark.md) and Common Bottlenose Dolphin ask for both decisive sensory clarity and communicative cooperation.
- **Commonly confused:** [North American River Otter](012-north-american-river-otter.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Common Bottlenose Dolphin in coastal ocean, engaged in the behavior described here: bottlenose dolphins use whistles, clicks, body contact, posture, and learned behavior in fluid social networks. Emphasize real anatomy, ecological context, and the tension between communication and social manipulation. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.fisheries.noaa.gov/species/common-bottlenose-dolphin) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
