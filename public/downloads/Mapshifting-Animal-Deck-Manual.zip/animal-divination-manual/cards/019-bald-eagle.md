---
card_number: 19
animal: "Bald Eagle"
slug: "bald-eagle"
scientific_name: "Haliaeetus leucocephalus"
alternate_names: ["American bald eagle"]
taxonomic_group: "Bird"
habitats: ["coast", "lake", "river", "wetland"]
geographic_range: ["North America"]
activity_cycle: "diurnal"
social_pattern: "pairs, family groups, and feeding aggregations"
core_archetype: "wide perspective with accountable descent"
primary_gifts: ["wide perspective", "decisive focus", "stewardship"]
primary_wounds: ["superiority", "status fixation", "distance from consequence"]
elemental_associations: ["air", "water"]
seasonal_associations: ["winter"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# Bald Eagle

## Essence

Bald Eagle teaches **wide perspective with accountable descent**: wide perspective becomes trustworthy when it stays connected to decisive focus and does not harden into superiority.

## Keywords

wide perspective, decisive focus, stewardship, superiority, status fixation, distance from consequence.

## The living animal

### Natural-history facts

- Bald eagles use powerful flight and keen vision to find fish, carrion, waterbirds, and other food.
- Pairs often reuse and enlarge large nests near water over multiple years.
- They may hunt, scavenge, or pirate food, showing flexibility beyond a simple noble-predator image.
- **Ecological role:** As large scavengers and predators, eagles link aquatic and terrestrial food webs.
- **Habitat and range:** coast, lake, river, wetland; North America.
- **Activity and social pattern:** diurnal; pairs, family groups, and feeding aggregations.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **wide perspective with accountable descent**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Bald Eagle occupies the role of **wide perspective with accountable descent**. Unlike Red-tailed Hawk, Eagle emphasizes broad territorial perspective and public responsibility more than close-field surveillance.

## Gifts

- **Wide Perspective:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Decisive Focus:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Stewardship:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Superiority:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Status Fixation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Distance From Consequence:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **wide perspective** can produce **superiority** when safety, timing, or relationship is lost. **decisive focus** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **stewardship** available while loosening the demand to live through **status fixation**.

## Balanced expression

A balanced expression combines wide perspective, decisive focus, and stewardship. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when wide perspective turns into superiority, or when stewardship dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding wide perspective, distrusting decisive focus, or surrendering stewardship even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **wide perspective**; ask whether **superiority** is driving or distorting it. |
| Relationships | Practice **decisive focus** without asking another person to absorb **status fixation**. |
| Community | The group may need the **wide perspective with accountable descent** role, with explicit limits against **distance from consequence**. |
| Work and vocation | Use **stewardship** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: pairs often reuse and enlarge large nests near water over multiple years. |
| Conflict | Choose the proportionate form of **wide perspective** rather than escalating into **superiority**. |
| Healing and restoration | Restore access to **decisive focus** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **stewardship** without repeating **status fixation**. |
| Change and transition | Use Bald Eagle as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **wide perspective** accountable to others and monitor for **distance from consequence**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is wide perspective already alive in my situation?
2. When does decisive focus become difficult to receive or sustain?
3. Could superiority be protecting something that needs a safer strategy?
4. Am I overexpressing stewardship or suppressing it?
5. What does the coast context teach me about the conditions this quality needs?
6. Where does my analogy with Bald Eagle stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Move from overview to accountability: name one consequence on the ground that your strategic view has overlooked, and address it.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Greek and Roman art | A Roman lamp record identifies the eagle with Zeus/Jupiter and notes later imperial association. | Roman, late 1st–early 2nd century CE | historical | high | [Met, terracotta oil lamp](https://www.metmuseum.org/art/collection/search/241625) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Bald Eagle. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Bald Eagle represents wide perspective with accountable descent. The synthesis derives from the verified behaviors above and adopts wide perspective as the primary Gift and superiority as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Red-tailed Hawk](022-red-tailed-hawk.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Common Earthworm](068-common-earthworm.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Red-tailed Hawk](022-red-tailed-hawk.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [African Lion](002-african-lion.md) can reveal a related defense in another form.
- **Productive tension:** [Common Earthworm](068-common-earthworm.md) and Bald Eagle ask for both humble transformation and wide perspective with accountable descent.
- **Commonly confused:** [Red-tailed Hawk](022-red-tailed-hawk.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Bald Eagle in coast, engaged in the behavior described here: bald eagles use powerful flight and keen vision to find fish, carrion, waterbirds, and other food. Emphasize real anatomy, ecological context, and the tension between wide perspective and superiority. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.allaboutbirds.org/guide/Bald_Eagle/lifehistory) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Met, terracotta oil lamp](https://www.metmuseum.org/art/collection/search/241625) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
