---
card_number: 34
animal: "American Alligator"
slug: "american-alligator"
scientific_name: "Alligator mississippiensis"
alternate_names: ["alligator"]
taxonomic_group: "Reptile"
habitats: ["swamp", "marsh", "river", "lake"]
geographic_range: ["southeastern United States"]
activity_cycle: "mostly crepuscular and nocturnal; temperature-dependent"
social_pattern: "mostly solitary with seasonal aggregations"
core_archetype: "patient threshold defense"
primary_gifts: ["patience", "survival memory", "threshold defense"]
primary_wounds: ["ambush mindset", "emotional armoring", "territorial aggression"]
elemental_associations: ["water", "earth"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# American Alligator

## Essence

American Alligator teaches **patient threshold defense**: patience becomes trustworthy when it stays connected to survival memory and does not harden into ambush mindset.

## Keywords

patience, survival memory, threshold defense, ambush mindset, emotional armoring, territorial aggression.

## The living animal

### Natural-history facts

- Alligators are ambush predators that use water edges, stealth, and rapid short-range power.
- Females build vegetation nests, guard them, and may assist hatchlings.
- They create and maintain depressions that can hold water during dry periods.
- **Ecological role:** Alligator holes can provide refuge for other wetland species; alligators are both predators and ecosystem engineers.
- **Habitat and range:** swamp, marsh, river, lake; southeastern United States.
- **Activity and social pattern:** mostly crepuscular and nocturnal; temperature-dependent; mostly solitary with seasonal aggregations.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **patient threshold defense**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

American Alligator occupies the role of **patient threshold defense**. Unlike King Cobra, Alligator protects through submerged patience and sudden force rather than raised warning and visual display.

## Gifts

- **Patience:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Survival Memory:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Threshold Defense:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Ambush Mindset:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Emotional Armoring:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Territorial Aggression:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **patience** can produce **ambush mindset** when safety, timing, or relationship is lost. **survival memory** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **threshold defense** available while loosening the demand to live through **emotional armoring**.

## Balanced expression

A balanced expression combines patience, survival memory, and threshold defense. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when patience turns into ambush mindset, or when threshold defense dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding patience, distrusting survival memory, or surrendering threshold defense even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **patience**; ask whether **ambush mindset** is driving or distorting it. |
| Relationships | Practice **survival memory** without asking another person to absorb **emotional armoring**. |
| Community | The group may need the **patient threshold defense** role, with explicit limits against **territorial aggression**. |
| Work and vocation | Use **threshold defense** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: females build vegetation nests, guard them, and may assist hatchlings. |
| Conflict | Choose the proportionate form of **patience** rather than escalating into **ambush mindset**. |
| Healing and restoration | Restore access to **survival memory** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **threshold defense** without repeating **emotional armoring**. |
| Change and transition | Use American Alligator as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **patience** accountable to others and monitor for **territorial aggression**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is patience already alive in my situation?
2. When does survival memory become difficult to receive or sustain?
3. Could ambush mindset be protecting something that needs a safer strategy?
4. Am I overexpressing threshold defense or suppressing it?
5. What does the swamp context teach me about the conditions this quality needs?
6. Where does my analogy with American Alligator stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Before reacting, decide whether you are waiting strategically or rehearsing an ambush. Replace one hidden test with a stated expectation.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Ancient Egypt—comparative crocodilian note | Sobek is shown as a crowned crocodile associated with water and fertility. Crocodile imagery must not be assigned directly to alligators without this species caveat. | New Kingdom, ca. 1300–1080 BCE | historical | low | [Met, *Scarab with Sobek and Wadjet*](https://www.metmuseum.org/art/collection/search/553403) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for American Alligator. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** American Alligator represents patient threshold defense. The synthesis derives from the verified behaviors above and adopts patience as the primary Gift and ambush mindset as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Ochre Sea Star](065-ochre-sea-star.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Ruby-throated Hummingbird](023-ruby-throated-hummingbird.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Ochre Sea Star](065-ochre-sea-star.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Ruby-throated Hummingbird](023-ruby-throated-hummingbird.md) can reveal a related defense in another form.
- **Productive tension:** [Ruby-throated Hummingbird](023-ruby-throated-hummingbird.md) and American Alligator ask for both precise energetic exchange and patient threshold defense.
- **Commonly confused:** [Ochre Sea Star](065-ochre-sea-star.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show American Alligator in swamp, engaged in the behavior described here: alligators are ambush predators that use water edges, stealth, and rapid short-range power. Emphasize real anatomy, ecological context, and the tension between patience and ambush mindset. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Alligator_mississippiensis/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Met, *Scarab with Sobek and Wadjet*](https://www.metmuseum.org/art/collection/search/553403) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- The cultural comparison concerns ancient Egyptian crocodile imagery, not alligators.
- No direct quotation from a commercial guidebook was used.
