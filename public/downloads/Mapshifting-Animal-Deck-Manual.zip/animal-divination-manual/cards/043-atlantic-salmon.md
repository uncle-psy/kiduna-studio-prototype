---
card_number: 43
animal: "Atlantic Salmon"
slug: "atlantic-salmon"
scientific_name: "Salmo salar"
alternate_names: ["salmon"]
taxonomic_group: "Fish"
habitats: ["river", "stream", "estuary", "North Atlantic ocean"]
geographic_range: ["North Atlantic basin"]
activity_cycle: "seasonal migration"
social_pattern: "schools at some stages; dispersive at sea"
core_archetype: "return informed by place-memory"
primary_gifts: ["return", "persistence", "place-memory"]
primary_wounds: ["compulsive return", "exhaustion", "identity bound to origin"]
elemental_associations: ["water", "earth"]
seasonal_associations: ["autumn"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Atlantic Salmon

## Essence

Atlantic Salmon teaches **return informed by place-memory**: return becomes trustworthy when it stays connected to persistence and does not harden into compulsive return.

## Keywords

return, persistence, place-memory, compulsive return, exhaustion, identity bound to origin.

## The living animal

### Natural-history facts

- Atlantic salmon begin in freshwater, migrate to sea, and return to freshwater to reproduce.
- Juveniles imprint on natal-water cues; adults use multiple senses during long navigation.
- Unlike most Pacific salmon, some Atlantic salmon survive spawning and may return again.
- **Ecological role:** They move nutrients between ocean and river and depend on connected, cool, clean waters.
- **Habitat and range:** river, stream, estuary, North Atlantic ocean; North Atlantic basin.
- **Activity and social pattern:** seasonal migration; schools at some stages; dispersive at sea.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **return informed by place-memory**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Atlantic Salmon occupies the role of **return informed by place-memory**. Unlike Sandhill Crane, Salmon returns through aquatic life-stage transformation and natal cues rather than family-guided flight.

## Gifts

- **Return:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Persistence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Place-Memory:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Compulsive Return:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Exhaustion:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Identity Bound To Origin:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **return** can produce **compulsive return** when safety, timing, or relationship is lost. **persistence** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **place-memory** available while loosening the demand to live through **exhaustion**.

## Balanced expression

A balanced expression combines return, persistence, and place-memory. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when return turns into compulsive return, or when place-memory dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding return, distrusting persistence, or surrendering place-memory even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **return**; ask whether **compulsive return** is driving or distorting it. |
| Relationships | Practice **persistence** without asking another person to absorb **exhaustion**. |
| Community | The group may need the **return informed by place-memory** role, with explicit limits against **identity bound to origin**. |
| Work and vocation | Use **place-memory** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: juveniles imprint on natal-water cues; adults use multiple senses during long navigation. |
| Conflict | Choose the proportionate form of **return** rather than escalating into **compulsive return**. |
| Healing and restoration | Restore access to **persistence** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **place-memory** without repeating **exhaustion**. |
| Change and transition | Use Atlantic Salmon as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **return** accountable to others and monitor for **identity bound to origin**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is return already alive in my situation?
2. When does persistence become difficult to receive or sustain?
3. Could compulsive return be protecting something that needs a safer strategy?
4. Am I overexpressing place-memory or suppressing it?
5. What does the river context teach me about the conditions this quality needs?
6. Where does my analogy with Atlantic Salmon stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Return to a formative place in memory or writing. Keep the resource it gave you without assuming you must reproduce the old conditions.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Atlantic Salmon. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Atlantic Salmon represents return informed by place-memory. The synthesis derives from the verified behaviors above and adopts return as the primary Gift and compulsive return as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Green Sea Turtle](032-green-sea-turtle.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Red Fox](004-red-fox.md) interrupts this card's likely overexpression.
- **Shared Gift:** [North American Beaver](011-north-american-beaver.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Red Fox](004-red-fox.md) can reveal a related defense in another form.
- **Productive tension:** [Red Fox](004-red-fox.md) and Atlantic Salmon ask for both adaptive edge-walker and return informed by place-memory.
- **Commonly confused:** [Green Sea Turtle](032-green-sea-turtle.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Atlantic Salmon in river, engaged in the behavior described here: atlantic salmon begin in freshwater, migrate to sea, and return to freshwater to reproduce. Emphasize real anatomy, ecological context, and the tension between return and compulsive return. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Salmo_salar/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Wild population status varies sharply; North American protected populations require NOAA review.
- No direct quotation from a commercial guidebook was used.
