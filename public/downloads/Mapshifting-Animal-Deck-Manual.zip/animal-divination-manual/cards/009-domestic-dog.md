---
card_number: 9
animal: "Domestic Dog"
slug: "domestic-dog"
scientific_name: "Canis lupus familiaris"
alternate_names: ["dog"]
taxonomic_group: "Mammal"
habitats: ["human settlements", "homes", "working landscapes"]
geographic_range: ["worldwide under human association"]
activity_cycle: "variable with household and work"
social_pattern: "human-dog groups; highly variable conspecific sociality"
core_archetype: "reciprocal trust"
primary_gifts: ["reciprocity", "loyalty", "attunement"]
primary_wounds: ["dependency", "people-pleasing", "guarding anxiety"]
elemental_associations: ["earth", "water"]
seasonal_associations: ["all seasons"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# Domestic Dog

## Essence

Domestic Dog teaches **reciprocal trust**: reciprocity becomes trustworthy when it stays connected to loyalty and does not harden into dependency.

## Keywords

reciprocity, loyalty, attunement, dependency, people-pleasing, guarding anxiety.

## The living animal

### Natural-history facts

- Dogs have been shaped by long domestication, selective breeding, work, and companionship with people.
- They read human gestures and routines with unusual skill, while welfare and behavior vary across individual history and breed.
- Scent is central to canine perception, communication, tracking, and environmental exploration.
- **Ecological role:** Dogs occupy roles from companions and free-ranging scavengers to herders, guardians, detectors, and assistance animals.
- **Habitat and range:** human settlements, homes, working landscapes; worldwide under human association.
- **Activity and social pattern:** variable with household and work; human-dog groups; highly variable conspecific sociality.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **reciprocal trust**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Domestic Dog occupies the role of **reciprocal trust**. Unlike Wolf, Dog asks what mutual obligation arises when trust crosses species and power is unequal.

## Gifts

- **Reciprocity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Loyalty:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Attunement:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Dependency:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **People-Pleasing:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Guarding Anxiety:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **reciprocity** can produce **dependency** when safety, timing, or relationship is lost. **loyalty** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **attunement** available while loosening the demand to live through **people-pleasing**.

## Balanced expression

A balanced expression combines reciprocity, loyalty, and attunement. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when reciprocity turns into dependency, or when attunement dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding reciprocity, distrusting loyalty, or surrendering attunement even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **reciprocity**; ask whether **dependency** is driving or distorting it. |
| Relationships | Practice **loyalty** without asking another person to absorb **people-pleasing**. |
| Community | The group may need the **reciprocal trust** role, with explicit limits against **guarding anxiety**. |
| Work and vocation | Use **attunement** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they read human gestures and routines with unusual skill, while welfare and behavior vary across individual history and breed. |
| Conflict | Choose the proportionate form of **reciprocity** rather than escalating into **dependency**. |
| Healing and restoration | Restore access to **loyalty** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **attunement** without repeating **people-pleasing**. |
| Change and transition | Use Domestic Dog as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **reciprocity** accountable to others and monitor for **guarding anxiety**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is reciprocity already alive in my situation?
2. When does loyalty become difficult to receive or sustain?
3. Could dependency be protecting something that needs a safer strategy?
4. Am I overexpressing attunement or suppressing it?
5. What does the human settlements context teach me about the conditions this quality needs?
6. Where does my analogy with Domestic Dog stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Make one clear request and offer one clear form of care without demanding mind-reading. Notice whether loyalty is reciprocal or maintained through fear.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Ancient Egypt | Anubis is represented as a canid/jackal connected with mummification and guarding burial space. The comparison does not equate jackals with domestic dogs. | Late/Ptolemaic period, 343–30 BCE | historical | medium | [Met, recumbent Anubis](https://www.metmuseum.org/art/collection/search/544075) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Domestic Dog. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Domestic Dog represents reciprocal trust. The synthesis derives from the verified behaviors above and adopts reciprocity as the primary Gift and dependency as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Gray Wolf](001-gray-wolf.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Domestic Cat](010-domestic-cat.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Gray Wolf](001-gray-wolf.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Axolotl](038-axolotl.md) can reveal a related defense in another form.
- **Productive tension:** [Domestic Cat](010-domestic-cat.md) and Domestic Dog ask for both self-possessed intimacy and reciprocal trust.
- **Commonly confused:** [Gray Wolf](001-gray-wolf.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Domestic Dog in human settlements, engaged in the behavior described here: dogs have been shaped by long domestication, selective breeding, work, and companionship with people. Emphasize real anatomy, ecological context, and the tension between reciprocity and dependency. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Canis_lupus_familiaris/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Met, recumbent Anubis](https://www.metmuseum.org/art/collection/search/544075) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Avoid universal breed claims and romanticized dominance models.
- No direct quotation from a commercial guidebook was used.
