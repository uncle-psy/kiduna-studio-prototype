---
card_number: 7
animal: "American Bison"
slug: "american-bison"
scientific_name: "Bison bison"
alternate_names: ["bison", "American buffalo"]
taxonomic_group: "Mammal"
habitats: ["prairie", "grassland", "open woodland"]
geographic_range: ["North America"]
activity_cycle: "diurnal with seasonal movement"
social_pattern: "herds that change by sex, season, and reproduction"
core_archetype: "grounded communal endurance"
primary_gifts: ["communal endurance", "grounded provision", "weather-facing resilience"]
primary_wounds: ["stubbornness", "scarcity fear", "herd conformity"]
elemental_associations: ["earth"]
seasonal_associations: ["winter"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# American Bison

## Essence

American Bison teaches **grounded communal endurance**: communal endurance becomes trustworthy when it stays connected to grounded provision and does not harden into stubbornness.

## Keywords

communal endurance, grounded provision, weather-facing resilience, stubbornness, scarcity fear, herd conformity.

## The living animal

### Natural-history facts

- Bison graze in herds, wallow in soil, and move in response to forage, water, weather, and disturbance.
- Their massive heads and shoulder structure help them sweep snow to reach winter forage.
- Herd composition shifts through the year, with larger mixed groups around the breeding season.
- **Ecological role:** Grazing, trampling, dung, and wallows create habitat heterogeneity used by many prairie species.
- **Habitat and range:** prairie, grassland, open woodland; North America.
- **Activity and social pattern:** diurnal with seasonal movement; herds that change by sex, season, and reproduction.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **grounded communal endurance**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

American Bison occupies the role of **grounded communal endurance**. Unlike Horse, Bison symbolizes collective staying power and ecological weight more than speed or partnership.

## Gifts

- **Communal Endurance:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Grounded Provision:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Weather-Facing Resilience:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Stubbornness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Scarcity Fear:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Herd Conformity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **communal endurance** can produce **stubbornness** when safety, timing, or relationship is lost. **grounded provision** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **weather-facing resilience** available while loosening the demand to live through **scarcity fear**.

## Balanced expression

A balanced expression combines communal endurance, grounded provision, and weather-facing resilience. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when communal endurance turns into stubbornness, or when weather-facing resilience dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding communal endurance, distrusting grounded provision, or surrendering weather-facing resilience even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **communal endurance**; ask whether **stubbornness** is driving or distorting it. |
| Relationships | Practice **grounded provision** without asking another person to absorb **scarcity fear**. |
| Community | The group may need the **grounded communal endurance** role, with explicit limits against **herd conformity**. |
| Work and vocation | Use **weather-facing resilience** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: their massive heads and shoulder structure help them sweep snow to reach winter forage. |
| Conflict | Choose the proportionate form of **communal endurance** rather than escalating into **stubbornness**. |
| Healing and restoration | Restore access to **grounded provision** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **weather-facing resilience** without repeating **scarcity fear**. |
| Change and transition | Use American Bison as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **communal endurance** accountable to others and monitor for **herd conformity**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is communal endurance already alive in my situation?
2. When does grounded provision become difficult to receive or sustain?
3. Could stubbornness be protecting something that needs a safer strategy?
4. Am I overexpressing weather-facing resilience or suppressing it?
5. What does the prairie context teach me about the conditions this quality needs?
6. Where does my analogy with American Bison stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Stand or sit with your feet supported. Identify the resource your group needs to keep moving through difficulty, and make one fair contribution to it.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for American Bison. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** American Bison represents grounded communal endurance. The synthesis derives from the verified behaviors above and adopts communal endurance as the primary Gift and stubbornness as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Common Earthworm](068-common-earthworm.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Ruby-throated Hummingbird](023-ruby-throated-hummingbird.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Common Earthworm](068-common-earthworm.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Ruby-throated Hummingbird](023-ruby-throated-hummingbird.md) can reveal a related defense in another form.
- **Productive tension:** [Ruby-throated Hummingbird](023-ruby-throated-hummingbird.md) and American Bison ask for both precise energetic exchange and grounded communal endurance.
- **Commonly confused:** [Common Earthworm](068-common-earthworm.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show American Bison in prairie, engaged in the behavior described here: bison graze in herds, wallow in soil, and move in response to forage, water, weather, and disturbance. Emphasize real anatomy, ecological context, and the tension between communal endurance and stubbornness. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Bison_bison/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Restoration and cultural relationships require specific regional and Tribal context beyond this biological card.
- No direct quotation from a commercial guidebook was used.
