---
card_number: 66
animal: "Staghorn Coral"
slug: "staghorn-coral"
scientific_name: "Acropora cervicornis"
alternate_names: ["branching coral"]
taxonomic_group: "Other marine invertebrate"
habitats: ["shallow coral reef"]
geographic_range: ["Caribbean", "western Atlantic"]
activity_cycle: "continuous colony life with day/night polyp rhythms"
social_pattern: "colonial animal in symbiosis"
core_archetype: "collective habitat-making"
primary_gifts: ["collective building", "symbiosis", "habitat generation"]
primary_wounds: ["brittleness", "dependency", "silent collapse"]
elemental_associations: ["water", "earth"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Staghorn Coral

## Essence

Staghorn Coral teaches **collective habitat-making**: collective building becomes trustworthy when it stays connected to symbiosis and does not harden into brittleness.

## Keywords

collective building, symbiosis, habitat generation, brittleness, dependency, silent collapse.

## The living animal

### Natural-history facts

- Staghorn coral is a colony of genetically connected polyps building a branching calcium-carbonate skeleton.
- Symbiotic algae provide much of the colony's energy under suitable light and temperature.
- Fragments can contribute to growth, yet heat stress, disease, storms, and water quality can cause rapid loss.
- **Ecological role:** Branching colonies create complex refuge and feeding surfaces for reef communities.
- **Habitat and range:** shallow coral reef; Caribbean, western Atlantic.
- **Activity and social pattern:** continuous colony life with day/night polyp rhythms; colonial animal in symbiosis.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **collective habitat-making**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Staghorn Coral occupies the role of **collective habitat-making**. Unlike Beaver, Coral builds through countless connected bodies and metabolic symbiosis rather than mobile family engineering.

## Gifts

- **Collective Building:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Symbiosis:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Habitat Generation:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Brittleness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Dependency:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Silent Collapse:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **collective building** can produce **brittleness** when safety, timing, or relationship is lost. **symbiosis** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **habitat generation** available while loosening the demand to live through **dependency**.

## Balanced expression

A balanced expression combines collective building, symbiosis, and habitat generation. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when collective building turns into brittleness, or when habitat generation dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding collective building, distrusting symbiosis, or surrendering habitat generation even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **collective building**; ask whether **brittleness** is driving or distorting it. |
| Relationships | Practice **symbiosis** without asking another person to absorb **dependency**. |
| Community | The group may need the **collective habitat-making** role, with explicit limits against **silent collapse**. |
| Work and vocation | Use **habitat generation** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: symbiotic algae provide much of the colony's energy under suitable light and temperature. |
| Conflict | Choose the proportionate form of **collective building** rather than escalating into **brittleness**. |
| Healing and restoration | Restore access to **symbiosis** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **habitat generation** without repeating **dependency**. |
| Change and transition | Use Staghorn Coral as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **collective building** accountable to others and monitor for **silent collapse**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is collective building already alive in my situation?
2. When does symbiosis become difficult to receive or sustain?
3. Could brittleness be protecting something that needs a safer strategy?
4. Am I overexpressing habitat generation or suppressing it?
5. What does the shallow coral reef context teach me about the conditions this quality needs?
6. Where does my analogy with Staghorn Coral stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Ask which relationship supplies energy to your shared structure and what heat it cannot absorb. Protect conditions before visible collapse.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Staghorn Coral. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Staghorn Coral represents collective habitat-making. The synthesis derives from the verified behaviors above and adopts collective building as the primary Gift and brittleness as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [North American Beaver](011-north-american-beaver.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Ochre Sea Star](065-ochre-sea-star.md) interrupts this card's likely overexpression.
- **Shared Gift:** [North American Beaver](011-north-american-beaver.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Domestic Dog](009-domestic-dog.md) can reveal a related defense in another form.
- **Productive tension:** [Ochre Sea Star](065-ochre-sea-star.md) and Staghorn Coral ask for both distributed keystone influence and collective habitat-making.
- **Commonly confused:** [North American Beaver](011-north-american-beaver.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Staghorn Coral in shallow coral reef, engaged in the behavior described here: staghorn coral is a colony of genetically connected polyps building a branching calcium-carbonate skeleton. Emphasize real anatomy, ecological context, and the tension between collective building and brittleness. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.fisheries.noaa.gov/species/staghorn-coral) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- This card represents a colony, not one solitary body; conservation status is time-sensitive.
- No direct quotation from a commercial guidebook was used.
