---
card_number: 23
animal: "Ruby-throated Hummingbird"
slug: "ruby-throated-hummingbird"
scientific_name: "Archilochus colubris"
alternate_names: ["hummingbird"]
taxonomic_group: "Bird"
habitats: ["forest edge", "garden", "meadow", "riparian corridor"]
geographic_range: ["eastern North America", "Central America in winter"]
activity_cycle: "diurnal"
social_pattern: "mostly solitary and territorial"
core_archetype: "precise energetic exchange"
primary_gifts: ["precision", "joy", "reciprocal exchange"]
primary_wounds: ["depletion", "territorial irritability", "chasing sweetness"]
elemental_associations: ["air", "fire"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Ruby-throated Hummingbird

## Essence

Ruby-throated Hummingbird teaches **precise energetic exchange**: precision becomes trustworthy when it stays connected to joy and does not harden into depletion.

## Keywords

precision, joy, reciprocal exchange, depletion, territorial irritability, chasing sweetness.

## The living animal

### Natural-history facts

- Ruby-throated hummingbirds hover and maneuver through rapid wingbeats to feed from flowers and catch small arthropods.
- They defend concentrated nectar resources but also migrate long distances relative to body size.
- High metabolic demand requires frequent feeding, while torpor can reduce energy use.
- **Ecological role:** They pollinate some flowers while moving among seasonal nectar landscapes.
- **Habitat and range:** forest edge, garden, meadow, riparian corridor; eastern North America, Central America in winter.
- **Activity and social pattern:** diurnal; mostly solitary and territorial.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **precise energetic exchange**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Ruby-throated Hummingbird occupies the role of **precise energetic exchange**. Unlike Honey Bee, Hummingbird emphasizes individual precision and energy budgeting rather than colony coordination.

## Gifts

- **Precision:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Joy:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Reciprocal Exchange:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Depletion:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Territorial Irritability:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Chasing Sweetness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **precision** can produce **depletion** when safety, timing, or relationship is lost. **joy** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **reciprocal exchange** available while loosening the demand to live through **territorial irritability**.

## Balanced expression

A balanced expression combines precision, joy, and reciprocal exchange. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when precision turns into depletion, or when reciprocal exchange dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding precision, distrusting joy, or surrendering reciprocal exchange even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **precision**; ask whether **depletion** is driving or distorting it. |
| Relationships | Practice **joy** without asking another person to absorb **territorial irritability**. |
| Community | The group may need the **precise energetic exchange** role, with explicit limits against **chasing sweetness**. |
| Work and vocation | Use **reciprocal exchange** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they defend concentrated nectar resources but also migrate long distances relative to body size. |
| Conflict | Choose the proportionate form of **precision** rather than escalating into **depletion**. |
| Healing and restoration | Restore access to **joy** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **reciprocal exchange** without repeating **territorial irritability**. |
| Change and transition | Use Ruby-throated Hummingbird as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **precision** accountable to others and monitor for **chasing sweetness**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is precision already alive in my situation?
2. When does joy become difficult to receive or sustain?
3. Could depletion be protecting something that needs a safer strategy?
4. Am I overexpressing reciprocal exchange or suppressing it?
5. What does the forest edge context teach me about the conditions this quality needs?
6. Where does my analogy with Ruby-throated Hummingbird stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Choose one source of genuine nourishment and one draining sweetness. Move toward the first, limit the second, and schedule recovery.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Ruby-throated Hummingbird. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Ruby-throated Hummingbird represents precise energetic exchange. The synthesis derives from the verified behaviors above and adopts precision as the primary Gift and depletion as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Western Honey Bee](050-western-honey-bee.md) expands the Gift through a different ecological strategy.
- **Balancing:** [American Bison](007-american-bison.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Western Honey Bee](050-western-honey-bee.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Giant Pacific Sea Cucumber](067-giant-pacific-sea-cucumber.md) can reveal a related defense in another form.
- **Productive tension:** [American Bison](007-american-bison.md) and Ruby-throated Hummingbird ask for both grounded communal endurance and precise energetic exchange.
- **Commonly confused:** [Western Honey Bee](050-western-honey-bee.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Ruby-throated Hummingbird in forest edge, engaged in the behavior described here: ruby-throated hummingbirds hover and maneuver through rapid wingbeats to feed from flowers and catch small arthropods. Emphasize real anatomy, ecological context, and the tension between precision and depletion. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.allaboutbirds.org/guide/Ruby-throated_Hummingbird/lifehistory) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
