---
card_number: 65
animal: "Ochre Sea Star"
slug: "ochre-sea-star"
scientific_name: "Pisaster ochraceus"
alternate_names: ["purple sea star"]
taxonomic_group: "Other marine invertebrate"
habitats: ["rocky intertidal", "tide pool"]
geographic_range: ["northeastern Pacific coast"]
activity_cycle: "tidal and day/night activity"
social_pattern: "mostly solitary with local aggregations"
core_archetype: "distributed keystone influence"
primary_gifts: ["regeneration", "keystone influence", "distributed sensing"]
primary_wounds: ["fragmentation", "clinging", "underestimating indirect power"]
elemental_associations: ["water", "earth"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Ochre Sea Star

## Essence

Ochre Sea Star teaches **distributed keystone influence**: regeneration becomes trustworthy when it stays connected to keystone influence and does not harden into fragmentation.

## Keywords

regeneration, keystone influence, distributed sensing, fragmentation, clinging, underestimating indirect power.

## The living animal

### Natural-history facts

- Ochre sea stars use tube feet and hydraulic systems to move, attach, sense, and handle prey.
- They prey heavily on mussels and can maintain space for diverse intertidal organisms.
- Some sea stars can regenerate damaged arms, though fragmentation is not harmless or unlimited.
- **Ecological role:** Classic removal studies helped establish the ecological concept of a keystone predator.
- **Habitat and range:** rocky intertidal, tide pool; northeastern Pacific coast.
- **Activity and social pattern:** tidal and day/night activity; mostly solitary with local aggregations.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **distributed keystone influence**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Ochre Sea Star occupies the role of **distributed keystone influence**. Unlike Staghorn Coral, Sea Star maintains diversity through selective predation rather than building habitat through colony growth.

## Gifts

- **Regeneration:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Keystone Influence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Distributed Sensing:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Fragmentation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Clinging:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Underestimating Indirect Power:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **regeneration** can produce **fragmentation** when safety, timing, or relationship is lost. **keystone influence** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **distributed sensing** available while loosening the demand to live through **clinging**.

## Balanced expression

A balanced expression combines regeneration, keystone influence, and distributed sensing. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when regeneration turns into fragmentation, or when distributed sensing dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding regeneration, distrusting keystone influence, or surrendering distributed sensing even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **regeneration**; ask whether **fragmentation** is driving or distorting it. |
| Relationships | Practice **keystone influence** without asking another person to absorb **clinging**. |
| Community | The group may need the **distributed keystone influence** role, with explicit limits against **underestimating indirect power**. |
| Work and vocation | Use **distributed sensing** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they prey heavily on mussels and can maintain space for diverse intertidal organisms. |
| Conflict | Choose the proportionate form of **regeneration** rather than escalating into **fragmentation**. |
| Healing and restoration | Restore access to **keystone influence** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **distributed sensing** without repeating **clinging**. |
| Change and transition | Use Ochre Sea Star as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **regeneration** accountable to others and monitor for **underestimating indirect power**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is regeneration already alive in my situation?
2. When does keystone influence become difficult to receive or sustain?
3. Could fragmentation be protecting something that needs a safer strategy?
4. Am I overexpressing distributed sensing or suppressing it?
5. What does the rocky intertidal context teach me about the conditions this quality needs?
6. Where does my analogy with Ochre Sea Star stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Identify one small lever that changes a crowded system. Use it carefully; regeneration is not permission to keep causing damage.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Ochre Sea Star. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Ochre Sea Star represents distributed keystone influence. The synthesis derives from the verified behaviors above and adopts regeneration as the primary Gift and fragmentation as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Axolotl](038-axolotl.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Staghorn Coral](066-staghorn-coral.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Axolotl](038-axolotl.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Common Earthworm](068-common-earthworm.md) can reveal a related defense in another form.
- **Productive tension:** [Staghorn Coral](066-staghorn-coral.md) and Ochre Sea Star ask for both collective habitat-making and distributed keystone influence.
- **Commonly confused:** [Axolotl](038-axolotl.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Ochre Sea Star in rocky intertidal, engaged in the behavior described here: ochre sea stars use tube feet and hydraulic systems to move, attach, sense, and handle prey. Emphasize real anatomy, ecological context, and the tension between regeneration and fragmentation. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Pisaster_ochraceus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Sea star wasting disease and population status require current review.
- No direct quotation from a commercial guidebook was used.
