---
card_number: 4
animal: "Red Fox"
slug: "red-fox"
scientific_name: "Vulpes vulpes"
alternate_names: ["fox"]
taxonomic_group: "Mammal"
habitats: ["forest edge", "grassland", "tundra", "farmland", "urban edge"]
geographic_range: ["North America", "Europe", "Asia", "North Africa"]
activity_cycle: "mostly crepuscular or nocturnal"
social_pattern: "usually solitary outside pair and family periods"
core_archetype: "adaptive edge-walker"
primary_gifts: ["adaptability", "opportunistic intelligence", "boundary navigation"]
primary_wounds: ["evasive habits", "self-serving opportunism", "mistrust"]
elemental_associations: ["earth", "air"]
seasonal_associations: ["autumn"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Red Fox

## Essence

Red Fox teaches **adaptive edge-walker**: adaptability becomes trustworthy when it stays connected to opportunistic intelligence and does not harden into evasive habits.

## Keywords

adaptability, opportunistic intelligence, boundary navigation, evasive habits, self-serving opportunism, mistrust.

## The living animal

### Natural-history facts

- Red foxes occupy an unusually broad range of climates and human-altered landscapes.
- They hunt through acute hearing, smell, stalking, and sudden pounces, and they cache surplus food.
- Adults often forage alone while maintaining pair or family relationships around breeding and young.
- **Ecological role:** As mesopredators, foxes consume rodents, rabbits, insects, fruit, carrion, and other seasonally available foods.
- **Habitat and range:** forest edge, grassland, tundra, farmland, urban edge; North America, Europe, Asia, North Africa.
- **Activity and social pattern:** mostly crepuscular or nocturnal; usually solitary outside pair and family periods.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **adaptive edge-walker**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Red Fox occupies the role of **adaptive edge-walker**. Unlike Chameleon, Fox changes tactics while retaining a recognizable way of moving through the world.

## Gifts

- **Adaptability:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Opportunistic Intelligence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Boundary Navigation:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Evasive Habits:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Self-Serving Opportunism:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Mistrust:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **adaptability** can produce **evasive habits** when safety, timing, or relationship is lost. **opportunistic intelligence** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **boundary navigation** available while loosening the demand to live through **self-serving opportunism**.

## Balanced expression

A balanced expression combines adaptability, opportunistic intelligence, and boundary navigation. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when adaptability turns into evasive habits, or when boundary navigation dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding adaptability, distrusting opportunistic intelligence, or surrendering boundary navigation even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **adaptability**; ask whether **evasive habits** is driving or distorting it. |
| Relationships | Practice **opportunistic intelligence** without asking another person to absorb **self-serving opportunism**. |
| Community | The group may need the **adaptive edge-walker** role, with explicit limits against **mistrust**. |
| Work and vocation | Use **boundary navigation** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they hunt through acute hearing, smell, stalking, and sudden pounces, and they cache surplus food. |
| Conflict | Choose the proportionate form of **adaptability** rather than escalating into **evasive habits**. |
| Healing and restoration | Restore access to **opportunistic intelligence** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **boundary navigation** without repeating **self-serving opportunism**. |
| Change and transition | Use Red Fox as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **adaptability** accountable to others and monitor for **mistrust**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is adaptability already alive in my situation?
2. When does opportunistic intelligence become difficult to receive or sustain?
3. Could evasive habits be protecting something that needs a safer strategy?
4. Am I overexpressing boundary navigation or suppressing it?
5. What does the forest edge context teach me about the conditions this quality needs?
6. Where does my analogy with Red Fox stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

List three available routes around a current obstacle. Choose the most honest adaptable route, not merely the easiest escape.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Red Fox. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Red Fox represents adaptive edge-walker. The synthesis derives from the verified behaviors above and adopts adaptability as the primary Gift and evasive habits as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Common Raven](021-common-raven.md) expands the Gift through a different ecological strategy.
- **Balancing:** [American Bison](007-american-bison.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Common Raven](021-common-raven.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [American Bison](007-american-bison.md) can reveal a related defense in another form.
- **Productive tension:** [American Bison](007-american-bison.md) and Red Fox ask for both grounded communal endurance and adaptive edge-walker.
- **Commonly confused:** [Common Raven](021-common-raven.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Red Fox in forest edge, engaged in the behavior described here: red foxes occupy an unusually broad range of climates and human-altered landscapes. Emphasize real anatomy, ecological context, and the tension between adaptability and evasive habits. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Vulpes_vulpes/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
