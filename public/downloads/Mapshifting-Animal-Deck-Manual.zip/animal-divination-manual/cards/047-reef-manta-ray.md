---
card_number: 47
animal: "Reef Manta Ray"
slug: "reef-manta-ray"
scientific_name: "Mobula alfredi"
alternate_names: ["manta ray"]
taxonomic_group: "Fish"
habitats: ["coral reef", "coastal ocean", "cleaning station"]
geographic_range: ["tropical Indo-Pacific"]
activity_cycle: "day and night; locally migratory"
social_pattern: "solitary or temporary aggregations"
core_archetype: "graceful scale"
primary_gifts: ["grace", "curiosity", "flow"]
primary_wounds: ["avoidance of friction", "diffuse boundaries", "vulnerability to exploitation"]
elemental_associations: ["water", "air"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Reef Manta Ray

## Essence

Reef Manta Ray teaches **graceful scale**: grace becomes trustworthy when it stays connected to curiosity and does not harden into avoidance of friction.

## Keywords

grace, curiosity, flow, avoidance of friction, diffuse boundaries, vulnerability to exploitation.

## The living animal

### Natural-history facts

- Reef mantas are large filter-feeding rays that consume plankton while swimming through productive water.
- Individuals visit cleaning stations where smaller fish remove parasites.
- They show curiosity and aggregate seasonally at feeding, cleaning, or courtship sites.
- **Ecological role:** Slow reproduction and targeted or incidental fishing make manta populations vulnerable.
- **Habitat and range:** coral reef, coastal ocean, cleaning station; tropical Indo-Pacific.
- **Activity and social pattern:** day and night; locally migratory; solitary or temporary aggregations.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **graceful scale**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Reef Manta Ray occupies the role of **graceful scale**. Unlike Flamingo, Manta filters while ranging through three-dimensional ocean space rather than standing in dense shallow-water colonies.

## Gifts

- **Grace:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Curiosity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Flow:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Avoidance Of Friction:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Diffuse Boundaries:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Vulnerability To Exploitation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **grace** can produce **avoidance of friction** when safety, timing, or relationship is lost. **curiosity** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **flow** available while loosening the demand to live through **diffuse boundaries**.

## Balanced expression

A balanced expression combines grace, curiosity, and flow. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when grace turns into avoidance of friction, or when flow dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding grace, distrusting curiosity, or surrendering flow even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **grace**; ask whether **avoidance of friction** is driving or distorting it. |
| Relationships | Practice **curiosity** without asking another person to absorb **diffuse boundaries**. |
| Community | The group may need the **graceful scale** role, with explicit limits against **vulnerability to exploitation**. |
| Work and vocation | Use **flow** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: individuals visit cleaning stations where smaller fish remove parasites. |
| Conflict | Choose the proportionate form of **grace** rather than escalating into **avoidance of friction**. |
| Healing and restoration | Restore access to **curiosity** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **flow** without repeating **diffuse boundaries**. |
| Change and transition | Use Reef Manta Ray as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **grace** accountable to others and monitor for **vulnerability to exploitation**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is grace already alive in my situation?
2. When does curiosity become difficult to receive or sustain?
3. Could avoidance of friction be protecting something that needs a safer strategy?
4. Am I overexpressing flow or suppressing it?
5. What does the coral reef context teach me about the conditions this quality needs?
6. Where does my analogy with Reef Manta Ray stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Let one problem become spacious: widen the time horizon and seek a cleaning relationship—feedback that removes drag without diminishing you.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Reef Manta Ray. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Reef Manta Ray represents graceful scale. The synthesis derives from the verified behaviors above and adopts grace as the primary Gift and avoidance of friction as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Greater Flamingo](029-greater-flamingo.md) expands the Gift through a different ecological strategy.
- **Balancing:** [King Cobra](033-king-cobra.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Common Raven](021-common-raven.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [King Cobra](033-king-cobra.md) can reveal a related defense in another form.
- **Productive tension:** [King Cobra](033-king-cobra.md) and Reef Manta Ray ask for both measured warning and power and graceful scale.
- **Commonly confused:** [Greater Flamingo](029-greater-flamingo.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Reef Manta Ray in coral reef, engaged in the behavior described here: reef mantas are large filter-feeding rays that consume plankton while swimming through productive water. Emphasize real anatomy, ecological context, and the tension between grace and avoidance of friction. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Mobula_alfredi/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- NOAA source profiles giant manta; reef manta requires dedicated taxonomic review.
- No direct quotation from a commercial guidebook was used.
