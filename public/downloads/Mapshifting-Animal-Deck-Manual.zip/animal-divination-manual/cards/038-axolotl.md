---
card_number: 38
animal: "Axolotl"
slug: "axolotl"
scientific_name: "Ambystoma mexicanum"
alternate_names: ["Mexican axolotl"]
taxonomic_group: "Amphibian"
habitats: ["freshwater canal", "lake remnant"]
geographic_range: ["Xochimilco wetland system, Mexico City"]
activity_cycle: "mostly nocturnal"
social_pattern: "mostly solitary"
core_archetype: "regenerative openness"
primary_gifts: ["regeneration", "retained openness", "niche adaptation"]
primary_wounds: ["arrested development", "dependency", "fragility outside the niche"]
elemental_associations: ["water"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Axolotl

## Essence

Axolotl teaches **regenerative openness**: regeneration becomes trustworthy when it stays connected to retained openness and does not harden into arrested development.

## Keywords

regeneration, retained openness, niche adaptation, arrested development, dependency, fragility outside the niche.

## The living animal

### Natural-history facts

- Axolotls usually retain aquatic larval features, including external gills, while becoming reproductively mature.
- They can regenerate limbs and parts of several organs, a capacity studied intensively in laboratories.
- Wild axolotls occupy a highly restricted, human-modified freshwater system.
- **Ecological role:** They are aquatic predators and prey within the Xochimilco food web and are threatened by habitat change, pollution, and introduced species.
- **Habitat and range:** freshwater canal, lake remnant; Xochimilco wetland system, Mexico City.
- **Activity and social pattern:** mostly nocturnal; mostly solitary.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **regenerative openness**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Axolotl occupies the role of **regenerative openness**. Unlike Tiger Salamander, Axolotl centers a life that remains aquatic and open-featured rather than metamorphosing into a terrestrial adult.

## Gifts

- **Regeneration:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Retained Openness:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Niche Adaptation:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Arrested Development:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Dependency:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Fragility Outside The Niche:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **regeneration** can produce **arrested development** when safety, timing, or relationship is lost. **retained openness** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **niche adaptation** available while loosening the demand to live through **dependency**.

## Balanced expression

A balanced expression combines regeneration, retained openness, and niche adaptation. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when regeneration turns into arrested development, or when niche adaptation dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding regeneration, distrusting retained openness, or surrendering niche adaptation even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **regeneration**; ask whether **arrested development** is driving or distorting it. |
| Relationships | Practice **retained openness** without asking another person to absorb **dependency**. |
| Community | The group may need the **regenerative openness** role, with explicit limits against **fragility outside the niche**. |
| Work and vocation | Use **niche adaptation** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they can regenerate limbs and parts of several organs, a capacity studied intensively in laboratories. |
| Conflict | Choose the proportionate form of **regeneration** rather than escalating into **arrested development**. |
| Healing and restoration | Restore access to **retained openness** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **niche adaptation** without repeating **dependency**. |
| Change and transition | Use Axolotl as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **regeneration** accountable to others and monitor for **fragility outside the niche**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is regeneration already alive in my situation?
2. When does retained openness become difficult to receive or sustain?
3. Could arrested development be protecting something that needs a safer strategy?
4. Am I overexpressing niche adaptation or suppressing it?
5. What does the freshwater canal context teach me about the conditions this quality needs?
6. Where does my analogy with Axolotl stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Choose one area for repair without treating your whole life as broken. Name what must remain open during regeneration and what support the niche requires.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Axolotl. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Axolotl represents regenerative openness. The synthesis derives from the verified behaviors above and adopts regeneration as the primary Gift and arrested development as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Ochre Sea Star](065-ochre-sea-star.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Emu](031-emu.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Ochre Sea Star](065-ochre-sea-star.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Domestic Dog](009-domestic-dog.md) can reveal a related defense in another form.
- **Productive tension:** [Emu](031-emu.md) and Axolotl ask for both steady adaptive stride and regenerative openness.
- **Commonly confused:** [Ochre Sea Star](065-ochre-sea-star.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Axolotl in freshwater canal, engaged in the behavior described here: axolotls usually retain aquatic larval features, including external gills, while becoming reproductively mature. Emphasize real anatomy, ecological context, and the tension between regeneration and arrested development. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Ambystoma_mexicanum/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Captive forms do not represent the condition of the critically imperiled wild population.
- No direct quotation from a commercial guidebook was used.
