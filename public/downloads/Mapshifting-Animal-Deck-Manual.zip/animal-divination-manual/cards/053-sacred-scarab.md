---
card_number: 53
animal: "Sacred Scarab"
slug: "sacred-scarab"
scientific_name: "Scarabaeus sacer"
alternate_names: ["dung beetle", "scarab beetle"]
taxonomic_group: "Insect"
habitats: ["dung-rich grassland", "savanna", "dry open country"]
geographic_range: ["Mediterranean region", "North Africa", "western Asia"]
activity_cycle: "mostly diurnal or crepuscular; heat-dependent"
social_pattern: "mostly solitary around brood balls"
core_archetype: "renewal through what is discarded"
primary_gifts: ["renewal", "persistence", "orientation"]
primary_wounds: ["compulsive labor", "false purity", "recycling the past without change"]
elemental_associations: ["earth", "fire"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# Sacred Scarab

## Essence

Sacred Scarab teaches **renewal through what is discarded**: renewal becomes trustworthy when it stays connected to persistence and does not harden into compulsive labor.

## Keywords

renewal, persistence, orientation, compulsive labor, false purity, recycling the past without change.

## The living animal

### Natural-history facts

- Sacred scarabs form and roll dung balls used as food or brood provisions.
- They navigate while moving a ball, using celestial and visual cues to maintain direction.
- By burying dung they relocate nutrients and reduce exposed waste.
- **Ecological role:** Dung beetles contribute to nutrient cycling, soil processes, parasite reduction, and seed movement.
- **Habitat and range:** dung-rich grassland, savanna, dry open country; Mediterranean region, North Africa, western Asia.
- **Activity and social pattern:** mostly diurnal or crepuscular; heat-dependent; mostly solitary around brood balls.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **renewal through what is discarded**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Sacred Scarab occupies the role of **renewal through what is discarded**. Unlike Earthworm, Scarab deliberately gathers and relocates concentrated waste rather than continuously processing soil from within.

## Gifts

- **Renewal:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Persistence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Orientation:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Compulsive Labor:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **False Purity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Recycling The Past Without Change:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **renewal** can produce **compulsive labor** when safety, timing, or relationship is lost. **persistence** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **orientation** available while loosening the demand to live through **false purity**.

## Balanced expression

A balanced expression combines renewal, persistence, and orientation. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when renewal turns into compulsive labor, or when orientation dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding renewal, distrusting persistence, or surrendering orientation even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **renewal**; ask whether **compulsive labor** is driving or distorting it. |
| Relationships | Practice **persistence** without asking another person to absorb **false purity**. |
| Community | The group may need the **renewal through what is discarded** role, with explicit limits against **recycling the past without change**. |
| Work and vocation | Use **orientation** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they navigate while moving a ball, using celestial and visual cues to maintain direction. |
| Conflict | Choose the proportionate form of **renewal** rather than escalating into **compulsive labor**. |
| Healing and restoration | Restore access to **persistence** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **orientation** without repeating **false purity**. |
| Change and transition | Use Sacred Scarab as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **renewal** accountable to others and monitor for **recycling the past without change**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is renewal already alive in my situation?
2. When does persistence become difficult to receive or sustain?
3. Could compulsive labor be protecting something that needs a safer strategy?
4. Am I overexpressing orientation or suppressing it?
5. What does the dung-rich grassland context teach me about the conditions this quality needs?
6. Where does my analogy with Sacred Scarab stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Choose one discarded experience and extract a usable lesson. Bury or release the remainder instead of rolling the whole past indefinitely.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Ancient Egypt | The scarab was associated with the sun moving across the sky and with rebirth in this British Museum educational record. | Ancient Egyptian symbolism | historical | high | [British Museum, *Symbols of the Pharaoh*](https://www.britishmuseum.org/sites/default/files/2019-09/Visit_Egypt_Symbols_KS2b.pdf) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Sacred Scarab. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Sacred Scarab represents renewal through what is discarded. The synthesis derives from the verified behaviors above and adopts renewal as the primary Gift and compulsive labor as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Common Earthworm](068-common-earthworm.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Laysan Albatross](027-laysan-albatross.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Indian Peafowl](030-indian-peafowl.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Laysan Albatross](027-laysan-albatross.md) can reveal a related defense in another form.
- **Productive tension:** [Laysan Albatross](027-laysan-albatross.md) and Sacred Scarab ask for both oceanic patience and renewal through what is discarded.
- **Commonly confused:** [Common Earthworm](068-common-earthworm.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Sacred Scarab in dung-rich grassland, engaged in the behavior described here: sacred scarabs form and roll dung balls used as food or brood provisions. Emphasize real anatomy, ecological context, and the tension between renewal and compulsive labor. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Scarabaeus_sacer/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [British Museum, *Symbols of the Pharaoh*](https://www.britishmuseum.org/sites/default/files/2019-09/Visit_Egypt_Symbols_KS2b.pdf) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Historical symbolism is specific to ancient Egyptian contexts.
- No direct quotation from a commercial guidebook was used.
