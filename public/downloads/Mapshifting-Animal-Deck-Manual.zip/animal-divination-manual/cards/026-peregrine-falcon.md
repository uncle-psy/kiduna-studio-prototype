---
card_number: 26
animal: "Peregrine Falcon"
slug: "peregrine-falcon"
scientific_name: "Falco peregrinus"
alternate_names: ["peregrine"]
taxonomic_group: "Bird"
habitats: ["cliff", "coast", "open country", "city"]
geographic_range: ["worldwide except Antarctica"]
activity_cycle: "diurnal"
social_pattern: "territorial pairs outside migration"
core_archetype: "committed velocity"
primary_gifts: ["commitment", "speed", "mid-course recalibration"]
primary_wounds: ["recklessness", "perfectionism", "impact without pause"]
elemental_associations: ["air", "fire"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Peregrine Falcon

## Essence

Peregrine Falcon teaches **committed velocity**: commitment becomes trustworthy when it stays connected to speed and does not harden into recklessness.

## Keywords

commitment, speed, mid-course recalibration, recklessness, perfectionism, impact without pause.

## The living animal

### Natural-history facts

- Peregrines pursue birds in flight and are renowned for high-speed hunting dives.
- They nest on cliffs and tall structures, including urban buildings, often using simple scrapes.
- Flight control and timing matter as much as raw speed; attacks are frequently adjusted or abandoned.
- **Ecological role:** As aerial predators, peregrines respond to prey abundance and contaminants; recovery from pesticide-era declines is a major conservation history.
- **Habitat and range:** cliff, coast, open country, city; worldwide except Antarctica.
- **Activity and social pattern:** diurnal; territorial pairs outside migration.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **committed velocity**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Peregrine Falcon occupies the role of **committed velocity**. Unlike Red-tailed Hawk, Peregrine commits through speed but still depends on continuous correction.

## Gifts

- **Commitment:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Speed:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Mid-Course Recalibration:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Recklessness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Perfectionism:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Impact Without Pause:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **commitment** can produce **recklessness** when safety, timing, or relationship is lost. **speed** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **mid-course recalibration** available while loosening the demand to live through **perfectionism**.

## Balanced expression

A balanced expression combines commitment, speed, and mid-course recalibration. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when commitment turns into recklessness, or when mid-course recalibration dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding commitment, distrusting speed, or surrendering mid-course recalibration even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **commitment**; ask whether **recklessness** is driving or distorting it. |
| Relationships | Practice **speed** without asking another person to absorb **perfectionism**. |
| Community | The group may need the **committed velocity** role, with explicit limits against **impact without pause**. |
| Work and vocation | Use **mid-course recalibration** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they nest on cliffs and tall structures, including urban buildings, often using simple scrapes. |
| Conflict | Choose the proportionate form of **commitment** rather than escalating into **recklessness**. |
| Healing and restoration | Restore access to **speed** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **mid-course recalibration** without repeating **perfectionism**. |
| Change and transition | Use Peregrine Falcon as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **commitment** accountable to others and monitor for **impact without pause**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is commitment already alive in my situation?
2. When does speed become difficult to receive or sustain?
3. Could recklessness be protecting something that needs a safer strategy?
4. Am I overexpressing mid-course recalibration or suppressing it?
5. What does the cliff context teach me about the conditions this quality needs?
6. Where does my analogy with Peregrine Falcon stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Choose one task that benefits from a focused sprint. Define the abort condition before beginning, then review impact after the burst.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Peregrine Falcon. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Peregrine Falcon represents committed velocity. The synthesis derives from the verified behaviors above and adopts commitment as the primary Gift and recklessness as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Banded Archerfish](049-banded-archerfish.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Garden Snail](061-garden-snail.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Banded Archerfish](049-banded-archerfish.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Cross Orbweaver](057-cross-orbweaver.md) can reveal a related defense in another form.
- **Productive tension:** [Garden Snail](061-garden-snail.md) and Peregrine Falcon ask for both portable pacing and committed velocity.
- **Commonly confused:** [Banded Archerfish](049-banded-archerfish.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Peregrine Falcon in cliff, engaged in the behavior described here: peregrines pursue birds in flight and are renowned for high-speed hunting dives. Emphasize real anatomy, ecological context, and the tension between commitment and recklessness. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.allaboutbirds.org/guide/Peregrine_Falcon/lifehistory) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
