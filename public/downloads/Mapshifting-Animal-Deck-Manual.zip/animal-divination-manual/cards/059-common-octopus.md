---
card_number: 59
animal: "Common Octopus"
slug: "common-octopus"
scientific_name: "Octopus vulgaris"
alternate_names: ["octopus"]
taxonomic_group: "Mollusk"
habitats: ["rocky reef", "seafloor den", "coastal ocean"]
geographic_range: ["temperate and tropical eastern Atlantic and Mediterranean; species complex concerns"]
activity_cycle: "mostly nocturnal or crepuscular"
social_pattern: "mostly solitary"
core_archetype: "flexible distributed intelligence"
primary_gifts: ["flexible intelligence", "adaptive expression", "escape skill"]
primary_wounds: ["evasion", "identity shifting", "isolation"]
elemental_associations: ["water", "air"]
seasonal_associations: ["autumn"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Common Octopus

## Essence

Common Octopus teaches **flexible distributed intelligence**: flexible intelligence becomes trustworthy when it stays connected to adaptive expression and does not harden into evasion.

## Keywords

flexible intelligence, adaptive expression, escape skill, evasion, identity shifting, isolation.

## The living animal

### Natural-history facts

- Octopuses explore and manipulate with eight arms rich in sensory and neural capacity.
- They change skin color and texture, squeeze through small openings, use dens, and solve novel problems.
- Most common octopuses have short lives; females invest heavily in guarding eggs and die after reproduction.
- **Ecological role:** They are active predators and prey within reef and seafloor food webs.
- **Habitat and range:** rocky reef, seafloor den, coastal ocean; temperate and tropical eastern Atlantic and Mediterranean; species complex concerns.
- **Activity and social pattern:** mostly nocturnal or crepuscular; mostly solitary.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **flexible distributed intelligence**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Common Octopus occupies the role of **flexible distributed intelligence**. Unlike Chameleon, Octopus changes color, texture, shape, route, and object use in a highly manipulative aquatic body.

## Gifts

- **Flexible Intelligence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Adaptive Expression:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Escape Skill:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Evasion:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Identity Shifting:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Isolation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **flexible intelligence** can produce **evasion** when safety, timing, or relationship is lost. **adaptive expression** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **escape skill** available while loosening the demand to live through **identity shifting**.

## Balanced expression

A balanced expression combines flexible intelligence, adaptive expression, and escape skill. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when flexible intelligence turns into evasion, or when escape skill dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding flexible intelligence, distrusting adaptive expression, or surrendering escape skill even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **flexible intelligence**; ask whether **evasion** is driving or distorting it. |
| Relationships | Practice **adaptive expression** without asking another person to absorb **identity shifting**. |
| Community | The group may need the **flexible distributed intelligence** role, with explicit limits against **isolation**. |
| Work and vocation | Use **escape skill** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they change skin color and texture, squeeze through small openings, use dens, and solve novel problems. |
| Conflict | Choose the proportionate form of **flexible intelligence** rather than escalating into **evasion**. |
| Healing and restoration | Restore access to **adaptive expression** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **escape skill** without repeating **identity shifting**. |
| Change and transition | Use Common Octopus as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **flexible intelligence** accountable to others and monitor for **isolation**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is flexible intelligence already alive in my situation?
2. When does adaptive expression become difficult to receive or sustain?
3. Could evasion be protecting something that needs a safer strategy?
4. Am I overexpressing escape skill or suppressing it?
5. What does the rocky reef context teach me about the conditions this quality needs?
6. Where does my analogy with Common Octopus stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Solve one problem with your environment rather than force: rearrange tools, change route, or create cover. Then state your identity without camouflage.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Common Octopus. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Common Octopus represents flexible distributed intelligence. The synthesis derives from the verified behaviors above and adopts flexible intelligence as the primary Gift and evasion as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Panther Chameleon](035-panther-chameleon.md) expands the Gift through a different ecological strategy.
- **Balancing:** [American Bison](007-american-bison.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Panther Chameleon](035-panther-chameleon.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Great Horned Owl](020-great-horned-owl.md) can reveal a related defense in another form.
- **Productive tension:** [American Bison](007-american-bison.md) and Common Octopus ask for both grounded communal endurance and flexible distributed intelligence.
- **Commonly confused:** [Panther Chameleon](035-panther-chameleon.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Common Octopus in rocky reef, engaged in the behavior described here: octopuses explore and manipulate with eight arms rich in sensory and neural capacity. Emphasize real anatomy, ecological context, and the tension between flexible intelligence and evasion. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://ocean.si.edu/ocean-life/invertebrates/octopus) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Octopus vulgaris may represent a species complex; range claims need taxonomic review.
- No direct quotation from a commercial guidebook was used.
