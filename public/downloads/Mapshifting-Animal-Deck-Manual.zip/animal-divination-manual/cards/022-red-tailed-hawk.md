---
card_number: 22
animal: "Red-tailed Hawk"
slug: "red-tailed-hawk"
scientific_name: "Buteo jamaicensis"
alternate_names: ["red-tail"]
taxonomic_group: "Bird"
habitats: ["open woodland", "grassland", "desert", "roadside edge"]
geographic_range: ["North America", "Central America", "Caribbean"]
activity_cycle: "diurnal"
social_pattern: "territorial pairs"
core_archetype: "patient surveillance"
primary_gifts: ["patient observation", "timing", "direct focus"]
primary_wounds: ["overmonitoring", "premature attack", "reductionism"]
elemental_associations: ["air", "fire"]
seasonal_associations: ["autumn"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Red-tailed Hawk

## Essence

Red-tailed Hawk teaches **patient surveillance**: patient observation becomes trustworthy when it stays connected to timing and does not harden into overmonitoring.

## Keywords

patient observation, timing, direct focus, overmonitoring, premature attack, reductionism.

## The living animal

### Natural-history facts

- Red-tailed hawks often hunt from a perch or by soaring over open ground.
- They use broad wings and rising air efficiently, then descend on detected prey.
- Pairs defend nesting territories and use varied habitats, including human-altered edges.
- **Ecological role:** These raptors regulate and respond to small-mammal and other prey populations.
- **Habitat and range:** open woodland, grassland, desert, roadside edge; North America, Central America, Caribbean.
- **Activity and social pattern:** diurnal; territorial pairs.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **patient surveillance**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Red-tailed Hawk occupies the role of **patient surveillance**. Unlike Peregrine Falcon, Red-tail favors patient scanning and a measured descent rather than high-speed aerial pursuit.

## Gifts

- **Patient Observation:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Timing:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Direct Focus:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Overmonitoring:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Premature Attack:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Reductionism:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **patient observation** can produce **overmonitoring** when safety, timing, or relationship is lost. **timing** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **direct focus** available while loosening the demand to live through **premature attack**.

## Balanced expression

A balanced expression combines patient observation, timing, and direct focus. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when patient observation turns into overmonitoring, or when direct focus dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding patient observation, distrusting timing, or surrendering direct focus even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **patient observation**; ask whether **overmonitoring** is driving or distorting it. |
| Relationships | Practice **timing** without asking another person to absorb **premature attack**. |
| Community | The group may need the **patient surveillance** role, with explicit limits against **reductionism**. |
| Work and vocation | Use **direct focus** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they use broad wings and rising air efficiently, then descend on detected prey. |
| Conflict | Choose the proportionate form of **patient observation** rather than escalating into **overmonitoring**. |
| Healing and restoration | Restore access to **timing** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **direct focus** without repeating **premature attack**. |
| Change and transition | Use Red-tailed Hawk as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **patient observation** accountable to others and monitor for **reductionism**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is patient observation already alive in my situation?
2. When does timing become difficult to receive or sustain?
3. Could overmonitoring be protecting something that needs a safer strategy?
4. Am I overexpressing direct focus or suppressing it?
5. What does the open woodland context teach me about the conditions this quality needs?
6. Where does my analogy with Red-tailed Hawk stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Set a decision window. Observe until it closes, then act on the best available evidence instead of monitoring indefinitely.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Red-tailed Hawk. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Red-tailed Hawk represents patient surveillance. The synthesis derives from the verified behaviors above and adopts patient observation as the primary Gift and overmonitoring as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Peregrine Falcon](026-peregrine-falcon.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Moon Jelly](064-moon-jelly.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Peregrine Falcon](026-peregrine-falcon.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Moon Jelly](064-moon-jelly.md) can reveal a related defense in another form.
- **Productive tension:** [Moon Jelly](064-moon-jelly.md) and Red-tailed Hawk ask for both rhythmic receptivity and patient surveillance.
- **Commonly confused:** [Peregrine Falcon](026-peregrine-falcon.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Red-tailed Hawk in open woodland, engaged in the behavior described here: red-tailed hawks often hunt from a perch or by soaring over open ground. Emphasize real anatomy, ecological context, and the tension between patient observation and overmonitoring. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.allaboutbirds.org/guide/Red-tailed_Hawk/lifehistory) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
