---
card_number: 46
animal: "Electric Eel"
slug: "electric-eel"
scientific_name: "Electrophorus electricus"
alternate_names: ["electric eel"]
taxonomic_group: "Fish"
habitats: ["slow river", "floodplain", "murky freshwater"]
geographic_range: ["northern South America"]
activity_cycle: "mostly nocturnal"
social_pattern: "mostly solitary"
core_archetype: "self-generated boundary and perception"
primary_gifts: ["internal power", "electrical sensing", "boundary signaling"]
primary_wounds: ["shock tactics", "isolation", "chronic defensiveness"]
elemental_associations: ["water", "fire"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Electric Eel

## Essence

Electric Eel teaches **self-generated boundary and perception**: internal power becomes trustworthy when it stays connected to electrical sensing and does not harden into shock tactics.

## Keywords

internal power, electrical sensing, boundary signaling, shock tactics, isolation, chronic defensiveness.

## The living animal

### Natural-history facts

- Electric eels generate weak electric fields for sensing and communication and stronger discharges for defense and prey capture.
- They surface to breathe air and are adapted to warm, oxygen-poor waters.
- Electrical perception helps map nearby objects in dark or turbid habitat.
- **Ecological role:** They are freshwater predators within floodplain and river systems.
- **Habitat and range:** slow river, floodplain, murky freshwater; northern South America.
- **Activity and social pattern:** mostly nocturnal; mostly solitary.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **self-generated boundary and perception**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Electric Eel occupies the role of **self-generated boundary and perception**. Unlike Firefly, Electric Eel uses self-generated signals to perceive and defend in murk rather than attract through visible light.

## Gifts

- **Internal Power:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Electrical Sensing:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Boundary Signaling:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Shock Tactics:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Isolation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Chronic Defensiveness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **internal power** can produce **shock tactics** when safety, timing, or relationship is lost. **electrical sensing** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **boundary signaling** available while loosening the demand to live through **isolation**.

## Balanced expression

A balanced expression combines internal power, electrical sensing, and boundary signaling. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when internal power turns into shock tactics, or when boundary signaling dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding internal power, distrusting electrical sensing, or surrendering boundary signaling even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **internal power**; ask whether **shock tactics** is driving or distorting it. |
| Relationships | Practice **electrical sensing** without asking another person to absorb **isolation**. |
| Community | The group may need the **self-generated boundary and perception** role, with explicit limits against **chronic defensiveness**. |
| Work and vocation | Use **boundary signaling** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they surface to breathe air and are adapted to warm, oxygen-poor waters. |
| Conflict | Choose the proportionate form of **internal power** rather than escalating into **shock tactics**. |
| Healing and restoration | Restore access to **electrical sensing** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **boundary signaling** without repeating **isolation**. |
| Change and transition | Use Electric Eel as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **internal power** accountable to others and monitor for **chronic defensiveness**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is internal power already alive in my situation?
2. When does electrical sensing become difficult to receive or sustain?
3. Could shock tactics be protecting something that needs a safer strategy?
4. Am I overexpressing boundary signaling or suppressing it?
5. What does the slow river context teach me about the conditions this quality needs?
6. Where does my analogy with Electric Eel stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Before using force, send a low-intensity signal: name the boundary and check whether it was received. Reserve stronger action for a proportionate need.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Electric Eel. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Electric Eel represents self-generated boundary and perception. The synthesis derives from the verified behaviors above and adopts internal power as the primary Gift and shock tactics as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Common Eastern Firefly](055-common-eastern-firefly.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Domestic Dog](009-domestic-dog.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Common Eastern Firefly](055-common-eastern-firefly.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Great Horned Owl](020-great-horned-owl.md) can reveal a related defense in another form.
- **Productive tension:** [Domestic Dog](009-domestic-dog.md) and Electric Eel ask for both reciprocal trust and self-generated boundary and perception.
- **Commonly confused:** [Common Eastern Firefly](055-common-eastern-firefly.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Electric Eel in slow river, engaged in the behavior described here: electric eels generate weak electric fields for sensing and communication and stronger discharges for defense and prey capture. Emphasize real anatomy, ecological context, and the tension between internal power and shock tactics. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Electrophorus_electricus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Electric eel taxonomy now includes multiple recognized species; this card retains the specified referent.
- No direct quotation from a commercial guidebook was used.
