---
card_number: 3
animal: "African Elephant"
slug: "african-elephant"
scientific_name: "Loxodonta africana"
alternate_names: ["African bush elephant"]
taxonomic_group: "Mammal"
habitats: ["savanna", "woodland", "scrub", "forest edge"]
geographic_range: ["sub-Saharan Africa"]
activity_cycle: "day and night, shaped by heat and human pressure"
social_pattern: "matriarchal family groups; adult males often separate"
core_archetype: "intergenerational memory"
primary_gifts: ["memory", "intergenerational care", "obstacle sense"]
primary_wounds: ["burden-bearing", "grief fixation", "overprotection"]
elemental_associations: ["earth", "water"]
seasonal_associations: ["late summer"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# African Elephant

## Essence

African Elephant teaches **intergenerational memory**: memory becomes trustworthy when it stays connected to intergenerational care and does not harden into burden-bearing.

## Keywords

memory, intergenerational care, obstacle sense, burden-bearing, grief fixation, overprotection.

## The living animal

### Natural-history facts

- Elephant families use touch, scent, audible calls, and low-frequency sound across distance.
- Older females can hold socially and ecologically useful knowledge about routes, water, and risk.
- Trunks combine breathing, smell, touch, drinking, manipulation, and social contact.
- **Ecological role:** Elephants disperse seeds, open vegetation, dig for water, and reshape habitat at landscape scale.
- **Habitat and range:** savanna, woodland, scrub, forest edge; sub-Saharan Africa.
- **Activity and social pattern:** day and night, shaped by heat and human pressure; matriarchal family groups; adult males often separate.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **intergenerational memory**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

African Elephant occupies the role of **intergenerational memory**. Unlike Humpback Whale, Elephant carries long memory through terrestrial family leadership and direct habitat engineering.

## Gifts

- **Memory:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Intergenerational Care:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Obstacle Sense:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Burden-Bearing:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Grief Fixation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Overprotection:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **memory** can produce **burden-bearing** when safety, timing, or relationship is lost. **intergenerational care** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **obstacle sense** available while loosening the demand to live through **grief fixation**.

## Balanced expression

A balanced expression combines memory, intergenerational care, and obstacle sense. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when memory turns into burden-bearing, or when obstacle sense dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding memory, distrusting intergenerational care, or surrendering obstacle sense even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **memory**; ask whether **burden-bearing** is driving or distorting it. |
| Relationships | Practice **intergenerational care** without asking another person to absorb **grief fixation**. |
| Community | The group may need the **intergenerational memory** role, with explicit limits against **overprotection**. |
| Work and vocation | Use **obstacle sense** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: older females can hold socially and ecologically useful knowledge about routes, water, and risk. |
| Conflict | Choose the proportionate form of **memory** rather than escalating into **burden-bearing**. |
| Healing and restoration | Restore access to **intergenerational care** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **obstacle sense** without repeating **grief fixation**. |
| Change and transition | Use African Elephant as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **memory** accountable to others and monitor for **overprotection**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is memory already alive in my situation?
2. When does intergenerational care become difficult to receive or sustain?
3. Could burden-bearing be protecting something that needs a safer strategy?
4. Am I overexpressing obstacle sense or suppressing it?
5. What does the savanna context teach me about the conditions this quality needs?
6. Where does my analogy with African Elephant stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Write down one inherited lesson that still serves and one burden that is not yours to carry. Take a concrete step to transmit the lesson without the burden.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Hindu art and devotion | The elephant-headed Ganesha is associated with good beginnings and overcoming obstacles in this Smithsonian teaching resource. This is a deity context, not a generic claim about all elephants. | Living Hindu tradition; object-based education | cultural | high | [Smithsonian National Museum of Asian Art, *Seated Ganesha*](https://asia.si.edu/education/educator-resources/encountering-religion-in-asian-art/explore-by-object/object/seated-ganesha/) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for African Elephant. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** African Elephant represents intergenerational memory. The synthesis derives from the verified behaviors above and adopts memory as the primary Gift and burden-bearing as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Humpback Whale](015-humpback-whale.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Ruby-throated Hummingbird](023-ruby-throated-hummingbird.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Common Raven](021-common-raven.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Ruby-throated Hummingbird](023-ruby-throated-hummingbird.md) can reveal a related defense in another form.
- **Productive tension:** [Ruby-throated Hummingbird](023-ruby-throated-hummingbird.md) and African Elephant ask for both precise energetic exchange and intergenerational memory.
- **Commonly confused:** [Humpback Whale](015-humpback-whale.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show African Elephant in savanna, engaged in the behavior described here: elephant families use touch, scent, audible calls, and low-frequency sound across distance. Emphasize real anatomy, ecological context, and the tension between memory and burden-bearing. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Loxodonta_africana/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Smithsonian National Museum of Asian Art, *Seated Ganesha*](https://asia.si.edu/education/educator-resources/encountering-religion-in-asian-art/explore-by-object/object/seated-ganesha/) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Use bush-elephant biology; do not collapse African elephant species.
- No direct quotation from a commercial guidebook was used.
