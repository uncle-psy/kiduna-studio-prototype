---
card_number: 16
animal: "Western Gorilla"
slug: "western-gorilla"
scientific_name: "Gorilla gorilla"
alternate_names: ["gorilla"]
taxonomic_group: "Mammal"
habitats: ["tropical forest", "swamp forest", "secondary forest"]
geographic_range: ["west-central Africa"]
activity_cycle: "diurnal"
social_pattern: "one-male or multi-male groups, females, and young; solitary males also occur"
core_archetype: "restrained protective strength"
primary_gifts: ["quiet strength", "protective leadership", "kin care"]
primary_wounds: ["intimidation", "dominance rigidity", "suppressed vulnerability"]
elemental_associations: ["earth", "water"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Western Gorilla

## Essence

Western Gorilla teaches **restrained protective strength**: quiet strength becomes trustworthy when it stays connected to protective leadership and does not harden into intimidation.

## Keywords

quiet strength, protective leadership, kin care, intimidation, dominance rigidity, suppressed vulnerability.

## The living animal

### Natural-history facts

- Western gorillas forage mostly on vegetation and fruit, with diet shifting by season and habitat.
- Groups communicate through posture, gaze, vocalization, touch, and displays; charges often communicate before contact.
- Young depend on long maternal care and social learning.
- **Ecological role:** Gorillas disperse seeds and depend on large, connected forest habitat.
- **Habitat and range:** tropical forest, swamp forest, secondary forest; west-central Africa.
- **Activity and social pattern:** diurnal; one-male or multi-male groups, females, and young; solitary males also occur.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **restrained protective strength**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Western Gorilla occupies the role of **restrained protective strength**. Unlike Lion, Gorilla centers strength that protects through restraint and social continuity rather than coalition competition and visible rule.

## Gifts

- **Quiet Strength:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Protective Leadership:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Kin Care:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Intimidation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Dominance Rigidity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Suppressed Vulnerability:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **quiet strength** can produce **intimidation** when safety, timing, or relationship is lost. **protective leadership** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **kin care** available while loosening the demand to live through **dominance rigidity**.

## Balanced expression

A balanced expression combines quiet strength, protective leadership, and kin care. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when quiet strength turns into intimidation, or when kin care dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding quiet strength, distrusting protective leadership, or surrendering kin care even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **quiet strength**; ask whether **intimidation** is driving or distorting it. |
| Relationships | Practice **protective leadership** without asking another person to absorb **dominance rigidity**. |
| Community | The group may need the **restrained protective strength** role, with explicit limits against **suppressed vulnerability**. |
| Work and vocation | Use **kin care** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: groups communicate through posture, gaze, vocalization, touch, and displays; charges often communicate before contact. |
| Conflict | Choose the proportionate form of **quiet strength** rather than escalating into **intimidation**. |
| Healing and restoration | Restore access to **protective leadership** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **kin care** without repeating **dominance rigidity**. |
| Change and transition | Use Western Gorilla as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **quiet strength** accountable to others and monitor for **suppressed vulnerability**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is quiet strength already alive in my situation?
2. When does protective leadership become difficult to receive or sustain?
3. Could intimidation be protecting something that needs a safer strategy?
4. Am I overexpressing kin care or suppressing it?
5. What does the tropical forest context teach me about the conditions this quality needs?
6. Where does my analogy with Western Gorilla stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Lower the volume of one display while keeping the boundary intact. Ask what protection would look like if it did not require intimidation.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Western Gorilla. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Western Gorilla represents restrained protective strength. The synthesis derives from the verified behaviors above and adopts quiet strength as the primary Gift and intimidation as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [African Elephant](003-african-elephant.md) expands the Gift through a different ecological strategy.
- **Balancing:** [European Mantis](054-european-mantis.md) interrupts this card's likely overexpression.
- **Shared Gift:** [African Elephant](003-african-elephant.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [King Cobra](033-king-cobra.md) can reveal a related defense in another form.
- **Productive tension:** [European Mantis](054-european-mantis.md) and Western Gorilla ask for both poised response and restrained protective strength.
- **Commonly confused:** [African Elephant](003-african-elephant.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Western Gorilla in tropical forest, engaged in the behavior described here: western gorillas forage mostly on vegetation and fruit, with diet shifting by season and habitat. Emphasize real anatomy, ecological context, and the tension between quiet strength and intimidation. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Gorilla_gorilla/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Conservation status and disease risk require current review.
- No direct quotation from a commercial guidebook was used.
