---
card_number: 20
animal: "Great Horned Owl"
slug: "great-horned-owl"
scientific_name: "Bubo virginianus"
alternate_names: ["great horned owl"]
taxonomic_group: "Bird"
habitats: ["forest", "desert", "wetland edge", "urban park"]
geographic_range: ["North America", "Central America", "northern South America"]
activity_cycle: "nocturnal and crepuscular"
social_pattern: "territorial pairs; otherwise mostly solitary"
core_archetype: "silent threshold discernment"
primary_gifts: ["nocturnal discernment", "silent focus", "threshold awareness"]
primary_wounds: ["secrecy", "predatory certainty", "isolation"]
elemental_associations: ["air", "earth"]
seasonal_associations: ["winter"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# Great Horned Owl

## Essence

Great Horned Owl teaches **silent threshold discernment**: nocturnal discernment becomes trustworthy when it stays connected to silent focus and does not harden into secrecy.

## Keywords

nocturnal discernment, silent focus, threshold awareness, secrecy, predatory certainty, isolation.

## The living animal

### Natural-history facts

- Great horned owls occupy diverse habitats and take a wide range of prey.
- Soft-edged flight feathers reduce flight noise, while strong hearing and low-light vision support nocturnal hunting.
- Pairs defend territories with vocalizations and commonly use existing nests rather than building from scratch.
- **Ecological role:** These owls are powerful generalist predators within nocturnal food webs.
- **Habitat and range:** forest, desert, wetland edge, urban park; North America, Central America, northern South America.
- **Activity and social pattern:** nocturnal and crepuscular; territorial pairs; otherwise mostly solitary.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **silent threshold discernment**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Great Horned Owl occupies the role of **silent threshold discernment**. Unlike Bat, Owl receives subtle cues in silence and commits from concealment rather than actively echolocating.

## Gifts

- **Nocturnal Discernment:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Silent Focus:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Threshold Awareness:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Secrecy:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Predatory Certainty:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Isolation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **nocturnal discernment** can produce **secrecy** when safety, timing, or relationship is lost. **silent focus** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **threshold awareness** available while loosening the demand to live through **predatory certainty**.

## Balanced expression

A balanced expression combines nocturnal discernment, silent focus, and threshold awareness. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when nocturnal discernment turns into secrecy, or when threshold awareness dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding nocturnal discernment, distrusting silent focus, or surrendering threshold awareness even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **nocturnal discernment**; ask whether **secrecy** is driving or distorting it. |
| Relationships | Practice **silent focus** without asking another person to absorb **predatory certainty**. |
| Community | The group may need the **silent threshold discernment** role, with explicit limits against **isolation**. |
| Work and vocation | Use **threshold awareness** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: soft-edged flight feathers reduce flight noise, while strong hearing and low-light vision support nocturnal hunting. |
| Conflict | Choose the proportionate form of **nocturnal discernment** rather than escalating into **secrecy**. |
| Healing and restoration | Restore access to **silent focus** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **threshold awareness** without repeating **predatory certainty**. |
| Change and transition | Use Great Horned Owl as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **nocturnal discernment** accountable to others and monitor for **isolation**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is nocturnal discernment already alive in my situation?
2. When does silent focus become difficult to receive or sustain?
3. Could secrecy be protecting something that needs a safer strategy?
4. Am I overexpressing threshold awareness or suppressing it?
5. What does the forest context teach me about the conditions this quality needs?
6. Where does my analogy with Great Horned Owl stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Spend five minutes observing without preparing a conclusion. Then write what you know, what you infer, and what remains hidden.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Greek textual tradition | Tzetzes identifies the little owl of Athena with wisdom and seeing what is obscure. The historical species is not the great horned owl. | Byzantine Greek text preserving older association | historical | medium | [Tzetzes, *Chiliades* 8.50](https://www.theoi.com/Text/TzetzesChiliades8.html) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Great Horned Owl. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Great Horned Owl represents silent threshold discernment. The synthesis derives from the verified behaviors above and adopts nocturnal discernment as the primary Gift and secrecy as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Little Brown Bat](013-little-brown-bat.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Common Eastern Firefly](055-common-eastern-firefly.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Little Brown Bat](013-little-brown-bat.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Tiger Salamander](040-tiger-salamander.md) can reveal a related defense in another form.
- **Productive tension:** [Common Eastern Firefly](055-common-eastern-firefly.md) and Great Horned Owl ask for both timely illumination and silent threshold discernment.
- **Commonly confused:** [Little Brown Bat](013-little-brown-bat.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Great Horned Owl in forest, engaged in the behavior described here: great horned owls occupy diverse habitats and take a wide range of prey. Emphasize real anatomy, ecological context, and the tension between nocturnal discernment and secrecy. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.allaboutbirds.org/guide/Great_Horned_Owl/lifehistory) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Tzetzes, *Chiliades* 8.50](https://www.theoi.com/Text/TzetzesChiliades8.html) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
