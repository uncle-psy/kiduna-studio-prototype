---
card_number: 37
animal: "Mojave Desert Tortoise"
slug: "mojave-desert-tortoise"
scientific_name: "Gopherus agassizii"
alternate_names: ["desert tortoise"]
taxonomic_group: "Reptile"
habitats: ["desert scrub", "alluvial fan", "rocky slope"]
geographic_range: ["Mojave Desert of the southwestern United States"]
activity_cycle: "diurnal/crepuscular seasonally; long burrow dormancy"
social_pattern: "mostly solitary"
core_archetype: "resource-paced endurance"
primary_gifts: ["conservation", "durable boundaries", "resource pacing"]
primary_wounds: ["rigidity", "withdrawal", "fear of change"]
elemental_associations: ["earth", "fire"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# Mojave Desert Tortoise

## Essence

Mojave Desert Tortoise teaches **resource-paced endurance**: conservation becomes trustworthy when it stays connected to durable boundaries and does not harden into rigidity.

## Keywords

conservation, durable boundaries, resource pacing, rigidity, withdrawal, fear of change.

## The living animal

### Natural-history facts

- Desert tortoises spend much of the year in burrows that buffer heat, cold, and dryness.
- They store water physiologically and time surface activity to favorable temperature and rainfall.
- Diet consists mainly of desert plants, and reproduction is slow.
- **Ecological role:** Burrows can shelter other species; populations are vulnerable to habitat fragmentation, disease, vehicles, and collection.
- **Habitat and range:** desert scrub, alluvial fan, rocky slope; Mojave Desert of the southwestern United States.
- **Activity and social pattern:** diurnal/crepuscular seasonally; long burrow dormancy; mostly solitary.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **resource-paced endurance**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Mojave Desert Tortoise occupies the role of **resource-paced endurance**. Unlike Green Turtle, Tortoise models staying with one arid homeland and rationing scarce resources rather than ocean migration and return.

## Gifts

- **Conservation:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Durable Boundaries:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Resource Pacing:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Rigidity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Withdrawal:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Fear Of Change:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **conservation** can produce **rigidity** when safety, timing, or relationship is lost. **durable boundaries** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **resource pacing** available while loosening the demand to live through **withdrawal**.

## Balanced expression

A balanced expression combines conservation, durable boundaries, and resource pacing. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when conservation turns into rigidity, or when resource pacing dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding conservation, distrusting durable boundaries, or surrendering resource pacing even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **conservation**; ask whether **rigidity** is driving or distorting it. |
| Relationships | Practice **durable boundaries** without asking another person to absorb **withdrawal**. |
| Community | The group may need the **resource-paced endurance** role, with explicit limits against **fear of change**. |
| Work and vocation | Use **resource pacing** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they store water physiologically and time surface activity to favorable temperature and rainfall. |
| Conflict | Choose the proportionate form of **conservation** rather than escalating into **rigidity**. |
| Healing and restoration | Restore access to **durable boundaries** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **resource pacing** without repeating **withdrawal**. |
| Change and transition | Use Mojave Desert Tortoise as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **conservation** accountable to others and monitor for **fear of change**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is conservation already alive in my situation?
2. When does durable boundaries become difficult to receive or sustain?
3. Could rigidity be protecting something that needs a safer strategy?
4. Am I overexpressing resource pacing or suppressing it?
5. What does the desert scrub context teach me about the conditions this quality needs?
6. Where does my analogy with Mojave Desert Tortoise stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Audit one limited resource—time, money, water, or attention. Set a protective budget that still includes a scheduled emergence.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Chinese and Japanese art history | Turtle/tortoise forms are linked in the object record with longevity, endurance, and divination. The species is not a Mojave tortoise. | Chinese Sui–Tang object; later East Asian symbolism | historical | medium | [Met, turtle-shaped inkstone](https://www.metmuseum.org/art/collection/search/65348) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Mojave Desert Tortoise. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Mojave Desert Tortoise represents resource-paced endurance. The synthesis derives from the verified behaviors above and adopts conservation as the primary Gift and rigidity as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Garden Snail](061-garden-snail.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Peregrine Falcon](026-peregrine-falcon.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Garden Snail](061-garden-snail.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Peregrine Falcon](026-peregrine-falcon.md) can reveal a related defense in another form.
- **Productive tension:** [Peregrine Falcon](026-peregrine-falcon.md) and Mojave Desert Tortoise ask for both committed velocity and resource-paced endurance.
- **Commonly confused:** [Garden Snail](061-garden-snail.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Mojave Desert Tortoise in desert scrub, engaged in the behavior described here: desert tortoises spend much of the year in burrows that buffer heat, cold, and dryness. Emphasize real anatomy, ecological context, and the tension between conservation and rigidity. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Gopherus_agassizii/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Met, turtle-shaped inkstone](https://www.metmuseum.org/art/collection/search/65348) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Do not touch or relocate wild tortoises except under local official guidance.
- No direct quotation from a commercial guidebook was used.
