# Complete Card Guide

All 68 core cards are complete research drafts with consistent YAML metadata and required sections.

| No. | Animal | Scientific name | Group | Core archetype |
|---:|---|---|---|---|
| 1 | [Gray Wolf](001-gray-wolf.md) | *Canis lupus* | Mammal | coordinated belonging |
| 2 | [African Lion](002-african-lion.md) | *Panthera leo* | Mammal | courageous presence |
| 3 | [African Elephant](003-african-elephant.md) | *Loxodonta africana* | Mammal | intergenerational memory |
| 4 | [Red Fox](004-red-fox.md) | *Vulpes vulpes* | Mammal | adaptive edge-walker |
| 5 | [American Black Bear](005-american-black-bear.md) | *Ursus americanus* | Mammal | resourceful retreat |
| 6 | [White-tailed Deer](006-white-tailed-deer.md) | *Odocoileus virginianus* | Mammal | sensitive responsiveness |
| 7 | [American Bison](007-american-bison.md) | *Bison bison* | Mammal | grounded communal endurance |
| 8 | [Domestic Horse](008-domestic-horse.md) | *Equus caballus* | Mammal | embodied partnership in motion |
| 9 | [Domestic Dog](009-domestic-dog.md) | *Canis lupus familiaris* | Mammal | reciprocal trust |
| 10 | [Domestic Cat](010-domestic-cat.md) | *Felis catus* | Mammal | self-possessed intimacy |
| 11 | [North American Beaver](011-north-american-beaver.md) | *Castor canadensis* | Mammal | constructive systems work |
| 12 | [North American River Otter](012-north-american-river-otter.md) | *Lontra canadensis* | Mammal | skillful play |
| 13 | [Little Brown Bat](013-little-brown-bat.md) | *Myotis lucifugus* | Mammal | discernment in darkness |
| 14 | [Common Bottlenose Dolphin](014-bottlenose-dolphin.md) | *Tursiops truncatus* | Mammal | communicative cooperation |
| 15 | [Humpback Whale](015-humpback-whale.md) | *Megaptera novaeangliae* | Mammal | long-range voice and return |
| 16 | [Western Gorilla](016-western-gorilla.md) | *Gorilla gorilla* | Mammal | restrained protective strength |
| 17 | [Red Kangaroo](017-red-kangaroo.md) | *Osphranter rufus* | Mammal | stored momentum |
| 18 | [Platypus](018-platypus.md) | *Ornithorhynchus anatinus* | Mammal | integrative originality |
| 19 | [Bald Eagle](019-bald-eagle.md) | *Haliaeetus leucocephalus* | Bird | wide perspective with accountable descent |
| 20 | [Great Horned Owl](020-great-horned-owl.md) | *Bubo virginianus* | Bird | silent threshold discernment |
| 21 | [Common Raven](021-common-raven.md) | *Corvus corax* | Bird | curious memory-maker |
| 22 | [Red-tailed Hawk](022-red-tailed-hawk.md) | *Buteo jamaicensis* | Bird | patient surveillance |
| 23 | [Ruby-throated Hummingbird](023-ruby-throated-hummingbird.md) | *Archilochus colubris* | Bird | precise energetic exchange |
| 24 | [Emperor Penguin](024-emperor-penguin.md) | *Aptenodytes forsteri* | Bird | collective warmth under pressure |
| 25 | [Sandhill Crane](025-sandhill-crane.md) | *Antigone canadensis* | Bird | attentive fidelity |
| 26 | [Peregrine Falcon](026-peregrine-falcon.md) | *Falco peregrinus* | Bird | committed velocity |
| 27 | [Laysan Albatross](027-laysan-albatross.md) | *Phoebastria immutabilis* | Bird | oceanic patience |
| 28 | [Wild Turkey](028-wild-turkey.md) | *Meleagris gallopavo* | Bird | grounded abundance |
| 29 | [Greater Flamingo](029-greater-flamingo.md) | *Phoenicopterus roseus* | Bird | selective filtering in company |
| 30 | [Indian Peafowl](030-indian-peafowl.md) | *Pavo cristatus* | Bird | truthful display |
| 31 | [Emu](031-emu.md) | *Dromaius novaehollandiae* | Bird | steady adaptive stride |
| 32 | [Green Sea Turtle](032-green-sea-turtle.md) | *Chelonia mydas* | Reptile | patient navigation and return |
| 33 | [King Cobra](033-king-cobra.md) | *Ophiophagus hannah* | Reptile | measured warning and power |
| 34 | [American Alligator](034-american-alligator.md) | *Alligator mississippiensis* | Reptile | patient threshold defense |
| 35 | [Panther Chameleon](035-panther-chameleon.md) | *Furcifer pardalis* | Reptile | contextual adaptation without disappearance |
| 36 | [Komodo Dragon](036-komodo-dragon.md) | *Varanus komodoensis* | Reptile | formidable economy |
| 37 | [Mojave Desert Tortoise](037-mojave-desert-tortoise.md) | *Gopherus agassizii* | Reptile | resource-paced endurance |
| 38 | [Axolotl](038-axolotl.md) | *Ambystoma mexicanum* | Amphibian | regenerative openness |
| 39 | [Dyeing Poison Frog](039-dyeing-poison-frog.md) | *Dendrobates tinctorius* | Amphibian | visible boundary |
| 40 | [Tiger Salamander](040-tiger-salamander.md) | *Ambystoma tigrinum* | Amphibian | hidden metamorphosis |
| 41 | [American Bullfrog](041-american-bullfrog.md) | *Lithobates catesbeianus* | Amphibian | amphibious voice |
| 42 | [Great White Shark](042-great-white-shark.md) | *Carcharodon carcharias* | Fish | decisive sensory clarity |
| 43 | [Atlantic Salmon](043-atlantic-salmon.md) | *Salmo salar* | Fish | return informed by place-memory |
| 44 | [Ocellaris Clownfish](044-ocellaris-clownfish.md) | *Amphiprion ocellaris* | Fish | mutual belonging |
| 45 | [Lined Seahorse](045-lined-seahorse.md) | *Hippocampus erectus* | Fish | receptive care |
| 46 | [Electric Eel](046-electric-eel.md) | *Electrophorus electricus* | Fish | self-generated boundary and perception |
| 47 | [Reef Manta Ray](047-reef-manta-ray.md) | *Mobula alfredi* | Fish | graceful scale |
| 48 | [Spot-fin Porcupinefish](048-porcupinefish.md) | *Diodon hystrix* | Fish | adaptive deterrence |
| 49 | [Banded Archerfish](049-banded-archerfish.md) | *Toxotes jaculatrix* | Fish | calibrated aim |
| 50 | [Western Honey Bee](050-western-honey-bee.md) | *Apis mellifera* | Insect | distributed cooperation |
| 51 | [Monarch Butterfly](051-monarch-butterfly.md) | *Danaus plexippus* | Insect | generational transformation |
| 52 | [Common Green Darner](052-common-green-darner.md) | *Anax junius* | Insect | life-stage agility |
| 53 | [Sacred Scarab](053-sacred-scarab.md) | *Scarabaeus sacer* | Insect | renewal through what is discarded |
| 54 | [European Mantis](054-european-mantis.md) | *Mantis religiosa* | Insect | poised response |
| 55 | [Common Eastern Firefly](055-common-eastern-firefly.md) | *Photinus pyralis* | Insect | timely illumination |
| 56 | [Leafcutter Ant](056-leafcutter-ant.md) | *Atta cephalotes* | Insect | cultivated infrastructure |
| 57 | [Cross Orbweaver](057-cross-orbweaver.md) | *Araneus diadematus* | Arachnid | sensitive pattern-maker |
| 58 | [Emperor Scorpion](058-emperor-scorpion.md) | *Pandinus imperator* | Arachnid | calibrated defense |
| 59 | [Common Octopus](059-common-octopus.md) | *Octopus vulgaris* | Mollusk | flexible distributed intelligence |
| 60 | [Chambered Nautilus](060-chambered-nautilus.md) | *Nautilus pompilius* | Mollusk | chambered continuity |
| 61 | [Garden Snail](061-garden-snail.md) | *Cornu aspersum* | Mollusk | portable pacing |
| 62 | [Caribbean Hermit Crab](062-caribbean-hermit-crab.md) | *Coenobita clypeatus* | Crustacean | adaptive housing |
| 63 | [Peacock Mantis Shrimp](063-peacock-mantis-shrimp.md) | *Odontodactylus scyllarus* | Crustacean | complex perception with rapid force |
| 64 | [Moon Jelly](064-moon-jelly.md) | *Aurelia aurita* | Other marine invertebrate | rhythmic receptivity |
| 65 | [Ochre Sea Star](065-ochre-sea-star.md) | *Pisaster ochraceus* | Other marine invertebrate | distributed keystone influence |
| 66 | [Staghorn Coral](066-staghorn-coral.md) | *Acropora cervicornis* | Other marine invertebrate | collective habitat-making |
| 67 | [Giant Pacific Sea Cucumber](067-giant-pacific-sea-cucumber.md) | *Apostichopus californicus* | Other marine invertebrate | quiet recycling |
| 68 | [Common Earthworm](068-common-earthworm.md) | *Lumbricus terrestris* | Annelid | humble transformation |

Return to the [manual README](../README.md).
