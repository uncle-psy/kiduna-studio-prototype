---
card_number: 40
animal: "Tiger Salamander"
slug: "tiger-salamander"
scientific_name: "Ambystoma tigrinum"
alternate_names: ["tiger salamander"]
taxonomic_group: "Amphibian"
habitats: ["grassland", "woodland", "burrow", "seasonal pond"]
geographic_range: ["North America"]
activity_cycle: "mostly nocturnal; seasonal emergence"
social_pattern: "mostly solitary"
core_archetype: "hidden metamorphosis"
primary_gifts: ["renewal", "seasonal emergence", "metamorphic capacity"]
primary_wounds: ["avoidant dormancy", "secrecy", "stalled transformation"]
elemental_associations: ["water", "earth"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Tiger Salamander

## Essence

Tiger Salamander teaches **hidden metamorphosis**: renewal becomes trustworthy when it stays connected to seasonal emergence and does not harden into avoidant dormancy.

## Keywords

renewal, seasonal emergence, metamorphic capacity, avoidant dormancy, secrecy, stalled transformation.

## The living animal

### Natural-history facts

- Tiger salamanders spend much of their terrestrial adult life underground in burrows.
- They emerge under favorable moist conditions and return to ponds to breed.
- Aquatic larvae generally metamorphose, though development varies with environment and population.
- **Ecological role:** They connect pond and land food webs as both predators and prey.
- **Habitat and range:** grassland, woodland, burrow, seasonal pond; North America.
- **Activity and social pattern:** mostly nocturnal; seasonal emergence; mostly solitary.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **hidden metamorphosis**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Tiger Salamander occupies the role of **hidden metamorphosis**. Unlike Axolotl, Tiger Salamander emphasizes leaving one medium for another when development and conditions permit.

## Gifts

- **Renewal:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Seasonal Emergence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Metamorphic Capacity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Avoidant Dormancy:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Secrecy:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Stalled Transformation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **renewal** can produce **avoidant dormancy** when safety, timing, or relationship is lost. **seasonal emergence** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **metamorphic capacity** available while loosening the demand to live through **secrecy**.

## Balanced expression

A balanced expression combines renewal, seasonal emergence, and metamorphic capacity. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when renewal turns into avoidant dormancy, or when metamorphic capacity dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding renewal, distrusting seasonal emergence, or surrendering metamorphic capacity even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **renewal**; ask whether **avoidant dormancy** is driving or distorting it. |
| Relationships | Practice **seasonal emergence** without asking another person to absorb **secrecy**. |
| Community | The group may need the **hidden metamorphosis** role, with explicit limits against **stalled transformation**. |
| Work and vocation | Use **metamorphic capacity** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they emerge under favorable moist conditions and return to ponds to breed. |
| Conflict | Choose the proportionate form of **renewal** rather than escalating into **avoidant dormancy**. |
| Healing and restoration | Restore access to **seasonal emergence** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **metamorphic capacity** without repeating **secrecy**. |
| Change and transition | Use Tiger Salamander as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **renewal** accountable to others and monitor for **stalled transformation**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is renewal already alive in my situation?
2. When does seasonal emergence become difficult to receive or sustain?
3. Could avoidant dormancy be protecting something that needs a safer strategy?
4. Am I overexpressing metamorphic capacity or suppressing it?
5. What does the grassland context teach me about the conditions this quality needs?
6. Where does my analogy with Tiger Salamander stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Identify whether you are incubating change or hiding from it. Choose one safe emergence tied to real conditions rather than an arbitrary deadline.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Tiger Salamander. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Tiger Salamander represents hidden metamorphosis. The synthesis derives from the verified behaviors above and adopts renewal as the primary Gift and avoidant dormancy as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Common Green Darner](052-common-green-darner.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Chambered Nautilus](060-chambered-nautilus.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Indian Peafowl](030-indian-peafowl.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Great Horned Owl](020-great-horned-owl.md) can reveal a related defense in another form.
- **Productive tension:** [Chambered Nautilus](060-chambered-nautilus.md) and Tiger Salamander ask for both chambered continuity and hidden metamorphosis.
- **Commonly confused:** [Common Green Darner](052-common-green-darner.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Tiger Salamander in grassland, engaged in the behavior described here: tiger salamanders spend much of their terrestrial adult life underground in burrows. Emphasize real anatomy, ecological context, and the tension between renewal and avoidant dormancy. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Ambystoma_tigrinum/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
