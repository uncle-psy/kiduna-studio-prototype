---
card_number: 64
animal: "Moon Jelly"
slug: "moon-jelly"
scientific_name: "Aurelia aurita"
alternate_names: ["moon jellyfish"]
taxonomic_group: "Other marine invertebrate"
habitats: ["coastal ocean", "bay", "estuary"]
geographic_range: ["temperate and tropical seas; species complex"]
activity_cycle: "day and night, moved by pulses and currents"
social_pattern: "aggregations shaped by current and food"
core_archetype: "rhythmic receptivity"
primary_gifts: ["receptivity", "rhythmic flow", "transparency"]
primary_wounds: ["drift", "porous boundaries", "passivity"]
elemental_associations: ["water", "air"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Moon Jelly

## Essence

Moon Jelly teaches **rhythmic receptivity**: receptivity becomes trustworthy when it stays connected to rhythmic flow and does not harden into drift.

## Keywords

receptivity, rhythmic flow, transparency, drift, porous boundaries, passivity.

## The living animal

### Natural-history facts

- Moon jellies pulse their bells but are also strongly transported by currents.
- Tentacles and oral arms capture plankton; a simple nerve net coordinates movement and response.
- Their life cycle alternates between attached polyps and free-swimming medusae.
- **Ecological role:** Jellies are predators and prey whose blooms respond to food webs, temperature, oxygen, and water movement.
- **Habitat and range:** coastal ocean, bay, estuary; temperate and tropical seas; species complex.
- **Activity and social pattern:** day and night, moved by pulses and currents; aggregations shaped by current and food.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **rhythmic receptivity**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Moon Jelly occupies the role of **rhythmic receptivity**. Unlike Reef Manta, Moon Jelly yields much more of its route to current and transforms across attached and drifting life stages.

## Gifts

- **Receptivity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Rhythmic Flow:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Transparency:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Drift:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Porous Boundaries:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Passivity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **receptivity** can produce **drift** when safety, timing, or relationship is lost. **rhythmic flow** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **transparency** available while loosening the demand to live through **porous boundaries**.

## Balanced expression

A balanced expression combines receptivity, rhythmic flow, and transparency. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when receptivity turns into drift, or when transparency dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding receptivity, distrusting rhythmic flow, or surrendering transparency even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **receptivity**; ask whether **drift** is driving or distorting it. |
| Relationships | Practice **rhythmic flow** without asking another person to absorb **porous boundaries**. |
| Community | The group may need the **rhythmic receptivity** role, with explicit limits against **passivity**. |
| Work and vocation | Use **transparency** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: tentacles and oral arms capture plankton; a simple nerve net coordinates movement and response. |
| Conflict | Choose the proportionate form of **receptivity** rather than escalating into **drift**. |
| Healing and restoration | Restore access to **rhythmic flow** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **transparency** without repeating **porous boundaries**. |
| Change and transition | Use Moon Jelly as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **receptivity** accountable to others and monitor for **passivity**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is receptivity already alive in my situation?
2. When does rhythmic flow become difficult to receive or sustain?
3. Could drift be protecting something that needs a safer strategy?
4. Am I overexpressing transparency or suppressing it?
5. What does the coastal ocean context teach me about the conditions this quality needs?
6. Where does my analogy with Moon Jelly stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Feel the current around a decision—deadlines, incentives, expectations. Choose one small pulse that changes direction instead of confusing receptivity with surrender.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Moon Jelly. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Moon Jelly represents rhythmic receptivity. The synthesis derives from the verified behaviors above and adopts receptivity as the primary Gift and drift as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Reef Manta Ray](047-reef-manta-ray.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Peacock Mantis Shrimp](063-peacock-mantis-shrimp.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Reef Manta Ray](047-reef-manta-ray.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Lined Seahorse](045-lined-seahorse.md) can reveal a related defense in another form.
- **Productive tension:** [Peacock Mantis Shrimp](063-peacock-mantis-shrimp.md) and Moon Jelly ask for both complex perception with rapid force and rhythmic receptivity.
- **Commonly confused:** [Reef Manta Ray](047-reef-manta-ray.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Moon Jelly in coastal ocean, engaged in the behavior described here: moon jellies pulse their bells but are also strongly transported by currents. Emphasize real anatomy, ecological context, and the tension between receptivity and drift. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Aurelia_aurita/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Aurelia is a species complex; avoid global single-species claims.
- No direct quotation from a commercial guidebook was used.
