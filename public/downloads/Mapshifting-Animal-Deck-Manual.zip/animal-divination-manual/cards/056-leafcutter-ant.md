---
card_number: 56
animal: "Leafcutter Ant"
slug: "leafcutter-ant"
scientific_name: "Atta cephalotes"
alternate_names: ["leaf-cutting ant"]
taxonomic_group: "Insect"
habitats: ["tropical forest", "forest edge", "agricultural mosaic"]
geographic_range: ["Central America", "northern South America"]
activity_cycle: "day and night; weather-dependent"
social_pattern: "eusocial colonies with specialized castes"
core_archetype: "cultivated infrastructure"
primary_gifts: ["distributed work", "cultivation", "infrastructure"]
primary_wounds: ["self-erasure in labor", "rigid hierarchy", "relentless extraction"]
elemental_associations: ["earth", "air"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Leafcutter Ant

## Essence

Leafcutter Ant teaches **cultivated infrastructure**: distributed work becomes trustworthy when it stays connected to cultivation and does not harden into self-erasure in labor.

## Keywords

distributed work, cultivation, infrastructure, self-erasure in labor, rigid hierarchy, relentless extraction.

## The living animal

### Natural-history facts

- Leafcutter ants cut vegetation to provision a cultivated fungus rather than eating the leaves directly.
- Colonies divide labor by size and task and maintain trails, chambers, waste areas, and fungus gardens.
- Communication through pheromone trails coordinates large flows of workers and material.
- **Ecological role:** Colonies alter vegetation, soil, nutrient movement, and relationships with fungi and microbes.
- **Habitat and range:** tropical forest, forest edge, agricultural mosaic; Central America, northern South America.
- **Activity and social pattern:** day and night; weather-dependent; eusocial colonies with specialized castes.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **cultivated infrastructure**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Leafcutter Ant occupies the role of **cultivated infrastructure**. Unlike Beaver, Leafcutter Ant builds a vast specialized production system whose agriculture depends on many small roles.

## Gifts

- **Distributed Work:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Cultivation:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Infrastructure:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Self-Erasure In Labor:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Rigid Hierarchy:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Relentless Extraction:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **distributed work** can produce **self-erasure in labor** when safety, timing, or relationship is lost. **cultivation** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **infrastructure** available while loosening the demand to live through **rigid hierarchy**.

## Balanced expression

A balanced expression combines distributed work, cultivation, and infrastructure. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when distributed work turns into self-erasure in labor, or when infrastructure dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding distributed work, distrusting cultivation, or surrendering infrastructure even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **distributed work**; ask whether **self-erasure in labor** is driving or distorting it. |
| Relationships | Practice **cultivation** without asking another person to absorb **rigid hierarchy**. |
| Community | The group may need the **cultivated infrastructure** role, with explicit limits against **relentless extraction**. |
| Work and vocation | Use **infrastructure** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: colonies divide labor by size and task and maintain trails, chambers, waste areas, and fungus gardens. |
| Conflict | Choose the proportionate form of **distributed work** rather than escalating into **self-erasure in labor**. |
| Healing and restoration | Restore access to **cultivation** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **infrastructure** without repeating **rigid hierarchy**. |
| Change and transition | Use Leafcutter Ant as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **distributed work** accountable to others and monitor for **relentless extraction**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is distributed work already alive in my situation?
2. When does cultivation become difficult to receive or sustain?
3. Could self-erasure in labor be protecting something that needs a safer strategy?
4. Am I overexpressing infrastructure or suppressing it?
5. What does the tropical forest context teach me about the conditions this quality needs?
6. Where does my analogy with Leafcutter Ant stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Trace one product back through every person and resource that sustains it. Improve one labor condition before asking the system for more output.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Leafcutter Ant. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Leafcutter Ant represents cultivated infrastructure. The synthesis derives from the verified behaviors above and adopts distributed work as the primary Gift and self-erasure in labor as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [North American Beaver](011-north-american-beaver.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Common Octopus](059-common-octopus.md) interrupts this card's likely overexpression.
- **Shared Gift:** [North American Beaver](011-north-american-beaver.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Common Octopus](059-common-octopus.md) can reveal a related defense in another form.
- **Productive tension:** [Common Octopus](059-common-octopus.md) and Leafcutter Ant ask for both flexible distributed intelligence and cultivated infrastructure.
- **Commonly confused:** [North American Beaver](011-north-american-beaver.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Leafcutter Ant in tropical forest, engaged in the behavior described here: leafcutter ants cut vegetation to provision a cultivated fungus rather than eating the leaves directly. Emphasize real anatomy, ecological context, and the tension between distributed work and self-erasure in labor. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Atta_cephalotes/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- ADW may provide taxonomy only; fungus-farming claims require entomology review.
- No direct quotation from a commercial guidebook was used.
