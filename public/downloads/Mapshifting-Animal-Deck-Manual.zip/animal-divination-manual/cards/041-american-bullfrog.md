---
card_number: 41
animal: "American Bullfrog"
slug: "american-bullfrog"
scientific_name: "Lithobates catesbeianus"
alternate_names: ["bullfrog"]
taxonomic_group: "Amphibian"
habitats: ["pond", "lake edge", "marsh", "slow stream"]
geographic_range: ["eastern North America; introduced widely"]
activity_cycle: "mostly nocturnal"
social_pattern: "territorial males; otherwise dispersed"
core_archetype: "amphibious voice"
primary_gifts: ["vocal presence", "territorial confidence", "transition between elements"]
primary_wounds: ["taking too much space", "invasiveness", "loudness without listening"]
elemental_associations: ["water", "air"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# American Bullfrog

## Essence

American Bullfrog teaches **amphibious voice**: vocal presence becomes trustworthy when it stays connected to territorial confidence and does not harden into taking too much space.

## Keywords

vocal presence, territorial confidence, transition between elements, taking too much space, invasiveness, loudness without listening.

## The living animal

### Natural-history facts

- Male bullfrogs produce carrying calls and defend breeding territories in water.
- They are large, opportunistic predators with aquatic tadpoles and amphibious adults.
- Introduced populations can affect native amphibians and other prey.
- **Ecological role:** Bullfrogs link aquatic and terrestrial food webs but can become ecologically disruptive outside native range.
- **Habitat and range:** pond, lake edge, marsh, slow stream; eastern North America; introduced widely.
- **Activity and social pattern:** mostly nocturnal; territorial males; otherwise dispersed.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **amphibious voice**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

American Bullfrog occupies the role of **amphibious voice**. Unlike Firefly, Bullfrog signals through sustained territorial voice rather than brief coded light.

## Gifts

- **Vocal Presence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Territorial Confidence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Transition Between Elements:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Taking Too Much Space:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Invasiveness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Loudness Without Listening:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **vocal presence** can produce **taking too much space** when safety, timing, or relationship is lost. **territorial confidence** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **transition between elements** available while loosening the demand to live through **invasiveness**.

## Balanced expression

A balanced expression combines vocal presence, territorial confidence, and transition between elements. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when vocal presence turns into taking too much space, or when transition between elements dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding vocal presence, distrusting territorial confidence, or surrendering transition between elements even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **vocal presence**; ask whether **taking too much space** is driving or distorting it. |
| Relationships | Practice **territorial confidence** without asking another person to absorb **invasiveness**. |
| Community | The group may need the **amphibious voice** role, with explicit limits against **loudness without listening**. |
| Work and vocation | Use **transition between elements** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they are large, opportunistic predators with aquatic tadpoles and amphibious adults. |
| Conflict | Choose the proportionate form of **vocal presence** rather than escalating into **taking too much space**. |
| Healing and restoration | Restore access to **territorial confidence** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **transition between elements** without repeating **invasiveness**. |
| Change and transition | Use American Bullfrog as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **vocal presence** accountable to others and monitor for **loudness without listening**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is vocal presence already alive in my situation?
2. When does territorial confidence become difficult to receive or sustain?
3. Could taking too much space be protecting something that needs a safer strategy?
4. Am I overexpressing transition between elements or suppressing it?
5. What does the pond context teach me about the conditions this quality needs?
6. Where does my analogy with American Bullfrog stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Say what space you need in one sentence, then leave equal time for a reply. Presence becomes invasion when it ignores the existing community.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for American Bullfrog. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** American Bullfrog represents amphibious voice. The synthesis derives from the verified behaviors above and adopts vocal presence as the primary Gift and taking too much space as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Common Eastern Firefly](055-common-eastern-firefly.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Great Horned Owl](020-great-horned-owl.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Common Eastern Firefly](055-common-eastern-firefly.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Great Horned Owl](020-great-horned-owl.md) can reveal a related defense in another form.
- **Productive tension:** [Great Horned Owl](020-great-horned-owl.md) and American Bullfrog ask for both silent threshold discernment and amphibious voice.
- **Commonly confused:** [Common Eastern Firefly](055-common-eastern-firefly.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show American Bullfrog in pond, engaged in the behavior described here: male bullfrogs produce carrying calls and defend breeding territories in water. Emphasize real anatomy, ecological context, and the tension between vocal presence and taking too much space. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Lithobates_catesbeianus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomic sources may use Rana catesbeiana; introduced-range impacts are context-dependent.
- No direct quotation from a commercial guidebook was used.
