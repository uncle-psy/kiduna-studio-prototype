---
card_number: 28
animal: "Wild Turkey"
slug: "wild-turkey"
scientific_name: "Meleagris gallopavo"
alternate_names: ["turkey"]
taxonomic_group: "Bird"
habitats: ["forest", "woodland edge", "grassland mosaic"]
geographic_range: ["North America"]
activity_cycle: "diurnal"
social_pattern: "flocks with seasonal sex and age structure"
core_archetype: "grounded abundance"
primary_gifts: ["grounded abundance", "social awareness", "honest display"]
primary_wounds: ["overdisplay", "complacency", "group panic"]
elemental_associations: ["earth", "air"]
seasonal_associations: ["autumn"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Wild Turkey

## Essence

Wild Turkey teaches **grounded abundance**: grounded abundance becomes trustworthy when it stays connected to social awareness and does not harden into overdisplay.

## Keywords

grounded abundance, social awareness, honest display, overdisplay, complacency, group panic.

## The living animal

### Natural-history facts

- Wild turkeys forage on the ground for seeds, nuts, insects, and other foods but roost in trees.
- Flocks and dominance relationships shift by sex and season; courtship includes conspicuous strutting and vocalization.
- Powerful running, alert group behavior, and short explosive flight support survival.
- **Ecological role:** Turkeys move seeds and nutrients through forest-edge systems and respond to habitat mosaics.
- **Habitat and range:** forest, woodland edge, grassland mosaic; North America.
- **Activity and social pattern:** diurnal; flocks with seasonal sex and age structure.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **grounded abundance**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Wild Turkey occupies the role of **grounded abundance**. Unlike Peafowl, Turkey joins display to practical ground foraging, vigilance, and seasonal social structure.

## Gifts

- **Grounded Abundance:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Social Awareness:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Honest Display:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Overdisplay:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Complacency:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Group Panic:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **grounded abundance** can produce **overdisplay** when safety, timing, or relationship is lost. **social awareness** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **honest display** available while loosening the demand to live through **complacency**.

## Balanced expression

A balanced expression combines grounded abundance, social awareness, and honest display. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when grounded abundance turns into overdisplay, or when honest display dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding grounded abundance, distrusting social awareness, or surrendering honest display even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **grounded abundance**; ask whether **overdisplay** is driving or distorting it. |
| Relationships | Practice **social awareness** without asking another person to absorb **complacency**. |
| Community | The group may need the **grounded abundance** role, with explicit limits against **group panic**. |
| Work and vocation | Use **honest display** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: flocks and dominance relationships shift by sex and season; courtship includes conspicuous strutting and vocalization. |
| Conflict | Choose the proportionate form of **grounded abundance** rather than escalating into **overdisplay**. |
| Healing and restoration | Restore access to **social awareness** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **honest display** without repeating **complacency**. |
| Change and transition | Use Wild Turkey as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **grounded abundance** accountable to others and monitor for **group panic**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is grounded abundance already alive in my situation?
2. When does social awareness become difficult to receive or sustain?
3. Could overdisplay be protecting something that needs a safer strategy?
4. Am I overexpressing honest display or suppressing it?
5. What does the forest context teach me about the conditions this quality needs?
6. Where does my analogy with Wild Turkey stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Name what is already enough before seeking more. If you display an accomplishment, connect it to the work and community that made it possible.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Wild Turkey. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Wild Turkey represents grounded abundance. The synthesis derives from the verified behaviors above and adopts grounded abundance as the primary Gift and overdisplay as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Indian Peafowl](030-indian-peafowl.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Great White Shark](042-great-white-shark.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Indian Peafowl](030-indian-peafowl.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Great White Shark](042-great-white-shark.md) can reveal a related defense in another form.
- **Productive tension:** [Great White Shark](042-great-white-shark.md) and Wild Turkey ask for both decisive sensory clarity and grounded abundance.
- **Commonly confused:** [Indian Peafowl](030-indian-peafowl.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Wild Turkey in forest, engaged in the behavior described here: wild turkeys forage on the ground for seeds, nuts, insects, and other foods but roost in trees. Emphasize real anatomy, ecological context, and the tension between grounded abundance and overdisplay. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://www.allaboutbirds.org/guide/Wild_Turkey/lifehistory) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
