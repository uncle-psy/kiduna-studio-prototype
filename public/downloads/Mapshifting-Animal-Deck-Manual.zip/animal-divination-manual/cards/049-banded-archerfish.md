---
card_number: 49
animal: "Banded Archerfish"
slug: "banded-archerfish"
scientific_name: "Toxotes jaculatrix"
alternate_names: ["archerfish", "riflefish"]
taxonomic_group: "Fish"
habitats: ["mangrove", "estuary", "brackish river"]
geographic_range: ["South and Southeast Asia", "northern Australia"]
activity_cycle: "diurnal"
social_pattern: "small groups or solitary"
core_archetype: "calibrated aim"
primary_gifts: ["aim", "learning", "distance judgment"]
primary_wounds: ["overcalculation", "target fixation", "instrumental thinking"]
elemental_associations: ["water", "air"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Banded Archerfish

## Essence

Banded Archerfish teaches **calibrated aim**: aim becomes trustworthy when it stays connected to learning and does not harden into overcalculation.

## Keywords

aim, learning, distance judgment, overcalculation, target fixation, instrumental thinking.

## The living animal

### Natural-history facts

- Archerfish shoot controlled jets of water to knock insects and other prey from vegetation.
- They compensate for optical refraction and adjust aim with distance and angle.
- Individuals can learn by practice and by observing successful shots.
- **Ecological role:** They connect aquatic feeding with insects and vegetation above the water surface.
- **Habitat and range:** mangrove, estuary, brackish river; South and Southeast Asia, northern Australia.
- **Activity and social pattern:** diurnal; small groups or solitary.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **calibrated aim**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Banded Archerfish occupies the role of **calibrated aim**. Unlike Peregrine Falcon, Archerfish acts across a boundary between media through calibration rather than speed and bodily pursuit.

## Gifts

- **Aim:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Learning:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Distance Judgment:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Overcalculation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Target Fixation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Instrumental Thinking:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **aim** can produce **overcalculation** when safety, timing, or relationship is lost. **learning** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **distance judgment** available while loosening the demand to live through **target fixation**.

## Balanced expression

A balanced expression combines aim, learning, and distance judgment. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when aim turns into overcalculation, or when distance judgment dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding aim, distrusting learning, or surrendering distance judgment even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **aim**; ask whether **overcalculation** is driving or distorting it. |
| Relationships | Practice **learning** without asking another person to absorb **target fixation**. |
| Community | The group may need the **calibrated aim** role, with explicit limits against **instrumental thinking**. |
| Work and vocation | Use **distance judgment** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they compensate for optical refraction and adjust aim with distance and angle. |
| Conflict | Choose the proportionate form of **aim** rather than escalating into **overcalculation**. |
| Healing and restoration | Restore access to **learning** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **distance judgment** without repeating **target fixation**. |
| Change and transition | Use Banded Archerfish as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **aim** accountable to others and monitor for **instrumental thinking**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is aim already alive in my situation?
2. When does learning become difficult to receive or sustain?
3. Could overcalculation be protecting something that needs a safer strategy?
4. Am I overexpressing distance judgment or suppressing it?
5. What does the mangrove context teach me about the conditions this quality needs?
6. Where does my analogy with Banded Archerfish stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Define a target and the medium between you and it. Make one measured attempt, observe the miss without shame, and recalibrate.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Banded Archerfish. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Banded Archerfish represents calibrated aim. The synthesis derives from the verified behaviors above and adopts aim as the primary Gift and overcalculation as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Peregrine Falcon](026-peregrine-falcon.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Moon Jelly](064-moon-jelly.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Peregrine Falcon](026-peregrine-falcon.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Moon Jelly](064-moon-jelly.md) can reveal a related defense in another form.
- **Productive tension:** [Moon Jelly](064-moon-jelly.md) and Banded Archerfish ask for both rhythmic receptivity and calibrated aim.
- **Commonly confused:** [Peregrine Falcon](026-peregrine-falcon.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Banded Archerfish in mangrove, engaged in the behavior described here: archerfish shoot controlled jets of water to knock insects and other prey from vegetation. Emphasize real anatomy, ecological context, and the tension between aim and overcalculation. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Toxotes_jaculatrix/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
