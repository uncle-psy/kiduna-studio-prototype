---
card_number: 54
animal: "European Mantis"
slug: "european-mantis"
scientific_name: "Mantis religiosa"
alternate_names: ["praying mantis"]
taxonomic_group: "Insect"
habitats: ["grassland", "shrub", "garden edge"]
geographic_range: ["Europe", "Africa", "Asia; introduced elsewhere"]
activity_cycle: "diurnal"
social_pattern: "solitary"
core_archetype: "poised response"
primary_gifts: ["stillness", "precise response", "embodied attention"]
primary_wounds: ["predatory patience", "emotional detachment", "waiting too long"]
elemental_associations: ["air", "earth"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# European Mantis

## Essence

European Mantis teaches **poised response**: stillness becomes trustworthy when it stays connected to precise response and does not harden into predatory patience.

## Keywords

stillness, precise response, embodied attention, predatory patience, emotional detachment, waiting too long.

## The living animal

### Natural-history facts

- Mantises use grasping forelegs, mobile heads, camouflage, and stillness to ambush prey.
- They track movement visually and can respond with sudden, precise strikes.
- Adults are generally solitary; mating behavior is more variable than simplified cannibalism stories suggest.
- **Ecological role:** Mantises are insect predators within grassland and edge food webs.
- **Habitat and range:** grassland, shrub, garden edge; Europe, Africa, Asia; introduced elsewhere.
- **Activity and social pattern:** diurnal; solitary.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **poised response**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

European Mantis occupies the role of **poised response**. Unlike Great Horned Owl, Mantis brings still attention into a small exposed body and immediate reach rather than nocturnal flight.

## Gifts

- **Stillness:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Precise Response:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Embodied Attention:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Predatory Patience:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Emotional Detachment:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Waiting Too Long:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **stillness** can produce **predatory patience** when safety, timing, or relationship is lost. **precise response** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **embodied attention** available while loosening the demand to live through **emotional detachment**.

## Balanced expression

A balanced expression combines stillness, precise response, and embodied attention. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when stillness turns into predatory patience, or when embodied attention dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding stillness, distrusting precise response, or surrendering embodied attention even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **stillness**; ask whether **predatory patience** is driving or distorting it. |
| Relationships | Practice **precise response** without asking another person to absorb **emotional detachment**. |
| Community | The group may need the **poised response** role, with explicit limits against **waiting too long**. |
| Work and vocation | Use **embodied attention** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they track movement visually and can respond with sudden, precise strikes. |
| Conflict | Choose the proportionate form of **stillness** rather than escalating into **predatory patience**. |
| Healing and restoration | Restore access to **precise response** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **embodied attention** without repeating **emotional detachment**. |
| Change and transition | Use European Mantis as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **stillness** accountable to others and monitor for **waiting too long**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is stillness already alive in my situation?
2. When does precise response become difficult to receive or sustain?
3. Could predatory patience be protecting something that needs a safer strategy?
4. Am I overexpressing embodied attention or suppressing it?
5. What does the grassland context teach me about the conditions this quality needs?
6. Where does my analogy with European Mantis stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Hold still for one minute while feeling your feet and hands. Then act on one visible opening before stillness becomes avoidance.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for European Mantis. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** European Mantis represents poised response. The synthesis derives from the verified behaviors above and adopts stillness as the primary Gift and predatory patience as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Great Horned Owl](020-great-horned-owl.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Common Bottlenose Dolphin](014-bottlenose-dolphin.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Great Horned Owl](020-great-horned-owl.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Common Bottlenose Dolphin](014-bottlenose-dolphin.md) can reveal a related defense in another form.
- **Productive tension:** [Common Bottlenose Dolphin](014-bottlenose-dolphin.md) and European Mantis ask for both communicative cooperation and poised response.
- **Commonly confused:** [Great Horned Owl](020-great-horned-owl.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show European Mantis in grassland, engaged in the behavior described here: mantises use grasping forelegs, mobile heads, camouflage, and stillness to ambush prey. Emphasize real anatomy, ecological context, and the tension between stillness and predatory patience. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Mantis_religiosa/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Avoid universalizing sexual cannibalism.
- No direct quotation from a commercial guidebook was used.
