---
card_number: 62
animal: "Caribbean Hermit Crab"
slug: "caribbean-hermit-crab"
scientific_name: "Coenobita clypeatus"
alternate_names: ["purple pincher"]
taxonomic_group: "Crustacean"
habitats: ["coast", "mangrove", "dry forest near sea"]
geographic_range: ["Caribbean", "western Atlantic islands and coasts"]
activity_cycle: "mostly nocturnal"
social_pattern: "social aggregations with shell competition"
core_archetype: "adaptive housing"
primary_gifts: ["resource reuse", "adaptive shelter", "transition"]
primary_wounds: ["insecure borrowing", "serial escape", "possessiveness"]
elemental_associations: ["water", "earth"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Caribbean Hermit Crab

## Essence

Caribbean Hermit Crab teaches **adaptive housing**: resource reuse becomes trustworthy when it stays connected to adaptive shelter and does not harden into insecure borrowing.

## Keywords

resource reuse, adaptive shelter, transition, insecure borrowing, serial escape, possessiveness.

## The living animal

### Natural-history facts

- Land hermit crabs protect soft abdomens in empty gastropod shells and change shells as they grow.
- They return to seawater for reproduction and require moisture for modified gills.
- Shell availability creates competition, negotiation, and sometimes vacancy chains among differently sized animals.
- **Ecological role:** They scavenge and recycle organic material between coastal land and sea.
- **Habitat and range:** coast, mangrove, dry forest near sea; Caribbean, western Atlantic islands and coasts.
- **Activity and social pattern:** mostly nocturnal; social aggregations with shell competition.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **adaptive housing**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Caribbean Hermit Crab occupies the role of **adaptive housing**. Unlike Clownfish, Hermit Crab repeatedly negotiates a portable inherited shelter rather than remaining within one living host partnership.

## Gifts

- **Resource Reuse:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Adaptive Shelter:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Transition:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Insecure Borrowing:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Serial Escape:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Possessiveness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **resource reuse** can produce **insecure borrowing** when safety, timing, or relationship is lost. **adaptive shelter** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **transition** available while loosening the demand to live through **serial escape**.

## Balanced expression

A balanced expression combines resource reuse, adaptive shelter, and transition. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when resource reuse turns into insecure borrowing, or when transition dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding resource reuse, distrusting adaptive shelter, or surrendering transition even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **resource reuse**; ask whether **insecure borrowing** is driving or distorting it. |
| Relationships | Practice **adaptive shelter** without asking another person to absorb **serial escape**. |
| Community | The group may need the **adaptive housing** role, with explicit limits against **possessiveness**. |
| Work and vocation | Use **transition** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they return to seawater for reproduction and require moisture for modified gills. |
| Conflict | Choose the proportionate form of **resource reuse** rather than escalating into **insecure borrowing**. |
| Healing and restoration | Restore access to **adaptive shelter** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **transition** without repeating **serial escape**. |
| Change and transition | Use Caribbean Hermit Crab as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **resource reuse** accountable to others and monitor for **possessiveness**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is resource reuse already alive in my situation?
2. When does adaptive shelter become difficult to receive or sustain?
3. Could insecure borrowing be protecting something that needs a safer strategy?
4. Am I overexpressing transition or suppressing it?
5. What does the coast context teach me about the conditions this quality needs?
6. Where does my analogy with Caribbean Hermit Crab stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Inventory the structures you use but did not create. Care for one borrowed resource and plan a transition before it becomes too small.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Caribbean Hermit Crab. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Caribbean Hermit Crab represents adaptive housing. The synthesis derives from the verified behaviors above and adopts resource reuse as the primary Gift and insecure borrowing as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Ocellaris Clownfish](044-ocellaris-clownfish.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Sandhill Crane](025-sandhill-crane.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Ocellaris Clownfish](044-ocellaris-clownfish.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Sandhill Crane](025-sandhill-crane.md) can reveal a related defense in another form.
- **Productive tension:** [Sandhill Crane](025-sandhill-crane.md) and Caribbean Hermit Crab ask for both attentive fidelity and adaptive housing.
- **Commonly confused:** [Ocellaris Clownfish](044-ocellaris-clownfish.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Caribbean Hermit Crab in coast, engaged in the behavior described here: land hermit crabs protect soft abdomens in empty gastropod shells and change shells as they grow. Emphasize real anatomy, ecological context, and the tension between resource reuse and insecure borrowing. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Coenobita_clypeatus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Never encourage collecting wild shells or crabs.
- No direct quotation from a commercial guidebook was used.
