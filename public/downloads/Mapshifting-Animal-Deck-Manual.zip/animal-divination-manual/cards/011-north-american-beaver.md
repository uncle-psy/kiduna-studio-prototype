---
card_number: 11
animal: "North American Beaver"
slug: "north-american-beaver"
scientific_name: "Castor canadensis"
alternate_names: ["beaver"]
taxonomic_group: "Mammal"
habitats: ["rivers", "streams", "ponds", "wetlands"]
geographic_range: ["North America"]
activity_cycle: "mostly crepuscular and nocturnal"
social_pattern: "family colonies"
core_archetype: "constructive systems work"
primary_gifts: ["systems building", "persistence", "habitat stewardship"]
primary_wounds: ["work compulsion", "overengineering", "territorial control"]
elemental_associations: ["water", "earth"]
seasonal_associations: ["autumn"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# North American Beaver

## Essence

North American Beaver teaches **constructive systems work**: systems building becomes trustworthy when it stays connected to persistence and does not harden into work compulsion.

## Keywords

systems building, persistence, habitat stewardship, work compulsion, overengineering, territorial control.

## The living animal

### Natural-history facts

- Beavers fell woody plants, build lodges and dams, and maintain underwater entrances and food stores.
- Their continuously growing incisors and swimming adaptations support a semi-aquatic life.
- Family colonies maintain structures over time, responding to water flow and breach.
- **Ecological role:** Beaver dams can slow water, trap sediment, expand wetland, and create habitat for many species.
- **Habitat and range:** rivers, streams, ponds, wetlands; North America.
- **Activity and social pattern:** mostly crepuscular and nocturnal; family colonies.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **constructive systems work**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

North American Beaver occupies the role of **constructive systems work**. Unlike Leafcutter Ant, Beaver transforms a shared landscape through a family-scale feedback system rather than a vast specialized colony.

## Gifts

- **Systems Building:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Persistence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Habitat Stewardship:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Work Compulsion:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Overengineering:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Territorial Control:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **systems building** can produce **work compulsion** when safety, timing, or relationship is lost. **persistence** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **habitat stewardship** available while loosening the demand to live through **overengineering**.

## Balanced expression

A balanced expression combines systems building, persistence, and habitat stewardship. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when systems building turns into work compulsion, or when habitat stewardship dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding systems building, distrusting persistence, or surrendering habitat stewardship even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **systems building**; ask whether **work compulsion** is driving or distorting it. |
| Relationships | Practice **persistence** without asking another person to absorb **overengineering**. |
| Community | The group may need the **constructive systems work** role, with explicit limits against **territorial control**. |
| Work and vocation | Use **habitat stewardship** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: their continuously growing incisors and swimming adaptations support a semi-aquatic life. |
| Conflict | Choose the proportionate form of **systems building** rather than escalating into **work compulsion**. |
| Healing and restoration | Restore access to **persistence** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **habitat stewardship** without repeating **overengineering**. |
| Change and transition | Use North American Beaver as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **systems building** accountable to others and monitor for **territorial control**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is systems building already alive in my situation?
2. When does persistence become difficult to receive or sustain?
3. Could work compulsion be protecting something that needs a safer strategy?
4. Am I overexpressing habitat stewardship or suppressing it?
5. What does the rivers context teach me about the conditions this quality needs?
6. Where does my analogy with North American Beaver stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Choose one small structural change that makes the desired behavior easier for everyone affected. Stop before improvement becomes control.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for North American Beaver. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** North American Beaver represents constructive systems work. The synthesis derives from the verified behaviors above and adopts systems building as the primary Gift and work compulsion as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Staghorn Coral](066-staghorn-coral.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Laysan Albatross](027-laysan-albatross.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Atlantic Salmon](043-atlantic-salmon.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Laysan Albatross](027-laysan-albatross.md) can reveal a related defense in another form.
- **Productive tension:** [Laysan Albatross](027-laysan-albatross.md) and North American Beaver ask for both oceanic patience and constructive systems work.
- **Commonly confused:** [Staghorn Coral](066-staghorn-coral.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show North American Beaver in rivers, engaged in the behavior described here: beavers fell woody plants, build lodges and dams, and maintain underwater entrances and food stores. Emphasize real anatomy, ecological context, and the tension between systems building and work compulsion. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Castor_canadensis/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
