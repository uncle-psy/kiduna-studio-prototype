---
card_number: 42
animal: "Great White Shark"
slug: "great-white-shark"
scientific_name: "Carcharodon carcharias"
alternate_names: ["white shark"]
taxonomic_group: "Fish"
habitats: ["coastal ocean", "continental shelf", "open ocean"]
geographic_range: ["temperate and subtropical oceans worldwide"]
activity_cycle: "day and night; migratory"
social_pattern: "mostly solitary with temporary aggregations"
core_archetype: "decisive sensory clarity"
primary_gifts: ["sensory clarity", "decisive movement", "apex responsibility"]
primary_wounds: ["fear projection", "relentless pursuit", "domination"]
elemental_associations: ["water", "fire"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Great White Shark

## Essence

Great White Shark teaches **decisive sensory clarity**: sensory clarity becomes trustworthy when it stays connected to decisive movement and does not harden into fear projection.

## Keywords

sensory clarity, decisive movement, apex responsibility, fear projection, relentless pursuit, domination.

## The living animal

### Natural-history facts

- Great white sharks detect prey through smell, vision, vibration, and electroreception.
- They travel long distances and shift habitat and diet with age, season, and region.
- Interactions at food sources can involve spacing and hierarchy rather than constant indiscriminate attack.
- **Ecological role:** As large predators and scavengers, they influence marine food webs and are vulnerable to fishing mortality and slow reproduction.
- **Habitat and range:** coastal ocean, continental shelf, open ocean; temperate and subtropical oceans worldwide.
- **Activity and social pattern:** day and night; migratory; mostly solitary with temporary aggregations.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **decisive sensory clarity**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Great White Shark occupies the role of **decisive sensory clarity**. Unlike Komodo Dragon, Great White emphasizes continuous movement and multi-sensory ocean search rather than terrestrial ambush economy.

## Gifts

- **Sensory Clarity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Decisive Movement:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Apex Responsibility:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Fear Projection:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Relentless Pursuit:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Domination:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **sensory clarity** can produce **fear projection** when safety, timing, or relationship is lost. **decisive movement** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **apex responsibility** available while loosening the demand to live through **relentless pursuit**.

## Balanced expression

A balanced expression combines sensory clarity, decisive movement, and apex responsibility. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when sensory clarity turns into fear projection, or when apex responsibility dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding sensory clarity, distrusting decisive movement, or surrendering apex responsibility even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **sensory clarity**; ask whether **fear projection** is driving or distorting it. |
| Relationships | Practice **decisive movement** without asking another person to absorb **relentless pursuit**. |
| Community | The group may need the **decisive sensory clarity** role, with explicit limits against **domination**. |
| Work and vocation | Use **apex responsibility** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they travel long distances and shift habitat and diet with age, season, and region. |
| Conflict | Choose the proportionate form of **sensory clarity** rather than escalating into **fear projection**. |
| Healing and restoration | Restore access to **decisive movement** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **apex responsibility** without repeating **relentless pursuit**. |
| Change and transition | Use Great White Shark as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **sensory clarity** accountable to others and monitor for **domination**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is sensory clarity already alive in my situation?
2. When does decisive movement become difficult to receive or sustain?
3. Could fear projection be protecting something that needs a safer strategy?
4. Am I overexpressing apex responsibility or suppressing it?
5. What does the coastal ocean context teach me about the conditions this quality needs?
6. Where does my analogy with Great White Shark stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Separate the real signal from the fear projected onto it. If action is needed, make one clean move and stop pursuing after the purpose is met.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Great White Shark. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Great White Shark represents decisive sensory clarity. The synthesis derives from the verified behaviors above and adopts sensory clarity as the primary Gift and fear projection as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Komodo Dragon](036-komodo-dragon.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Moon Jelly](064-moon-jelly.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Komodo Dragon](036-komodo-dragon.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [African Lion](002-african-lion.md) can reveal a related defense in another form.
- **Productive tension:** [Moon Jelly](064-moon-jelly.md) and Great White Shark ask for both rhythmic receptivity and decisive sensory clarity.
- **Commonly confused:** [Komodo Dragon](036-komodo-dragon.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Great White Shark in coastal ocean, engaged in the behavior described here: great white sharks detect prey through smell, vision, vibration, and electroreception. Emphasize real anatomy, ecological context, and the tension between sensory clarity and fear projection. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Carcharodon_carcharias/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Avoid sensational human-attack framing.
- No direct quotation from a commercial guidebook was used.
