---
card_number: 52
animal: "Common Green Darner"
slug: "common-green-darner"
scientific_name: "Anax junius"
alternate_names: ["green darner", "dragonfly"]
taxonomic_group: "Insect"
habitats: ["pond", "marsh", "lake edge", "open air corridor"]
geographic_range: ["North America", "Central America", "Caribbean"]
activity_cycle: "diurnal; some populations migratory"
social_pattern: "mostly solitary and territorial adults"
core_archetype: "life-stage agility"
primary_gifts: ["aerial agility", "life-stage transformation", "territorial clarity"]
primary_wounds: ["restless motion", "competitive vigilance", "detachment from origins"]
elemental_associations: ["air", "water"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Common Green Darner

## Essence

Common Green Darner teaches **life-stage agility**: aerial agility becomes trustworthy when it stays connected to life-stage transformation and does not harden into restless motion.

## Keywords

aerial agility, life-stage transformation, territorial clarity, restless motion, competitive vigilance, detachment from origins.

## The living animal

### Natural-history facts

- Green darner larvae are aquatic predators; adults are powerful aerial hunters.
- Some populations migrate over long distances, while others are resident.
- Adults patrol territories and capture insects in flight with agile maneuvering.
- **Ecological role:** Dragonflies connect aquatic juvenile habitats with terrestrial and aerial food webs.
- **Habitat and range:** pond, marsh, lake edge, open air corridor; North America, Central America, Caribbean.
- **Activity and social pattern:** diurnal; some populations migratory; mostly solitary and territorial adults.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **life-stage agility**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Common Green Darner occupies the role of **life-stage agility**. Unlike Monarch, Darner’s transformation connects water to air and predatory roles rather than host-plant specialization and generational migration.

## Gifts

- **Aerial Agility:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Life-Stage Transformation:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Territorial Clarity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Restless Motion:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Competitive Vigilance:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Detachment From Origins:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **aerial agility** can produce **restless motion** when safety, timing, or relationship is lost. **life-stage transformation** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **territorial clarity** available while loosening the demand to live through **competitive vigilance**.

## Balanced expression

A balanced expression combines aerial agility, life-stage transformation, and territorial clarity. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when aerial agility turns into restless motion, or when territorial clarity dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding aerial agility, distrusting life-stage transformation, or surrendering territorial clarity even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **aerial agility**; ask whether **restless motion** is driving or distorting it. |
| Relationships | Practice **life-stage transformation** without asking another person to absorb **competitive vigilance**. |
| Community | The group may need the **life-stage agility** role, with explicit limits against **detachment from origins**. |
| Work and vocation | Use **territorial clarity** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: some populations migrate over long distances, while others are resident. |
| Conflict | Choose the proportionate form of **aerial agility** rather than escalating into **restless motion**. |
| Healing and restoration | Restore access to **life-stage transformation** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **territorial clarity** without repeating **competitive vigilance**. |
| Change and transition | Use Common Green Darner as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **aerial agility** accountable to others and monitor for **detachment from origins**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is aerial agility already alive in my situation?
2. When does life-stage transformation become difficult to receive or sustain?
3. Could restless motion be protecting something that needs a safer strategy?
4. Am I overexpressing territorial clarity or suppressing it?
5. What does the pond context teach me about the conditions this quality needs?
6. Where does my analogy with Common Green Darner stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Review a skill learned in an earlier life stage. Bring it into a new medium without pretending you have no aquatic past.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Common Green Darner. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Common Green Darner represents life-stage agility. The synthesis derives from the verified behaviors above and adopts aerial agility as the primary Gift and restless motion as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Tiger Salamander](040-tiger-salamander.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Chambered Nautilus](060-chambered-nautilus.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Tiger Salamander](040-tiger-salamander.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Chambered Nautilus](060-chambered-nautilus.md) can reveal a related defense in another form.
- **Productive tension:** [Chambered Nautilus](060-chambered-nautilus.md) and Common Green Darner ask for both chambered continuity and life-stage agility.
- **Commonly confused:** [Tiger Salamander](040-tiger-salamander.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Common Green Darner in pond, engaged in the behavior described here: green darner larvae are aquatic predators; adults are powerful aerial hunters. Emphasize real anatomy, ecological context, and the tension between aerial agility and restless motion. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Anax_junius/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
