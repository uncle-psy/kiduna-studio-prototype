---
card_number: 61
animal: "Garden Snail"
slug: "garden-snail"
scientific_name: "Cornu aspersum"
alternate_names: ["brown garden snail", "Helix aspersa"]
taxonomic_group: "Mollusk"
habitats: ["garden", "grassland", "woodland edge", "urban vegetation"]
geographic_range: ["Mediterranean origin; introduced widely"]
activity_cycle: "mostly nocturnal or active in moisture"
social_pattern: "mostly solitary, aggregating in shelter or feeding areas"
core_archetype: "portable pacing"
primary_gifts: ["patient contact", "portable refuge", "measured pacing"]
primary_wounds: ["avoidance", "inertia", "excessive self-protection"]
elemental_associations: ["earth", "water"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Garden Snail

## Essence

Garden Snail teaches **portable pacing**: patient contact becomes trustworthy when it stays connected to portable refuge and does not harden into avoidance.

## Keywords

patient contact, portable refuge, measured pacing, avoidance, inertia, excessive self-protection.

## The living animal

### Natural-history facts

- Garden snails move on muscular feet using mucus and rasp food with a radula.
- Tentacles carry eyes and chemical/tactile senses; moisture strongly shapes activity.
- They can withdraw into shells and reduce activity through unfavorable dry or cold periods.
- **Ecological role:** Snails consume plant and decaying material and are prey for many animals; introduced populations can affect gardens and ecosystems.
- **Habitat and range:** garden, grassland, woodland edge, urban vegetation; Mediterranean origin; introduced widely.
- **Activity and social pattern:** mostly nocturnal or active in moisture; mostly solitary, aggregating in shelter or feeding areas.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **portable pacing**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Garden Snail occupies the role of **portable pacing**. Unlike Desert Tortoise, Snail carries a lightweight refuge through a small moisture-dependent world rather than a vertebrate shell and burrow strategy.

## Gifts

- **Patient Contact:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Portable Refuge:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Measured Pacing:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Avoidance:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Inertia:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Excessive Self-Protection:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **patient contact** can produce **avoidance** when safety, timing, or relationship is lost. **portable refuge** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **measured pacing** available while loosening the demand to live through **inertia**.

## Balanced expression

A balanced expression combines patient contact, portable refuge, and measured pacing. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when patient contact turns into avoidance, or when measured pacing dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding patient contact, distrusting portable refuge, or surrendering measured pacing even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **patient contact**; ask whether **avoidance** is driving or distorting it. |
| Relationships | Practice **portable refuge** without asking another person to absorb **inertia**. |
| Community | The group may need the **portable pacing** role, with explicit limits against **excessive self-protection**. |
| Work and vocation | Use **measured pacing** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: tentacles carry eyes and chemical/tactile senses; moisture strongly shapes activity. |
| Conflict | Choose the proportionate form of **patient contact** rather than escalating into **avoidance**. |
| Healing and restoration | Restore access to **portable refuge** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **measured pacing** without repeating **inertia**. |
| Change and transition | Use Garden Snail as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **patient contact** accountable to others and monitor for **excessive self-protection**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is patient contact already alive in my situation?
2. When does portable refuge become difficult to receive or sustain?
3. Could avoidance be protecting something that needs a safer strategy?
4. Am I overexpressing measured pacing or suppressing it?
5. What does the garden context teach me about the conditions this quality needs?
6. Where does my analogy with Garden Snail stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Reduce a task to the smallest continuous pace. Carry one simple refuge—water, a note, a boundary—that lets you continue without vanishing.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Garden Snail. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Garden Snail represents portable pacing. The synthesis derives from the verified behaviors above and adopts patient contact as the primary Gift and avoidance as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Mojave Desert Tortoise](037-mojave-desert-tortoise.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Peregrine Falcon](026-peregrine-falcon.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Mojave Desert Tortoise](037-mojave-desert-tortoise.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Peregrine Falcon](026-peregrine-falcon.md) can reveal a related defense in another form.
- **Productive tension:** [Peregrine Falcon](026-peregrine-falcon.md) and Garden Snail ask for both committed velocity and portable pacing.
- **Commonly confused:** [Mojave Desert Tortoise](037-mojave-desert-tortoise.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Garden Snail in garden, engaged in the behavior described here: garden snails move on muscular feet using mucus and rasp food with a radula. Emphasize real anatomy, ecological context, and the tension between patient contact and avoidance. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Cornu_aspersum/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Scientific naming varies in older sources.
- No direct quotation from a commercial guidebook was used.
