---
card_number: 12
animal: "North American River Otter"
slug: "north-american-river-otter"
scientific_name: "Lontra canadensis"
alternate_names: ["river otter"]
taxonomic_group: "Mammal"
habitats: ["rivers", "lakes", "wetlands", "coasts"]
geographic_range: ["North America"]
activity_cycle: "mostly crepuscular; regionally variable"
social_pattern: "solitary or fluid groups, often sex- and season-dependent"
core_archetype: "skillful play"
primary_gifts: ["play", "dexterity", "social ease"]
primary_wounds: ["avoidance through play", "impulsiveness", "scattered attention"]
elemental_associations: ["water", "air"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# North American River Otter

## Essence

North American River Otter teaches **skillful play**: play becomes trustworthy when it stays connected to dexterity and does not harden into avoidance through play.

## Keywords

play, dexterity, social ease, avoidance through play, impulsiveness, scattered attention.

## The living animal

### Natural-history facts

- River otters swim with streamlined bodies, webbed feet, strong tails, and dense insulating fur.
- They use slides, rolling, wrestling, scent marking, and varied vocal communication.
- Diet includes fish, crustaceans, amphibians, and other aquatic prey, shifting by place and season.
- **Ecological role:** As aquatic predators, otters reflect water quality, prey communities, and connected shore habitat.
- **Habitat and range:** rivers, lakes, wetlands, coasts; North America.
- **Activity and social pattern:** mostly crepuscular; regionally variable; solitary or fluid groups, often sex- and season-dependent.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **skillful play**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

North American River Otter occupies the role of **skillful play**. Unlike Dolphin, Otter brings play into tactile, local, shore-to-water life rather than wide-ranging vocal society.

## Gifts

- **Play:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Dexterity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Social Ease:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Avoidance Through Play:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Impulsiveness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Scattered Attention:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **play** can produce **avoidance through play** when safety, timing, or relationship is lost. **dexterity** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **social ease** available while loosening the demand to live through **impulsiveness**.

## Balanced expression

A balanced expression combines play, dexterity, and social ease. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when play turns into avoidance through play, or when social ease dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding play, distrusting dexterity, or surrendering social ease even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **play**; ask whether **avoidance through play** is driving or distorting it. |
| Relationships | Practice **dexterity** without asking another person to absorb **impulsiveness**. |
| Community | The group may need the **skillful play** role, with explicit limits against **scattered attention**. |
| Work and vocation | Use **social ease** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they use slides, rolling, wrestling, scent marking, and varied vocal communication. |
| Conflict | Choose the proportionate form of **play** rather than escalating into **avoidance through play**. |
| Healing and restoration | Restore access to **dexterity** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **social ease** without repeating **impulsiveness**. |
| Change and transition | Use North American River Otter as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **play** accountable to others and monitor for **scattered attention**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is play already alive in my situation?
2. When does dexterity become difficult to receive or sustain?
3. Could avoidance through play be protecting something that needs a safer strategy?
4. Am I overexpressing social ease or suppressing it?
5. What does the rivers context teach me about the conditions this quality needs?
6. Where does my analogy with North American River Otter stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Do a familiar task in a deliberately playful but safe way. Then finish one necessary step before seeking the next stimulation.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for North American River Otter. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** North American River Otter represents skillful play. The synthesis derives from the verified behaviors above and adopts play as the primary Gift and avoidance through play as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Common Bottlenose Dolphin](014-bottlenose-dolphin.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Emperor Scorpion](058-emperor-scorpion.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Common Bottlenose Dolphin](014-bottlenose-dolphin.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Emperor Scorpion](058-emperor-scorpion.md) can reveal a related defense in another form.
- **Productive tension:** [Emperor Scorpion](058-emperor-scorpion.md) and North American River Otter ask for both calibrated defense and skillful play.
- **Commonly confused:** [Common Bottlenose Dolphin](014-bottlenose-dolphin.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show North American River Otter in rivers, engaged in the behavior described here: river otters swim with streamlined bodies, webbed feet, strong tails, and dense insulating fur. Emphasize real anatomy, ecological context, and the tension between play and avoidance through play. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Lontra_canadensis/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation status should be refreshed against the live institutional source before publication.
- No direct quotation from a commercial guidebook was used.
