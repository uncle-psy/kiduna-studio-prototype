---
card_number: 68
animal: "Common Earthworm"
slug: "common-earthworm"
scientific_name: "Lumbricus terrestris"
alternate_names: ["nightcrawler"]
taxonomic_group: "Annelid"
habitats: ["soil", "grassland", "garden", "forest litter"]
geographic_range: ["Europe; introduced widely"]
activity_cycle: "mostly nocturnal and moisture-dependent"
social_pattern: "mostly solitary within shared soil"
core_archetype: "humble transformation"
primary_gifts: ["soil renewal", "humble transformation", "sensitivity"]
primary_wounds: ["self-neglect", "buried emotion", "fragmentation"]
elemental_associations: ["earth", "water"]
seasonal_associations: ["spring"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Common Earthworm

## Essence

Common Earthworm teaches **humble transformation**: soil renewal becomes trustworthy when it stays connected to humble transformation and does not harden into self-neglect.

## Keywords

soil renewal, humble transformation, sensitivity, self-neglect, buried emotion, fragmentation.

## The living animal

### Natural-history facts

- Earthworms ingest soil and organic material, mix layers, and create burrows that affect air and water movement.
- They sense vibration, moisture, chemicals, and light despite lacking eyes like vertebrates.
- The common nightcrawler pulls surface litter into vertical burrows and emerges mainly under moist, dark conditions.
- **Ecological role:** Earthworm effects depend on ecosystem history: beneficial in many managed soils, potentially disruptive where introduced into formerly worm-free forests.
- **Habitat and range:** soil, grassland, garden, forest litter; Europe; introduced widely.
- **Activity and social pattern:** mostly nocturnal and moisture-dependent; mostly solitary within shared soil.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **humble transformation**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Common Earthworm occupies the role of **humble transformation**. Unlike Sacred Scarab, Earthworm transforms diffuse soil continuously from within rather than rolling a discrete resource away.

## Gifts

- **Soil Renewal:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Humble Transformation:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Sensitivity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Self-Neglect:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Buried Emotion:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Fragmentation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **soil renewal** can produce **self-neglect** when safety, timing, or relationship is lost. **humble transformation** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **sensitivity** available while loosening the demand to live through **buried emotion**.

## Balanced expression

A balanced expression combines soil renewal, humble transformation, and sensitivity. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when soil renewal turns into self-neglect, or when sensitivity dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding soil renewal, distrusting humble transformation, or surrendering sensitivity even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **soil renewal**; ask whether **self-neglect** is driving or distorting it. |
| Relationships | Practice **humble transformation** without asking another person to absorb **buried emotion**. |
| Community | The group may need the **humble transformation** role, with explicit limits against **fragmentation**. |
| Work and vocation | Use **sensitivity** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: they sense vibration, moisture, chemicals, and light despite lacking eyes like vertebrates. |
| Conflict | Choose the proportionate form of **soil renewal** rather than escalating into **self-neglect**. |
| Healing and restoration | Restore access to **humble transformation** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **sensitivity** without repeating **buried emotion**. |
| Change and transition | Use Common Earthworm as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **soil renewal** accountable to others and monitor for **fragmentation**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is soil renewal already alive in my situation?
2. When does humble transformation become difficult to receive or sustain?
3. Could self-neglect be protecting something that needs a safer strategy?
4. Am I overexpressing sensitivity or suppressing it?
5. What does the soil context teach me about the conditions this quality needs?
6. Where does my analogy with Common Earthworm stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Take one neglected remainder and work it into the foundation: compost a note, repair a process, or name a buried feeling. Do not confuse invisibility with worthlessness.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Common Earthworm. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Common Earthworm represents humble transformation. The synthesis derives from the verified behaviors above and adopts soil renewal as the primary Gift and self-neglect as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Sacred Scarab](053-sacred-scarab.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Bald Eagle](019-bald-eagle.md) interrupts this card's likely overexpression.
- **Shared Gift:** [White-tailed Deer](006-white-tailed-deer.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Ochre Sea Star](065-ochre-sea-star.md) can reveal a related defense in another form.
- **Productive tension:** [Bald Eagle](019-bald-eagle.md) and Common Earthworm ask for both wide perspective with accountable descent and humble transformation.
- **Commonly confused:** [Sacred Scarab](053-sacred-scarab.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Common Earthworm in soil, engaged in the behavior described here: earthworms ingest soil and organic material, mix layers, and create burrows that affect air and water movement. Emphasize real anatomy, ecological context, and the tension between soil renewal and self-neglect. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Lumbricus_terrestris/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Ecological value differs between native and introduced ranges.
- No direct quotation from a commercial guidebook was used.
