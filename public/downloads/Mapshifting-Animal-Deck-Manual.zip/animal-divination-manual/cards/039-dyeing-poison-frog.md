---
card_number: 39
animal: "Dyeing Poison Frog"
slug: "dyeing-poison-frog"
scientific_name: "Dendrobates tinctorius"
alternate_names: ["dyeing dart frog"]
taxonomic_group: "Amphibian"
habitats: ["tropical rainforest floor", "leaf litter", "near small water"]
geographic_range: ["Guiana Shield of northern South America"]
activity_cycle: "diurnal"
social_pattern: "territorial adults with parental care"
core_archetype: "visible boundary"
primary_gifts: ["clear boundaries", "small-scale potency", "environmental sensitivity"]
primary_wounds: ["warning as identity", "defensiveness", "toxic reciprocity"]
elemental_associations: ["water", "fire"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Dyeing Poison Frog

## Essence

Dyeing Poison Frog teaches **visible boundary**: clear boundaries becomes trustworthy when it stays connected to small-scale potency and does not harden into warning as identity.

## Keywords

clear boundaries, small-scale potency, environmental sensitivity, warning as identity, defensiveness, toxic reciprocity.

## The living animal

### Natural-history facts

- Bright coloration warns potential predators; skin alkaloids in wild frogs derive from diet and differ in captivity.
- Adults defend small territories, and parents transport tadpoles to water.
- Moist microhabitats are essential to amphibian skin and reproduction.
- **Ecological role:** These frogs consume small arthropods and are sensitive to habitat and collection pressure.
- **Habitat and range:** tropical rainforest floor, leaf litter, near small water; Guiana Shield of northern South America.
- **Activity and social pattern:** diurnal; territorial adults with parental care.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **visible boundary**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Dyeing Poison Frog occupies the role of **visible boundary**. Unlike Porcupinefish, Poison Frog communicates defense continuously through visible coloration rather than inflating only under acute threat.

## Gifts

- **Clear Boundaries:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Small-Scale Potency:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Environmental Sensitivity:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Warning As Identity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Defensiveness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Toxic Reciprocity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **clear boundaries** can produce **warning as identity** when safety, timing, or relationship is lost. **small-scale potency** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **environmental sensitivity** available while loosening the demand to live through **defensiveness**.

## Balanced expression

A balanced expression combines clear boundaries, small-scale potency, and environmental sensitivity. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when clear boundaries turns into warning as identity, or when environmental sensitivity dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding clear boundaries, distrusting small-scale potency, or surrendering environmental sensitivity even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **clear boundaries**; ask whether **warning as identity** is driving or distorting it. |
| Relationships | Practice **small-scale potency** without asking another person to absorb **defensiveness**. |
| Community | The group may need the **visible boundary** role, with explicit limits against **toxic reciprocity**. |
| Work and vocation | Use **environmental sensitivity** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: adults defend small territories, and parents transport tadpoles to water. |
| Conflict | Choose the proportionate form of **clear boundaries** rather than escalating into **warning as identity**. |
| Healing and restoration | Restore access to **small-scale potency** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **environmental sensitivity** without repeating **defensiveness**. |
| Change and transition | Use Dyeing Poison Frog as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **clear boundaries** accountable to others and monitor for **toxic reciprocity**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is clear boundaries already alive in my situation?
2. When does small-scale potency become difficult to receive or sustain?
3. Could warning as identity be protecting something that needs a safer strategy?
4. Am I overexpressing environmental sensitivity or suppressing it?
5. What does the tropical rainforest floor context teach me about the conditions this quality needs?
6. Where does my analogy with Dyeing Poison Frog stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Make one boundary visible before resentment becomes toxic. Pair the warning with a specific path for safe cooperation.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Dyeing Poison Frog. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Dyeing Poison Frog represents visible boundary. The synthesis derives from the verified behaviors above and adopts clear boundaries as the primary Gift and warning as identity as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Spot-fin Porcupinefish](048-porcupinefish.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Domestic Dog](009-domestic-dog.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Spot-fin Porcupinefish](048-porcupinefish.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Domestic Dog](009-domestic-dog.md) can reveal a related defense in another form.
- **Productive tension:** [Domestic Dog](009-domestic-dog.md) and Dyeing Poison Frog ask for both reciprocal trust and visible boundary.
- **Commonly confused:** [Spot-fin Porcupinefish](048-porcupinefish.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Dyeing Poison Frog in tropical rainforest floor, engaged in the behavior described here: bright coloration warns potential predators; skin alkaloids in wild frogs derive from diet and differ in captivity. Emphasize real anatomy, ecological context, and the tension between clear boundaries and warning as identity. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Dendrobates_tinctorius/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Do not imply captive frogs share wild dietary toxicity.
- No direct quotation from a commercial guidebook was used.
