---
card_number: 63
animal: "Peacock Mantis Shrimp"
slug: "peacock-mantis-shrimp"
scientific_name: "Odontodactylus scyllarus"
alternate_names: ["mantis shrimp"]
taxonomic_group: "Crustacean"
habitats: ["coral rubble", "reef burrow", "shallow tropical sea"]
geographic_range: ["Indo-Pacific"]
activity_cycle: "diurnal"
social_pattern: "mostly solitary and territorial"
core_archetype: "complex perception with rapid force"
primary_gifts: ["complex perception", "rapid commitment", "burrow defense"]
primary_wounds: ["explosive force", "sensory overwhelm", "combative certainty"]
elemental_associations: ["water", "fire"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis"]
confidence: medium
status: draft
---

# Peacock Mantis Shrimp

## Essence

Peacock Mantis Shrimp teaches **complex perception with rapid force**: complex perception becomes trustworthy when it stays connected to rapid commitment and does not harden into explosive force.

## Keywords

complex perception, rapid commitment, burrow defense, explosive force, sensory overwhelm, combative certainty.

## The living animal

### Natural-history facts

- Peacock mantis shrimp have highly complex visual systems and powerful club-like appendages.
- The striking appendages accelerate rapidly to break hard-shelled prey and can produce cavitation effects.
- Individuals maintain burrows used for refuge, feeding, and reproduction.
- **Ecological role:** They are predators of mollusks and crustaceans within reef-rubble communities.
- **Habitat and range:** coral rubble, reef burrow, shallow tropical sea; Indo-Pacific.
- **Activity and social pattern:** diurnal; mostly solitary and territorial.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **complex perception with rapid force**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Peacock Mantis Shrimp occupies the role of **complex perception with rapid force**. Unlike Archerfish, Mantis Shrimp closes distance with explosive impact rather than acting through a calibrated water jet.

## Gifts

- **Complex Perception:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Rapid Commitment:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Burrow Defense:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Explosive Force:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Sensory Overwhelm:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Combative Certainty:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **complex perception** can produce **explosive force** when safety, timing, or relationship is lost. **rapid commitment** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **burrow defense** available while loosening the demand to live through **sensory overwhelm**.

## Balanced expression

A balanced expression combines complex perception, rapid commitment, and burrow defense. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when complex perception turns into explosive force, or when burrow defense dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding complex perception, distrusting rapid commitment, or surrendering burrow defense even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **complex perception**; ask whether **explosive force** is driving or distorting it. |
| Relationships | Practice **rapid commitment** without asking another person to absorb **sensory overwhelm**. |
| Community | The group may need the **complex perception with rapid force** role, with explicit limits against **combative certainty**. |
| Work and vocation | Use **burrow defense** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: the striking appendages accelerate rapidly to break hard-shelled prey and can produce cavitation effects. |
| Conflict | Choose the proportionate form of **complex perception** rather than escalating into **explosive force**. |
| Healing and restoration | Restore access to **rapid commitment** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **burrow defense** without repeating **sensory overwhelm**. |
| Change and transition | Use Peacock Mantis Shrimp as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **complex perception** accountable to others and monitor for **combative certainty**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is complex perception already alive in my situation?
2. When does rapid commitment become difficult to receive or sustain?
3. Could explosive force be protecting something that needs a safer strategy?
4. Am I overexpressing burrow defense or suppressing it?
5. What does the coral rubble context teach me about the conditions this quality needs?
6. Where does my analogy with Peacock Mantis Shrimp stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Before using a powerful response, name the channel of evidence you trust and one you may be overreading. Protect the burrow without turning every movement into attack.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

No cultural or historical association is adopted for this card in the current draft. Unattributed or insufficiently specific claims were omitted rather than universalized.

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Peacock Mantis Shrimp. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Peacock Mantis Shrimp represents complex perception with rapid force. The synthesis derives from the verified behaviors above and adopts complex perception as the primary Gift and explosive force as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Banded Archerfish](049-banded-archerfish.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Moon Jelly](064-moon-jelly.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Banded Archerfish](049-banded-archerfish.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Moon Jelly](064-moon-jelly.md) can reveal a related defense in another form.
- **Productive tension:** [Moon Jelly](064-moon-jelly.md) and Peacock Mantis Shrimp ask for both rhythmic receptivity and complex perception with rapid force.
- **Commonly confused:** [Banded Archerfish](049-banded-archerfish.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Peacock Mantis Shrimp in coral rubble, engaged in the behavior described here: peacock mantis shrimp have highly complex visual systems and powerful club-like appendages. Emphasize real anatomy, ecological context, and the tension between complex perception and explosive force. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Odontodactylus_scyllarus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).

## Research notes

- Provenance: behavioral, deck-synthesis.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Avoid exaggerated claims that map its color vision directly onto human experience.
- No direct quotation from a commercial guidebook was used.
