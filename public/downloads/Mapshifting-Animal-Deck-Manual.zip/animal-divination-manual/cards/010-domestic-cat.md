---
card_number: 10
animal: "Domestic Cat"
slug: "domestic-cat"
scientific_name: "Felis catus"
alternate_names: ["cat"]
taxonomic_group: "Mammal"
habitats: ["homes", "farms", "urban areas", "feral landscapes"]
geographic_range: ["worldwide under human association"]
activity_cycle: "crepuscular with flexible household rhythms"
social_pattern: "solitary-foraging ancestry with flexible social groups"
core_archetype: "self-possessed intimacy"
primary_gifts: ["self-possession", "sensory discernment", "affectionate boundaries"]
primary_wounds: ["aloofness", "predatory entitlement", "overstimulation"]
elemental_associations: ["earth", "water"]
seasonal_associations: ["autumn"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# Domestic Cat

## Essence

Domestic Cat teaches **self-possessed intimacy**: self-possession becomes trustworthy when it stays connected to sensory discernment and does not harden into aloofness.

## Keywords

self-possession, sensory discernment, affectionate boundaries, aloofness, predatory entitlement, overstimulation.

## The living animal

### Natural-history facts

- Cats are small ambush predators with acute hearing, low-light vision, whisker-based touch, and flexible bodies.
- Domestic cats can form social colonies around concentrated resources, though many hunt alone.
- Human companionship ranges from close cohabitation to feral independence, and individual consent signals matter.
- **Ecological role:** Free-ranging cats can exert major predation pressure on wildlife; responsible care includes containment and enrichment.
- **Habitat and range:** homes, farms, urban areas, feral landscapes; worldwide under human association.
- **Activity and social pattern:** crepuscular with flexible household rhythms; solitary-foraging ancestry with flexible social groups.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **self-possessed intimacy**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Domestic Cat occupies the role of **self-possessed intimacy**. Unlike Dog, Cat emphasizes consent, proximity, and self-directed contact rather than overt cooperative attunement.

## Gifts

- **Self-Possession:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Sensory Discernment:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Affectionate Boundaries:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Aloofness:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Predatory Entitlement:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Overstimulation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **self-possession** can produce **aloofness** when safety, timing, or relationship is lost. **sensory discernment** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **affectionate boundaries** available while loosening the demand to live through **predatory entitlement**.

## Balanced expression

A balanced expression combines self-possession, sensory discernment, and affectionate boundaries. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when self-possession turns into aloofness, or when affectionate boundaries dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding self-possession, distrusting sensory discernment, or surrendering affectionate boundaries even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **self-possession**; ask whether **aloofness** is driving or distorting it. |
| Relationships | Practice **sensory discernment** without asking another person to absorb **predatory entitlement**. |
| Community | The group may need the **self-possessed intimacy** role, with explicit limits against **overstimulation**. |
| Work and vocation | Use **affectionate boundaries** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: domestic cats can form social colonies around concentrated resources, though many hunt alone. |
| Conflict | Choose the proportionate form of **self-possession** rather than escalating into **aloofness**. |
| Healing and restoration | Restore access to **sensory discernment** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **affectionate boundaries** without repeating **predatory entitlement**. |
| Change and transition | Use Domestic Cat as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **self-possession** accountable to others and monitor for **overstimulation**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is self-possession already alive in my situation?
2. When does sensory discernment become difficult to receive or sustain?
3. Could aloofness be protecting something that needs a safer strategy?
4. Am I overexpressing affectionate boundaries or suppressing it?
5. What does the homes context teach me about the conditions this quality needs?
6. Where does my analogy with Domestic Cat stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Practice a clean yes, no, and not-yet in one relationship. Pair the boundary with an available form of warmth rather than disappearing.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Ancient Egypt | Bastet was represented as a cat and described in the object record as protective and prosperity-bringing. | Late/Ptolemaic period, 664–30 BCE | historical | high | [Met, *Cat*](https://www.metmuseum.org/art/collection/search/552028) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Domestic Cat. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Domestic Cat represents self-possessed intimacy. The synthesis derives from the verified behaviors above and adopts self-possession as the primary Gift and aloofness as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Red Fox](004-red-fox.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Domestic Dog](009-domestic-dog.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Red Fox](004-red-fox.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Domestic Dog](009-domestic-dog.md) can reveal a related defense in another form.
- **Productive tension:** [Domestic Dog](009-domestic-dog.md) and Domestic Cat ask for both reciprocal trust and self-possessed intimacy.
- **Commonly confused:** [Red Fox](004-red-fox.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Domestic Cat in homes, engaged in the behavior described here: cats are small ambush predators with acute hearing, low-light vision, whisker-based touch, and flexible bodies. Emphasize real anatomy, ecological context, and the tension between self-possession and aloofness. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Felis_catus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Met, *Cat*](https://www.metmuseum.org/art/collection/search/552028) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Include wildlife-impact and welfare review before publication.
- No direct quotation from a commercial guidebook was used.
