---
card_number: 2
animal: "African Lion"
slug: "african-lion"
scientific_name: "Panthera leo"
alternate_names: ["lion"]
taxonomic_group: "Mammal"
habitats: ["savanna", "grassland", "open woodland"]
geographic_range: ["sub-Saharan Africa", "Gir landscape of India"]
activity_cycle: "cathemeral; often active at night or cooler hours"
social_pattern: "prides, coalitions, and solitary dispersers"
core_archetype: "courageous presence"
primary_gifts: ["courage", "cooperative defense", "rest and timing"]
primary_wounds: ["domination", "status fixation", "entitlement"]
elemental_associations: ["fire", "earth"]
seasonal_associations: ["summer"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# African Lion

## Essence

African Lion teaches **courageous presence**: courage becomes trustworthy when it stays connected to cooperative defense and does not harden into domination.

## Keywords

courage, cooperative defense, rest and timing, domination, status fixation, entitlement.

## The living animal

### Natural-history facts

- Lions are the most social living cats, forming prides whose membership and territory change over time.
- Related females often cooperate in hunting and cub care; males may form coalitions.
- Long periods of rest conserve energy for short, demanding hunts and defense.
- **Ecological role:** As large predators, lions affect herbivore movement and compete with other carnivores.
- **Habitat and range:** savanna, grassland, open woodland; sub-Saharan Africa, Gir landscape of India.
- **Activity and social pattern:** cathemeral; often active at night or cooler hours; prides, coalitions, and solitary dispersers.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **courageous presence**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

African Lion occupies the role of **courageous presence**. Unlike Gorilla, Lion foregrounds visible status, coalition, and energetic timing rather than restrained kin leadership.

## Gifts

- **Courage:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Cooperative Defense:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Rest And Timing:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Domination:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Status Fixation:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Entitlement:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **courage** can produce **domination** when safety, timing, or relationship is lost. **cooperative defense** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **rest and timing** available while loosening the demand to live through **status fixation**.

## Balanced expression

A balanced expression combines courage, cooperative defense, and rest and timing. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when courage turns into domination, or when rest and timing dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding courage, distrusting cooperative defense, or surrendering rest and timing even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **courage**; ask whether **domination** is driving or distorting it. |
| Relationships | Practice **cooperative defense** without asking another person to absorb **status fixation**. |
| Community | The group may need the **courageous presence** role, with explicit limits against **entitlement**. |
| Work and vocation | Use **rest and timing** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: related females often cooperate in hunting and cub care; males may form coalitions. |
| Conflict | Choose the proportionate form of **courage** rather than escalating into **domination**. |
| Healing and restoration | Restore access to **cooperative defense** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **rest and timing** without repeating **status fixation**. |
| Change and transition | Use African Lion as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **courage** accountable to others and monitor for **entitlement**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is courage already alive in my situation?
2. When does cooperative defense become difficult to receive or sustain?
3. Could domination be protecting something that needs a safer strategy?
4. Am I overexpressing rest and timing or suppressing it?
5. What does the savanna context teach me about the conditions this quality needs?
6. Where does my analogy with African Lion stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Choose one responsibility that deserves your full presence and one task that can wait. Practice courage without occupying every space.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Ancient Egypt | A monumental recumbent lion guarded a sanctuary; the museum record describes the lion as an early royal symbol and form of several deities. | Old Kingdom, ca. 2575–2450 BCE | historical | high | [Met, *Recumbent Lion*](https://www.metmuseum.org/art/collection/search/549541) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for African Lion. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** African Lion represents courageous presence. The synthesis derives from the verified behaviors above and adopts courage as the primary Gift and domination as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [African Elephant](003-african-elephant.md) expands the Gift through a different ecological strategy.
- **Balancing:** [Western Gorilla](016-western-gorilla.md) interrupts this card's likely overexpression.
- **Shared Gift:** [African Elephant](003-african-elephant.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [Great White Shark](042-great-white-shark.md) can reveal a related defense in another form.
- **Productive tension:** [Western Gorilla](016-western-gorilla.md) and African Lion ask for both restrained protective strength and courageous presence.
- **Commonly confused:** [African Elephant](003-african-elephant.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show African Lion in savanna, engaged in the behavior described here: lions are the most social living cats, forming prides whose membership and territory change over time. Emphasize real anatomy, ecological context, and the tension between courage and domination. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Panthera_leo/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Met, *Recumbent Lion*](https://www.metmuseum.org/art/collection/search/549541) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Taxonomy and conservation differ between African and Asiatic populations.
- No direct quotation from a commercial guidebook was used.
