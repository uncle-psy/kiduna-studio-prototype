---
card_number: 1
animal: "Gray Wolf"
slug: "gray-wolf"
scientific_name: "Canis lupus"
alternate_names: ["wolf"]
taxonomic_group: "Mammal"
habitats: ["forest", "tundra", "grassland", "mountain"]
geographic_range: ["North America", "Europe", "Asia"]
activity_cycle: "mostly crepuscular and nocturnal"
social_pattern: "family-based packs or pairs"
core_archetype: "coordinated belonging"
primary_gifts: ["coordination", "endurance", "social intelligence"]
primary_wounds: ["conformity", "exclusion", "hypervigilance"]
elemental_associations: ["earth", "air"]
seasonal_associations: ["winter"]
provenance_labels: ["behavioral", "deck-synthesis", "historical", "cultural"]
confidence: medium
status: draft
---

# Gray Wolf

## Essence

Gray Wolf teaches **coordinated belonging**: coordination becomes trustworthy when it stays connected to endurance and does not harden into conformity.

## Keywords

coordination, endurance, social intelligence, conformity, exclusion, hypervigilance.

## The living animal

### Natural-history facts

- Wolves use scent, posture, and vocalization to coordinate and maintain territory.
- Pack structure is usually family-based and changes with prey, habitat, and human pressure.
- They can travel long distances and hunt cooperatively, while many individuals also disperse alone.
- **Ecological role:** Large-carnivore predation influences prey behavior and ecosystem relationships.
- **Habitat and range:** forest, tundra, grassland, mountain; North America, Europe, Asia.
- **Activity and social pattern:** mostly crepuscular and nocturnal; family-based packs or pairs.

### Symbolic bridge

The deck uses these observations as a reflective analogy for **coordinated belonging**. The animal does not literally carry a human message, and the interpretation is labeled deck synthesis.

## Core archetype

Gray Wolf occupies the role of **coordinated belonging**. Unlike Dog, Wolf emphasizes belonging negotiated within a wild family and territory rather than cross-species partnership.

## Gifts

- **Coordination:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Endurance:** Explore this as a capacity that can be practiced with timing, consent, and proportion.
- **Social Intelligence:** Explore this as a capacity that can be practiced with timing, consent, and proportion.

## Wounds

- **Conformity:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Exclusion:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.
- **Hypervigilance:** Consider this a possible defense or imbalance, not a diagnosis or fixed identity.

## Gift–Wound relationship

The same energy that supports **coordination** can produce **conformity** when safety, timing, or relationship is lost. **endurance** may grow as an intelligent response to the wound, yet become overused and conceal it. Integration keeps **social intelligence** available while loosening the demand to live through **exclusion**.

## Balanced expression

A balanced expression combines coordination, endurance, and social intelligence. It responds to actual conditions, remains open to feedback, and stops when the purpose is met.

## Overexpression

The Gift becomes rigid when coordination turns into conformity, or when social intelligence dominates context and relationship. The person may mistake intensity for truth.

## Underexpression

Disconnection from this card can look like withholding coordination, distrusting endurance, or surrendering social intelligence even when the situation calls for it.

## The animal appearing in a reading

| Context | Reflective possibility |
|---|---|
| Identity | You may be developing **coordination**; ask whether **conformity** is driving or distorting it. |
| Relationships | Practice **endurance** without asking another person to absorb **exclusion**. |
| Community | The group may need the **coordinated belonging** role, with explicit limits against **hypervigilance**. |
| Work and vocation | Use **social intelligence** deliberately; check whether the surrounding habitat actually supports it. |
| Creativity | Let the animal's way of living suggest a form: pack structure is usually family-based and changes with prey, habitat, and human pressure. |
| Conflict | Choose the proportionate form of **coordination** rather than escalating into **conformity**. |
| Healing and restoration | Restore access to **endurance** through conditions of safety, time, and support; this is reflection, not treatment. |
| Decision-making | Ask which option embodies **social intelligence** without repeating **exclusion**. |
| Change and transition | Use Gray Wolf as a behavioral analogy for moving between present conditions and a viable next state. |
| Leadership and responsibility | Make **coordination** accountable to others and monitor for **hypervigilance**. |

These are possibilities, not predictions.

## Questions for reflection

1. Where is coordination already alive in my situation?
2. When does endurance become difficult to receive or sustain?
3. Could conformity be protecting something that needs a safer strategy?
4. Am I overexpressing social intelligence or suppressing it?
5. What does the forest context teach me about the conditions this quality needs?
6. Where does my analogy with Gray Wolf stop being accurate or useful?
7. What thought, word, and practical action would restore proportion?

## Practice

Map the groups you belong to. Name one contribution you freely offer and one boundary that keeps belonging from becoming self-erasure.

**Secular alternative:** Treat the card as a behavioral analogy and journaling prompt. Never approach, feed, touch, capture, purchase, or disturb wildlife for the exercise.

## Cultural and historical symbolism

| Tradition or source | Association | Period or context | Provenance | Confidence | Citation |
|---|---|---|---|---|---|
| Ancient Roman foundation tradition | A she-wolf nurses Romulus and Remus in the Roman foundation motif. This is a historical art/literary comparison, not a universal wolf meaning. | Roman tradition; later European artwork | historical | medium | [Met, Conca study referencing the Aeneid motif](https://www.metmuseum.org/art/collection/search/420445) |

## Modern interpretations

The official record for Ted Andrews' *Animal-Speak* confirms its animal-teacher and behavior-oriented scope, and the official records for Kim Krans' deck confirm a concise animal-archetype, self-discovery, and elemental framework. The complete requested editions were not available, so this draft does **not** claim either author's animal-specific interpretation, wording, or page reference for Gray Wolf. This comparison remains pending.

## Deck synthesis

**Deck synthesis — medium confidence:** Gray Wolf represents coordinated belonging. The synthesis derives from the verified behaviors above and adopts coordination as the primary Gift and conformity as its closest Wound. It is original to this deck and may be revised after zoological, cultural, and comparative-source review.

## Relationships to other cards

- **Complementary:** [Common Raven](021-common-raven.md) expands the Gift through a different ecological strategy.
- **Balancing:** [White-tailed Deer](006-white-tailed-deer.md) interrupts this card's likely overexpression.
- **Shared Gift:** [Emperor Penguin](024-emperor-penguin.md) overlaps with one capacity but uses a different method.
- **Shared Wound:** [White-tailed Deer](006-white-tailed-deer.md) can reveal a related defense in another form.
- **Productive tension:** [White-tailed Deer](006-white-tailed-deer.md) and Gray Wolf ask for both sensitive responsiveness and coordinated belonging.
- **Commonly confused:** [Common Raven](021-common-raven.md); compare the Core archetype sections rather than merging their keywords.

## Future illustration brief

Show Gray Wolf in forest, engaged in the behavior described here: wolves use scent, posture, and vocalization to coordinate and maintain territory. Emphasize real anatomy, ecological context, and the tension between coordination and conformity. Use an original composition and do not imitate any existing deck or artist.

## Sources

- [Institutional natural-history account](https://animaldiversity.org/accounts/Canis_lupus/) — taxonomy, habitat, behavior, ecology, and/or conservation.
- [Research methodology](../02-methodology.md) and [source ledger](../research/source-ledger.md).
- [Met, Conca study referencing the Aeneid motif](https://www.metmuseum.org/art/collection/search/420445) — cultural/historical comparison.

## Research notes

- Provenance: behavioral, deck-synthesis, historical, cultural.
- Confidence: medium; behavior-to-symbol inference is transparent, while full modern-reference comparison remains unavailable.
- Population status and human coexistence vary sharply by region.
- No direct quotation from a commercial guidebook was used.
