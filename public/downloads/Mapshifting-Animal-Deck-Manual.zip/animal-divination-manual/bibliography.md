# Annotated Bibliography

## Requested modern references

Andrews, Ted. *Animal-Speak: The Spiritual & Magical Powers of Creatures Great & Small*. Llewellyn, September 2002 trade paperback. ISBN 9780875420288. The official publisher record was consulted for bibliographic and high-level scope information. The complete text was unavailable, so this manual makes no animal-specific Andrews attribution.

Krans, Kim. *The Wild Unknown Animal Spirit Deck and Guidebook*. HarperOne, 2018. ISBN 9780062742865. The creator's site and bibliographic/product records confirm a 63-card animal-archetype deck and 208-page guidebook. The complete guidebook was unavailable; no card entry, wording, sequence, or artwork was used.

## Natural history

Animal Diversity Web. University of Michigan Museum of Zoology. Species accounts used for structured checks of taxonomy, range, habitat, behavior, reproduction, and ecology. ADW notes that many accounts are student-authored and edited but not guaranteed; higher-risk facts should be triangulated before publication.

Cornell Lab of Ornithology. *All About Birds*. Life-history accounts used for North American birds, drawing on Cornell's deeper Birds of the World scholarship.

NOAA Fisheries. Species profiles used for whales, dolphins, sea turtles, salmon, manta rays, and corals, especially conservation and migration.

Smithsonian Ocean. Institutional overviews used for marine invertebrate and coral ecology.

U.S. Fish and Wildlife Service. Species profiles used where applicable for protected and migratory species.

## Cultural integrity and historical interpretation

National Museum of the American Indian. *Native Knowledge 360°: Essential Understandings about American Indians*. The baseline cultural-care framework for rejecting pan-Indigenous generalizations and centering distinct living peoples.

Metropolitan Museum of Art collection and educational records. Specific object records used for a small set of ancient Egyptian, Greek/Roman, Chinese, Japanese, and Hindu associations. A museum record documents an object/context; it does not establish a universal culture-wide meaning.

British Museum. *Ancient Egypt: Symbols of the Pharaoh*. Used narrowly for the documented Egyptian scarab/rebirth and uraeus/protection associations.

Snorri Sturluson. *Gylfaginning*, §38, translated by Arthur Gilchrist Brodeur (1916), hosted by Internet Sacred Text Archive. Used narrowly for Huginn and Muninn; translation/source review remains desirable.

John Tzetzes. *Chiliades*, book 8, English translation hosted by Theoi Classical Texts Library. Used narrowly as a historical textual record connecting Athena's owl with wisdom.

See the [source ledger](research/source-ledger.md) for direct links and card-level sources.
