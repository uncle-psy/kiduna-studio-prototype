# Philosophy

## Animals are lives, not labels

An animal is never reducible to a human personality trait. Each species is a lineage with its own body, senses, habitat, relationships, ecological work, and evolutionary history. Symbolism becomes responsible when it begins with attention to that life and remains visibly separate from it.

## What animal symbolism is

Animal symbolism is a human act of meaning-making. It can arise from close observation, historical art and text, a named cultural tradition, a modern author, or a new deck synthesis. These sources do not carry equal authority and must not be blended without labels.

This deck therefore uses two voices:

1. **The living animal:** testable natural-history statements.
2. **The symbolic mirror:** an invitation to explore a human situation by analogy.

The bridge between them is suggestive, not causal. A beaver's dam-building can inspire reflection on constructive persistence; it does not prove that beavers “mean” productivity in every place or tradition.

## Agency over fate

A reading describes possibilities and relationships among present conditions. It does not command, condemn, or foreclose choice. Even a difficult card asks: *What can be noticed? What can be changed? What support is available? What small action restores room to move?*

## A Mapshifting practice

The deck adopts Mapshifting's agency-centered close: a deliberate **thought**, **word**, and **action**. A reading is useful when it changes the reader's available map—not when it makes the reader dependent on the deck.

## Ecological reciprocity

To learn symbolically from an animal while ignoring its habitat or conservation pressures would be incomplete. Each encounter should deepen respect for the more-than-human world. Practices never require approaching, feeding, touching, capturing, buying, or disturbing wildlife.

Continue to [Research methodology](02-methodology.md).
