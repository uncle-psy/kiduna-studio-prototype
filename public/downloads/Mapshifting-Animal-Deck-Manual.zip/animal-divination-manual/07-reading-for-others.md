# Reading for Another Person

## Consent

Ask whether the person wants a reflective card reading, what topic is in scope, what is private, whether notes may be kept, and whether spiritual language is welcome. Consent can be withdrawn at any point. Do not read an absent person as though you have access to their motives or future.

## A respectful method

1. Let the participant phrase or approve the question.
2. Explain that cards offer possibilities, not facts about them.
3. Describe the animal and source of the interpretation before applying it.
4. Use tentative language: “Could this point toward…?”
5. Invite correction: “What does not fit?”
6. Let the participant name the Wound, if any. Never assign trauma.
7. Distinguish your reaction from theirs.
8. End with options and participant-chosen action.

## Ethical boundaries

Do not use the deck to:

- diagnose illness or determine treatment;
- replace medical, mental-health, legal, financial, or safety expertise;
- pronounce death, pregnancy, infidelity, abuse, criminality, or inevitable events;
- pressure someone to remain in or leave a relationship;
- make decisions for a child or dependent without appropriate care and consent;
- expose restricted cultural material; or
- create fear or dependency to sell further readings.

When immediate danger, abuse, crisis, or serious health concerns arise, move from symbolism to practical safety and appropriate qualified help.

Continue to [Spreads](08-spreads.md).
