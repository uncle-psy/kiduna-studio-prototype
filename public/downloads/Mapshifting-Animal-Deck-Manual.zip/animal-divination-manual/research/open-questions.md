# Open Research Questions

## Highest priority

1. Obtain lawful copies of the specified Andrews and Krans editions and perform animal-by-animal comparison with page-level notes.
2. Commission zoological review of every card, prioritizing fast-changing taxonomy and conservation status.
3. Commission cultural review of the twelve adopted historical rows and decide whether each adds enough value to retain.
4. Determine a publication policy for broad card names when the living-animal referent is a single species.

## Biological

- Which species accounts have changed since the 2026-08-23 access date?
- Should domestic dog and cat cards cite breed/landrace research more explicitly?
- Should “electric eel” use the broader genus now known to include multiple species?
- Should the reef manta card replace or accompany the giant manta in NOAA comparisons?
- Does the coral card's colony-level “animal” identity need a dedicated explanatory sidebar?

## Cultural

- Can appropriate, community-authored sources add named living-culture relationships without extracting restricted knowledge?
- Which historical records depend on outdated translations or museum interpretation?
- Should species-mismatched comparison rows be removed rather than retained with caveats?

## Deck system

- Should reversed cards remain optional or be removed in favor of explicit balance-state prompts?
- Should future expansions be bioregional rather than universal?
- Which expansion candidates add a genuinely new archetype after field testing?
- How should user-created personal meanings be stored without presenting them as shared tradition?
