# Contradictions and Tensions

## Broad animal names versus species

Popular symbolism speaks of “owl,” “turtle,” “snake,” or “bear,” while biology and culture often concern a particular species. This deck fixes one living referent per card and labels broader comparisons. Species mismatch remains a publication-review flag.

## Observation versus projection

The same behavior can support opposing analogies. Solitude can signify autonomy or isolation; vigilance can be discernment or fear; migration can be fidelity to place or willingness to leave. Cards keep both Gift and Wound visible rather than resolving ambiguity through a universal meaning.

## Domestication

Dog, cat, horse, and honey bee are shaped by long human relationships. Their cards cannot be understood as untouched “wild nature.” Domestication can produce reciprocity, dependence, exploitation, companionship, and ecological effects at once.

## Conservation status

Species status varies by population and changes over time. Card files avoid timeless status labels where possible and direct readers to live institutional sources. Conservation claims must be refreshed before publication.

## Requested modern references

The project asks for animal-specific comparison with Andrews and Krans, but their complete texts were unavailable. Inventing a comparison would violate the project's research and copyright rules. The manual therefore retains complete modern-interpretation sections that clearly record the gap.

## Cultural analogy across related animals

Several documented records concern a close relative or broad animal form rather than the exact card species: little owl/great horned owl, red-crowned/sandhill crane, crocodile/alligator, jackal/dog. These appear as comparative historical notes with medium or low transfer confidence, never as biological identity.
