# Source Comparison Matrix

| Dimension | Andrews, *Animal-Speak* | Krans, *Animal Spirit* | This deck |
|---|---|---|---|
| Access in this draft | Official product record only | Creator and bibliographic/product records only | Full original manuscript |
| Verified high-level frame | Animals as teachers; behavior and nature signs; 100+ creatures | 63 animal archetype cards; concise guidebook; self-discovery; elemental organization | 68 real-animal cards; Gift–Wound integration; behavior-first self-inquiry |
| Animal-specific text used | None—full text unavailable | None—full guidebook unavailable | Original synthesis linked to biological sources |
| Structure borrowed | None | None | Original YAML schema and required sections supplied by project goal |
| Balance model | Not verified at entry level | Product descriptions mention contradictions and complex natures; entry details not verified | Explicit balanced, overexpressed, and underexpressed forms |
| Culture policy | Not assessed without full text | Not assessed without full text | Named-source attribution and NK360° baseline |
| Artwork relationship | Not used | No wording, composition, or style imitated | Text-only future illustration briefs |

## Required future comparison

If lawful copies become available, a researcher should compare each relevant animal entry, record exact edition/pages, paraphrase only what changes the research, and mark any new claim `author-derived`. No existing deck synthesis should be retroactively attributed to either author.
