# Cultural Attribution Ledger

Only twelve specific cultural/historical records are adopted in this draft. They appear on the directly relevant card and nowhere else as universal meanings.

| Source ID | Card(s) | Attribution scope | Publication review need |
|---|---|---|---|
| C01 | African Lion | Ancient Egyptian royal and deity imagery in a specific Old Kingdom object/context | Egyptology review desirable |
| C02 | Domestic Cat | Bastet in Late/Ptolemaic-period Egyptian votive imagery | Egyptology review desirable |
| C03 | King Cobra; American Alligator | Wadjet/cobra and Sobek/crocodile on one New Kingdom scarab | Do not generalize from crocodile to all alligators; retained as comparative crocodilian note only |
| C04 | Sacred Scarab | Museum educational synthesis of ancient Egyptian solar/rebirth association | Egyptology review desirable |
| C05 | African Elephant | Ganesha in a Hindu art-education context | Hindu studies/practitioner review desirable |
| C06 | Bald Eagle | Greek/Roman eagle association with Zeus/Jupiter on Roman object | Classics review desirable |
| C07 | Great Horned Owl | Owl/Athena relation in a Byzantine-era Greek text preserving older association | Species mismatch: historical little owl, not great horned owl; used only as a broad owl comparison |
| C08 | Common Raven | Huginn/Muninn in a named Old Norse prose source and English translation | Old Norse translation review desirable |
| C09 | Sandhill Crane | Japanese artwork record on crane, longevity, and fidelity | Species mismatch: red-crowned crane, not sandhill; used only as comparative crane note |
| C10 | Mojave Desert Tortoise; Green Sea Turtle | Turtle/tortoise longevity/divination in Chinese Sui–Tang object and later Japanese motif | Do not collapse turtle species or living practices |
| C11 | Gray Wolf | Roman she-wolf motif in later European artwork referencing the Aeneid tradition | Classics/source-chain review desirable |
| C12 | Domestic Dog | Anubis as canid/jackal in Late/Ptolemaic Egyptian context | Do not equate jackal, wild canid, and domestic dog |

## Deliberate omissions

- No pan-Indigenous North American animal meanings.
- No restricted or ceremonial material.
- No unsourced “totem,” “medicine,” or “power animal” assignments.
- No assumption that a museum object proves a single meaning across a whole civilization.
