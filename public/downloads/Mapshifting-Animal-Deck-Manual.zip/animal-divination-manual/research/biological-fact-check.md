# Biological Fact-check Ledger

Every card was anchored to a direct institutional natural-history record and uses species-specific behavior. “Single-source research check” means the draft was checked against the linked source family; it is not a substitute for independent zoological review. Taxonomy, conservation, introduced-range effects, and species-complex issues are called out for refresh.

| No. | Card | Scientific referent | Primary check | Status |
|---:|---|---|---|---|
| 1 | [Gray Wolf](../cards/001-gray-wolf.md) | *Canis lupus* | [institutional account](https://animaldiversity.org/accounts/Canis_lupus/) | single-source research check; expert review pending |
| 2 | [African Lion](../cards/002-african-lion.md) | *Panthera leo* | [institutional account](https://animaldiversity.org/accounts/Panthera_leo/) | single-source research check; expert review pending |
| 3 | [African Elephant](../cards/003-african-elephant.md) | *Loxodonta africana* | [institutional account](https://animaldiversity.org/accounts/Loxodonta_africana/) | single-source research check; expert review pending |
| 4 | [Red Fox](../cards/004-red-fox.md) | *Vulpes vulpes* | [institutional account](https://animaldiversity.org/accounts/Vulpes_vulpes/) | single-source research check; expert review pending |
| 5 | [American Black Bear](../cards/005-american-black-bear.md) | *Ursus americanus* | [institutional account](https://animaldiversity.org/accounts/Ursus_americanus/) | single-source research check; expert review pending |
| 6 | [White-tailed Deer](../cards/006-white-tailed-deer.md) | *Odocoileus virginianus* | [institutional account](https://animaldiversity.org/accounts/Odocoileus_virginianus/) | single-source research check; expert review pending |
| 7 | [American Bison](../cards/007-american-bison.md) | *Bison bison* | [institutional account](https://animaldiversity.org/accounts/Bison_bison/) | single-source research check; expert review pending |
| 8 | [Domestic Horse](../cards/008-domestic-horse.md) | *Equus caballus* | [institutional account](https://animaldiversity.org/accounts/Equus_caballus/) | single-source research check; expert review pending |
| 9 | [Domestic Dog](../cards/009-domestic-dog.md) | *Canis lupus familiaris* | [institutional account](https://animaldiversity.org/accounts/Canis_lupus_familiaris/) | single-source research check; expert review pending |
| 10 | [Domestic Cat](../cards/010-domestic-cat.md) | *Felis catus* | [institutional account](https://animaldiversity.org/accounts/Felis_catus/) | single-source research check; expert review pending |
| 11 | [North American Beaver](../cards/011-north-american-beaver.md) | *Castor canadensis* | [institutional account](https://animaldiversity.org/accounts/Castor_canadensis/) | single-source research check; expert review pending |
| 12 | [North American River Otter](../cards/012-north-american-river-otter.md) | *Lontra canadensis* | [institutional account](https://animaldiversity.org/accounts/Lontra_canadensis/) | single-source research check; expert review pending |
| 13 | [Little Brown Bat](../cards/013-little-brown-bat.md) | *Myotis lucifugus* | [institutional account](https://animaldiversity.org/accounts/Myotis_lucifugus/) | single-source research check; expert review pending |
| 14 | [Common Bottlenose Dolphin](../cards/014-bottlenose-dolphin.md) | *Tursiops truncatus* | [institutional account](https://www.fisheries.noaa.gov/species/common-bottlenose-dolphin) | single-source research check; expert review pending |
| 15 | [Humpback Whale](../cards/015-humpback-whale.md) | *Megaptera novaeangliae* | [institutional account](https://www.fisheries.noaa.gov/species/humpback-whale) | single-source research check; expert review pending |
| 16 | [Western Gorilla](../cards/016-western-gorilla.md) | *Gorilla gorilla* | [institutional account](https://animaldiversity.org/accounts/Gorilla_gorilla/) | single-source research check; expert review pending |
| 17 | [Red Kangaroo](../cards/017-red-kangaroo.md) | *Osphranter rufus* | [institutional account](https://animaldiversity.org/accounts/Macropus_rufus/) | single-source research check; expert review pending |
| 18 | [Platypus](../cards/018-platypus.md) | *Ornithorhynchus anatinus* | [institutional account](https://animaldiversity.org/accounts/Ornithorhynchus_anatinus/) | single-source research check; expert review pending |
| 19 | [Bald Eagle](../cards/019-bald-eagle.md) | *Haliaeetus leucocephalus* | [institutional account](https://www.allaboutbirds.org/guide/Bald_Eagle/lifehistory) | single-source research check; expert review pending |
| 20 | [Great Horned Owl](../cards/020-great-horned-owl.md) | *Bubo virginianus* | [institutional account](https://www.allaboutbirds.org/guide/Great_Horned_Owl/lifehistory) | single-source research check; expert review pending |
| 21 | [Common Raven](../cards/021-common-raven.md) | *Corvus corax* | [institutional account](https://www.allaboutbirds.org/guide/Common_Raven/lifehistory) | single-source research check; expert review pending |
| 22 | [Red-tailed Hawk](../cards/022-red-tailed-hawk.md) | *Buteo jamaicensis* | [institutional account](https://www.allaboutbirds.org/guide/Red-tailed_Hawk/lifehistory) | single-source research check; expert review pending |
| 23 | [Ruby-throated Hummingbird](../cards/023-ruby-throated-hummingbird.md) | *Archilochus colubris* | [institutional account](https://www.allaboutbirds.org/guide/Ruby-throated_Hummingbird/lifehistory) | single-source research check; expert review pending |
| 24 | [Emperor Penguin](../cards/024-emperor-penguin.md) | *Aptenodytes forsteri* | [institutional account](https://animaldiversity.org/accounts/Aptenodytes_forsteri/) | single-source research check; expert review pending |
| 25 | [Sandhill Crane](../cards/025-sandhill-crane.md) | *Antigone canadensis* | [institutional account](https://www.allaboutbirds.org/guide/Sandhill_Crane/lifehistory) | single-source research check; expert review pending |
| 26 | [Peregrine Falcon](../cards/026-peregrine-falcon.md) | *Falco peregrinus* | [institutional account](https://www.allaboutbirds.org/guide/Peregrine_Falcon/lifehistory) | single-source research check; expert review pending |
| 27 | [Laysan Albatross](../cards/027-laysan-albatross.md) | *Phoebastria immutabilis* | [institutional account](https://www.allaboutbirds.org/guide/Laysan_Albatross/lifehistory) | single-source research check; expert review pending |
| 28 | [Wild Turkey](../cards/028-wild-turkey.md) | *Meleagris gallopavo* | [institutional account](https://www.allaboutbirds.org/guide/Wild_Turkey/lifehistory) | single-source research check; expert review pending |
| 29 | [Greater Flamingo](../cards/029-greater-flamingo.md) | *Phoenicopterus roseus* | [institutional account](https://animaldiversity.org/accounts/Phoenicopterus_roseus/) | single-source research check; expert review pending |
| 30 | [Indian Peafowl](../cards/030-indian-peafowl.md) | *Pavo cristatus* | [institutional account](https://animaldiversity.org/accounts/Pavo_cristatus/) | single-source research check; expert review pending |
| 31 | [Emu](../cards/031-emu.md) | *Dromaius novaehollandiae* | [institutional account](https://animaldiversity.org/accounts/Dromaius_novaehollandiae/) | single-source research check; expert review pending |
| 32 | [Green Sea Turtle](../cards/032-green-sea-turtle.md) | *Chelonia mydas* | [institutional account](https://www.fisheries.noaa.gov/species/green-turtle) | single-source research check; expert review pending |
| 33 | [King Cobra](../cards/033-king-cobra.md) | *Ophiophagus hannah* | [institutional account](https://animaldiversity.org/accounts/Ophiophagus_hannah/) | single-source research check; expert review pending |
| 34 | [American Alligator](../cards/034-american-alligator.md) | *Alligator mississippiensis* | [institutional account](https://animaldiversity.org/accounts/Alligator_mississippiensis/) | single-source research check; expert review pending |
| 35 | [Panther Chameleon](../cards/035-panther-chameleon.md) | *Furcifer pardalis* | [institutional account](https://animaldiversity.org/accounts/Furcifer_pardalis/) | single-source research check; expert review pending |
| 36 | [Komodo Dragon](../cards/036-komodo-dragon.md) | *Varanus komodoensis* | [institutional account](https://animaldiversity.org/accounts/Varanus_komodoensis/) | single-source research check; expert review pending |
| 37 | [Mojave Desert Tortoise](../cards/037-mojave-desert-tortoise.md) | *Gopherus agassizii* | [institutional account](https://animaldiversity.org/accounts/Gopherus_agassizii/) | single-source research check; expert review pending |
| 38 | [Axolotl](../cards/038-axolotl.md) | *Ambystoma mexicanum* | [institutional account](https://animaldiversity.org/accounts/Ambystoma_mexicanum/) | single-source research check; expert review pending |
| 39 | [Dyeing Poison Frog](../cards/039-dyeing-poison-frog.md) | *Dendrobates tinctorius* | [institutional account](https://animaldiversity.org/accounts/Dendrobates_tinctorius/) | single-source research check; expert review pending |
| 40 | [Tiger Salamander](../cards/040-tiger-salamander.md) | *Ambystoma tigrinum* | [institutional account](https://animaldiversity.org/accounts/Ambystoma_tigrinum/) | single-source research check; expert review pending |
| 41 | [American Bullfrog](../cards/041-american-bullfrog.md) | *Lithobates catesbeianus* | [institutional account](https://animaldiversity.org/accounts/Lithobates_catesbeianus/) | single-source research check; expert review pending |
| 42 | [Great White Shark](../cards/042-great-white-shark.md) | *Carcharodon carcharias* | [institutional account](https://animaldiversity.org/accounts/Carcharodon_carcharias/) | single-source research check; expert review pending |
| 43 | [Atlantic Salmon](../cards/043-atlantic-salmon.md) | *Salmo salar* | [institutional account](https://animaldiversity.org/accounts/Salmo_salar/) | single-source research check; expert review pending |
| 44 | [Ocellaris Clownfish](../cards/044-ocellaris-clownfish.md) | *Amphiprion ocellaris* | [institutional account](https://animaldiversity.org/accounts/Amphiprion_ocellaris/) | single-source research check; expert review pending |
| 45 | [Lined Seahorse](../cards/045-lined-seahorse.md) | *Hippocampus erectus* | [institutional account](https://animaldiversity.org/accounts/Hippocampus_erectus/) | single-source research check; expert review pending |
| 46 | [Electric Eel](../cards/046-electric-eel.md) | *Electrophorus electricus* | [institutional account](https://animaldiversity.org/accounts/Electrophorus_electricus/) | single-source research check; expert review pending |
| 47 | [Reef Manta Ray](../cards/047-reef-manta-ray.md) | *Mobula alfredi* | [institutional account](https://animaldiversity.org/accounts/Mobula_alfredi/) | single-source research check; expert review pending |
| 48 | [Spot-fin Porcupinefish](../cards/048-porcupinefish.md) | *Diodon hystrix* | [institutional account](https://animaldiversity.org/accounts/Diodon_hystrix/) | single-source research check; expert review pending |
| 49 | [Banded Archerfish](../cards/049-banded-archerfish.md) | *Toxotes jaculatrix* | [institutional account](https://animaldiversity.org/accounts/Toxotes_jaculatrix/) | single-source research check; expert review pending |
| 50 | [Western Honey Bee](../cards/050-western-honey-bee.md) | *Apis mellifera* | [institutional account](https://animaldiversity.org/accounts/Apis_mellifera/) | single-source research check; expert review pending |
| 51 | [Monarch Butterfly](../cards/051-monarch-butterfly.md) | *Danaus plexippus* | [institutional account](https://www.fws.gov/species/monarch-butterfly-danaus-plexippus) | single-source research check; expert review pending |
| 52 | [Common Green Darner](../cards/052-common-green-darner.md) | *Anax junius* | [institutional account](https://animaldiversity.org/accounts/Anax_junius/) | single-source research check; expert review pending |
| 53 | [Sacred Scarab](../cards/053-sacred-scarab.md) | *Scarabaeus sacer* | [institutional account](https://animaldiversity.org/accounts/Scarabaeus_sacer/) | single-source research check; expert review pending |
| 54 | [European Mantis](../cards/054-european-mantis.md) | *Mantis religiosa* | [institutional account](https://animaldiversity.org/accounts/Mantis_religiosa/) | single-source research check; expert review pending |
| 55 | [Common Eastern Firefly](../cards/055-common-eastern-firefly.md) | *Photinus pyralis* | [institutional account](https://animaldiversity.org/accounts/Photinus_pyralis/) | single-source research check; expert review pending |
| 56 | [Leafcutter Ant](../cards/056-leafcutter-ant.md) | *Atta cephalotes* | [institutional account](https://animaldiversity.org/accounts/Atta_cephalotes/) | single-source research check; expert review pending |
| 57 | [Cross Orbweaver](../cards/057-cross-orbweaver.md) | *Araneus diadematus* | [institutional account](https://animaldiversity.org/accounts/Araneus_diadematus/) | single-source research check; expert review pending |
| 58 | [Emperor Scorpion](../cards/058-emperor-scorpion.md) | *Pandinus imperator* | [institutional account](https://animaldiversity.org/accounts/Pandinus_imperator/) | single-source research check; expert review pending |
| 59 | [Common Octopus](../cards/059-common-octopus.md) | *Octopus vulgaris* | [institutional account](https://ocean.si.edu/ocean-life/invertebrates/octopus) | single-source research check; expert review pending |
| 60 | [Chambered Nautilus](../cards/060-chambered-nautilus.md) | *Nautilus pompilius* | [institutional account](https://animaldiversity.org/accounts/Nautilus_pompilius/) | single-source research check; expert review pending |
| 61 | [Garden Snail](../cards/061-garden-snail.md) | *Cornu aspersum* | [institutional account](https://animaldiversity.org/accounts/Cornu_aspersum/) | single-source research check; expert review pending |
| 62 | [Caribbean Hermit Crab](../cards/062-caribbean-hermit-crab.md) | *Coenobita clypeatus* | [institutional account](https://animaldiversity.org/accounts/Coenobita_clypeatus/) | single-source research check; expert review pending |
| 63 | [Peacock Mantis Shrimp](../cards/063-peacock-mantis-shrimp.md) | *Odontodactylus scyllarus* | [institutional account](https://animaldiversity.org/accounts/Odontodactylus_scyllarus/) | single-source research check; expert review pending |
| 64 | [Moon Jelly](../cards/064-moon-jelly.md) | *Aurelia aurita* | [institutional account](https://animaldiversity.org/accounts/Aurelia_aurita/) | single-source research check; expert review pending |
| 65 | [Ochre Sea Star](../cards/065-ochre-sea-star.md) | *Pisaster ochraceus* | [institutional account](https://animaldiversity.org/accounts/Pisaster_ochraceus/) | single-source research check; expert review pending |
| 66 | [Staghorn Coral](../cards/066-staghorn-coral.md) | *Acropora cervicornis* | [institutional account](https://www.fisheries.noaa.gov/species/staghorn-coral) | single-source research check; expert review pending |
| 67 | [Giant Pacific Sea Cucumber](../cards/067-giant-pacific-sea-cucumber.md) | *Apostichopus californicus* | [institutional account](https://animaldiversity.org/accounts/Apostichopus_californicus/) | single-source research check; expert review pending |
| 68 | [Common Earthworm](../cards/068-common-earthworm.md) | *Lumbricus terrestris* | [institutional account](https://animaldiversity.org/accounts/Lumbricus_terrestris/) | single-source research check; expert review pending |

## Priority rechecks

- Electric eel and common octopus species-complex/taxonomy questions.
- Reef versus giant manta source alignment.
- Conservation status for axolotl, gorilla, elephant, turtles, manta, coral, albatross, monarch, and other threatened populations.
- Introduced-range effects for cat, bullfrog, garden snail, earthworm, and peafowl.
- Leafcutter-ant behavior needs a second entomological source because the recurring ADW record is taxonomically stronger than behaviorally complete.
