# Source and Provenance Ledger

Access date for web sources: 2026-08-23.

## Requested primary and comparative references

| ID | Source | Exact edition/status | Access and permitted use |
|---|---|---|---|
| R01 | Ted Andrews, *Animal-Speak: The Spiritual & Magical Powers of Creatures Great & Small* | Llewellyn, September 2002 trade paperback, 400 pages, ISBN 9780875420288 | [Official publisher record](https://www.llewellyn.com/product.php?ean=9780875420288) consulted. Complete text not available; no animal-specific claims, quotations, or pages used. |
| R02 | Kim Krans, *The Wild Unknown Animal Spirit Deck and Guidebook* | HarperOne, March 27, 2018, 63-card set with 208-page guidebook, ISBN 9780062742865 | [Creator overview](https://kimkrans.com/the-wild-unknown) and [bibliographic record](https://books.google.com/books/about/The_Wild_Unknown_Animal_Spirit_Deck_and.html?id=mTpstAEACAAJ) consulted. Complete guidebook not available; product-level structural comparison only. |

## Method and cultural-care sources

| ID | Source | Use |
|---|---|---|
| M01 | [NMAI Native Knowledge 360° Essential Understandings](https://americanindian.si.edu/nk360/about/essential-understandings) | Baseline for specificity, living cultures, diversity, and Native perspectives. |
| M02 | [NMAI terminology guidance](https://americanindian.si.edu/nk360/informational/impact-words-tips) | Naming and stereotype avoidance. |
| M03 | [Animal Diversity Web—About](https://animaldiversity.org/about/) | Natural-history database scope and limitations; species accounts are edited but often student-authored. |
| M04 | [Cornell Lab—All About Birds](https://www.allaboutbirds.org/guide/) | Authoritative bird life-history summaries. |
| M05 | [NOAA Fisheries species directory](https://www.fisheries.noaa.gov/species-directory) | Marine life history and conservation. |
| M06 | [Smithsonian Ocean](https://ocean.si.edu/ocean-life) | Marine invertebrates and reef ecology. |

## Card-level biological sources

Every card includes its direct species or institutional account under **Sources**. The primary recurring collections are ADW, Cornell Lab, NOAA Fisheries, Smithsonian Ocean, and USFWS. Direct links are counted as separate consulted records in the manifest's source total. Where an institutional page could not be fully retrieved during drafting, that limitation is noted on the card and in the [biological fact-check](biological-fact-check.md).

## Cultural and historical sources adopted

| ID | Named context | Source |
|---|---|---|
| C01 | Ancient Egyptian lion and royal/deity symbolism | [Met, *Recumbent Lion*, ca. 2575–2450 BCE](https://www.metmuseum.org/art/collection/search/549541) |
| C02 | Ancient Egyptian Bastet/cat protection and prosperity | [Met, *Cat*, 664–30 BCE](https://www.metmuseum.org/art/collection/search/552028) |
| C03 | Ancient Egyptian Wadjet/cobra and Sobek/crocodile | [Met, *Scarab with Sobek and Wadjet*, ca. 1300–1080 BCE](https://www.metmuseum.org/art/collection/search/553403) |
| C04 | Ancient Egyptian scarab, solar movement, and rebirth | [British Museum, *Ancient Egypt: Symbols of the Pharaoh*](https://www.britishmuseum.org/sites/default/files/2019-09/Visit_Egypt_Symbols_KS2b.pdf) |
| C05 | Hindu Ganesha and elephant-headed obstacle removal | [Smithsonian National Museum of Asian Art, *Seated Ganesha*](https://asia.si.edu/education/educator-resources/encountering-religion-in-asian-art/explore-by-object/object/seated-ganesha/) |
| C06 | Greek/Roman eagle association with Zeus/Jupiter | [Met, Roman terracotta oil lamp, late 1st–early 2nd c. CE](https://www.metmuseum.org/art/collection/search/241625) |
| C07 | Greek owl of Athena and wisdom | [Tzetzes, *Chiliades* 8.50, translated text](https://www.theoi.com/Text/TzetzesChiliades8.html) |
| C08 | Old Norse Huginn and Muninn | [Snorri Sturluson, *Gylfaginning* §38, 1916 English translation](https://www.sacred-texts.com/neu/pre/pre04.htm) |
| C09 | Japanese crane, fidelity and longevity | [Met, Tomioka Tessai, *Nine Auspicious Symbols*, 1913](https://www.metmuseum.org/art/collection/search/853226) |
| C10 | Chinese/Japanese tortoise, longevity and divination | [Met, turtle-shaped inkstone, 6th–7th c.](https://www.metmuseum.org/art/collection/search/65348) |
| C11 | Roman she-wolf and Romulus/Remus | [Met, Conca study with Roman shield, ca. 1716–18](https://www.metmuseum.org/art/collection/search/420445) |
| C12 | Ancient Egyptian Anubis/canid funerary guardianship | [Met, recumbent Anubis, 343–30 BCE](https://www.metmuseum.org/art/collection/search/544075) |

## Excluded source types

Unauthorized scans, file-sharing copies, unattributed “animal meaning” websites, generic lists of “Native American” symbolism, AI-generated citations, and sources that collapse distinct cultures were not used.
