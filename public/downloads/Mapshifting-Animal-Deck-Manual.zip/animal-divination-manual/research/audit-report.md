# Completeness and Cultural-Integrity Audit

Audit date: 2026-08-23  
Release state: 0.1.0 complete research draft

## Executive result

The collection is structurally complete: 68 numbered card manuscripts, every requested manual chapter, all ten cross-indexes, research ledgers, template, glossary, bibliography, manifest, and changelog are present. Each card contains all required metadata and sections, seven reflection questions, ten life-context reading prompts, a safe practice, sources, relationships, and a text-only illustration brief.

The draft is **not yet publication-final**. The two requested commercial guidebooks were unavailable in full, several institutional species pages require retrieval or second-source follow-up, and no specialist cultural or zoological review has been commissioned. These are stated limitations rather than blank or fabricated content.

## Structural completeness

| Requirement | Result |
|---|---|
| Core deck between 60 and 80 animals | Pass — 68 cards |
| One Markdown file per animal | Pass — 68 numbered files |
| Required YAML fields | Pass — present and parseable on all cards |
| Required card sections | Pass — all 20 required level-two sections on all cards |
| Gift, Wound, and relationship | Pass — three primary Gifts, three primary Wounds, and integration on each card |
| Balanced/over/underexpression | Pass on every card |
| Reading contexts | Pass — ten contexts on every card |
| Reflection questions | Pass — seven per card |
| Safe practice and secular alternative | Pass on every card |
| Cultural/historical table or explicit omission | Pass |
| Modern comparison section | Pass, with unavailability stated rather than invented |
| Relationships among cards | Pass on each card and in master index |
| Future illustration brief | Pass — text only |
| Required manual chapters | Pass |
| Required layouts | Pass — nine spreads with every position explained |
| Required indexes and research files | Pass |
| Empty files/placeholders | None |
| Generated images | None |

## Biological fact audit

Every card fixes a scientific referent, separates natural-history facts from the symbolic bridge, and links a direct institutional account. The primary collections are Animal Diversity Web, Cornell Lab of Ornithology, NOAA Fisheries, Smithsonian Ocean, and USFWS.

The natural-history writing corrects several common myths or oversimplifications, including:

- wolf packs as typically family-based rather than simple dominance caricatures;
- chameleon color change as communication/physiology as well as camouflage;
- honey bees as one pollinator lineage rather than a stand-in for all bees;
- alligator maternal care and ecosystem engineering;
- firefly signals as species-specific and light-sensitive;
- mantis sexual cannibalism as variable rather than universal;
- coral as a colonial animal in symbiosis; and
- regeneration as a biological capacity, not an invitation to injury.

The [biological fact-check ledger](biological-fact-check.md) is a single-source research audit, not independent expert certification. Highest-priority rechecks are taxonomy/species-complex questions, fast-changing conservation status, introduced-range effects, manta source alignment, and the leafcutter-ant behavior record.

## Cultural-integrity audit

Fourteen cards contain a sourced historical or cultural comparison drawn from twelve named source records. Each row identifies a period or context, provenance, confidence, and direct citation. The [cultural attribution ledger](cultural-attribution-ledger.md) records species-transfer cautions.

Safeguards applied:

- no generic “Native American” or pan-Indigenous meanings;
- no casual use of “spirit animal”;
- no restricted, ceremonial, initiatory, or closed teaching;
- no claim that a museum object establishes one civilization-wide meaning;
- no assignment of a cultural association merely to fill a card;
- named-source attribution for every adopted row; and
- explicit distinction between historical documentation and living practice.

Specialist review is still recommended for ancient Egyptian, Hindu, Greek/Roman, Old Norse, Chinese, and Japanese records. Species-mismatched comparisons—owl, crane, crocodilian, canid, and turtle/tortoise—should receive special scrutiny and may be removed before publication.

## Copyright and originality audit

- No direct quotation from Andrews, Krans, or another commercial guidebook appears.
- No unauthorized scan or pirated copy was accessed.
- No page number was invented.
- No existing deck's sequence, roster, suit system, prose, imagery, or card composition was copied.
- Product-level comparison is confined to official/bibliographic facts.
- Every symbolic meaning is labeled as behavioral inference, named historical/cultural material, or original deck synthesis.
- No images were generated and no missing-image placeholder appears.

## Gift–Wound balance audit

Each card uses one behavioral tension to generate related Gifts and Wounds. Wounds are consistently framed as tentative, participant-revisable, and non-diagnostic. Each card explains how a Gift can become excessive, how access can be suppressed, and how integration preserves capacity without repeating defense.

No animal is designated inherently positive or negative. Predators, prey, domesticated animals, invertebrates, scavengers, and decomposers all carry useful capacities and possible distortions.

## Redundancy and coverage

The roster covers eighteen mammals, thirteen birds, six reptiles, four amphibians, eight fish/rays, seven insects, two arachnids, three mollusks, two crustaceans, four other marine invertebrates, and one annelid.

Near-neighbor distinctions are explicit:

- **Wolf / Dog:** wild family-territory coordination versus reciprocal cross-species trust.
- **Bison / Horse:** communal ecological weight versus negotiated movement and partnership.
- **Bat / Owl:** active echolocating feedback versus silent receptive ambush.
- **Red-tailed Hawk / Peregrine:** patient surveillance versus committed speed and recalibration.
- **Turtle / Tortoise:** ocean navigation and return versus land-based resource pacing.
- **Axolotl / Salamander:** retained aquatic form versus seasonal emergence and metamorphosis.
- **Bee / Ant:** pollination and dance communication versus fungus cultivation and infrastructure.
- **Beaver / Coral:** mobile family engineering versus symbiotic colonial habitat-building.
- **Chameleon / Octopus:** contextual signaling in place versus distributed manipulation, escape, and form change.
- **Earthworm / Scarab / Sea Cucumber:** diffuse soil processing, deliberate dung relocation, and marine sediment recycling.

Expansion candidates were excluded when their contribution overlapped too closely or required deeper cultural/conservation work. They remain in the [expansion index](../indexes/expansion-candidates.md).

## Agency and safety audit

The manual consistently presents readings as possibilities rather than fate. It includes consent for readings, participant authority to reject meanings, non-diagnostic Wound language, stop boundaries, high-stakes exclusions, wildlife non-interference, and a closing thought–word–action practice.

## Link and data audit

Automated checks verify unique card numbers 1–68, unique slugs, required YAML arrays, all required section headings, seven questions, ten reading contexts, nonempty Markdown files, and relative-link targets. The final manifest records file hashes and sizes. External sites can change and should be rechecked before publication.

## Remaining uncertainty

1. Full animal-specific comparison with the specified Andrews and Krans editions remains unavailable.
2. Institutional biology links are strong draft anchors but not a substitute for expert review or peer-reviewed triangulation.
3. Conservation and taxonomy may change after the access date.
4. Historical cultural rows need specialist review, especially where the exact species differs.
5. Field testing is needed to discover ambiguous prompts, emotional effects, and hidden redundancy.

## Publication recommendation

Treat version 0.1.0 as complete for continued research, prototyping, structured-data conversion, and editorial review. Before public release, complete the four highest-priority tasks in [open questions](open-questions.md), then rerun links, taxonomy, conservation, cultural attribution, and originality checks.
