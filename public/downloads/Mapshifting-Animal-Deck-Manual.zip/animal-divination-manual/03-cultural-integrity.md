# Cultural Integrity and Attribution

## Baseline

The deck follows the Smithsonian National Museum of the American Indian's Native Knowledge 360° baseline: there is no single American Indian culture or language; Native nations are distinct, contemporary, adaptive, and sovereign; and Native perspectives should be encountered through Native voices and specific contexts.

## Rules

1. Name the people, nation, community, period, text, artist, museum, or author connected to a claim.
2. Prefer community-created or community-endorsed sources and living-culture context.
3. Do not collapse different peoples into a universal Indigenous worldview.
4. Do not reproduce restricted, initiatory, ceremonial, or closed knowledge.
5. Do not use “spirit animal” as a casual synonym for affinity or personality.
6. Do not assign an Indigenous association to every card for decorative completeness.
7. Separate a documented historical object from a claim about present-day belief.
8. Treat translation, colonial collection history, and outsider interpretation as possible limitations.
9. Place weak or unattributed material in [open questions](research/open-questions.md), not the card meaning.
10. Seek specialist review before publication when a cultural claim shapes the deck's central meaning.

## Scope of this draft

This draft deliberately adopts few cultural claims. Included rows are limited to specific, accessible museum records or named historical texts, such as an ancient Egyptian object connected to Bastet, a Roman lamp connecting the eagle with Jupiter, a Japanese Edo-period artwork connecting cranes with longevity/fidelity, or a translated Old Norse prose passage naming Odin's ravens.

No North American Indigenous animal teaching is assigned to a card in this draft. That is a safeguard, not an assertion that such relationships do not exist. Any future addition requires nation-specific, preferably community-authored evidence and review.

## Reader responsibility

A reader may have a personal, familial, religious, or community relationship with an animal that differs from this deck. That relationship takes precedence for that reader. The deck should invite a person to name their source and context rather than claiming all meanings are interchangeable.

Continue to [Gifts and Wounds](04-gifts-and-wounds.md).
