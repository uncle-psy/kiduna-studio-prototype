# How to Use the Deck

## Before drawing

Name a question that preserves agency. Prefer “What should I notice about this choice?” to “What will happen?” Decide whether you want an open encounter or a defined spread. You may shuffle physical cards, use a randomizer, deliberately select an animal, or work from an animal encountered in ordinary life without disturbing it.

## One animal

1. Observe before looking up the meaning: body, posture, habitat, movement, and your immediate response.
2. Read the living-animal section and separate fact from analogy.
3. Notice which Gift and Wound feel relevant, irrelevant, or incomplete.
4. Check balanced, overexpressed, and underexpressed possibilities.
5. Apply only the reading context that matches the question.
6. Close with one thought, one word, and one feasible action.

## Multiple animals

Read the relationship before adding meanings:

- Do the animals share a habitat or require different environments?
- Is one predator, prey, partner, competitor, host, pollinator, or ecosystem engineer?
- Do they share a Gift but differ in method?
- Does one reveal the other's Wound?
- Which card describes a condition, which an action, and which a balancing influence?

Do not force a single story. Two cards may expose a real tension that remains unresolved.

## Working over time

Choose one card for a day, week, project phase, or recurring decision. Keep a dated record of observations, actions, and changes. Revisit the original question before drawing again. Dependence on repeated draws is a sign to pause and make a grounded decision with available evidence or support.

## Reversals

Reversals are optional. If used, an inverted card does not mean “bad.” Read it as a prompt to examine **overexpression**, **underexpression**, blocked access, private/internal expression, or a quality whose timing is not yet right. State which lens you are using.

## Clarifiers and wild cards

This core deck contains no mythical or culture-specific wild card. A reader may draw one clarifier after articulating what remains unclear. More draws are not automatically more information. Expansion candidates are listed separately.

Continue to [Reading for others](07-reading-for-others.md).
