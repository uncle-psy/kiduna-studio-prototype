# The Living Mirror

## A 68-card animal deck for divination, agency, and self-inquiry

*The Living Mirror* is a source-grounded manual for encountering animals as living beings first and symbolic mirrors second. Each card joins a **Gift**—a capacity that can be cultivated—with a **Wound**—a related hurt, defense, or imbalance that can be recognized without diagnosis or shame.

The deck offers patterns, questions, and possible actions. It does not declare fate, diagnose a person, claim authority over a culture, or replace professional care.

## Read the manual

1. [Goal and scope](00-goal-and-scope.md)
2. [Philosophy](01-philosophy.md)
3. [Research methodology](02-methodology.md)
4. [Cultural integrity](03-cultural-integrity.md)
5. [Gifts and Wounds](04-gifts-and-wounds.md)
6. [Deck architecture](05-deck-architecture.md)
7. [How to use the deck](06-how-to-use-the-deck.md)
8. [Reading for others](07-reading-for-others.md)
9. [Spreads](08-spreads.md)
10. [Integration practices](09-integration-practices.md)

## Reference

- [Complete card guide](cards/README.md)
- [Card index](indexes/card-index.md)
- [Gift index](indexes/gifts-index.md)
- [Wound index](indexes/wounds-index.md)
- [Archetype index](indexes/archetypes-index.md)
- [Relationships among cards](indexes/relationships-between-cards.md)
- [Glossary](glossary.md)
- [Annotated bibliography](bibliography.md)
- [Source and provenance ledger](research/source-ledger.md)
- [Audit report](research/audit-report.md)
- [Manifest](manifest.md)

## Source-status notice

The complete text of Ted Andrews’ *Animal-Speak* and Kim Krans’ *The Wild Unknown Animal Spirit Deck and Guidebook* was not supplied or lawfully accessible during this draft. Their official bibliographic and product records were consulted; no animal-specific meaning, quotation, or page number from either work is claimed. Every affected card says so. See the [source ledger](research/source-ledger.md) and [open questions](research/open-questions.md).

All writing is original. No images were generated.
