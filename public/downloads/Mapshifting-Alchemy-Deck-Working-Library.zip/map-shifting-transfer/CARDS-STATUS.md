# Card Reading Status

The conversation captured substantial readings and concise card summaries across *The Book of Alchemy*, including suits, grades, keywords, gifts, challenges, imagery, planetary balances, stones, layouts, and wild-card instructions.

## Important transfer note

The complete, word-for-word source readings have not yet been exported as individual card Markdown files. This package therefore preserves the structured design notes and records the next authoring task:

1. Create one Markdown file per card.
2. Preserve the source reading separately from any concise interpretation.
3. Build suit and master indexes that link cards by keyword, grade, stone, planet, and theme.
4. Package the finished library as the Map Shifting skill.

## Current naming corrections to preserve

- Egg One: Protect.
- Egg Two: Secrete.
- Egg Three: Guard.
- Egg Four: Shelter.
- Egg Five: Fortify.
- The card “Subdue” was confirmed as Mars–Uranus with bloodstone; reconcile its suit and number against the source transcription before publishing a final index.

These card notes contain corrections made during dictation and should be reconciled against the source transcription before publishing a final index.
