# Book of Alchemy — Notes Inbox

Use this space for ideas, questions, cross-card observations, and follow-ups that arise during dictation. Entries can later be linked to the relevant card or moved into the integrated index.

## Notes

### Invitation transparency

- An invitation should open to an inspectable web scene that makes the destination clear before a person joins.
- Show the scene's purpose, its coherence and other salient aspects, and the agents present.
- The design goal is informed consent: people should not be able to be tricked into joining something they did not intend to join.

### Naming update

- Replace “Uncle Silas” with “Psylas Mariner” (spelled P-S-Y-L-A-S).

### Bellwether receiving room

- The Compass Rose receiving room currently contains six family-member figures.
- Add Kai and the user's avatar, “Modo the Magical Mapshifter.”
- Establish map-shifting as the complete practice underlying all of the user's domains.
- For a first-time participant, the first action asks guided questions and creates a personal guest room.
- The guest room should be ready for work immediately, with the elements the participant needs, including their initial ally.
- A colored rose identifies which of the four primary allies will attend to the participant.
- Decorate the starter room with the ally's appropriate theme, sigils, and objects. Participants may later build their own place.
- Private-room requirement: the participant's personal conversations and activity must not be visible to the system operator, even when the operator runs the system. The privacy model and implementation should be inspectable through source code and stated rules.

### Book title

- New title: *Map-shifting: An Epic Adventure Beyond Time, Space, and the Death Grip of Global Civilization*.

### Wallet assets

- Gifts, sigils, and related items are represented as NFTs in the wallet.
- The giver designates an NFT as locked (non-transferable) or transferable.
- An NFT can have associated fungible tokens, such as compute credits or USDC.
- Recipients may redistribute granted compute, including compute that is staked, to support others' access—for example, a limited number of free invitations or ongoing allocations.

### Launch access: Trevor

- Create a dedicated page for Trevor, who will distribute invitations to it at launch.
- Visitors receive early access for press, technical audiences, “Mahaa” (spelling/context to confirm), and other groups.
- Trevor's area functions as a briefing and onboarding space that he manages.

### Player-controlled game funds

- Explore a player-controlled shared-wallet model for game funds: participants voluntarily fund a common wallet they control, and releases occur only on their instructions.
- The platform takes no rake or share. Consider a dispute-escalation process.
- Treat this as a product concept, not a way to bypass betting or payments rules. Obtain jurisdiction-specific legal, payments, consumer-protection, and custody review before implementation.

### Investor reception

- Invite venture capitalists to the reception area.
- From there, they can request a copy of the deck and other project materials from the user's allies, and learn about the project.

### Primary allies: representation and change

- The six primary allies should have visibly diverse racial and cultural representation.
- Their visual appearance may evolve over time and in different circumstances.

### Scene scale and in-world communication

- Different scenes can accommodate different group sizes, from intimate theaters to theaters, coliseums, and stadiums; each scale offers a different perspective on events.
- Participants can send notes to one another through era-appropriate messenger models, such as crows or ravens, adapted to future, modern, medieval, or ancient settings.

### In-world card games

- Place decks of cards in rooms. A participant can pick up a deck and invite others to play in that room.
- Tapping a deck shows games currently being played in the room.
- Provide a switchboard area where participants can challenge one another.

### Personal environment pattern

- A participant's guest room/private quarters also begins as their reception area; they may relocate it later.
- Each complete environment includes the nine major archetypes, a personal vault, a navigation map, and essential tools. Some components, such as the vault, are private to the participant.
- Participants can use Bellwether's patterns to create and place their own environments. The user intends to keep building out Bellwether as their own complete environment.
- After a participant completes the foyer or initiation experience and receives an initial room, they can have one room for each Pattern.
- Bellwether will include the user's Pattern and Archetypal areas, which the user can invite people into. Other participants can likewise develop their own Pattern rooms and invite people into them.

### Individual and institutional onboarding

- In the reception area, a person declares whether they are participating individually or representing an institution.
- Everyone starts as an individual, then may create separate institutional accounts and build organization-specific capabilities.
- Support registration for centralized organizations and AI-assisted onboarding that checks relevant registries.
- A representative certifies their role; verify the claim later. Do not grant authority that depends on institutional representation until verification is complete.

### Map Shifting: conceptual framework

- Map Shifting will use four suits: health, wealth, wisdom, and love.
- Its proposed framework combines alchemy, Indigenous medicine traditions, and starseed/Gnostic mythology.
- Present map-shifting as a quantum-inspired practice concerned with memory, networks, and the perceived nature of time and space. Any use of specific Indigenous teachings must be accurate, attributed, and used with appropriate permission.

### Invitation and permission flow

- Invitations to the system originate through a person's personal link.
- Internal codes are transferred and used inside the system rather than functioning as arbitrary external access links.
- A first-time participant may receive an external invitation link. It opens the inviter's portal and starts onboarding; the linked code is then registered during onboarding to apply its specific permissions.
- Reconsider special invitations: relationships, groups, and sub-realms can instead provide the routing context. A foyer or reception area uses recorded relationship and community context to engage and route a participant correctly.
- A community or sub-realm need not have its own dedicated place; the database must preserve its context so the appropriate Forces, data, and routing apply.
- A personal link may be published broadly. An optional code entered on that link's page supplies person-specific context and may grant an associated Resource, such as a Coupon or compute allocation; without the code, the person receives no associated benefit.

### Registration entry points

- Change registration so a person can sign up only through someone else's handle page at `kaduna.ai/<handle>`.
- On the main page, direct visitors to contact the user's avatar, Modo.
- Let visitors choose to contact the user directly at the supplied Kaduna email address, contact Modo, or contact both together.
- The contact form asks for a reason and includes a purpose selector, such as partnering, sponsoring, gaining early access, funding, or investing.

### Personal clan pages

- Each person has a personal clan landing page that links to their host, other clan members, member avatars, and other relevant information.
- Build a view of the clan's connection network, including who is online where appropriate, and develop a fuller metrics page over time.
- The user's clan is the Kinship Clan.
- Each clan can choose a generated logo or supply its own design system, including a distinctive clan-specific logo.

### Proposed token launch — pending legal and event confirmation

- Proposed launch: October 13 at noon Eastern, at an AI Engineer Daily event or venue (exact name and year to confirm).
- Proposed offering: up to $1 million at a $40 million fully diluted valuation; launch regardless of the amount sold by that point.
- Do not announce or execute this plan until securities, token, payments, and consumer-protection requirements have been reviewed for all relevant jurisdictions.

### Foundation and permissionless capital coordination

- Respond to concerns about foundation favoritism by enabling people to aggregate capital and support the work they choose.
- Kinship Intelligence Institute is proposed as the foundation, operating on Solana's permissionless infrastructure.
- The intended participation model is peer-to-peer: participants make their case to one another rather than seeking a gatekeeper's pitch approval.
- Any arrangement involving pooled capital, returns, token value, or financial participation requires legal, securities, tax, and consumer-protection review before implementation or promotion.

### NIST/SBA decentralized communications concept

- Propose a fully decentralized communications network for NIST and the SBA, powered by intelligence and agency.
- The decentralized layer is specifically alignment and coherence, allowing the appropriate alignment and coherence context to be routed across many use cases.

### Landing-page methodology

- Describe Map Shifting as the user's methodology: a synthesis of Howard Teich's quantum-complementarity model and the Four Arrows Indigenous medicine model.
- Position quantum complementarity as oriented to the institutional age, the Four Arrows model as oriented to nature, and Map Shifting as their new synthesis for the agentic age.
- Confirm names, source materials, permissions, and attribution before publishing any description of the Indigenous medicine model.

### Ally source mapping

- Stella is based on Howard and draws on Cosmic Humanity material.
- Orson is based on Four Arrows and draws on Four Arrows material.
- Confirm source permissions, attribution, and appropriate boundaries before incorporating either body of material.

### Specialist allies outside the core pantheon

- Create additional allies from the materials associated with other major figures.
- These specialists are outside the seven-figure pantheon (family plus Kai) and the eight-figure version that includes the user.
- Possible support domains include organizational development, community building, addiction-related support, and sales drawing on Kevin Nation's material.
- Confirm source permissions and attribution. For addiction-related support, limit the ally to safe informational, support, and referral roles; do not present it as diagnosis or treatment.

### Core terminology: association

- Replace the core-canon concept of “guild” with “association.”
- Add association as a type of realm.
- Reserve “guild” for in-world use, particularly in medieval settings, rather than as core-canon terminology.

### Sigils: cat and fawn

- Create a major cat–fawn sigil using the rounded-edge square format reserved for major sigils.
- The cat may be a mountain lion, cougar, ocelot, or lynx; pair it with a fawn.
- Also create a regular cat sigil, using a mountain lion/cougar or similar big-cat form.

### Map Shifting: central organizing map

- Map the Map Shifting categories of health, wealth, wisdom, and love to the system's existing symbols and categories, including earth, air, fire, water, and its archetypes (for example, warrior, noble, and rogue).
- Make health, wealth, wisdom, and love the central organizing principles.
- Orient the main pantheon as: east, south, west, and north for the four children; up for the mother; down for the father; inside for both the avatar and Kai.
- Treat inside as the zero point: everything and the connection to everything.
- Each person can design the same number of allies for their own purposes and choose their own reception-area type and style.

### Compass Rose: choice, navigation, and transformation

- The Crossroads/Compass Rose room is for making choices. The navigation Pattern is distinct: it is for understanding the whole Field.
- Map Shifting uses the room as a reflective framework: consider what is behind, what seems ahead, and the plans and projects that connect them; then identify what authority, information, relationships, or other present resources can make the next state possible now.
- Facing forward: left is the past; right is the future; below is what has been done; above is the “magic carpet” or aspirational/possibility layer; inside is transformation. Include forward, back, left, right, up, down, and center.
- Use this directional room for divination and transformation experiences.
- Bring the complete card library and future related material into the rotating Compass Rose room, so the room reflects the participant through seven viewpoints.

### Map Shifting room pattern

- Create a Map Shifting room as the place a participant returns to re-center and shift their maps; it functions as both a map and a Map Shifting Pattern.
- Present images and invite reflection: what colors stand out, what the image suggests, and how it relates to the participant's life.
- Allies can deepen the inquiry and assist across scenes. They may deliver messages or perform other roles, while their helpful activity aggregates to the participant's Avatar.
- Offer optional guided relaxation and focused reflection through Kai or an Ally, using gentle imagery, breathing, and attention exercises before a participant reflects on sigils.
- Support spoken voice and text interaction. Frame this as voluntary relaxation, not as proof of a trance state or clinical treatment; include clear pause, stop, and exit controls.
- Use the room as a recurring portal or liminal space. On entry, offer a brief, selectable ritual using sensory cues such as sound, visual atmosphere, or incense-like effects; do not require it.

### Card reflection and reading

- A participant may record the card's supplied interpretation, then reflect on their immediate reaction to the image, colors, and components.
- If no reaction comes, use quiet observation, breathing, and nonjudgmental attention; note passing thoughts without elaborating on them, then return to the image and the participant's situation.
- Treat supplied meanings as guidance, not prediction. For readings for others, prioritize what the image reveals in the present context over fixed written interpretations.

### Map Shifting agency principle

- Present cards and divination as tools for self-inquiry and for noticing current conditions and forces, never as fixed predictions or directives.
- A probable future is not inevitable. A participant retains agency and can change conditions through informed choices and action.
- If a reading suggests a problem, treat it as a prompt to consider practical, proportionate preventive steps—not as a certainty.
- The purpose of the Map Shifting room is to increase agency: better understand situations and Forces, then choose actions that serve the participant, others, and the wider context.

### Card-layout form inside the Map Shifting room

- Present a second form alongside the spatial Scene: cards and sigils arranged in an intentional, sacred-design layout with visible energy flows among them.
- The layout is not constrained to a fixed number of positions. Kai may select its arrangement using discernment, with optional randomization.
- When a participant asks a question, Kai may use authorized contextual information to offer relevant clues. Never use information from other places without the applicable access, Consent, and privacy authorization.

### Map Shifting practice: thought, word, action

- Map Shifting is a pause, reflection, and new opportunity to choose.
- Its three deliberate choices are: a thought, a word spoken internally or aloud, and an action that brings the thought and word into the world.

### Map Shifting and alchemy — distinction in development

- Alchemy and depth psychology focus on reorienting oneself and one's psyche.
- Map Shifting also reorients the self, but treats inner and outer change as equally important: act effectively in the world rather than only adjusting oneself to fit it.
- Its practice aligns thought, word, and deed through continual reflection and resonance, aiming to transform the person, their circumstances, and the wider world.

### Proposed manifestation flow

- Creation progresses through: Notion → Element → Component → Overlay → Scene.
- A Notion is an idea recorded in personal notes.
- An Element is the notion instantiated as a database entity.
- Elements can be realized as Components, then Overlays, and eventually complete Scenes.
- This is a proposed system flow; define any canon-level distinctions after the terminology has been thought through further.

### Gifts and wounds

- Use Gifts and Wounds as the two sides of each coin or card, rather than Gifts and Challenges.
- A wound represents a trauma or unresolved challenge the participant is still addressing; a gift represents the capacity available to overcome or work with it.
- Treat wounds as participant-defined reflective language, not diagnosis or clinical assessment.

### Future canon and sigil update — deferred

- Do not update the canon yet.
- After further thought, create four sigils for health, wealth, wisdom, and love.
- Relate those four sigils to a practice sigil called Map Shifting, then update the canon and sigil library.
- Do not update the canon yet: later add economic concepts such as agency premium and additional governance concepts.
- Model every canonical term in the graph database with relationships to Actions, to support both probabilistic and deterministic reasoning.
- Add sigils for probabilistic and deterministic; lunar is proposed as probabilistic and solar as deterministic.
- Later add or refine Agency and Intelligence as explicit canon concepts. Agency is already a canonical Force, so clarify or extend it rather than duplicate it.

### Reusable Map Shifting capability

- When the card and note library is complete, package it as a reusable Map Shifting skill.
- Then develop the user's first plugin using that skill as a foundation.

### OpenAI-centered experience

- Design the experience around ChatGPT and OpenAI capabilities.
- Create sigils and icons that show which intelligence is handling or receiving a routed task.
- Build a single plugin that supports the experience well, including its intended relationship to ChatGPT voice.

### Isometric depth and priority

- In isometric scenes, use the existing five gravity layers to size and place each item farther back or closer up based on its priority in that scene.
- Simulate movement between depth or level layers through animation paths, moving items from front to back or back to front instead of requiring full 3D.
