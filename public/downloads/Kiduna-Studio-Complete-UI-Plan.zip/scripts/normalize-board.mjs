import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const sourcePath = process.argv[2];
const outputPath = process.argv[3];
if (!sourcePath || !outputPath) throw new Error("Usage: node scripts/normalize-board.mjs SOURCE OUTPUT");

const board = JSON.parse(await readFile(sourcePath, "utf8"));
const crosswalk = {
  7: ["/implementation#delivery", "Delivery sequence"],
  8: ["/implementation#delivery", "Delivery sequence"],
  9: ["/implementation#delivery", "Verification phase"],
  10: ["/implementation#delivery", "Review gate"],
  11: ["/implementation#delivery", "Staging verification"],
  12: ["/downloads", "Handoff archive"],
  13: ["/royals-and-rogues#design-system", "R&R Realm design boundary"],
  14: ["/ki-allies-actors#gameplay", "Ki during gameplay"],
  15: ["/actions-permissions#automations", "Automation contract"],
  16: ["/royals-and-rogues#matching", "Matching specification"],
  17: ["/ki-allies-actors#bring-ally", "Bring an Ally"],
  18: ["/royals-and-rogues#create-cell", "Cell builder"],
  19: ["/royals-and-rogues#create-alliance", "Alliance relationship"],
  20: ["/royals-and-rogues#invite", "Invite and onboarding"],
  21: ["/actions-permissions#resources", "Resources boundary"],
  22: ["/gameplay#table-economy", "Table economy"],
  23: ["/gameplay#tournaments", "Tournament extension"],
  24: ["/ki-allies-actors#voice", "Voice gathering"],
  25: ["/actions-permissions#constraints", "System constraints"],
  26: ["/standard-chrome", "Standard Studio chrome"],
  27: ["/gameplay#rules", "Rules in context"],
  28: ["/kinship-duna#mage-boundary", "Mage boundary"]
};
const lists = [...board.lists].sort((a, b) => a.pos - b.pos).map((list) => ({
  sourceId: list.id,
  name: list.name,
  closed: list.closed,
  position: list.pos,
  cards: board.cards
    .filter((card) => card.idList === list.id)
    .sort((a, b) => a.pos - b.pos)
    .map((card) => ({
      sourceId: card.id,
      id: card.idShort,
      title: card.name,
      description: card.desc,
      sourceUrl: card.url,
      closed: card.closed,
      position: card.pos,
      designHref: crosswalk[card.idShort]?.[0] ?? null,
      designAnswer: crosswalk[card.idShort]?.[1] ?? null,
      template: card.idShort >= 7 && card.idShort <= 12
    }))
}));

const normalized = {
  schemaVersion: "1.0.0",
  generatedAt: new Date().toISOString(),
  sourceFile: path.basename(sourcePath),
  sourceBoardId: board.id,
  boardName: board.name,
  sourceUrl: board.url,
  normalizationNote: "All source card text and workflow placement are preserved. designHref, designAnswer, and template are added by the Kiduna Studio UI Plan.",
  lists
};
await writeFile(outputPath, `${JSON.stringify(normalized, null, 2)}\n`, "utf8");
