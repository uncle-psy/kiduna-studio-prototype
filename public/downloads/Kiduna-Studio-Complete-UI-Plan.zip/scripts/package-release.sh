#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
OUT="$ROOT/public/downloads"

cd "$ROOT"
mkdir -p "$OUT/docs" "$OUT/data"
cp docs/*.md "$OUT/docs/"
cp data/*.json "$OUT/data/"

zip -q -r -FS "$OUT/Kiduna-Studio-UI-Specifications.zip" docs -x 'docs/reference/*'
zip -q -r -FS "$OUT/Kiduna-Studio-UI-Data-Contracts.zip" data
zip -q -r -FS "$OUT/Kiduna-Studio-Curated-Assets.zip" public/assets public/fonts public/og.png docs/ASSET-MANIFEST.md
zip -q -r -FS "$OUT/Kiduna-Studio-UI-Plan-Site-Source.zip" app public/assets public/fonts public/og.png package.json package-lock.json next.config.ts vite.config.ts tsconfig.json postcss.config.mjs eslint.config.mjs README.md scripts docs data .openai -x 'public/downloads/*'
zip -q -r -FS "$OUT/Kiduna-Studio-Complete-UI-Plan.zip" app public/assets public/fonts public/og.png package.json package-lock.json next.config.ts vite.config.ts tsconfig.json postcss.config.mjs eslint.config.mjs README.md scripts docs data evidence/rapid-board-source.json .openai -x 'public/downloads/*'

cd "$OUT"
shasum -a 256 Kiduna-Studio-*.zip > CHECKSUMS-SHA256.txt
