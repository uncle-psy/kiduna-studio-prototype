Kiduna Canon — Taxonomy
V0.36 — 2026-08-16 14:11 EDT
1. Categories
Kiduna is described through the following primary categories:
Domains — the four dimensions through which systems are designed and understood: Technology, Governance, Economics, and Culture.
Themes — fields of meaning that describe what a Realm concerns. Each Realm has one Primary Theme and one Primary Focus within that Theme, may have up to two Supporting Focuses, and can use open-ended Tags for additional specificity and discovery.
Purposes — the intended changes, conditions, value, contributions, or continuing functions that Realms and other work exist to serve.
Forces — the dynamic influences that shape behavior, movement, relationship, attention, value, authority, persistence, and change throughout Kiduna.
Realms — the contexts in which Sources, Avatars, intelligence, relationships, Resources, and Activities come together.
Elements — the fundamental entities that interact inside Kiduna.
Resources — usable holdings and instruments that carry utility, proof, access, benefit, opportunity, admission, or value.
Roles — Realm-scoped relationships and grants that define how an interaction is classified and how Sources participate, contribute, and exercise explicitly authorized privileges within a Realm.
Capacities — the foundational capabilities that shape what a Realm, Ally, or Actor knows, how it behaves, what it can access, what it can do, and how it remains coherent.
Patterns — reusable organizational templates that structure Activities and experiences for particular Purposes.
Field — the complete operating environment in which Sources work through Archetypes and participate through their Avatars with Allies and Actors.
Modes — the three operational conditions in which Allies, Actors, Scenes, and other work can exist within Field: Development, Rehearsal, and Live.
Scenes — situated compositions through which a Realm becomes present, experiential, and interactive.
Forms — the primary visual and interaction grammars through which Scenes are expressed.
Components — reusable visual and interactive building blocks used to construct Scenes.
Dimensions — the spatial systems through which Scenes and Components are represented, scaled, positioned, and related across 2D, 2.5D isometric, and 3D environments.
Designs — reusable visual systems that establish color, typography, materials, styling, and other presentation rules so Components and Scenes can remain coherent and compatible.
Surfaces — the device and experiential contexts through which Kiduna is experienced.

2. Domains
Domains are the four fundamental dimensions through which Kiduna systems are designed, understood, and developed. Every Realm can express all four: how it works, how it decides, how value flows, and how people relate.
Technology — capability – what can happen
The systems, intelligence, tools, infrastructure, protocols, data, and interfaces that determine what a Realm can do and how it operates.
Governance — authority – who decides
The structures and processes through which Sources establish rules, distribute Authority, make decisions, grant Permissions, resolve differences, and remain accountable.
Economics — value – how Resources circulate
The ways Resources are created, contributed, exchanged, allocated, compensated, held, and reinvested to sustain a Realm and its Purpose.
Culture — meaning – how we belong
The values, relationships, language, practices, stories, aesthetics, norms, and shared experiences that shape how participation feels and what a Realm becomes.

3. Themes — Fields of Meaning
Themes describe what a Realm concerns. They help Sources discover, understand, and connect related Realms across Kiduna.
Themes do not determine a Realm’s type, structure, authority, visibility, governance, or behavior.
Theme
A Theme is a broad field of meaning that describes the general area a Realm concerns.
The six canonical Themes are:
People & Care · Society & Justice · Culture & Play · Place & Planet · Work & Wealth · Knowledge & Frontier
Focus
A Focus is a canonical subject within a Theme that describes a Realm more specifically.
Each Realm has one Primary Focus and may have up to two Supporting Focuses when they add meaningful context.
Example:
Theme: Place & Planet
Primary Focus: Energy, Infrastructure & Mobility
Supporting Focus: Environment, Climate & Conservation
Tag
A Tag is an open-ended descriptive label that adds specificity beyond the canonical Theme and Focus structure.
Tags can describe particular places, communities, movements, industries, technologies, practices, identities, subjects, or other relevant characteristics.
Example:
Tags: solar, renewable energy, West Virginia, installation
Classification Rule
Each Realm may have:
One Primary Theme
One Primary Focus within that Theme
Up to two Supporting Focuses from any Theme
Additional Tags as needed for specificity and discovery
Canonical Themes and Focuses
People & Care
Health, Disability & Wellbeing
Mental Health, Recovery & Grief
Relationships, Family & Caregiving
Service Communities
Society & Justice
Rights, Justice & Solidarity
Civic Life, Democracy & Governance
Community, Mutual Aid & Participation
Safety, Preparedness & Response
Culture & Play
Arts & Creative Expression
Heritage, Language & Identity
Spirit, Meaning & Practice
Sports, Outdoors & Recreation
Games, Fandom & Social Entertainment
Media, Storytelling & Journalism
Place & Planet
Travel, Hospitality & Tourism
Environment, Climate & Conservation
Energy, Infrastructure & Mobility
Housing, Place & Belonging
Water, Agriculture & Food Systems
Animals & Animal Welfare
Work & Wealth
Work, Careers & Trades
Enterprise, Commerce & Markets
Money, Finance & Ownership
Knowledge & Frontier
Education, Learning & Skills
Science, Research & Discovery
Technology, AI & Digital Life

4. Purposes
Purposes describe the intended changes, conditions, value, contributions, or continuing functions that Realms and other work exist to serve.
Purpose — why the work exists
A Purpose is the intended change, condition, value, contribution, or continuing function that a Realm, Scene, Gathering, Activity, Ally, Actor, Action, Offer, or other work exists to serve.
A Theme describes what something concerns. A Purpose describes why it exists and what it is intended to accomplish or sustain.
Purposes orient governance, participation, Gatherings, Resources, Activities, Actions, evaluation, and stewardship. Evidence and outcomes may indicate how well a Purpose is being fulfilled, but neither replaces the Purpose itself.

5. Forces
Forces — the influences that shape behavior and movement
Forces are dynamic conditions acting on Sources, Avatars, Allies, Realms, Elements, Resources, relationships, and Activities. They shape what draws together or moves apart; what becomes visible or important; where attention, Authority, energy, Resources, and value flow; and how structures form, persist, compete, cooperate, weaken, renew, and change.
Forces allow Kiduna to behave less like a collection of pages, feeds, rankings, and notifications and more like a living world—one that reorganizes around who a Source is, how they are represented through an Avatar, what matters to them, where they belong, what they are doing, and what is happening around them.
Forces operate through both Kiduna’s semantic model and its interface physics. Forces interact, reinforce or oppose one another, and change in strength over time. The state of a Realm, Scene, relationship, Source, or Avatar therefore reflects not only what exists, but the Forces acting upon it.

Gravity — attraction and relevance
Gravity brings what matters closer.
It organizes Realms, people, relationships, knowledge, Activities, and opportunities around what is relevant to a Source now.
Gravity changes with context, interests, Roles, relationships, Commitments, Activities, and intent.
Its Purpose is not to capture attention, but to help Sources navigate a rich, deep world.
Gravity asks: What matters here, to this Source, now?

Affinity — likeness and belonging
Affinity reveals why Sources, Allies, and Actors are drawn together.
It can arise through shared interests, Realms, relationships, experiences, values, or complementary abilities and needs.
Affinity is contextual: two Sources may be close in one Realm or Purpose and distant in another.
Affinity asks: Why are we drawn together?

Agency — intention and initiative
Agency turns intention into action.
It arises when a Source, Ally, or collective chooses, creates, responds, organizes, commits Resources, or changes something.
Human authority originates with Sources; Allies and Actors act only within the authority and boundaries a Source has granted.
Agency asks: What are we choosing to bring into the world?

Trust — confidence and reliance
Trust makes coordination, exchange, delegation, and collaboration possible.
It grows through relationships, experience, competence, fulfilled Commitments, transparency, and verifiable Records.
Trust is contextual, not a universal score, and never replaces explicit Authority.
Trust asks: What can we reasonably rely on?

Authority — legitimate power
Authority determines who has the recognized right to decide or act.
It may arise through governance, Roles, delegation, ownership, stewardship, agreements, or system rules.
Authority is always bounded by scope and is distinct from both Influence and Agency.
Authority asks: Who has the legitimate power to make a decision or take an action here?

Influence — the ability to affect others
Influence changes how people understand, choose, or act without requiring formal Authority.
It can arise through relationships, reputation, expertise, communication, creativity, leadership, or example.
Influence can spread through networks, but it does not create permission or legitimacy.
Influence asks: How are we affecting how others understand, choose, or act?

Attention — directed awareness
Attention brings an entity or object into conscious focus.
Gravity may make many things relevant, but Attention determines what a Source is actually encountering at a particular moment in time.
Attention finds what matters without treating itself as something to capture or maximize.
Attention asks: What is being consciously encountered now?

Incentive — motivation through consequence
Incentive makes some choices more or less attractive through rewards, costs, access, recognition, responsibility, reputation, compensation, or other consequences.
Healthy Incentives are visible, governable, and aligned with purposes participants have consciously chosen.
Incentive asks: What makes one course of action more or less attractive?

Exchange — reciprocal flow
Exchange moves value between Sources, Allies, Actors, and Realms.
What moves may be money, knowledge, labor, Resources, Media, access, care, Commitments, opportunities, or other contributions.
Exchange creates the flows through which relationships and economies grow.
Exchange asks: What is moving between us, and what is being given or received?

Constraint — limitation and boundary
Constraint defines what cannot, should not, or must not occur in a particular context.
Constraints may come from rules, Permissions, scarcity, privacy, Commitments, Resources, technology, time, safety, Governance, or physical limits.
Some Constraints protect agency and coherence; others may be changed through Agency.
Constraint asks: What limits are appropriate here?

Tension — competing pressures
Tension appears when purposes, values, needs, Resources, relationships, or Forces pull in different directions.
It may signal conflict, but it can also create the conditions for negotiation, creativity, governance, and change.
Tension asks: What is pulling in different directions?

Momentum — accumulated movement
Momentum makes established Activity easier to continue.
Participation, creation, exchange, adoption, and repeated Actions can compound into practices, culture, and institutions.
Momentum can carry healthy or harmful patterns, so movement alone is not success.
Momentum asks: What is already moving, and what is it carrying?

Entropy — dispersion and decay
Entropy causes relationships, knowledge, Resources, structures, and Activities to weaken or lose coherence over time.
It is a natural condition of living systems and creates the need for maintenance, stewardship, pruning, archiving, and renewal.
Entropy asks: What is weakening, dispersing, or losing coherence?

Renewal — regeneration and restoration
Renewal restores vitality and capacity.
It can occur through care, repair, reconciliation, replenishment, new participation, succession, learning, restoration, or redesign.
Renewal does more than preserve a system; it can make it more resilient and generative.
Renewal asks: What is being restored or made capable of flourishing?

Forces Interact
Forces rarely act alone.
Gravity may bring something to Attention so that Affinity may reveal its significance. Trust may enable Exchange. Incentive may strengthen Agency. Agency may create Momentum. Authority and Constraint may shape together what can legitimately occur. Tension may provoke change as Entropy weakens systems, until Renewal restores them.
Forces describe changing relationships and conditions. They are never presented as fixed metrics or scores.

The Key Principle of Forces
Forces serve the Agency of the Source.
They help make relevance, relationships, movement, limits, and possibilities intelligible.
They are not designed to maximize engagement, manufacture urgency, manipulate behavior, or sell Attention.
No Force overrides privacy, Consent, Governance, Roles, or legitimate Authority.
Forces shape how the world unfolds. The Source remains free to sense, choose, act, and learn within it.

6. Realms
Realms are the living contexts inside Kiduna where Sources, represented through Avatars where appropriate, come together with Allies, Resources, relationships, knowledge, and Activities around something that matters.
Realms can stand alone as Surfaced Realms or be placed within other Realms as Nested Realms. Each Realm can develop its own identity, Capacities, membership, governance, Resources, and ways of acting.
Ecosystem — a connected whole
A broad network of Realms, Sources, Avatars, Resources, and relationships that participate in a shared environment or Purpose.
Organization — an enduring body
A member-governed entity formed to pursue a continuing Purpose, coordinate Activities, hold Resources, and act collectively.
Alliance — a partnership
A Realm formed when Sources, organizations, or other Realms join around a shared objective while retaining their individual identities.
Program — a sustained initiative
An organized body of related activities, Projects, and Resources directed toward an ongoing goal or outcome.
Project — a focused undertaking
A coordinated effort created to accomplish something specific, usually with defined objectives, participants, and a lifecycle.
Dyad — a shared connection
A Realm centered on an ongoing relationship between two and only two Sources, Allies, organizations, or other Realms, with its own context and history.
Community — a group that belongs together
A Realm of three or more Sources, Allies, Actors, organizations, or other Realms formed around shared identity, place, interest, experience, practice, or Purpose where relationships and participation can grow over time.
Guild — a community of practice
A Realm formed around a shared craft, profession, discipline, or capability where Sources and Allies develop mastery, exchange knowledge, establish practices, and contribute their skills together.
Institution — an established function
A Realm created to perform a durable social, civic, cultural, educational, economic, or other recognized function.
Council — a body for deliberation and stewardship
A Realm formed to bring designated Sources or Allies together to advise, coordinate, deliberate, make recommendations, or exercise defined authority over a shared domain.
Concept — an idea made inhabitable
A Realm organized around a subject, question, body of knowledge, Theme, or idea so Sources and Allies can explore and develop it together.
Cell — a small autonomous unit
A lightweight Realm for a small group, function, team, or Activity that can operate independently while remaining part of something larger.
Clan — a living chain of invitation and organization
A Realm formed by four generations of invitations originating from a single Source, providing a context for supporting, connecting, and organizing the people whose path into Kiduna descends from their own.

7. Elements
Elements are the fundamental entities that interact inside Kiduna.
Patterns arrange them, Forces influence how they relate and become perceptible, Surfaces present them, and Sources use Avatars and Allies to create, organize, govern, exchange, and act.
Sources — humans
The human beings at the center of Kiduna—the origin of identity, intention, consent, authority, responsibility, ownership, and agency.
Avatars — representation
The representation of a Source within a Realm, expressing their presence, identity, Roles, permissions, relationships, position, and Actions in forms suited to the Scene.
Realms — contexts
The spaces where things belong and happen: Ecosystems, Organizations, Alliances, Programs, Projects, Dyads, Communities, Guilds, Institutions, Councils, Concepts, Cells, Clans, and other nested or surfaced worlds.
Actors — operators
Specialized intelligent entities that perform defined roles and work within a Realm, such as Operators, Envoys, Sentinels, Researchers, Workers, and Supervisors.
Media — expression
The content Sources and Allies create, share, encounter, and experience: text, images, audio, video, documents, interfaces, and interactive works.
Allies — intelligence
Intelligent companions shaped by Sources or Realms to understand context, collaborate, advise, create, and act within defined permissions.
Ki — continuous Ecosystem intelligence
Ki is the persistent Ecosystem intelligence present with Sources throughout Field. Ki is distinct from a Source, Avatar, Ally, or Actor and does not independently create Consent, Permissions, or Authority.
Within every authorized context, Ki is always present in the background—listening to permitted interactions, processing context, learning from authorized experience, and remembering what it is allowed to retain.
Ki carries all authorized context across Archetypes, Scenes, Realms, Surfaces, Modes, and handoffs without bypassing privacy, Consent, Roles, Permissions, Authority, or system-level limits.
Ki can always hand off an active chat or other communication to an authorized Actor or Ally, carrying only the authorized context needed for continuity.
Ki’s continuous presence does not authorize ambient surveillance, recording, access, retention, disclosure, or learning beyond what the Source and applicable Realm have permitted.
Gatherings — bounded assemblies
A Gathering is an ad hoc, bounded collection of Sources, Allies, Actors, and/or Avatars brought together for a particular Purpose, Activity, event, session, or interaction.
A Gathering may occur within one Realm, include participants from connected Realms, and become present in one or more Scenes.
A Gathering may identify its initiator, participants, inclusion criteria, Purpose, associated Activities, beginning, duration, completion condition, and current state.
A Gathering does not automatically create a new Realm, membership body, shared identity, Governance structure, Authority, Role, Permission, Resource pool, or continuing relationship. Participants retain the identities, Roles, Permissions, and Authority they hold in the relevant Realms.
An Avatar included in a Gathering represents its Source and is not an additional human participant separate from that Source.
A Gathering is bounded rather than enduring. If a Gathering develops its own continuing identity, membership, Governance, Resources, or ongoing Purpose, it may be constituted as an appropriate Realm, such as a Cell, Community, Council, Project, or another Realm type.
A Realm provides an enduring context in which things belong and happen.
A Gathering identifies who or what has been assembled for a bounded Purpose or occasion.
An Activity organizes what participants do over time.
A Scene spatially organizes Components.
An Area logically organizes Components and Scenes.
Resources — usable holdings and instruments
Resources are things and instruments that can be held, used, shared, allocated, presented, verified, redeemed, consumed, transferred, earned, or stewarded.
Resources are both Elements and a specialized primary category with the canonical types defined in the Resources section.
Actions — bounded operations
An Action is a discrete, attributable operation performed by a Source, Ally, Actor, Automation, or authorized system.
An Action may observe, create, change, move, grant, publish, restrict, transfer, exchange, settle, or retire something.
Every Action occurs within a context and is subject to applicable Authority, Permissions, Consent, Roles, Constraints, and system-level limits.
An Action may stand alone or form part of an Activity.
Activities — organized participation over time
An Activity is a purposeful course of participation, interaction, or work that unfolds over time through one or more Actions.
An Activity may involve a Gathering or other combination of Sources, represented through Avatars where appropriate, together with Allies, Actors, Media, Resources, Offers, Permissions, Consents, Commitments, Records, and other Elements.
An Activity may occur within one Scene, move through several Scenes, or continue across an entire Realm. It may have participants, Roles, timing, state, outcomes, and associated Records.
A Gathering identifies who or what has been assembled.
An Activity organizes what they do over time.
A Scene spatially organizes Components.
An Area logically organizes Components and Scenes.
A Pattern may provide a reusable template for an Activity, but the Pattern is not the Activity itself.
Offers — proposals with terms
An Offer is a proposal to provide, exchange, grant, perform, or make available a Resource, benefit, opportunity, service, Action, access right, or other value under defined terms.
An Offer may identify an issuer, intended recipient or audience, subject, scope, terms, validity, expiration, transferability, required response, and current state.
An Offer does not by itself complete an Exchange or create a Commitment unless it is accepted or the governing rules explicitly establish that effect.
Acceptance of an Offer may create a Commitment, initiate an Activity, authorize an Action, form a Gathering, or cause Resources or other value to move.
Permissions — scoped grants
A Permission is an explicit, scoped grant allowing an identified Source, Ally, Actor, Automation, or system to perform specified Actions under defined conditions.
Permissions are created through legitimate Authority and Governance.
A Permission may define its grantor, recipient, Realm, subject, permitted Actions, limits, conditions, duration, delegation rights, revocation rules, and current state.
A Permission does not include the right to grant further Permissions unless that Authority is explicitly included.
Roles may carry Permissions, but a Role name alone does not create universal Permissions.
Participation in a Gathering does not itself grant a Permission.
Consents — voluntary authorizations
Consent is a Source’s informed, voluntary, specific, and revocable agreement to participate or to permit a defined use of their identity, information, Resources, representation, or Activity.
Consent identifies what is permitted, for what Purpose, by whom, under what conditions, and for how long.
Consent is distinct from Authority. A Source may consent to something without gaining Authority over a Realm, and Realm Authority cannot substitute for a Source’s required Consent.
Inclusion in a Gathering does not replace any Consent required for participation, representation, information use, recording, or other Actions.
Withdrawal of Consent affects future participation or use according to applicable Commitments, laws, safety requirements, and retention rules. It does not require the falsification or deletion of Records that must legitimately be preserved.
Commitments — acknowledged obligations
A Commitment is an acknowledged obligation to act, provide, maintain, deliver, refrain, compensate, or settle something for a Source, Realm, Purpose, or other identified beneficiary.
A Commitment may identify responsible parties, beneficiaries, Purpose, scope, terms, Resources, conditions, deadlines, dependencies, evidence, current state, and means of completion, transfer, amendment, or release.
An Offer may become a Commitment when accepted.
Participation in a Gathering may be associated with Commitments, but the Gathering itself does not create a Commitment unless its terms or governing rules explicitly do so.
Commitments do not create Authority beyond their stated and legitimately authorized scope.
Records — durable evidence
A Record is durable, attributable evidence of an Action, Activity, Gathering, event, decision, state, Permission, Consent, Commitment, Offer, Exchange, publication, or other significant occurrence.
A Record may identify its subject, creator, participants, time, provenance, version, access rules, retention requirements, and relationship to other Records.
Records are distinct from expressive Media. Media communicates or creates an experience; Records preserve evidence, continuity, accountability, or history. A particular object may serve as both Media and a Record when both functions apply.

8. Resources
Resources are things and instruments that can be held, used, shared, allocated, presented, verified, redeemed, consumed, transferred, earned, or stewarded.
They carry utility, proof, access, benefit, opportunity, admission, or value.
The eight canonical Resource types are:
Capacity — consumable utility value — spend
Badge — verified accomplishment — present or verify
Code — access or activation — use or enter
Coupon — conditional benefit — redeem
Invitation — opportunity to participate — accept or decline
Ticket — admission or reserved participation — present or use
Gift — freely given value — give or receive
Reward — earned value or benefit — earn or claim
Resource types can share properties such as issuer, giver, holder, recipient, subject, scope, transferability, validity, expiration, remaining uses, earning criteria, claim status, revocation, provenance, and current state where relevant.

9. Roles
Roles are Realm-scoped descriptions and grants that classify an interaction with a Realm and define how an identified Source participates, contributes, and—where explicitly authorized—acts within that Realm.
A Badge may inform eligibility for a Role, and other Resources may affect access or participation, but no Resource independently creates a Role or Authority unless the rules of the Realm explicitly provide that effect.
A Source holds the Role.
The Source’s Avatar expresses that Role within the Realm.
Roles do not belong independently to the Avatar, because the Avatar is a Realm representation of the Source rather than a separate holder of identity or authority.
Roles apply only to the Realm that grants them.
The Kiduna Ecosystem is the master Realm, but an Ecosystem Role is not a global Role.
A Source may have one Role in the Ecosystem and different Roles in other Realms.
Roles include Realm relationship Roles—Visitor, Guest, Member, Host, and Mage—and contribution Roles—Catalyst, Organizer, Steward, Creator, Builder, Luminary, and Sponsor.
A Source may hold multiple Roles in the same Realm when that Realm allows it.
Realm Relationship Roles
Visitor — unidentified interaction
A Visitor is a human interacting without an account or without authenticated identity in the interaction.
This can happen through social media, Telegram, email, or another external channel, where an Ally or Actor may be interacting with someone or something that Kiduna cannot identify or verify as a Source.
Visitor is a classification of the interaction, not proof of identity.
It conveys no account-based or Realm membership privileges.
Guest — admitted, not a Member
A Guest is a Source who has an account and is allowed into a Realm but has not been granted the privileges of a Member of that Realm.
A Guest has only the access and privileges that the Realm explicitly grants to Guests.
The Guest may be represented within the Realm through an Avatar.
Member — full Member privileges
A Member is a Source who has all the privileges assigned to Members by that Realm.
Because Member privileges are defined independently by each Realm, being a Member in one Realm does not make the Source a Member in any other Realm.
The Source’s Avatar expresses those Member privileges when the Source participates within the Realm.
Host — inviter
A Host is the Source credited with inviting another Source to participate in a Realm.
Host is a Realm-scoped relationship among the inviting Source, the invited Source, and the destination Realm.
A Host may provide invitation context—such as an introduction, reason for the invitation, relevant interests, Realms, people, or opportunities—to help Ki orient the invited Source, subject to privacy, Consent, and Realm rules.
Host context may inform what Ki presents or asks first, but it does not determine the invited Source’s identity, interests, choices, Roles, Permissions, or Authority.
The Host Role does not by itself grant Authority over the invited Source, access to their private Activity, responsibility for their conduct, or any privilege beyond those explicitly granted by the Realm.
A Source may hold Host alongside other Realm relationship or contribution Roles.
Mage — bounded Realm administration
A Mage is a Source granted the Realm-scoped equivalent of administrator, owner, or super-administrator authority.
A Mage may perform any administrative task that the Realm authorizes and that the system itself does not prohibit.
The Mage may exercise those capabilities through their Avatar, Allies, or other authorized interfaces.
Mages may assign and remove privileges from Sources within their Realm.
They may also take specifically authorized protective actions, such as changing offensive public Media to Personal so that only the Source who posted it can see it.
Mage authority never overrides system-level privacy, safety, security, or access limits.
A Mage cannot view personal information, use Mage status in one Realm to enter another private Realm, or exercise Mage powers outside the particular Realm in which the Role was granted.
Contribution Roles
Catalyst — Start a movement that matters.
Bring a project, program, or organization into being.
Catalysts clarify the initial Purpose, gather the founding participants, assemble the necessary Resources, and carry an emerging idea through formation and into motion.
Organizer — Build a community with purpose and power.
Form and sustain the relationships that make collective action possible.
Organizers bring people together around a shared Purpose, help them find their place, and nurture the participation and Activities that grow through the communities they support.
Steward — Sustain and renew the work.
A Steward is a Source with ongoing, bounded responsibility for caring for a particular Realm or for identified work belonging to that Realm over time.
Stewards help sustain the Realm’s Purpose, people, relationships, Resources, Commitments, Capacities, and Coherence. They respond to Entropy, enable Renewal, and coordinate appropriate maintenance, continuation, change, succession, transfer, or retirement.
Steward is a Realm-scoped Role. A Source may hold Steward alongside other Roles.
The Steward Role does not by itself grant Governance Authority, access to private information, or Permission to change, transfer, publish, restrict, or retire anything. Those rights must be explicitly granted through the Realm’s Governance and Permissions.
Creator — Bring the work to life.
Turn knowledge, imagination, and lived experience into living capabilities.
Creators add Wisdom, shape an organization’s Presence, design its stories and experiences, train its Allies, and create the instructions, Media, methods, and processes through which its Purpose becomes real.
Builder — Expand the realm of possibility.
Create the apps, agents, tools, automations, systems, and infrastructure that expand what an organization can do.
Builders make valuable work easier to perform, repeat, improve, share, and extend into entirely new forms of individual and collective agency.
Luminary — Give the work depth and direction.
Contribute a defining work, body of wisdom, creative practice, or deep intellectual grounding around which a collective can form and grow.
Luminaries may be supported through project budgets, royalties, repayment of development costs, or allocations established by the organization.
Sponsor — Support participation and possibility.
Provide agreed financial, computational, promotional, or other support to a Realm, Source, Ally, Actor, or other eligible recipient.
A Source holding the Sponsor Role may pay for compute, provide Resources such as Rewards or Coupons, fund Activities, or offer other agreed value.
Sponsors may make sponsorship agreements with Realms that include promoting the Sponsor’s technology, Offers, or other approved Media within that Realm.
Every sponsorship is governed by the receiving Realm’s rules and the terms of the agreement.
The Sponsor Role does not by itself create control over the recipient, access to private information, endorsement, or permission to promote anything outside the agreed scope.
Realm-Defined Rights
Every Role receives its actual rights within the Realm that grants it; the Role name alone does not create a universal permission set.
For example, a Source granted the Creator Role receives the rights the Realm’s Catalyst or Catalysts have defined for Creator in that Realm, subject to the Realm’s current governance and immutable system limits.
The Source may exercise those rights through their Avatar or other authorized interfaces.
Authority is established through Governance.
Permissions determine which Actions may be taken.
Roles identify the Realm-scoped relationship, contribution, or entrusted Authority to which those Permissions apply.
Membership Authority
Any Realm rule, guardrail, setting, or policy—including Role definitions and privilege assignments—may be changed by the membership through whatever process the membership has established.
Membership governance cannot override system-level limits, including the privacy and access boundaries that constrain Mages.
Role Principle
Roles are local to Realms, not global to Kiduna.
The Ecosystem is the master Realm, yet each other Realm defines and grants its own Roles independently.
A Source may:
hold more than one Role in the same Realm when that Realm allows it;
hold different Roles across different Realms;
be represented by different Avatars across different Realms or Scenes while remaining the same Source;
be a Member of the Ecosystem and a Guest in one Realm, a Creator in another, and a Mage in another;
contribute without holding a formal office;
move between Roles as participation changes;
be recognized and compensated for attributable contribution associated with one or more Roles.
Roles create a shared language for Realm-specific participation, contribution, and bounded authority without creating a global hierarchy.

10. Capacities
Capacities are the six foundational capabilities that shape what a Realm, Ally, or Actor knows, how it behaves, what it can access, what it can do, and how it remains coherent.
Wisdom — inform
The knowledge and memory available to the Realm or Ally, typically held in a vector database and expanded through relevant information.
Presence — instruct
The system prompt and governing instructions that shape how the Realm or Ally presents itself, responds, reasons, and behaves in context.
Connections — empower
Integrations with third-party systems, software, services, data sources, communication tools, financial rails, and other external capabilities.
Automations — enable
Deep agents, triggers, workflows, and sequences that allow Activities to begin, continue, and complete automatically.
Abilities — impart
Reusable skills, procedures, and markdown-based instructions that teach a Realm or Ally how to perform particular kinds of work.
Coherence — align
Sentinels, principles, constraints, guardrails, and shared values that help keep behavior, decisions, and Activities aligned with the Purpose and standards of the Realm.

11. Patterns
Patterns are reusable organizational templates inside Kiduna.
Each Pattern defines reusable structures, behaviors, relationships, tools, and arrangements for organizing Activities and experiences around particular Purposes.
Embodiment — an implemented Pattern
When a Pattern is instantiated in Field, that implementation is an Embodiment of the Pattern.
An Embodiment may have its own Scene, be clearly delineated within a Scene, or span multiple Scenes. It may combine Components—including Overlays—with Capacities, Elements, Resources, interfaces, and other structures needed to fulfill its Purpose.
A Pattern may have many Embodiments. Each Embodiment follows the Pattern while retaining its own context, identity, contents, state, access, and implementation.
Archetypes — the nine ways Sources work within Field
The nine Archetypes are the core Ecosystem Embodiments of the nine core Patterns. They provide the primary ways Sources navigate, gather, create, build, enjoy, act, govern, settle, and store within Field.
Each Archetype is clearly delineated by its Purpose. It may have its own Scene, be present within a Scene, or span multiple Scenes.
A core Pattern may have many other Embodiments throughout Kiduna, but only its core Ecosystem Embodiment is an Archetype.
The Pattern and its Archetype share a name. Viewport refers to the reusable Pattern in the abstract and to the Viewport Archetype when referring to the core Embodiment Sources can enter and use.
Viewport — navigate
See the larger landscape: Realms, Sources, Avatars, relationships, Activities, and pathways between them.
Commons — gather
Gather Sources, represented through Avatars, together with Allies; form relationships; coordinate participation; and organize around shared Purpose.
Studio — create
Studio is the Archetype and process for creation. Sources and Allies use it to shape ideas, Media, experiences, Realms, Scenes, Allies, and other things that can be created together.
Factory — build
Produce working systems: Actors, Automations, applications, integrations, tools, and infrastructure.
Garden — enjoy
Experience, explore, play, learn, gather, and interact with what Sources and Allies have created, including other Archetypes, Allies, and Actors.
New Sources always enter through the Garden Archetype as presented within the scope of the Realm they entered. The Garden reveals only the context and access authorized by that Realm and by the Source’s Roles, Permissions, Consent, and relationships.
World — act
Operate in a living environment where Sources, acting through their Avatars and working with authorized Allies, can perform work, coordinate Activities, and make things happen beyond Kiduna in the wider world.
Forum — govern
Deliberate, propose, decide, establish policy, delegate Authority, and govern shared Resources and Actions.
Exchange — settle
Make Offers, transact, exchange value, spend Capacity, redeem Coupons, purchase or transfer Tickets, give Gifts, distribute or claim Rewards, compensate contributions, and settle economic Activity.
Vault — store
Hold and manage assets; Resources including Capacity, Badges, Codes, Coupons, Invitations, Tickets, Gifts, and Rewards; Records; credentials; balances; Media; and other things entrusted to a Source or Realm.

12. Field
Field is Kiduna’s complete operating environment.
Sources, represented through their Avatars, work within Field through the nine Archetypes and alongside authorized Allies and Actors.
Realms, Archetypes, Scenes, Activities, creation, validation, publication, participation, governance, exchange, and action all occur within Field.
Field Principle
Nothing moves into or out of Field merely because its Mode or lifecycle state changes.
Development, Rehearsal, Live, Draft, Published, Superseded, Retirement, and Retired describe operational conditions, availability, and lifecycle within Field.

13. Modes
Modes are the three operational conditions in which Allies, Actors, Realms, Scenes, Archetypes, Automations, applications, integrations, and other work can exist within Field: Development, Rehearsal, and Live.
A Mode applies to a particular implementation or version of the work rather than replacing its underlying identity.
The same underlying work may have a current Live Published version while a new version is in Development or Rehearsal.
Development — create and change
Development is the Mode in which work is being created, designed, assembled, configured, changed, tested, or prepared within Studio before formal validation.
Sources and authorized Allies may develop Realms, Gatherings, Activities, Actors, Avatars and their representations, Scenes, Purposes, Patterns, Elements, Resources, Capacities, Forms, Components, Dimensions, Designs, applications, integrations, tools, and other work.
Rehearsal — validate a Draft
Rehearsal is the Mode in which a Draft is reviewed, tested, and experienced as it is intended to work before authorization and publication.
A Source may participate through their Avatar exactly as they would in the Live Published version, subject to the specific Permissions and access established for the Rehearsal.
Rehearse — validation Activity within Studio
Rehearse is the Activity performed within Studio during Rehearsal. Authorized Sources, represented through their Avatars where appropriate and assisted by authorized Allies, review, test, and experience a Draft before publication.
Rehearse does not create a separate place, Scene, environment, or Mode.
Live — operate a Published version
Live is the Mode in which the current Published version is available and operating for its intended participants according to its Realm, Roles, Permissions, Consent, and access rules.
Sources participate through their Avatars where the Realm or Scene uses representation. Sources, Allies, and Actors can navigate, gather, create, build, enjoy, act, govern, settle, and store according to their Roles and Permissions.
Publishing lifecycle
Development → designate as Draft → Rehearsal → authorize and publish → Live / Published.
Publishing changes availability and Mode; it does not create different underlying work.
Draft and Published are lifecycle states of the same underlying work. A current Live Published version may remain available while a new version is in Development or Rehearsal.
Draft — awaiting validation
A Draft is a version designated from Development for validation in Rehearsal.
A Draft is not yet the current version available to its intended participants and does not replace the current Published version.
Published — authorized and available
Published is the authorized lifecycle state of a version made Live for its intended participants according to its Realm, Roles, Permissions, Consent, and access rules.
Publishing changes availability and Mode; it does not create a different Scene, Realm, Ally, Actor, or other underlying work.
Superseded — replaced by a newer publication
A Superseded version is a previously Published version that has been replaced by a newer Published version.
It is no longer the current Live version but retains its identity, history, provenance, and required Records.
Retirement — authorized withdrawal
Retirement is the authorized process of withdrawing Published work from active availability.
Retirement includes responsibility for affected participants, Gatherings, Activities, Commitments, Resources, Permissions, access, Invitations, Tickets, Connections, Portals, communication, and required Records.
Retirement does not erase the identity or history of the work.
Retired — intentionally unavailable
Retired is the lifecycle state of work that has been intentionally withdrawn from active availability through legitimate Authority.
Retired work is no longer Live or available as an active Published experience, but its identity, history, provenance, and required Records remain.
Retired is distinct from Superseded. Superseded work has been replaced by a newer Published version. Retired work has been intentionally withdrawn, whether or not a replacement exists.

14. Scenes
Scenes are situated compositions through which a Realm becomes present, experiential, and interactive.
A Scene is a spatial organization of Components within a particular context.
A Scene brings together Purposes, Elements, Resources, Capacities, Patterns, Archetypes, Forms, Components, Dimensions, Designs, and the effects of Forces within a particular context.
Sources experience and participate in Scenes.
Where representation is appropriate, they become present within a Scene through their Avatars.
A Scene operates within Field and may be in Development, Rehearsal, or Live according to the Mode and lifecycle state of its particular version.
The same underlying Scene may have a current Live Published version while a new version is in Development or Rehearsal.
An Archetype may have its own Scene, be clearly delineated within a Scene, or span multiple Scenes. A Scene may participate in more than one clearly delineated Archetype where their Purposes remain legible.
Because Forces are Source-relative and context-sensitive, the same underlying Scene may organize itself differently around different Sources without becoming a different Scene.
The Avatar provides the Scene-level representation through which those Source-relative conditions can become visible and interactive.
Gravity may alter prominence, proximity, pathways, or emphasis around a Source and their Avatar.
Affinity may make meaningful relationships among Sources, Avatars, and Allies visible.
Attention may be expressed through the Avatar’s orientation, selection, movement, or interaction and may bring particular Elements or Activities into the foreground.
Exchange may appear as flows among participants or Realms.
Authority may reveal where decisions and Permissions reside.
Tension may reveal competing pressures.
Momentum may make active trajectories perceptible.
Entropy and Renewal may reveal where living systems are weakening or renewing.
A Realm may contain one Scene or many Scenes, each designed for a different Purpose, Activity, Gathering, audience, or experience.
Area — logical organization
An Area is a logical organization of Components.
An Area can be part of a Scene or can hold multiple Scenes.
An Area can hold Components from various Scenes.
Membership in an Area does not remove a Component from its Scene or change its spatial position or relationships within that Scene.
Areas allow Components and Scenes to be organized by Purpose, function, responsibility, workflow, audience, subject, state, or another logical relationship.

15. Forms — Types of Scenes
Forms define the primary visual and interaction grammar of a Scene.
Literal Spatial
Rooms, terrain, Objects, routes, Avatars, and embodied memory.
Realistic
Photographic, scanned, or photorealistic representations of real places and environments, with Objects and Entities that can be explored, animated, and made interactive.
Symbolic
Emblems, talismans, connectors, Avatars expressed as symbols, and stable meaning.
Impressionistic
Fields, light, texture, rhythm, atmosphere, and sparse anchors.
Diagrammatic
Constellations, flows, dependencies, relationships, systems, governance, and Avatars represented as nodes or other diagrammatic forms.
Hybrid
Two or more Forms may coexist when one clearly leads and the combination serves the Purpose of the Scene.

16. Components
Components are the reusable visual and interactive building blocks used to construct Scenes inside Kiduna.
They define the world, the things that inhabit it, the Activities occurring within it, and the interfaces through which Sources interact with it.
An Avatar is an Element, not merely a Component.
Its visible or interactive representation may, however, be rendered through one or more Components according to the Scene’s Form, Dimension, Design, and Surface.
Backgrounds — environment
The world behind and around the grid: landscapes, skies, distant architecture, atmosphere, and other environmental context.
Tiles — ground
Traversable floor and terrain surfaces that establish where movement and placement can occur.
Walls — boundaries
Vertical partitions and barriers that define rooms, edges, enclosures, and divisions within a Scene.
Objects — forms
Static placed elements such as furniture, structures, equipment, vegetation, decorations, and other non-animated things in the world.
Entities — presences
Animated, addressable beings or active elements that can move, respond, communicate, or be interacted with.
Avatars, Allies, and Actors may each be visually expressed through Entity Components without becoming the same kind of Element.
Effects — activity
Transient visual or environmental phenomena such as light, weather, particles, energy, smoke, animation, and other momentary changes.
Portals — transitions
Entrances and spatial connections that move a Source and their Avatar between locations, Scenes, Realms, or other contexts.
Panels — embedded interfaces
Interface surfaces that exist inside the world—signs, consoles, displays, kiosks, dashboards, control surfaces, and floating interfaces.
Overlays — explanatory interface layers
Interface layers placed visually over a Scene to explain what is present and why it matters, reveal context, and provide interactive buttons, labels, guidance, controls, and other points of interaction.
The Scene beneath an Overlay is often composed from raster imagery, while Overlays are typically composed from vector graphics and type so they remain crisp, legible, and responsive.
Chrome — application interface
Interface surfaces that belong to the surrounding Kiduna experience rather than the world itself—toolbars, inspectors, inventories, navigation, controls, and status displays.
Key distinction: Panels are embedded in the Scene. Overlays are placed over the Scene to explain or interact with what is there. Chrome sits outside the Scene as part of the surrounding Kiduna application.

17. Dimensions
Dimensions define the spatial representation, scale, coordinates, and relationships through which Scenes and Components exist.
They make it possible for the same underlying Element, Component, or Scene to be expressed through different visual environments without becoming a completely different thing.
An Avatar, Object, Entity, Realm, Portal, interface, or other Component representation can therefore possess a consistent identity and relational scale even when represented differently across Desktop, Mobile, CTV, AR, VR, MR, XR, or future Surfaces.
Dimensions separate what something is from how it is spatially presented.
2D — planar
A flat coordinate space organized through horizontal and vertical position.
Used for interfaces, diagrams, maps, cards, documents, dashboards, symbolic compositions, Avatars, and other primarily planar experiences.
Components can be represented as vectors, raster images, text, interface objects, diagrams, or other two-dimensional forms.
2.5D — isometric
A spatially suggestive coordinate system that represents depth while remaining fundamentally composed and rendered as a two-dimensional Scene.
Used for isometric environments, layered worlds, rooms, landscapes, maps, organizational spaces, Avatars, and other Scenes where spatial relationships matter without requiring a complete three-dimensional simulation.
2.5D allows Components and Avatar representations to preserve depth, orientation, layering, adjacency, and relative scale while retaining the clarity, efficiency, and composability of two-dimensional assets.
3D — spatial
A three-dimensional coordinate space in which Components possess position, scale, orientation, volume, depth, and spatial relationships.
Used for immersive worlds, spatial interfaces, simulations, augmented environments, virtual environments, embodied Avatars, and other Scenes in which Sources and intelligent entities can move through or around space.
Scale
Dimensions also establish a shared system of scale.
Every spatial Component can describe its size and relationship to other Components using canonical measurements or proportional relationships rather than relying solely on the dimensions of a particular image, model, or asset.
This allows Components created by different Sources, systems, tools, and applications to work together predictably.
A door should relate sensibly to an Avatar.
An Avatar should relate sensibly to a building.
A building should relate sensibly to a landscape.
The representation may change.
The relationship does not.
Spatial Relationships
Dimensional metadata can describe relationships including:
position;
size;
scale;
orientation;
depth;
elevation;
bounds;
anchors;
attachment points;
adjacency;
containment;
traversal;
collision;
visibility;
distance;
perspective.
Not every Component needs every property.
The dimensional system provides a common language when those properties matter.
Cross-Dimensional Representation
A Component or Avatar may possess representations for one or more Dimensions.
For example, the same Avatar might have:
a 2D portrait or sigil;
a 2D presentation asset;
a 2.5D isometric representation;
a 3D embodied representation.
These are representations of the same Avatar and therefore ultimately of the same Source rather than unrelated identities.
Likewise, the same Object might have:
a 2D icon;
a 2D presentation asset;
a 2.5D isometric asset;
a 3D model.
These are representations of the same Component rather than unrelated assets.
Where an exact representation does not exist, Kiduna may adapt, project, simplify, generate, or substitute an appropriate representation while preserving the Component or Avatar’s identity and important relationships.
A Scene itself can also have more than one dimensional representation.
A Scene created as an isometric environment, for example, might be presented as a simplified map on Mobile and as an immersive spatial environment in VR.
Dimensional Principle
Identity persists across representation.
The Source remains the same human.
The Avatar remains the Source’s Realm representation.
Its appearance may change across Dimensions without changing who it represents.
Dimensions allow Scenes, Avatars, and Components to move between flat, isometric, and spatial experiences while preserving their underlying Realm, Elements, relationships, Actions, and meaning.
This makes Kiduna extensible to new interfaces and technologies without requiring the underlying system to be rebuilt around each new display medium.

18. Designs
Designs are reusable visual systems that determine how Scenes and Components look and feel.
A Design can establish the colors, typography, materials, shapes, spacing, iconography, lighting, motion, and other presentation rules through which a Realm or Scene expresses its identity.
Designs make visual expression portable, composable, and compatible rather than embedding appearance independently into every Component.
Avatar representations may also inherit or adapt to Design rules while preserving the identity of the Source they represent.
Colors
Palettes, semantic colors, states, contrast relationships, gradients, environmental colors, and other rules governing the use of color.
Typography
Font families, weights, scales, hierarchy, spacing, treatments, and other rules governing written language.
Shape
Corner systems, geometry, outlines, borders, depth, framing, proportions, and recurring visual forms.
Materials
Surface qualities such as glass, enamel, metal, paper, stone, fabric, wood, light, ceramics, plastics, natural materials, and other physical or digital treatments.
Iconography
Sigils, symbols, icons, pictograms, marks, and the visual rules that allow them to work coherently together.
Totems — animal-form sigils
Totems are canonical sigils whose central figure is an animal, insect, or other living creature used as a symbolic guide, presence, or bearer of meaning.
Totems are classified by the creature represented, not by the subject matter the sigil concerns.
Firefly, Bee, Hummingbird, Rabbit, Bear, Owl, Fox, Turtle, Stag, and Octopus are Totems.
The Animals & Animal Welfare Focus remains a Theme classification for Realms concerned with animals, pets, welfare, or rescue; it is not itself a Totem and does not cause every sigil associated with that Focus to become one.
Spacing
Grids, rhythm, margins, padding, density, scale, alignment, and proportional relationships.
Motion
Transitions, easing, movement character, duration, timing, responsiveness, and other animation conventions.
Lighting
Illumination, shadow, reflection, glow, atmosphere, environmental light, and other treatments relevant to spatial or rendered experiences.
Interface Treatment
The visual and interactive rules governing Panels, Overlays, Chrome, controls, states, selections, notifications, feedback, and other interface behaviors.
Asset Treatment
Rules governing how Backgrounds, Tiles, Walls, Objects, Entities, Effects, Portals, Panels, Overlays, Avatars, and other Components or representations appear together.
Design Systems
A Design may range from a small collection of presentation choices to a complete design system.
A full Design System can contain:
design tokens;
palettes;
typography;
icons and sigils;
reusable Components;
spacing and sizing systems;
shape systems;
materials;
interaction states;
accessibility requirements;
motion rules;
lighting rules;
dimensional variants;
implementation guidance.
Compatibility
Designs provide a compatibility layer between Components created by different Sources.
A Component does not have to be permanently bound to the exact colors, typography, material, or styling with which it was originally created.
Where appropriate, Components can expose designable properties that allow the active Design to determine their presentation.
Avatar representations may similarly adapt to the active Design where appropriate, while preserving characteristics necessary to maintain the continuity, legibility, and identity of the Source they represent.
This allows something created in one Realm to be brought into another Realm and adapted without losing either its identity or the coherence of its new environment.
Inheritance
Designs can be inherited.
A Realm may establish a Design.
A Nested Realm may inherit the Design of its parent.
A Scene may inherit the Design of its Realm.
A Scene may extend or override parts of that Design.
Individual Components may inherit the Scene Design while retaining specific characteristics that should not be overridden.
Avatar representations may inherit the Scene Design while retaining Source-specific or Realm-specific identity characteristics.
This creates a cascading visual system in which consistency is the default while meaningful difference remains possible.
Design + Dimension
Design and Dimension are independent but complementary.
Dimension determines spatial representation.
Design determines visual expression.
The same Design may therefore be expressed in 2D, 2.5D, and 3D.
Likewise, the same spatial Scene can be expressed through different Designs without changing the underlying Elements, relationships, geometry, or Actions.
An Avatar may similarly change visual treatment or dimensional representation while continuing to represent the same Source.
This separation allows Scenes to adapt simultaneously to different brands, communities, cultures, accessibility needs, devices, and spatial environments.
Design Principle
Structure should survive style, and identity should survive adaptation.
Designs allow Kiduna to support an expanding ecosystem of Sources, creators, Realms, Components, interfaces, Avatars, and Surfaces without forcing everything to look identical or allowing everything to become visually incompatible.

19. Surfaces
Surfaces are the device and experiential contexts through which Sources experience Kiduna.
The same Realms, Sources, Avatars, Allies, Actors, identity, relationships, Gatherings, Activities, Patterns, Scenes, Resources, Forces, and Actions persist across Surfaces, but each Surface presents them in the form best suited to its capabilities, context, and mode of interaction.
A Surface does not define a separate Kiduna.
It provides another way of encountering the same underlying world.
A Source remains the same human across every Surface.
The Source’s Avatar may be represented differently according to the needs and capabilities of each Surface.
Desktop — create and coordinate
The full working Surface.
Best for sustained attention, complex creation in Studio, building, organizing, governance, rehearsing Drafts, working across Development, Rehearsal, and Live Modes, and managing multiple parts of a Realm at once.
Desktop can support 2D, 2.5D, and 3D Scenes depending on their Purpose.
A Source’s Avatar may appear as a portrait, node, isometric figure, spatial entity, or other Scene-appropriate representation.
Mobile — participate and act
The always-with-you Surface.
Best for conversation, notifications, approvals, identity, quick Actions, capturing information, navigating nearby context, and participating wherever you are.
Mobile may also serve as a controller, camera, sensor, identity device, or companion to other Surfaces.
A Source may control an Avatar appearing on another Surface from Mobile.
CTV — gather and experience
The shared-room Surface.
Best for communal experiences, presentations, live Activities, games, Media, Gatherings, shared experiences, and interacting with Kiduna together on a large screen.
Avatars may allow multiple Sources to become individually present within a shared CTV experience while controlling their participation through companion devices.
Chrome Extension — connect the web
The contextual Surface.
Brings Kiduna into the existing web so Sources can recognize Realms, Resources, relationships, and relevant context; work with what is on the page; and act without leaving the current environment.
Avatar representation may be minimal or symbolic where an embodied representation would add no value.
AR — augment
The augmented-reality Surface.
Places Kiduna Elements, information, interfaces, Allies, Actions, and Scenes into a Source’s view of the physical world.
AR allows digital context to become spatially associated with people, places, Objects, environments, and Activities without replacing the surrounding physical environment.
A Realm might appear around a physical location.
An Object might reveal information or Actions when encountered.
An Ally might become spatially present beside a Source.
A Scene might overlay a workplace, neighborhood, museum, landscape, meeting, or event.
Because the Source’s physical body may already be perceptible in AR, an Avatar may appear as an identity layer, visual augmentation, spatial indicator, symbolic representation, or other contextual extension rather than as a duplicate body.
VR — immerse
The virtual-reality Surface.
Places Sources inside fully spatial Kiduna Scenes where environments, Objects, Entities, Avatars, Allies, interfaces, relationships, and Activities can be experienced through embodied presence.
In VR, the Avatar becomes the Source’s primary embodied representation within the virtual Realm.
The Source controls its movement, orientation, gestures, interactions, and Actions.
VR is particularly suited to immersive Gardens, collaborative spaces, simulations, learning environments, gatherings, creation, exploration, storytelling, and spatial forms of work.
MR — integrate
The mixed-reality Surface.
Allows physical and digital space to operate as one interactive environment.
Kiduna Scenes and Components can understand and respond to the geometry, Objects, surfaces, movement, and other characteristics of a Source’s physical environment, allowing digital Elements to participate meaningfully within it.
A physical table might become part of a Forum.
A wall could become a shared Panel.
A digital Object could remain anchored to a physical location.
Sources in the same room could interact with shared Elements that occupy the space between them.
Avatars may combine physical presence with digital identity, Roles, state, Effects, or other Realm-specific representation.
XR — extend
The extended-reality Surface.
XR provides the generalized spatial-computing context spanning AR, VR, MR, and emerging forms that combine or move between them.
It allows Kiduna to support devices and experiences whose relationship between physical and digital space may change dynamically rather than fitting permanently into a single category.
XR also provides a category for future spatial interfaces that cannot yet be cleanly described as AR, VR, or MR.
An Avatar may correspondingly move between symbolic, augmented, and embodied representation while remaining bound to the same Source.
Surface Adaptation
Scenes do not need to look or behave identically across Surfaces.
A Realm might appear as:
a diagram or constellation in 2D;
an isometric environment on Desktop;
a compact contextual interface on Mobile;
a shared experience on CTV;
spatial information, Avatars, and Objects overlaid on the physical world in AR;
an inhabitable environment with embodied Avatars in VR;
an environment integrating physical Sources and digital Avatar representations in MR;
an experience that moves fluidly between physical and digital presence in XR.
These are different presentations of the same underlying Realm and Scene.
The Source remains the same human throughout.
The Avatar provides the contextual representation of that human within the Realm.
Forms, Components, Dimensions, Designs, and Forces provide the translation and organizational layers that make this possible.
Surface Principle
The world persists. The presentation adapts.
The Source persists. The Avatar represents.
A Source should be able to move between Realms, Archetypes, Scenes, Activities, Modes, lifecycle states, and Surfaces without losing human identity, context, relationships, Resources, history, authority, or agency.
An Avatar may change form as the context changes, but the human it represents does not.
