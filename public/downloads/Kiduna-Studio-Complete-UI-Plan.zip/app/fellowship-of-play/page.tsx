import { PlanPage } from "../ui/PlanPage"; export default function Page(){return <PlanPage page="fellowship"/>}
