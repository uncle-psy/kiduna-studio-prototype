import type { Metadata } from "next";
import { PlanPage } from "./ui/PlanPage";

export const metadata: Metadata = {
  title: "Kiduna Studio — Complete UI Plan",
  description: "A navigable product specification for the nested Kiduna Studio experience.",
};

export default function Home() {
  return <PlanPage page="overview" />;
}
