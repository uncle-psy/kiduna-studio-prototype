import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Kiduna Studio — Complete UI Plan", template: "%s · Kiduna Studio UI Plan" },
  description: "The complete, interactive Studio UI plan for Kinship Duna, Fellowship of Play, and Royals & Rogues.",
  openGraph: {
    title: "Kiduna Studio — Complete UI Plan",
    description: "A build-ready, navigable product specification for three nested Realms.",
    images: ["/og.png"],
  },
  icons: { icon: "/assets/kiduna/mark.svg" },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
