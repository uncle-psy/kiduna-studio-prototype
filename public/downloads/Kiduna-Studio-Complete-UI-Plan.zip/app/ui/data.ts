export type PageKey = "overview" | "chrome" | "kinship" | "fellowship" | "royals" | "gameplay" | "ki" | "actions" | "components" | "implementation" | "board" | "downloads";

export const nav: Array<{ key: PageKey; n: string; label: string; href: string }> = [
  { key: "overview", n: "01", label: "System overview", href: "/" },
  { key: "chrome", n: "02", label: "Studio chrome", href: "/standard-chrome" },
  { key: "kinship", n: "03", label: "Kinship Duna", href: "/kinship-duna" },
  { key: "fellowship", n: "04", label: "Fellowship of Play", href: "/fellowship-of-play" },
  { key: "royals", n: "05", label: "Royals & Rogues", href: "/royals-and-rogues" },
  { key: "gameplay", n: "06", label: "Gameplay", href: "/gameplay" },
  { key: "ki", n: "07", label: "Ki, Allies & Actors", href: "/ki-allies-actors" },
  { key: "actions", n: "08", label: "Actions & permissions", href: "/actions-permissions" },
  { key: "components", n: "09", label: "Components & states", href: "/components-states" },
  { key: "implementation", n: "10", label: "Implementation plan", href: "/implementation" },
  { key: "board", n: "11", label: "Rapid Board", href: "/rapid-board" },
  { key: "downloads", n: "12", label: "Developer downloads", href: "/downloads" },
];

export const pageMeta: Record<PageKey, { eyebrow: string; title: string; intro: string }> = {
  overview: { eyebrow: "Complete UI plan · Canon V0.36", title: "A world nested around what matters most.", intro: "One navigable specification for Kinship Duna, the Fellowship of Play inside it, and Royals & Rogues inside the Fellowship—designed as a clear system, not a constellation of disconnected screens." },
  chrome: { eyebrow: "Standard Studio shell", title: "The Field stays continuous while context changes.", intro: "The same four-part frame holds every Realm: inspect at upper left, act in the Field, work with Ki at right, and take contextual actions from the tray." },
  kinship: { eyebrow: "Realm 01 · Duna", title: "Kinship Duna", intro: "A member-led Duna with inspectable purpose, participants, relationships, resources, Wisdom, Presence, Connections, and a bounded Mage." },
  fellowship: { eyebrow: "Realm 02 · Fellowship", title: "Fellowship of Play", intro: "A focused Fellowship nested inside Kinship Duna. Its layout stays legible even as a small number of child Realms appear." },
  royals: { eyebrow: "Realm 03 · Experience", title: "Royals & Rogues", intro: "The Realm keeps Studio structure at its boundary, then adopts its own quiet-enamel game language only where play begins." },
  gameplay: { eyebrow: "Playable state sequence", title: "From invitation to the last hand.", intro: "Fifteen explicit states show how players arrive, gather, match, play, speak, recover, and leave—without losing their place in the Field." },
  ki: { eyebrow: "Relational intelligence", title: "Ki stays beside the work.", intro: "Ki is a conversational Ally, not a navigation menu. Actors may join a Realm, but only within declared purpose, consent, access, and privacy boundaries." },
  actions: { eyebrow: "Behavior contract", title: "Every action has an owner and a boundary.", intro: "The matrix makes permissions, confirmation, visibility, outcomes, auditability, and failure recovery explicit before engineering begins." },
  components: { eyebrow: "Reusable interface grammar", title: "A small set of components carries the system.", intro: "Components express context, relationship, activity, permission, transition, focus, and consequence—with complete states and accessibility behavior." },
  implementation: { eyebrow: "Build sequence", title: "Ship the spine before the decoration.", intro: "A framework-neutral implementation sequence that protects route integrity, data contracts, permissions, progressive disclosure, and state continuity." },
  board: { eyebrow: "Rapid Board crosswalk", title: "Every story points to its designed answer.", intro: "The working board is reconstructed here with its original workflow state, full story intent, and direct links to the exact view or anchor that resolves it." },
  downloads: { eyebrow: "Developer handoff", title: "Everything needed to build from here.", intro: "Download the full site source, framework-neutral specifications, normalized data contracts, curated visual assets, or the complete package." },
};

export const gameStates = [
  ["01", "Invitation received", "A personal invitation names host, Realm, purpose, trust context, and what joining reveals."],
  ["02", "Realm preview", "The guest sees the Realm’s purpose and public Presence before committing."],
  ["03", "Handshake", "Kinship Code and Private Handshake establish the first relationship."],
  ["04", "Great Hall", "Arrival preserves orientation: Realm, Scene, people, open Cells, Ki, and next actions."],
  ["05", "Match preferences", "Choose pace, familiarity, time, voice, accessibility, and social preference."],
  ["06", "Match proposed", "Ki or an Actor explains why the Cell fits and what information was used."],
  ["07", "Cell gathering", "Players assemble; roles, seats, voice, rules, and readiness are visible."],
  ["08", "Table setup", "Antes, 52-card deck plus Joker, Power deck, and house choices are confirmed."],
  ["09", "Deal", "Each player receives three private hole cards; first hand also receives three Powers."],
  ["10", "Setup powers", "Players ready eligible Powers and discard to the five-card hand limit."],
  ["11", "Round", "Betting, actions, table state, and voice occur without hiding whose turn it is."],
  ["12", "Counter", "A bounded response window makes timing, eligible cards, and expiration clear."],
  ["13", "Showdown", "Showdown Powers resolve, cards reveal, hand ranks compare, and the pot is awarded."],
  ["14", "After the hand", "The table may continue, pause, invite, adjust voice, or leave without penalty."],
  ["15", "Realm return", "The Source returns to the Great Hall with relationships and continuity intact."],
] as const;

export const actionRows = [
  ["Create a child Realm", "Member with Realm permission", "Realm", "Draft summary + explicit confirmation", "Participants named by access", "New Realm + lineage event", "Retryable draft; no partial Realm", "High"],
  ["Invite a person", "Member", "Realm / relationship", "Recipient, trust, context, use policy", "Inviter + authorized stewards", "Code + private perspective record", "Expire, revoke, or issue again", "High"],
  ["Bring an Ally", "Source or permitted host", "Gathering", "Owner, purpose, access, duration", "All gathering participants", "Ally Presence + audit event", "Remove immediately", "High"],
  ["Add an Actor", "Realm steward", "Realm", "Capabilities, data, actions, owner", "Realm participants", "Actor grant + expiry", "Deny with missing permission", "Critical"],
  ["Start voice", "Participant", "Gathering", "Consent + recording state", "Current gathering", "Voice session", "Fall back to text", "High"],
  ["Create a Cell", "Fellowship member", "Royals & Rogues", "Purpose, seats, access, matching", "Eligible participants", "Cell + seat policy", "Draft retained", "Medium"],
  ["Create an Alliance", "Authorized Realm steward", "Two or more Realms", "Purpose, terms, visibility, review", "Named Realms", "Alliance relationship", "Proposal remains pending", "Critical"],
  ["Move resources", "Wallet holder", "Kiduna Web", "Amount, asset, destination, fees", "Wallet holder", "Signed transfer + receipt", "No silent retry", "Critical"],
] as const;

export type BoardCard = [number, string, string, string, string];
export const boardColumns: Array<{ name: string; tone: string; cards: BoardCard[] }> = [
  { name: "Backlog", tone: "backlog", cards: [] },
  { name: "Ready", tone: "ready", cards: [
    [13, "Change out the Art", "Replace placeholder visuals with the Royals & Rogues design system inside the Realm boundary.", "/royals-and-rogues#design-system", "R&R Realm design boundary"],
    [14, "Integrate Ki", "Add Ki as the persistent Ally across lobby, gathering, match, play, and return.", "/ki-allies-actors#gameplay", "Ki during gameplay"],
    [15, "Integrate automations", "Specify visible, permissioned automation triggers, outcomes, pause, and failure behavior.", "/actions-permissions#automations", "Automation contract"],
    [16, "Set up matching system", "Match by availability, pace, experience, access needs, and declared preference.", "/royals-and-rogues#matching", "Matching specification"],
    [17, "Character creation — Create Ally", "Let a Source bring an Ally with explicit identity, purpose, scope, and access.", "/ki-allies-actors#bring-ally", "Bring an Ally"],
    [18, "Create Cell", "Create a bounded play gathering with purpose, seats, voice, access, and matching.", "/royals-and-rogues#create-cell", "Cell builder"],
    [19, "Create Alliance", "Connect Realms through named purpose, terms, visibility, review, and revocation.", "/royals-and-rogues#create-alliance", "Alliance relationship"],
    [21, "Buying KIDUNA — Tokenomics", "Keep resource balance inspectable and send any money-moving action to Kiduna Web.", "/actions-permissions#resources", "Resources boundary"],
    [22, "Acquiring free Chips", "Define table Chips as game state, distinct from Compute and money.", "/gameplay#table-economy", "Table economy"],
    [23, "Create tournaments and leaderboard", "Specify future competitive modes with scoring, privacy, appeals, and opt-out.", "/gameplay#tournaments", "Tournament extension"],
    [24, "Voice chat through Gemini Voice API", "Design consent, state, identity, recording, failure, and provider boundaries before integration.", "/ki-allies-actors#voice", "Voice gathering"],
    [25, "Coherence/alignment", "Apply canonical vocabulary, Realm boundaries, permission rules, and event lineage everywhere.", "/actions-permissions#constraints", "System constraints"],
    [28, "Mage in the world", "Place the Mage in Kinship Duna with explicit shared capability and hard privacy limits.", "/kinship-duna#mage-boundary", "Mage boundary"],
  ] },
  { name: "In Progress", tone: "progress", cards: [
    [7, "Implement the highest-priority feature", "Work on the most important feature slice first. Keep notes on the approach, assumptions, and what still needs testing.", "/implementation#delivery", "Delivery sequence"],
    [8, "Fix the most visible bug", "Use this for the issue that most affects users or slows down the team. Preserve reproduction, cause, and verification notes.", "/implementation#delivery", "Delivery sequence"],
    [9, "Update tests and clean up edge cases", "Add or adjust tests while the code is still fresh and record every path that must be checked.", "/implementation#delivery", "Verification phase"],
    [20, "Invite & Onboarding", "Create a conversational invitation, Kinship Code, Private Handshake, preview, and arrival flow.", "/royals-and-rogues#invite", "Invite & onboarding"],
    [26, "Desktop version", "Use the continuous standard Studio shell and nested Realm context for desktop.", "/standard-chrome", "Standard Studio chrome"],
  ] },
  { name: "Review & Done", tone: "done", cards: [
    [10, "Review pull request", "Board workflow template: design, behavior, accessibility, and contract review.", "/implementation#delivery", "Review gate"],
    [11, "Verify in staging", "Board workflow template: exercise the Source journey and failure cases in a real environment.", "/implementation#delivery", "Staging verification"],
    [12, "Ship and archive", "Board workflow template: release, preserve evidence, record changes, and close the loop.", "/downloads", "Handoff archive"],
  ] },
  { name: "Resources", tone: "resource", cards: [[27, "Royals & Rogues Rules (Formerly Medieval Poker)", "The original board links the rules and source folder as working resources. The plan translates them into progressive gameplay states.", "/gameplay#rules", "Rules in context"]] },
];
