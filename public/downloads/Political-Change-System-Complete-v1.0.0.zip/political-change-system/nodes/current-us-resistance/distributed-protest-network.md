# Distributed Protest Network

> Distributed Protest Network is mapped as the democratic alarm: it uses distributed protest and local organization to oppose perceived democratic backsliding and policy harms.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:current-us-resistance:distributed-protest-network` |
| Family | Current U.S. Resistance Movements |
| Domain | Movements |
| Kind | movement |
| Archetypal function | The Democratic Alarm |
| Epistemic status | synthesis; supported |

## Concrete anchor

Distributed Protest Network belongs to the **Current U.S. Resistance Movements** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Distributed Protest Network uses distributed protest and local organization to oppose perceived democratic backsliding and policy harms, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Distributed Protest Network, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Democratic Alarm.** Distributed Protest Network is mapped as the democratic alarm: it uses distributed protest and local organization to oppose perceived democratic backsliding and policy harms.

## Gift

converts alarm into visible, nonviolent participation and durable local capacity; through Distributed Protest Network, that capacity becomes available for deliberate use.

## Wound / Shadow

confuses turnout with leverage or treats a broad coalition as ideologically uniform; Distributed Protest Network can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Distributed Protest Network to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Democratic Alarm enters through Distributed Protest Network. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Distributed Protest Network becomes the unit of analysis rather than background?

## Game function

**role.** Reveal one hidden dependency connected to Distributed Protest Network; another player names a countermove. Initiative 5.

## Relationships

- **enables — Democracy Vigil:** Democracy Vigil enables Distributed Protest Network by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — First-Wave Feminism:** First-Wave Feminism legitimizes Distributed Protest Network by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **distributes costs to — Preference Falsification:** Distributed Protest Network distributes costs to Preference Falsification by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **mobilizes — Bureaucratic Drift:** Bureaucratic Drift mobilizes Distributed Protest Network by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Distributed Protest Network from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Distributed Protest Network is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Distributed Protest Network: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [No Kings](https://www.nokings.org/) — No Kings coalition, 2026. Movement self-description, principles, events, and participation claims; crowd estimates require independent corroboration.
- [About Indivisible](https://indivisible.org/about) — Indivisible, 2026. Organization self-description and distributed organizing model.
- [Know Your Rights: Protesters' Rights](https://www.aclu.org/know-your-rights/protesters-rights) — American Civil Liberties Union, ongoing. U.S. protest-rights overview; local law and facts vary.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
