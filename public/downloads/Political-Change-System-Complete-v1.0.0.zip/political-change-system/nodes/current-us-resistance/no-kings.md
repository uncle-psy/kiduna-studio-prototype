# No Kings

> a distributed U.S. protest coalition opposing what organizers describe as authoritarian concentration under the second Trump administration

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:current-us-resistance:no-kings` |
| Family | Current U.S. Resistance Movements |
| Domain | Movements |
| Kind | movement |
| Archetypal function | The Democratic Alarm |
| Epistemic status | participant_statement; supported |

## Concrete anchor

No Kings belongs to the **Current U.S. Resistance Movements** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

National days of action connect local nonviolent events through a common constitutional-democracy frame; organizer participation estimates remain claims requiring independent corroboration.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use No Kings, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Democratic Alarm.** a distributed U.S. protest coalition opposing what organizers describe as authoritarian concentration under the second Trump administration

## Gift

A broad, legible ritual of democratic alarm and mass participation.

## Wound / Shadow

One-day scale can be mistaken for durable leverage or ideological unity.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use No Kings to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Democratic Alarm enters through No Kings. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What organization remains when the crowd goes home?

## Game function

**role.** Reveal one hidden dependency connected to No Kings; another player names a countermove. Initiative 5.

## Relationships

- **counteracts — Indivisible:** No Kings counteracts Indivisible by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **counteracts — Audit:** Audit counteracts No Kings by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **institutionalizes — Political Purge:** No Kings institutionalizes Political Purge by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read No Kings from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if No Kings is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: participant_statement, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
Sentinel factors: current movement; contested political characterization; crowd estimates. These are descriptive handoff annotations, not a verdict and not a mutation of Engine Output.

## Visual direction

A text-free enamel expression of No Kings: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [No Kings](https://www.nokings.org/) — No Kings coalition, 2026. Movement self-description, principles, events, and participation claims; crowd estimates require independent corroboration.
- [About Indivisible](https://indivisible.org/about) — Indivisible, 2026. Organization self-description and distributed organizing model.
- [Know Your Rights: Protesters' Rights](https://www.aclu.org/know-your-rights/protesters-rights) — American Civil Liberties Union, ongoing. U.S. protest-rights overview; local law and facts vary.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
