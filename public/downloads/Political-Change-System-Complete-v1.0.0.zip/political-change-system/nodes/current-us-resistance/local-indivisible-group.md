# Local Indivisible Group

> Local Indivisible Group is mapped as the democratic alarm: it uses distributed protest and local organization to oppose perceived democratic backsliding and policy harms.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:current-us-resistance:local-indivisible-group` |
| Family | Current U.S. Resistance Movements |
| Domain | Movements |
| Kind | movement |
| Archetypal function | The Democratic Alarm |
| Epistemic status | synthesis; supported |

## Concrete anchor

Local Indivisible Group belongs to the **Current U.S. Resistance Movements** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Local Indivisible Group uses distributed protest and local organization to oppose perceived democratic backsliding and policy harms, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Local Indivisible Group, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Democratic Alarm.** Local Indivisible Group is mapped as the democratic alarm: it uses distributed protest and local organization to oppose perceived democratic backsliding and policy harms.

## Gift

converts alarm into visible, nonviolent participation and durable local capacity; through Local Indivisible Group, that capacity becomes available for deliberate use.

## Wound / Shadow

confuses turnout with leverage or treats a broad coalition as ideologically uniform; Local Indivisible Group can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Local Indivisible Group to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Democratic Alarm enters through Local Indivisible Group. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Local Indivisible Group becomes the unit of analysis rather than background?

## Game function

**leverage.** Reveal one hidden dependency connected to Local Indivisible Group; another player names a countermove. Initiative 1.

## Relationships

- **depends on — Rapid Response Protest:** Rapid Response Protest depends on Local Indivisible Group by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **institutionalizes — Constitutional Defense:** Local Indivisible Group institutionalizes Constitutional Defense by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **translates into — Deterrence:** Local Indivisible Group translates into Deterrence by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **distributes costs to — Countermobilization:** Countermobilization distributes costs to Local Indivisible Group by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Local Indivisible Group from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Local Indivisible Group is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Local Indivisible Group: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [No Kings](https://www.nokings.org/) — No Kings coalition, 2026. Movement self-description, principles, events, and participation claims; crowd estimates require independent corroboration.
- [About Indivisible](https://indivisible.org/about) — Indivisible, 2026. Organization self-description and distributed organizing model.
- [Know Your Rights: Protesters' Rights](https://www.aclu.org/know-your-rights/protesters-rights) — American Civil Liberties Union, ongoing. U.S. protest-rights overview; local law and facts vary.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
