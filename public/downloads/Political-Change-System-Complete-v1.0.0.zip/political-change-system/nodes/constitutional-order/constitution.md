# Constitution

> power agreeing in advance to limits on itself

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:constitutional-order:constitution` |
| Family | Constitutional Order |
| Domain | Governance |
| Kind | institution |
| Archetypal function | The Frame |
| Epistemic status | synthesis; supported |

## Concrete anchor

Constitution belongs to the **Constitutional Order** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

A constitution hardens political memory into superior rules for offices, rights, conflict, and legitimate self-change.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Constitution, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Frame.** power agreeing in advance to limits on itself

## Gift

Constraint on arbitrary power and continuity across governments.

## Wound / Shadow

The dead hand of the past restricting democratic adaptation.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Constitution to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Frame enters through Constitution. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** Which rules should be difficult to change, by whom, and why?

## Game function

**leverage.** Reveal one hidden dependency connected to Constitution; another player names a countermove. Initiative 1.

## Relationships

- **constrains — Constitutionalism:** Constitution constrains Constitutionalism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **mobilizes — Hacktivism:** Hacktivism mobilizes Constitution by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **amplifies — Burnout:** Constitution amplifies Burnout by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Constitution from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Constitution is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Constitution: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Constitution of the United States](https://www.archives.gov/founding-docs/constitution-transcript) — National Archives, 1787. Federal structure, separated powers, amendment, elections, and rights.
- [The Federalist Papers](https://guides.loc.gov/federalist-papers/full-text) — Library of Congress, 1787–1788. Arguments for the U.S. constitutional design; read as advocacy, not neutral description.
- [Universal Declaration of Human Rights](https://www.un.org/en/about-us/universal-declaration-of-human-rights) — United Nations, 1948. International human-rights framework.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
