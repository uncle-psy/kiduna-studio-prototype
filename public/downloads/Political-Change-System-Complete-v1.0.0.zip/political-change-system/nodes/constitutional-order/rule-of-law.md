# Rule of Law

> Rule of Law is mapped as the frame: it places durable rules above ordinary political competition.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:constitutional-order:rule-of-law` |
| Family | Constitutional Order |
| Domain | Governance |
| Kind | institution |
| Archetypal function | The Frame |
| Epistemic status | synthesis; supported |

## Concrete anchor

Rule of Law belongs to the **Constitutional Order** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Rule of Law places durable rules above ordinary political competition, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Rule of Law, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Frame.** Rule of Law is mapped as the frame: it places durable rules above ordinary political competition.

## Gift

constrains arbitrary power and enables legitimate self-change; through Rule of Law, that capacity becomes available for deliberate use.

## Wound / Shadow

lets inherited rules entrench exclusion or block adaptation; Rule of Law can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Rule of Law to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Frame enters through Rule of Law. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Rule of Law becomes the unit of analysis rather than background?

## Game function

**resource.** Reveal one hidden dependency connected to Rule of Law; another player names a countermove. Initiative 3.

## Relationships

- **legitimizes — Constitutionalism:** Constitutionalism legitimizes Rule of Law by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **mobilizes — Separation of Powers:** Rule of Law mobilizes Separation of Powers by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — W.E.B. Du Bois:** Rule of Law legitimizes W.E.B. Du Bois by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **counteracts — Drain the Swamp:** Drain the Swamp counteracts Rule of Law by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Rule of Law from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Rule of Law is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Rule of Law: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Constitution of the United States](https://www.archives.gov/founding-docs/constitution-transcript) — National Archives, 1787. Federal structure, separated powers, amendment, elections, and rights.
- [The Federalist Papers](https://guides.loc.gov/federalist-papers/full-text) — Library of Congress, 1787–1788. Arguments for the U.S. constitutional design; read as advocacy, not neutral description.
- [Universal Declaration of Human Rights](https://www.un.org/en/about-us/universal-declaration-of-human-rights) — United Nations, 1948. International human-rights framework.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
