# Border

> Border is mapped as the threshold: it decides who may enter, remain, belong, work, receive protection, or be removed.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:immigration-border:border` |
| Family | Immigration, Borders & Sanctuary |
| Domain | State Power |
| Kind | field |
| Archetypal function | The Threshold |
| Epistemic status | synthesis; supported |

## Concrete anchor

Border belongs to the **Immigration, Borders & Sanctuary** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Border decides who may enter, remain, belong, work, receive protection, or be removed, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Border, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Threshold.** Border is mapped as the threshold: it decides who may enter, remain, belong, work, receive protection, or be removed.

## Gift

can provide order, refuge, status, and public safety; through Border, that capacity becomes available for deliberate use.

## Wound / Shadow

creates deportability, family separation, racialized suspicion, and rights without secure membership; Border can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Border to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Threshold enters through Border. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Border becomes the unit of analysis rather than background?

## Game function

**event.** Reveal one hidden dependency connected to Border; another player names a countermove. Initiative 4.

## Relationships

- **counteracts — Citizenship:** Border counteracts Citizenship by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — Reparations:** Reparations legitimizes Border by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **constrains — American Revolution:** Border constrains American Revolution by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Border from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Border is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Border: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [ICE Mission](https://www.ice.gov/mission) — U.S. Immigration and Customs Enforcement, 2025. Agency self-description of enforcement and investigative missions.
- [Documented ICE Actions](https://www.aclu.org/news/immigrants-rights/we-documented-1200-actions-by-ice-heres-what-we-found) — American Civil Liberties Union, 2026. Civil-liberties organization findings and allegations; methodology and adversarial posture remain explicit.
- [Universal Declaration of Human Rights](https://www.un.org/en/about-us/universal-declaration-of-human-rights) — United Nations, 1948. International human-rights framework.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
