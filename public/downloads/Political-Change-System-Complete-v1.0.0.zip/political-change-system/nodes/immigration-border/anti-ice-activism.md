# Anti-ICE Activism

> a broad field opposing ICE practices, detention, deportation, agency expansion, or the institution itself

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:immigration-border:anti-ice-activism` |
| Family | Immigration, Borders & Sanctuary |
| Domain | State Power |
| Kind | field |
| Archetypal function | The Threshold |
| Epistemic status | synthesis; supported |

## Concrete anchor

Anti-ICE Activism belongs to the **Immigration, Borders & Sanctuary** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Tactics include protest, legal observation, rapid-response alerts, accompaniment, sanctuary, litigation, labor action, and abolition advocacy; participants do not share one program or risk tolerance.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Anti-ICE Activism, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Threshold.** a broad field opposing ICE practices, detention, deportation, agency expansion, or the institution itself

## Gift

Makes enforcement visible and builds immediate defense capacity.

## Wound / Shadow

Abolition slogans can conceal different replacement proposals; confrontation can expose migrants and supporters to risk.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Anti-ICE Activism to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Threshold enters through Anti-ICE Activism. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** Is the target a practice, contract, budget, detention site, legal authority, or the agency's existence?

## Game function

**role.** Reveal one hidden dependency connected to Anti-ICE Activism; another player names a countermove. Initiative 5.

## Relationships

- **translates into — Abolish ICE:** Abolish ICE translates into Anti-ICE Activism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **enables — Know-Your-Rights Network:** Anti-ICE Activism enables Know-Your-Rights Network by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — Blockade:** Anti-ICE Activism legitimizes Blockade by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **constrains — Online Citizens' Assembly:** Online Citizens' Assembly constrains Anti-ICE Activism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Anti-ICE Activism from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Anti-ICE Activism is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
Sentinel factors: current movement; legal risk; vulnerable people. These are descriptive handoff annotations, not a verdict and not a mutation of Engine Output.

## Visual direction

A text-free enamel expression of Anti-ICE Activism: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [ICE Mission](https://www.ice.gov/mission) — U.S. Immigration and Customs Enforcement, 2025. Agency self-description of enforcement and investigative missions.
- [Documented ICE Actions](https://www.aclu.org/news/immigrants-rights/we-documented-1200-actions-by-ice-heres-what-we-found) — American Civil Liberties Union, 2026. Civil-liberties organization findings and allegations; methodology and adversarial posture remain explicit.
- [Universal Declaration of Human Rights](https://www.un.org/en/about-us/universal-declaration-of-human-rights) — United Nations, 1948. International human-rights framework.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
