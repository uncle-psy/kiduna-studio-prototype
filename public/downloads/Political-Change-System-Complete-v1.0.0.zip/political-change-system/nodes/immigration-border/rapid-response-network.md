# Rapid Response Network

> Rapid Response Network is mapped as the threshold: it decides who may enter, remain, belong, work, receive protection, or be removed.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:immigration-border:rapid-response-network` |
| Family | Immigration, Borders & Sanctuary |
| Domain | State Power |
| Kind | field |
| Archetypal function | The Threshold |
| Epistemic status | synthesis; supported |

## Concrete anchor

Rapid Response Network belongs to the **Immigration, Borders & Sanctuary** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Rapid Response Network decides who may enter, remain, belong, work, receive protection, or be removed, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Rapid Response Network, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Threshold.** Rapid Response Network is mapped as the threshold: it decides who may enter, remain, belong, work, receive protection, or be removed.

## Gift

can provide order, refuge, status, and public safety; through Rapid Response Network, that capacity becomes available for deliberate use.

## Wound / Shadow

creates deportability, family separation, racialized suspicion, and rights without secure membership; Rapid Response Network can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Rapid Response Network to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Threshold enters through Rapid Response Network. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Rapid Response Network becomes the unit of analysis rather than background?

## Game function

**role.** Reveal one hidden dependency connected to Rapid Response Network; another player names a countermove. Initiative 5.

## Relationships

- **constrains — Know-Your-Rights Network:** Know-Your-Rights Network constrains Rapid Response Network by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — Deportation Defense:** Rapid Response Network legitimizes Deportation Defense by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **translates into — Public Media:** Public Media translates into Rapid Response Network by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **institutionalizes — Agent Provocateur:** Rapid Response Network institutionalizes Agent Provocateur by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Rapid Response Network from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Rapid Response Network is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Rapid Response Network: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [ICE Mission](https://www.ice.gov/mission) — U.S. Immigration and Customs Enforcement, 2025. Agency self-description of enforcement and investigative missions.
- [Documented ICE Actions](https://www.aclu.org/news/immigrants-rights/we-documented-1200-actions-by-ice-heres-what-we-found) — American Civil Liberties Union, 2026. Civil-liberties organization findings and allegations; methodology and adversarial posture remain explicit.
- [Universal Declaration of Human Rights](https://www.un.org/en/about-us/universal-declaration-of-human-rights) — United Nations, 1948. International human-rights framework.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
