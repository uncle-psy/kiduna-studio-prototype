# ICE

> a U.S. federal agency responsible for immigration enforcement and transnational criminal investigations

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:immigration-border:ice` |
| Family | Immigration, Borders & Sanctuary |
| Domain | State Power |
| Kind | field |
| Archetypal function | The Threshold |
| Epistemic status | synthesis; established |

## Concrete anchor

ICE belongs to the **Immigration, Borders & Sanctuary** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

ICE divides work chiefly between Enforcement and Removal Operations and Homeland Security Investigations; agency mission claims, legal authority, implementation, and civil-liberties critiques must be kept distinct.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use ICE, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Threshold.** a U.S. federal agency responsible for immigration enforcement and transnational criminal investigations

## Gift

Enforcement capacity against immigration violations and transnational crime under enacted law.

## Wound / Shadow

Detention, deportability, opaque discretion, rights violations, and political use of enforcement power.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use ICE to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Threshold enters through ICE. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** Which mission, authority, discretion, and accountability mechanism is active here?

## Game function

**constraint.** Reveal one hidden dependency connected to ICE; another player names a countermove. Initiative 2.

## Relationships

- **distributes costs to — Immigration Court:** Immigration Court distributes costs to ICE by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Customs and Border Protection:** ICE depends on Customs and Border Protection by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **institutionalizes — The Fixer:** The Fixer institutionalizes ICE by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **counteracts — Frederick Douglass:** ICE counteracts Frederick Douglass by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read ICE from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if ICE is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: sourced_claim, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
Sentinel factors: current agency; contested enforcement; human rights. These are descriptive handoff annotations, not a verdict and not a mutation of Engine Output.

## Visual direction

A text-free enamel expression of ICE: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [ICE Mission](https://www.ice.gov/mission) — U.S. Immigration and Customs Enforcement, 2025. Agency self-description of enforcement and investigative missions.
- [Documented ICE Actions](https://www.aclu.org/news/immigrants-rights/we-documented-1200-actions-by-ice-heres-what-we-found) — American Civil Liberties Union, 2026. Civil-liberties organization findings and allegations; methodology and adversarial posture remain explicit.
- [Universal Declaration of Human Rights](https://www.un.org/en/about-us/universal-declaration-of-human-rights) — United Nations, 1948. International human-rights framework.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
