# Synthetic Media

> Synthetic Media is mapped as the network: it routes attention, identity, organization, surveillance, and participation through computational systems.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:digital-politics:synthetic-media` |
| Family | Digital Politics & Platforms |
| Domain | Technology |
| Kind | technology |
| Archetypal function | The Network |
| Epistemic status | synthesis; supported |

## Concrete anchor

Synthetic Media belongs to the **Digital Politics & Platforms** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Synthetic Media routes attention, identity, organization, surveillance, and participation through computational systems, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Synthetic Media, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Network.** Synthetic Media is mapped as the network: it routes attention, identity, organization, surveillance, and participation through computational systems.

## Gift

lowers coordination costs and multiplies voices; through Synthetic Media, that capacity becomes available for deliberate use.

## Wound / Shadow

centralizes opaque governance, accelerates falsehood, and makes people measurable targets; Synthetic Media can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Synthetic Media to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Network enters through Synthetic Media. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Synthetic Media becomes the unit of analysis rather than background?

## Game function

**constraint.** Reveal one hidden dependency connected to Synthetic Media; another player names a countermove. Initiative 2.

## Relationships

- **amplifies — Deepfake:** Deepfake amplifies Synthetic Media by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **translates into — Content Moderation:** Synthetic Media translates into Content Moderation by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **counteracts — Democratic Transition:** Synthetic Media counteracts Democratic Transition by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **institutionalizes — United Front:** United Front institutionalizes Synthetic Media by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Synthetic Media from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Synthetic Media is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Synthetic Media: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Guidance for Regulation of Digital Platforms](https://unesdoc.unesco.org/ark:/48223/pf0000387339) — UNESCO, 2023. Platform governance, expression, information integrity, and rights.
- [Examining Extremism: QAnon](https://www.csis.org/blogs/examining-extremism/examining-extremism-qanon) — Center for Strategic and International Studies, 2021. Origins, networked conspiracy claims, mobilization, and a violent subset.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
