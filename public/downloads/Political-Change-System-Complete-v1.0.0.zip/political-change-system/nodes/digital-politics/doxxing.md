# Doxxing

> Doxxing is mapped as the network: it routes attention, identity, organization, surveillance, and participation through computational systems.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:digital-politics:doxxing` |
| Family | Digital Politics & Platforms |
| Domain | Technology |
| Kind | technology |
| Archetypal function | The Network |
| Epistemic status | synthesis; supported |

## Concrete anchor

Doxxing belongs to the **Digital Politics & Platforms** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Doxxing routes attention, identity, organization, surveillance, and participation through computational systems, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Doxxing, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Network.** Doxxing is mapped as the network: it routes attention, identity, organization, surveillance, and participation through computational systems.

## Gift

lowers coordination costs and multiplies voices; through Doxxing, that capacity becomes available for deliberate use.

## Wound / Shadow

centralizes opaque governance, accelerates falsehood, and makes people measurable targets; Doxxing can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Doxxing to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Network enters through Doxxing. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Doxxing becomes the unit of analysis rather than background?

## Game function

**event.** Reveal one hidden dependency connected to Doxxing; another player names a countermove. Initiative 4.

## Relationships

- **mobilizes — Data Broker:** Data Broker mobilizes Doxxing by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **distributes costs to — Encrypted Messaging:** Doxxing distributes costs to Encrypted Messaging by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — Stakeholder Analysis:** Doxxing legitimizes Stakeholder Analysis by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **depends on — BDS Movement:** BDS Movement depends on Doxxing by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Doxxing from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Doxxing is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Doxxing: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Guidance for Regulation of Digital Platforms](https://unesdoc.unesco.org/ark:/48223/pf0000387339) — UNESCO, 2023. Platform governance, expression, information integrity, and rights.
- [Examining Extremism: QAnon](https://www.csis.org/blogs/examining-extremism/examining-extremism-qanon) — Center for Strategic and International Studies, 2021. Origins, networked conspiracy claims, mobilization, and a violent subset.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
