# Russian Revolution

> Russian Revolution is mapped as the regime threshold: it reorders legitimacy, institutions, property, coercion, and membership when an old order can no longer reproduce itself.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:revolutions-transitions:russian-revolution` |
| Family | Revolutions & Political Transitions |
| Domain | History |
| Kind | event |
| Archetypal function | The Regime Threshold |
| Epistemic status | sourced_claim; supported |

## Concrete anchor

Russian Revolution belongs to the **Revolutions & Political Transitions** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Russian Revolution reorders legitimacy, institutions, property, coercion, and membership when an old order can no longer reproduce itself, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Russian Revolution, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Regime Threshold.** Russian Revolution is mapped as the regime threshold: it reorders legitimacy, institutions, property, coercion, and membership when an old order can no longer reproduce itself.

## Gift

opens previously impossible political futures; through Russian Revolution, that capacity becomes available for deliberate use.

## Wound / Shadow

unleashes civil war, terror, restoration, or new concentrated rule; Russian Revolution can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Russian Revolution to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Regime Threshold enters through Russian Revolution. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Russian Revolution becomes the unit of analysis rather than background?

## Game function

**leverage.** Reveal one hidden dependency connected to Russian Revolution; another player names a countermove. Initiative 1.

## Relationships

- **constrains — Mexican Revolution:** Mexican Revolution constrains Russian Revolution by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(cultural_historical; supported)_
- **legitimizes — Chinese Revolution:** Russian Revolution legitimizes Chinese Revolution by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(cultural_historical; supported)_
- **amplifies — Trans Rights Movement:** Russian Revolution amplifies Trans Rights Movement by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **counteracts — War:** War counteracts Russian Revolution by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Russian Revolution from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Russian Revolution is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: cultural_historical, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Russian Revolution: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Revolution](https://www.britannica.com/topic/revolution-politics) — Encyclopaedia Britannica, ongoing. Comparative conceptual background; supplement with case-specific scholarship.
- [V-Dem Dataset and Codebook](https://www.v-dem.net/data/the-v-dem-dataset/) — V-Dem Institute, 2026. Comparative measurement of democratic institutions; indicators remain model-based measures.
- [Charter of the United Nations](https://www.un.org/en/about-us/un-charter/full-text) — United Nations, 1945. International institutional order, sovereignty, security, and cooperation.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
