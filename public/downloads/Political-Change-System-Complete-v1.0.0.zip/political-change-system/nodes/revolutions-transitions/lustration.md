# Lustration

> Lustration is mapped as the regime threshold: it reorders legitimacy, institutions, property, coercion, and membership when an old order can no longer reproduce itself.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:revolutions-transitions:lustration` |
| Family | Revolutions & Political Transitions |
| Domain | History |
| Kind | event |
| Archetypal function | The Regime Threshold |
| Epistemic status | sourced_claim; supported |

## Concrete anchor

Lustration belongs to the **Revolutions & Political Transitions** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Lustration reorders legitimacy, institutions, property, coercion, and membership when an old order can no longer reproduce itself, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Lustration, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Regime Threshold.** Lustration is mapped as the regime threshold: it reorders legitimacy, institutions, property, coercion, and membership when an old order can no longer reproduce itself.

## Gift

opens previously impossible political futures; through Lustration, that capacity becomes available for deliberate use.

## Wound / Shadow

unleashes civil war, terror, restoration, or new concentrated rule; Lustration can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Lustration to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Regime Threshold enters through Lustration. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Lustration becomes the unit of analysis rather than background?

## Game function

**resource.** Reveal one hidden dependency connected to Lustration; another player names a countermove. Initiative 3.

## Relationships

- **counteracts — Pacted Transition:** Pacted Transition counteracts Lustration by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(cultural_historical; supported)_
- **amplifies — Constitution-Making Process:** Lustration amplifies Constitution-Making Process by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(cultural_historical; supported)_
- **enables — Mobilization:** Lustration enables Mobilization by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **constrains — Nakba:** Nakba constrains Lustration by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Lustration from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Lustration is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: cultural_historical, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Lustration: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Revolution](https://www.britannica.com/topic/revolution-politics) — Encyclopaedia Britannica, ongoing. Comparative conceptual background; supplement with case-specific scholarship.
- [V-Dem Dataset and Codebook](https://www.v-dem.net/data/the-v-dem-dataset/) — V-Dem Institute, 2026. Comparative measurement of democratic institutions; indicators remain model-based measures.
- [Charter of the United Nations](https://www.un.org/en/about-us/un-charter/full-text) — United Nations, 1945. International institutional order, sovereignty, security, and cooperation.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
