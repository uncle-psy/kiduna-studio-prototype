# The Bureaucrat

> The Bureaucrat is mapped as the role: it concentrates a recurring political function in a recognizable role.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:political-archetypes:the-bureaucrat` |
| Family | Political Archetypes |
| Domain | Culture |
| Kind | archetype |
| Archetypal function | The Role |
| Epistemic status | synthesis; supported |

## Concrete anchor

The Bureaucrat belongs to the **Political Archetypes** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

The Bureaucrat concentrates a recurring political function in a recognizable role, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use The Bureaucrat, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Role.** The Bureaucrat is mapped as the role: it concentrates a recurring political function in a recognizable role.

## Gift

clarifies the work a person or institution is performing; through The Bureaucrat, that capacity becomes available for deliberate use.

## Wound / Shadow

mistakes a role for a person's fixed essence; The Bureaucrat can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use The Bureaucrat to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Role enters through The Bureaucrat. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when The Bureaucrat becomes the unit of analysis rather than background?

## Game function

**role.** Reveal one hidden dependency connected to The Bureaucrat; another player names a countermove. Initiative 5.

## Relationships

- **amplifies — The Statesperson:** The Statesperson amplifies The Bureaucrat by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **translates into — The Whistleblower:** The Bureaucrat translates into The Whistleblower by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **distributes costs to — Pluralism:** The Bureaucrat distributes costs to Pluralism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **counteracts — Trans Rights Movement:** Trans Rights Movement counteracts The Bureaucrat by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read The Bureaucrat from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if The Bureaucrat is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of The Bureaucrat: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Introduction to Political Science](https://openstax.org/details/books/introduction-political-science) — OpenStax, 2022. Comparative institutions, political behavior, and public policy foundations.
- [Letter from Birmingham Jail](https://kinginstitute.stanford.edu/king-papers/documents/letter-birmingham-jail) — Martin Luther King, Jr. Research and Education Institute, 1963. Direct action, constructive tension, law, justice, and timing.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
