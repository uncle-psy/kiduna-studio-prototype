# Accountability Structure

> Accountability Structure is mapped as the vessel: it structures decision, accountability, succession, learning, resources, and collective identity.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:leadership-organization:accountability-structure` |
| Family | Leadership & Organizational Form |
| Domain | Organizations |
| Kind | mechanism |
| Archetypal function | The Vessel |
| Epistemic status | synthesis; supported |

## Concrete anchor

Accountability Structure belongs to the **Leadership & Organizational Form** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Accountability Structure structures decision, accountability, succession, learning, resources, and collective identity, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Accountability Structure, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Vessel.** Accountability Structure is mapped as the vessel: it structures decision, accountability, succession, learning, resources, and collective identity.

## Gift

turns motivation into durable coordinated capacity; through Accountability Structure, that capacity becomes available for deliberate use.

## Wound / Shadow

centralizes charisma, reproduces hierarchy, or lets process consume purpose; Accountability Structure can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Accountability Structure to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Vessel enters through Accountability Structure. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Accountability Structure becomes the unit of analysis rather than background?

## Game function

**resource.** Reveal one hidden dependency connected to Accountability Structure; another player names a countermove. Initiative 3.

## Relationships

- **depends on — Mandate:** Mandate depends on Accountability Structure by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **institutionalizes — Membership Organization:** Accountability Structure institutionalizes Membership Organization by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — The Political Exile:** The Political Exile legitimizes Accountability Structure by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **translates into — Popular Vote:** Accountability Structure translates into Popular Vote by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Accountability Structure from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Accountability Structure is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Accountability Structure: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Why Civil Resistance Works](https://cup.columbia.edu/book/why-civil-resistance-works/9780231156820) — Erica Chenoweth and Maria J. Stephan, 2011. Comparative study of violent and nonviolent campaigns, with scope and coding limits.
- [Civil Rights History Project](https://www.loc.gov/collections/civil-rights-history-project/) — Library of Congress and Smithsonian, ongoing. Participant accounts of the U.S. civil-rights movement.
- [About Indivisible](https://indivisible.org/about) — Indivisible, 2026. Organization self-description and distributed organizing model.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
