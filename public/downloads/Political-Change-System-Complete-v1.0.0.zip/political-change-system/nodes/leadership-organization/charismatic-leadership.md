# Charismatic Leadership

> Charismatic Leadership is mapped as the vessel: it structures decision, accountability, succession, learning, resources, and collective identity.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:leadership-organization:charismatic-leadership` |
| Family | Leadership & Organizational Form |
| Domain | Organizations |
| Kind | mechanism |
| Archetypal function | The Vessel |
| Epistemic status | synthesis; supported |

## Concrete anchor

Charismatic Leadership belongs to the **Leadership & Organizational Form** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Charismatic Leadership structures decision, accountability, succession, learning, resources, and collective identity, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Charismatic Leadership, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Vessel.** Charismatic Leadership is mapped as the vessel: it structures decision, accountability, succession, learning, resources, and collective identity.

## Gift

turns motivation into durable coordinated capacity; through Charismatic Leadership, that capacity becomes available for deliberate use.

## Wound / Shadow

centralizes charisma, reproduces hierarchy, or lets process consume purpose; Charismatic Leadership can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Charismatic Leadership to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Vessel enters through Charismatic Leadership. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Charismatic Leadership becomes the unit of analysis rather than background?

## Game function

**resource.** Reveal one hidden dependency connected to Charismatic Leadership; another player names a countermove. Initiative 3.

## Relationships

- **distributes costs to — Leadership:** Leadership distributes costs to Charismatic Leadership by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Servant Leadership:** Charismatic Leadership depends on Servant Leadership by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — Burnout:** Charismatic Leadership legitimizes Burnout by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **mobilizes — Strategic Defeat:** Strategic Defeat mobilizes Charismatic Leadership by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Charismatic Leadership from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Charismatic Leadership is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Charismatic Leadership: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Why Civil Resistance Works](https://cup.columbia.edu/book/why-civil-resistance-works/9780231156820) — Erica Chenoweth and Maria J. Stephan, 2011. Comparative study of violent and nonviolent campaigns, with scope and coding limits.
- [Civil Rights History Project](https://www.loc.gov/collections/civil-rights-history-project/) — Library of Congress and Smithsonian, ongoing. Participant accounts of the U.S. civil-rights movement.
- [About Indivisible](https://indivisible.org/about) — Indivisible, 2026. Organization self-description and distributed organizing model.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
