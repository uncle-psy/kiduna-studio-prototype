# Recount

> Recount is mapped as the contest: it aggregates authorization through bounded rules, candidacies, persuasion, and counting.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:elections-campaigns:recount` |
| Family | Elections & Campaigns |
| Domain | Elections |
| Kind | process |
| Archetypal function | The Contest |
| Epistemic status | synthesis; supported |

## Concrete anchor

Recount belongs to the **Elections & Campaigns** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Recount aggregates authorization through bounded rules, candidacies, persuasion, and counting, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Recount, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Contest.** Recount is mapped as the contest: it aggregates authorization through bounded rules, candidacies, persuasion, and counting.

## Gift

permits peaceful competition and replacement; through Recount, that capacity becomes available for deliberate use.

## Wound / Shadow

compresses politics into episodic choice and rewards money, attention, and structural advantage; Recount can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Recount to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Contest enters through Recount. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Recount becomes the unit of analysis rather than background?

## Game function

**role.** Reveal one hidden dependency connected to Recount; another player names a countermove. Initiative 5.

## Relationships

- **depends on — Get Out the Vote:** Get Out the Vote depends on Recount by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **institutionalizes — Concession:** Recount institutionalizes Concession by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **distributes costs to — Special District:** Special District distributes costs to Recount by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **translates into — Coalition Table:** Recount translates into Coalition Table by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Recount from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Recount is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Recount: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Electoral System Design: The New International IDEA Handbook](https://www.idea.int/publications/catalogue/electoral-system-design-new-international-idea-handbook) — International IDEA, 2005. Comparative electoral-system design and consequences.
- [Understanding Ways to Support Federal Candidates](https://www.fec.gov/introduction-campaign-finance/understanding-ways-support-federal-candidates/) — Federal Election Commission, 2024. Federal campaign committees, independent expenditures, and contribution rules.
- [Redistricting Law 2020](https://www.ncsl.org/redistricting-and-census/redistricting-law-2020) — National Conference of State Legislatures, 2020. U.S. redistricting institutions, rules, and litigation.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
