# Political Purge

> Political Purge is mapped as the closed fist: it reduces plural contestation through concentrated authority, exclusion, violence, or totalizing certainty.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:authoritarian-extremist:political-purge` |
| Family | Authoritarian & Extremist Formations |
| Domain | State Power |
| Kind | formation |
| Archetypal function | The Closed Fist |
| Epistemic status | synthesis; supported |

## Concrete anchor

Political Purge belongs to the **Authoritarian & Extremist Formations** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Political Purge reduces plural contestation through concentrated authority, exclusion, violence, or totalizing certainty, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Political Purge, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Closed Fist.** Political Purge is mapped as the closed fist: it reduces plural contestation through concentrated authority, exclusion, violence, or totalizing certainty.

## Gift

can produce rapid coordination under perceived existential threat; through Political Purge, that capacity becomes available for deliberate use.

## Wound / Shadow

destroys accountability, equal standing, factual correction, and safe opposition; Political Purge can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Political Purge to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Closed Fist enters through Political Purge. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Political Purge becomes the unit of analysis rather than background?

## Game function

**constraint.** Reveal one hidden dependency connected to Political Purge; another player names a countermove. Initiative 2.

## Relationships

- **counteracts — Leader Principle:** Leader Principle counteracts Political Purge by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Women of Liberia Mass Action for Peace:** Political Purge depends on Women of Liberia Mass Action for Peace by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **institutionalizes — No Kings:** No Kings institutionalizes Political Purge by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Political Purge from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Political Purge is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Political Purge: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Fascism](https://encyclopedia.ushmm.org/content/en/article/fascism-1) — United States Holocaust Memorial Museum, 2019. Historically bounded definition and features; avoid use as a generic insult.
- [FBI–DHS Domestic Terrorism Strategic Report](https://www.fbi.gov/file-repository/fbi-dhs-domestic-terrorism-strategic-report-2022.pdf) — FBI and DHS, 2022. Threat categories and incidents; agencies state protected political activity is not terrorism.
- [Violent Extremism and Domestic Terrorism in America](https://www.fbi.gov/news/speeches-and-testimony/violent-extremism-and-domestic-terrorism-in-america-the-role-and-response-of-the-department-of-justice) — Federal Bureau of Investigation, 2021. Distinguishes protected belief and association from unlawful force or violence.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
