# Domestic Violent Extremism

> a U.S. government category for actors based primarily in the United States who pursue political or social goals through unlawful force or violence

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:authoritarian-extremist:domestic-violent-extremism` |
| Family | Authoritarian & Extremist Formations |
| Domain | State Power |
| Kind | formation |
| Archetypal function | The Closed Fist |
| Epistemic status | synthesis; established |

## Concrete anchor

Domestic Violent Extremism belongs to the **Authoritarian & Extremist Formations** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Threat classification focuses on violence and mobilization to violence, not ideology alone; definitions and investigative use carry civil-liberties implications.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Domestic Violent Extremism, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Closed Fist.** a U.S. government category for actors based primarily in the United States who pursue political or social goals through unlawful force or violence

## Gift

Centers conduct and threat while allowing cross-ideological analysis.

## Wound / Shadow

Broad security categories can chill protected dissent or be applied selectively.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Domestic Violent Extremism to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Closed Fist enters through Domestic Violent Extremism. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What specific unlawful force, threat, intent, and authority support the classification?

## Game function

**constraint.** Reveal one hidden dependency connected to Domestic Violent Extremism; another player names a countermove. Initiative 2.

## Relationships

- **distributes costs to — Lone-Actor Violence:** Lone-Actor Violence distributes costs to Domestic Violent Extremism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Cult of Personality:** Domestic Violent Extremism depends on Cult of Personality by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Countermove:** Countermove depends on Domestic Violent Extremism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **distributes costs to — Truth and Reconciliation:** Domestic Violent Extremism distributes costs to Truth and Reconciliation by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Domestic Violent Extremism from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Domestic Violent Extremism is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: sourced_claim, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
Sentinel factors: extremism; law enforcement category; civil liberties. These are descriptive handoff annotations, not a verdict and not a mutation of Engine Output.

## Visual direction

A text-free enamel expression of Domestic Violent Extremism: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Fascism](https://encyclopedia.ushmm.org/content/en/article/fascism-1) — United States Holocaust Memorial Museum, 2019. Historically bounded definition and features; avoid use as a generic insult.
- [FBI–DHS Domestic Terrorism Strategic Report](https://www.fbi.gov/file-repository/fbi-dhs-domestic-terrorism-strategic-report-2022.pdf) — FBI and DHS, 2022. Threat categories and incidents; agencies state protected political activity is not terrorism.
- [Violent Extremism and Domestic Terrorism in America](https://www.fbi.gov/news/speeches-and-testimony/violent-extremism-and-domestic-terrorism-in-america-the-role-and-response-of-the-department-of-justice) — Federal Bureau of Investigation, 2021. Distinguishes protected belief and association from unlawful force or violence.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
