# Illiberal Democracy

> Illiberal Democracy is mapped as the closed fist: it reduces plural contestation through concentrated authority, exclusion, violence, or totalizing certainty.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:authoritarian-extremist:illiberal-democracy` |
| Family | Authoritarian & Extremist Formations |
| Domain | State Power |
| Kind | formation |
| Archetypal function | The Closed Fist |
| Epistemic status | synthesis; supported |

## Concrete anchor

Illiberal Democracy belongs to the **Authoritarian & Extremist Formations** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Illiberal Democracy reduces plural contestation through concentrated authority, exclusion, violence, or totalizing certainty, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Illiberal Democracy, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Closed Fist.** Illiberal Democracy is mapped as the closed fist: it reduces plural contestation through concentrated authority, exclusion, violence, or totalizing certainty.

## Gift

can produce rapid coordination under perceived existential threat; through Illiberal Democracy, that capacity becomes available for deliberate use.

## Wound / Shadow

destroys accountability, equal standing, factual correction, and safe opposition; Illiberal Democracy can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Illiberal Democracy to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Closed Fist enters through Illiberal Democracy. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Illiberal Democracy becomes the unit of analysis rather than background?

## Game function

**resource.** Reveal one hidden dependency connected to Illiberal Democracy; another player names a countermove. Initiative 3.

## Relationships

- **legitimizes — One-Party State:** One-Party State legitimizes Illiberal Democracy by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **mobilizes — Competitive Authoritarianism:** Illiberal Democracy mobilizes Competitive Authoritarianism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **enables — Minister:** Illiberal Democracy enables Minister by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **translates into — Anti-Palestinian Racism:** Anti-Palestinian Racism translates into Illiberal Democracy by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Illiberal Democracy from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Illiberal Democracy is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Illiberal Democracy: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Fascism](https://encyclopedia.ushmm.org/content/en/article/fascism-1) — United States Holocaust Memorial Museum, 2019. Historically bounded definition and features; avoid use as a generic insult.
- [FBI–DHS Domestic Terrorism Strategic Report](https://www.fbi.gov/file-repository/fbi-dhs-domestic-terrorism-strategic-report-2022.pdf) — FBI and DHS, 2022. Threat categories and incidents; agencies state protected political activity is not terrorism.
- [Violent Extremism and Domestic Terrorism in America](https://www.fbi.gov/news/speeches-and-testimony/violent-extremism-and-domestic-terrorism-in-america-the-role-and-response-of-the-department-of-justice) — Federal Bureau of Investigation, 2021. Distinguishes protected belief and association from unlawful force or violence.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
