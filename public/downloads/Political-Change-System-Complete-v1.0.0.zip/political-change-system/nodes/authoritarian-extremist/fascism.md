# Fascism

> a historically specific family of ultranationalist, authoritarian mass politics that subordinates pluralism and individual rights to a mythic national community

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:authoritarian-extremist:fascism` |
| Family | Authoritarian & Extremist Formations |
| Domain | State Power |
| Kind | formation |
| Archetypal function | The Closed Fist |
| Epistemic status | synthesis; supported |

## Concrete anchor

Fascism belongs to the **Authoritarian & Extremist Formations** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Historical fascisms fused leader rule, mobilized nationalism, exclusion, paramilitarism or celebrated violence, suppression of opposition, and narratives of decline and rebirth; scholarly definitions vary.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Fascism, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Closed Fist.** a historically specific family of ultranationalist, authoritarian mass politics that subordinates pluralism and individual rights to a mythic national community

## Gift

As an analytic warning, the concept helps identify combinations that should not be normalized.

## Wound / Shadow

Used as a generic insult, it destroys historical precision and blocks comparison.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Fascism to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Closed Fist enters through Fascism. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** Which historically grounded features are present, absent, or disputed?

## Game function

**role.** Reveal one hidden dependency connected to Fascism; another player names a countermove. Initiative 5.

## Relationships

- **counteracts — Totalitarianism:** Totalitarianism counteracts Fascism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **amplifies — Nazism:** Fascism amplifies Nazism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — The Nonvoter:** Fascism depends on The Nonvoter by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **enables — Interest-Based Bargaining:** Interest-Based Bargaining enables Fascism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Fascism from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Fascism is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
Sentinel factors: extremism; historical atrocity; contested application. These are descriptive handoff annotations, not a verdict and not a mutation of Engine Output.

## Visual direction

A text-free enamel expression of Fascism: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Fascism](https://encyclopedia.ushmm.org/content/en/article/fascism-1) — United States Holocaust Memorial Museum, 2019. Historically bounded definition and features; avoid use as a generic insult.
- [FBI–DHS Domestic Terrorism Strategic Report](https://www.fbi.gov/file-repository/fbi-dhs-domestic-terrorism-strategic-report-2022.pdf) — FBI and DHS, 2022. Threat categories and incidents; agencies state protected political activity is not terrorism.
- [Violent Extremism and Domestic Terrorism in America](https://www.fbi.gov/news/speeches-and-testimony/violent-extremism-and-domestic-terrorism-in-america-the-role-and-response-of-the-department-of-justice) — Federal Bureau of Investigation, 2021. Distinguishes protected belief and association from unlawful force or violence.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
