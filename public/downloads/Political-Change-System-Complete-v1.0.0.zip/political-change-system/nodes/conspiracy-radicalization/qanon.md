# QAnon

> a networked conspiracy movement built around anonymous 'Q' posts and a hidden-war narrative

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:conspiracy-radicalization:qanon` |
| Family | Conspiracy & Radicalization |
| Domain | Information |
| Kind | formation |
| Archetypal function | The Hidden Plot |
| Epistemic status | synthesis; supported |

## Concrete anchor

QAnon belongs to the **Conspiracy & Radicalization** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Participants collectively interpreted cryptic posts within online research communities; false and unfalsifiable claims created identity, anticipation, and mobilization. A minority has been linked to violence, but belief or protected association is not itself violent extremism.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use QAnon, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Hidden Plot.** a networked conspiracy movement built around anonymous 'Q' posts and a hidden-war narrative

## Gift

Reveals how participatory storytelling can create intense belonging and distributed investigation.

## Wound / Shadow

Epistemic closure, demonization, and the conversion of uncertainty into total certainty.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use QAnon to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Hidden Plot enters through QAnon. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What evidence could change the story—and what happens when the answer is none?

## Game function

**leverage.** Reveal one hidden dependency connected to QAnon; another player names a countermove. Initiative 1.

## Relationships

- **mobilizes — Pizzagate:** QAnon mobilizes Pizzagate by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **translates into — Agenda Setting:** QAnon translates into Agenda Setting by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **institutionalizes — Islamophobia:** Islamophobia institutionalizes QAnon by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read QAnon from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if QAnon is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
Sentinel factors: false claims; extremism; protected belief versus violence. These are descriptive handoff annotations, not a verdict and not a mutation of Engine Output.

## Visual direction

A text-free enamel expression of QAnon: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Examining Extremism: QAnon](https://www.csis.org/blogs/examining-extremism/examining-extremism-qanon) — Center for Strategic and International Studies, 2021. Origins, networked conspiracy claims, mobilization, and a violent subset.
- [FBI–DHS Domestic Terrorism Strategic Report](https://www.fbi.gov/file-repository/fbi-dhs-domestic-terrorism-strategic-report-2022.pdf) — FBI and DHS, 2022. Threat categories and incidents; agencies state protected political activity is not terrorism.
- [Guidance for Regulation of Digital Platforms](https://unesdoc.unesco.org/ark:/48223/pf0000387339) — UNESCO, 2023. Platform governance, expression, information integrity, and rights.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
