# Great Replacement Theory

> Great Replacement Theory is mapped as the hidden plot: it turns uncertainty and distrust into a total explanatory community.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:conspiracy-radicalization:great-replacement-theory` |
| Family | Conspiracy & Radicalization |
| Domain | Information |
| Kind | formation |
| Archetypal function | The Hidden Plot |
| Epistemic status | synthesis; supported |

## Concrete anchor

Great Replacement Theory belongs to the **Conspiracy & Radicalization** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Great Replacement Theory turns uncertainty and distrust into a total explanatory community, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Great Replacement Theory, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Hidden Plot.** Great Replacement Theory is mapped as the hidden plot: it turns uncertainty and distrust into a total explanatory community.

## Gift

detects that real power can operate invisibly and gives adherents belonging; through Great Replacement Theory, that capacity becomes available for deliberate use.

## Wound / Shadow

makes unfalsifiability, demonization, and escalating commitment self-sealing; Great Replacement Theory can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Great Replacement Theory to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Hidden Plot enters through Great Replacement Theory. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Great Replacement Theory becomes the unit of analysis rather than background?

## Game function

**event.** Reveal one hidden dependency connected to Great Replacement Theory; another player names a countermove. Initiative 4.

## Relationships

- **institutionalizes — The Storm:** The Storm institutionalizes Great Replacement Theory by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **counteracts — Election Denial:** Great Replacement Theory counteracts Election Denial by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **counteracts — Zapatismo:** Great Replacement Theory counteracts Zapatismo by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **amplifies — Social Strike:** Social Strike amplifies Great Replacement Theory by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Great Replacement Theory from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Great Replacement Theory is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Great Replacement Theory: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Examining Extremism: QAnon](https://www.csis.org/blogs/examining-extremism/examining-extremism-qanon) — Center for Strategic and International Studies, 2021. Origins, networked conspiracy claims, mobilization, and a violent subset.
- [FBI–DHS Domestic Terrorism Strategic Report](https://www.fbi.gov/file-repository/fbi-dhs-domestic-terrorism-strategic-report-2022.pdf) — FBI and DHS, 2022. Threat categories and incidents; agencies state protected political activity is not terrorism.
- [Guidance for Regulation of Digital Platforms](https://unesdoc.unesco.org/ark:/48223/pf0000387339) — UNESCO, 2023. Platform governance, expression, information integrity, and rights.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
