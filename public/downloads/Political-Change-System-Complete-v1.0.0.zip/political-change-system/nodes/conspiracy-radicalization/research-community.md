# Research Community

> Research Community is mapped as the hidden plot: it turns uncertainty and distrust into a total explanatory community.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:conspiracy-radicalization:research-community` |
| Family | Conspiracy & Radicalization |
| Domain | Information |
| Kind | formation |
| Archetypal function | The Hidden Plot |
| Epistemic status | synthesis; supported |

## Concrete anchor

Research Community belongs to the **Conspiracy & Radicalization** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Research Community turns uncertainty and distrust into a total explanatory community, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Research Community, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Hidden Plot.** Research Community is mapped as the hidden plot: it turns uncertainty and distrust into a total explanatory community.

## Gift

detects that real power can operate invisibly and gives adherents belonging; through Research Community, that capacity becomes available for deliberate use.

## Wound / Shadow

makes unfalsifiability, demonization, and escalating commitment self-sealing; Research Community can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Research Community to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Hidden Plot enters through Research Community. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Research Community becomes the unit of analysis rather than background?

## Game function

**role.** Reveal one hidden dependency connected to Research Community; another player names a countermove. Initiative 5.

## Relationships

- **translates into — Unfalsifiability:** Unfalsifiability translates into Research Community by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **enables — Coded Signal:** Research Community enables Coded Signal by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **constrains — Ideology:** Ideology constrains Research Community by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **amplifies — Clientelism:** Research Community amplifies Clientelism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Research Community from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Research Community is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Research Community: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Examining Extremism: QAnon](https://www.csis.org/blogs/examining-extremism/examining-extremism-qanon) — Center for Strategic and International Studies, 2021. Origins, networked conspiracy claims, mobilization, and a violent subset.
- [FBI–DHS Domestic Terrorism Strategic Report](https://www.fbi.gov/file-repository/fbi-dhs-domestic-terrorism-strategic-report-2022.pdf) — FBI and DHS, 2022. Threat categories and incidents; agencies state protected political activity is not terrorism.
- [Guidance for Regulation of Digital Platforms](https://unesdoc.unesco.org/ark:/48223/pf0000387339) — UNESCO, 2023. Platform governance, expression, information integrity, and rights.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
