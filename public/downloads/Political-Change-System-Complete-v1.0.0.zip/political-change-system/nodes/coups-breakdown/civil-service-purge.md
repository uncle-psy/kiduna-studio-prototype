# Civil Service Purge

> Civil Service Purge is mapped as the seized center: it changes rule by capturing command, disabling rivals, or hollowing institutions.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:coups-breakdown:civil-service-purge` |
| Family | Coups, Breakdown & Consolidation |
| Domain | State Power |
| Kind | process |
| Archetypal function | The Seized Center |
| Epistemic status | synthesis; supported |

## Concrete anchor

Civil Service Purge belongs to the **Coups, Breakdown & Consolidation** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Civil Service Purge changes rule by capturing command, disabling rivals, or hollowing institutions, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Civil Service Purge, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Seized Center.** Civil Service Purge is mapped as the seized center: it changes rule by capturing command, disabling rivals, or hollowing institutions.

## Gift

can end paralysis or dislodge a failed regime; through Civil Service Purge, that capacity becomes available for deliberate use.

## Wound / Shadow

substitutes coercive fact for public authorization and normalizes exceptional rule; Civil Service Purge can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Civil Service Purge to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Seized Center enters through Civil Service Purge. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Civil Service Purge becomes the unit of analysis rather than background?

## Game function

**role.** Reveal one hidden dependency connected to Civil Service Purge; another player names a countermove. Initiative 5.

## Relationships

- **distributes costs to — Election Subversion:** Election Subversion distributes costs to Civil Service Purge by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Loyalty Test:** Civil Service Purge depends on Loyalty Test by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **amplifies — Citizenship:** Citizenship amplifies Civil Service Purge by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **depends on — Precarity:** Civil Service Purge depends on Precarity by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Civil Service Purge from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Civil Service Purge is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Civil Service Purge: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [V-Dem Dataset and Codebook](https://www.v-dem.net/data/the-v-dem-dataset/) — V-Dem Institute, 2026. Comparative measurement of democratic institutions; indicators remain model-based measures.
- [National Emergency Powers](https://crsreports.congress.gov/product/pdf/RL/98-505) — Congressional Research Service, 2024. U.S. emergency authorities and congressional checks.
- [Charter of the United Nations](https://www.un.org/en/about-us/un-charter/full-text) — United Nations, 1945. International institutional order, sovereignty, security, and cooperation.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
