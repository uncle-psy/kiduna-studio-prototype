# Precedent

> Precedent is mapped as the forum: it converts conflict into claims adjudicated through authoritative procedure.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:courts-law:precedent` |
| Family | Courts & Legal Change |
| Domain | Law |
| Kind | institution |
| Archetypal function | The Forum |
| Epistemic status | synthesis; supported |

## Concrete anchor

Precedent belongs to the **Courts & Legal Change** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Precedent converts conflict into claims adjudicated through authoritative procedure, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Precedent, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Forum.** Precedent is mapped as the forum: it converts conflict into claims adjudicated through authoritative procedure.

## Gift

offers reasons, remedies, and continuity beyond immediate majorities; through Precedent, that capacity becomes available for deliberate use.

## Wound / Shadow

privileges access, delay, technical language, and judicial power; Precedent can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Precedent to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Forum enters through Precedent. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Precedent becomes the unit of analysis rather than background?

## Game function

**event.** Reveal one hidden dependency connected to Precedent; another player names a countermove. Initiative 4.

## Relationships

- **distributes costs to — Standing:** Standing distributes costs to Precedent by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Stare Decisis:** Precedent depends on Stare Decisis by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **distributes costs to — Dual Power:** Dual Power distributes costs to Precedent by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **translates into — Third-Wave Feminism:** Precedent translates into Third-Wave Feminism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Precedent from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Precedent is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Precedent: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Constitution of the United States](https://www.archives.gov/founding-docs/constitution-transcript) — National Archives, 1787. Federal structure, separated powers, amendment, elections, and rights.
- [Rome Statute of the International Criminal Court](https://www.icc-cpi.int/sites/default/files/Publications/Rome-Statute.pdf) — International Criminal Court, 1998. International criminal jurisdiction and definitions.
- [Advisory Opinion: Occupied Palestinian Territory](https://www.icj-cij.org/case/186) — International Court of Justice, 2024. Court record and advisory opinion; advisory rather than contentious judgment.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
