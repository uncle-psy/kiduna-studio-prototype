# Cesar Chavez

> Cesar Chavez is mapped as the refusal travels: it adapts disciplined noncooperation across empires, dictatorships, occupations, and democracies.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:global-nonviolence:cesar-chavez` |
| Family | Global Nonviolent Lineages |
| Domain | History |
| Kind | lineage |
| Archetypal function | The Refusal Travels |
| Epistemic status | sourced_claim; supported |

## Concrete anchor

Cesar Chavez belongs to the **Global Nonviolent Lineages** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Cesar Chavez adapts disciplined noncooperation across empires, dictatorships, occupations, and democracies, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Cesar Chavez, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Refusal Travels.** Cesar Chavez is mapped as the refusal travels: it adapts disciplined noncooperation across empires, dictatorships, occupations, and democracies.

## Gift

carries strategy and moral imagination across contexts; through Cesar Chavez, that capacity becomes available for deliberate use.

## Wound / Shadow

flattens local histories into a heroic universal recipe; Cesar Chavez can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Cesar Chavez to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Refusal Travels enters through Cesar Chavez. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Cesar Chavez becomes the unit of analysis rather than background?

## Game function

**leverage.** Reveal one hidden dependency connected to Cesar Chavez; another player names a countermove. Initiative 1.

## Relationships

- **enables — James Lawson:** James Lawson enables Cesar Chavez by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(cultural_historical; supported)_
- **constrains — Dolores Huerta:** Cesar Chavez constrains Dolores Huerta by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(cultural_historical; supported)_
- **translates into — Campaign Contribution:** Campaign Contribution translates into Cesar Chavez by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **legitimizes — Platform Cooperative:** Cesar Chavez legitimizes Platform Cooperative by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Cesar Chavez from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Cesar Chavez is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: cultural_historical, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Cesar Chavez: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Gandhi Heritage Portal](https://www.gandhiheritageportal.org/) — Sabarmati Ashram Preservation and Memorial Trust, ongoing. Digitized writings and historical materials; interpretations require context.
- [Why Civil Resistance Works](https://cup.columbia.edu/book/why-civil-resistance-works/9780231156820) — Erica Chenoweth and Maria J. Stephan, 2011. Comparative study of violent and nonviolent campaigns, with scope and coding limits.
- [198 Methods of Nonviolent Action](https://www.aeinstein.org/nonviolentaction/198-methods-of-nonviolent-action/) — Albert Einstein Institution, 1973. Tactic taxonomy; inclusion does not imply effectiveness or ethical endorsement in every context.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
