# 3.5 Percent

> a memorable empirical pattern about peak active participation, not a universal magic threshold

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:nonviolent-resistance:3-5-percent` |
| Family | Nonviolent Resistance |
| Domain | Movements |
| Kind | strategy |
| Archetypal function | The Refusal |
| Epistemic status | synthesis; supported |

## Concrete anchor

3.5 Percent belongs to the **Nonviolent Resistance** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Chenoweth's historical dataset found no campaign that had achieved active and sustained peak participation of about 3.5 percent had failed, while many successful campaigns mobilized less; cases, coding, eras, and outcomes vary.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use 3.5 Percent, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Refusal.** a memorable empirical pattern about peak active participation, not a universal magic threshold

## Gift

Makes participation scale strategically visible.

## Wound / Shadow

Numerology replaces organization, defections, strategy, and context.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use 3.5 Percent to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Refusal enters through 3.5 Percent. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What kind of participation changes loyalty and capacity in this case?

## Game function

**event.** Reveal one hidden dependency connected to 3.5 Percent; another player names a countermove. Initiative 4.

## Relationships

- **translates into — Nonviolent Discipline:** Nonviolent Discipline translates into 3.5 Percent by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **enables — Defection:** 3.5 Percent enables Defection by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **amplifies — Democratic Convention 1968:** 3.5 Percent amplifies Democratic Convention 1968 by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **counteracts — Democratic Centralism:** Democratic Centralism counteracts 3.5 Percent by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read 3.5 Percent from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if 3.5 Percent is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of 3.5 Percent: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Why Civil Resistance Works](https://cup.columbia.edu/book/why-civil-resistance-works/9780231156820) — Erica Chenoweth and Maria J. Stephan, 2011. Comparative study of violent and nonviolent campaigns, with scope and coding limits.
- [Questions, Answers, and Some Cautionary Updates Regarding the 3.5% Rule](https://carrcenter.hks.harvard.edu/publications/questions-answers-and-some-cautionary-updates-regarding-35-rule) — Erica Chenoweth, 2020. Clarifies that 3.5% is an observed pattern, not a universal threshold.
- [Gandhi Heritage Portal](https://www.gandhiheritageportal.org/) — Sabarmati Ashram Preservation and Memorial Trust, ongoing. Digitized writings and historical materials; interpretations require context.
- [Letter from Birmingham Jail](https://kinginstitute.stanford.edu/king-papers/documents/letter-birmingham-jail) — Martin Luther King, Jr. Research and Education Institute, 1963. Direct action, constructive tension, law, justice, and timing.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
