# Repression Dilemma

> Repression Dilemma is mapped as the refusal: it withdraws cooperation while building discipline, legitimacy, and participation.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:nonviolent-resistance:repression-dilemma` |
| Family | Nonviolent Resistance |
| Domain | Movements |
| Kind | strategy |
| Archetypal function | The Refusal |
| Epistemic status | synthesis; supported |

## Concrete anchor

Repression Dilemma belongs to the **Nonviolent Resistance** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Repression Dilemma withdraws cooperation while building discipline, legitimacy, and participation, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Repression Dilemma, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Refusal.** Repression Dilemma is mapped as the refusal: it withdraws cooperation while building discipline, legitimacy, and participation.

## Gift

creates moral, social, economic, and political asymmetry; through Repression Dilemma, that capacity becomes available for deliberate use.

## Wound / Shadow

romanticizes suffering or assumes repression will reliably backfire; Repression Dilemma can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Repression Dilemma to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Refusal enters through Repression Dilemma. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Repression Dilemma becomes the unit of analysis rather than background?

## Game function

**leverage.** Reveal one hidden dependency connected to Repression Dilemma; another player names a countermove. Initiative 1.

## Relationships

- **counteracts — Backfire:** Backfire counteracts Repression Dilemma by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **amplifies — Nonviolent Discipline:** Repression Dilemma amplifies Nonviolent Discipline by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **distributes costs to — Extinction Rebellion:** Repression Dilemma distributes costs to Extinction Rebellion by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **mobilizes — Strongman Politics:** Strongman Politics mobilizes Repression Dilemma by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Repression Dilemma from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Repression Dilemma is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Repression Dilemma: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Why Civil Resistance Works](https://cup.columbia.edu/book/why-civil-resistance-works/9780231156820) — Erica Chenoweth and Maria J. Stephan, 2011. Comparative study of violent and nonviolent campaigns, with scope and coding limits.
- [Questions, Answers, and Some Cautionary Updates Regarding the 3.5% Rule](https://carrcenter.hks.harvard.edu/publications/questions-answers-and-some-cautionary-updates-regarding-35-rule) — Erica Chenoweth, 2020. Clarifies that 3.5% is an observed pattern, not a universal threshold.
- [Gandhi Heritage Portal](https://www.gandhiheritageportal.org/) — Sabarmati Ashram Preservation and Memorial Trust, ongoing. Digitized writings and historical materials; interpretations require context.
- [Letter from Birmingham Jail](https://kinginstitute.stanford.edu/king-papers/documents/letter-birmingham-jail) — Martin Luther King, Jr. Research and Education Institute, 1963. Direct action, constructive tension, law, justice, and timing.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
