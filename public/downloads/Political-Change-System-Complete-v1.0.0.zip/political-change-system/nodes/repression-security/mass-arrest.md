# Mass Arrest

> Mass Arrest is mapped as the fist: it raises the cost of dissent through surveillance, force, law, detention, or fear.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:repression-security:mass-arrest` |
| Family | Repression & Security |
| Domain | State Power |
| Kind | mechanism |
| Archetypal function | The Fist |
| Epistemic status | synthesis; supported |

## Concrete anchor

Mass Arrest belongs to the **Repression & Security** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Mass Arrest raises the cost of dissent through surveillance, force, law, detention, or fear, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Mass Arrest, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Fist.** Mass Arrest is mapped as the fist: it raises the cost of dissent through surveillance, force, law, detention, or fear.

## Gift

can protect people and institutions from genuine threats; through Mass Arrest, that capacity becomes available for deliberate use.

## Wound / Shadow

collapses dissent into danger and makes emergency power permanent; Mass Arrest can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Mass Arrest to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Fist enters through Mass Arrest. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Mass Arrest becomes the unit of analysis rather than background?

## Game function

**constraint.** Reveal one hidden dependency connected to Mass Arrest; another player names a countermove. Initiative 2.

## Relationships

- **institutionalizes — Curfew:** Curfew institutionalizes Mass Arrest by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **counteracts — Preventive Detention:** Mass Arrest counteracts Preventive Detention by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **institutionalizes — Conditionality:** Mass Arrest institutionalizes Conditionality by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **mobilizes — Transition:** Transition mobilizes Mass Arrest by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Mass Arrest from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Mass Arrest is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Mass Arrest: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Violent Extremism and Domestic Terrorism in America](https://www.fbi.gov/news/speeches-and-testimony/violent-extremism-and-domestic-terrorism-in-america-the-role-and-response-of-the-department-of-justice) — Federal Bureau of Investigation, 2021. Distinguishes protected belief and association from unlawful force or violence.
- [National Emergency Powers](https://crsreports.congress.gov/product/pdf/RL/98-505) — Congressional Research Service, 2024. U.S. emergency authorities and congressional checks.
- [Church Committee Reports](https://www.senate.gov/about/powers-procedures/investigations/church-committee.htm) — U.S. Senate, 1975–1976. Investigations of intelligence abuses and subsequent oversight reforms.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
