# Carbon Tax

> Carbon Tax is mapped as the long horizon: it politicizes shared ecological conditions, unequal exposure, and intergenerational risk.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:environment-climate:carbon-tax` |
| Family | Environmental & Climate Politics |
| Domain | Ecology |
| Kind | movement |
| Archetypal function | The Long Horizon |
| Epistemic status | synthesis; supported |

## Concrete anchor

Carbon Tax belongs to the **Environmental & Climate Politics** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Carbon Tax politicizes shared ecological conditions, unequal exposure, and intergenerational risk, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Carbon Tax, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Long Horizon.** Carbon Tax is mapped as the long horizon: it politicizes shared ecological conditions, unequal exposure, and intergenerational risk.

## Gift

expands the constituency to future people and living systems; through Carbon Tax, that capacity becomes available for deliberate use.

## Wound / Shadow

turns urgency into technocracy, sacrifice zones, or moral purity; Carbon Tax can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Carbon Tax to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Long Horizon enters through Carbon Tax. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Carbon Tax becomes the unit of analysis rather than background?

## Game function

**role.** Reveal one hidden dependency connected to Carbon Tax; another player names a countermove. Initiative 5.

## Relationships

- **distributes costs to — Loss and Damage:** Loss and Damage distributes costs to Carbon Tax by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Cap and Trade:** Carbon Tax depends on Cap and Trade by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **institutionalizes — Bot Network:** Bot Network institutionalizes Carbon Tax by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **translates into — Culture War:** Carbon Tax translates into Culture War by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Carbon Tax from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Carbon Tax is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Carbon Tax: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [IPCC Sixth Assessment Synthesis Report](https://www.ipcc.ch/report/ar6/syr/) — Intergovernmental Panel on Climate Change, 2023. Climate risks, mitigation, adaptation, and justice-relevant distributional consequences.
- [Environmental Justice](https://www.epa.gov/environmentaljustice) — U.S. Environmental Protection Agency, ongoing. Environmental-justice concepts and federal activity; program names and status may change.
- [198 Methods of Nonviolent Action](https://www.aeinstein.org/nonviolentaction/198-methods-of-nonviolent-action/) — Albert Einstein Institution, 1973. Tactic taxonomy; inclusion does not imply effectiveness or ethical endorsement in every context.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
