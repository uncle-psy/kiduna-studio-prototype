# Fridays for Future

> Fridays for Future is mapped as the long horizon: it politicizes shared ecological conditions, unequal exposure, and intergenerational risk.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:environment-climate:fridays-for-future` |
| Family | Environmental & Climate Politics |
| Domain | Ecology |
| Kind | movement |
| Archetypal function | The Long Horizon |
| Epistemic status | synthesis; supported |

## Concrete anchor

Fridays for Future belongs to the **Environmental & Climate Politics** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Fridays for Future politicizes shared ecological conditions, unequal exposure, and intergenerational risk, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Fridays for Future, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Long Horizon.** Fridays for Future is mapped as the long horizon: it politicizes shared ecological conditions, unequal exposure, and intergenerational risk.

## Gift

expands the constituency to future people and living systems; through Fridays for Future, that capacity becomes available for deliberate use.

## Wound / Shadow

turns urgency into technocracy, sacrifice zones, or moral purity; Fridays for Future can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Fridays for Future to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Long Horizon enters through Fridays for Future. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Fridays for Future becomes the unit of analysis rather than background?

## Game function

**event.** Reveal one hidden dependency connected to Fridays for Future; another player names a countermove. Initiative 4.

## Relationships

- **constrains — Climate Strike:** Climate Strike constrains Fridays for Future by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — Extinction Rebellion:** Fridays for Future legitimizes Extinction Rebellion by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **amplifies — Relational Organizing:** Fridays for Future amplifies Relational Organizing by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **mobilizes — Jean-Jacques Rousseau:** Jean-Jacques Rousseau mobilizes Fridays for Future by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Fridays for Future from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Fridays for Future is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Fridays for Future: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [IPCC Sixth Assessment Synthesis Report](https://www.ipcc.ch/report/ar6/syr/) — Intergovernmental Panel on Climate Change, 2023. Climate risks, mitigation, adaptation, and justice-relevant distributional consequences.
- [Environmental Justice](https://www.epa.gov/environmentaljustice) — U.S. Environmental Protection Agency, ongoing. Environmental-justice concepts and federal activity; program names and status may change.
- [198 Methods of Nonviolent Action](https://www.aeinstein.org/nonviolentaction/198-methods-of-nonviolent-action/) — Albert Einstein Institution, 1973. Tactic taxonomy; inclusion does not imply effectiveness or ethical endorsement in every context.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
