# Coalition

> Coalition is mapped as the turning: it moves a condition through interpretation, organization, action, countermove, and settlement.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:change-sequence:coalition` |
| Family | Political Change Sequence |
| Domain | Strategy |
| Kind | mechanism |
| Archetypal function | The Turning |
| Epistemic status | synthesis; supported |

## Concrete anchor

Coalition belongs to the **Political Change Sequence** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Coalition moves a condition through interpretation, organization, action, countermove, and settlement, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Coalition, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Turning.** Coalition is mapped as the turning: it moves a condition through interpretation, organization, action, countermove, and settlement.

## Gift

shows where an intervention can alter a trajectory; through Coalition, that capacity becomes available for deliberate use.

## Wound / Shadow

encourages linear stories for recursive and path-dependent change; Coalition can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Coalition to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Turning enters through Coalition. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Coalition becomes the unit of analysis rather than background?

## Game function

**resource.** Reveal one hidden dependency connected to Coalition; another player names a countermove. Initiative 3.

## Relationships

- **mobilizes — Collective Identity:** Collective Identity mobilizes Coalition by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **distributes costs to — Organization:** Coalition distributes costs to Organization by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **distributes costs to — The Informant:** The Informant distributes costs to Coalition by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **counteracts — Small-Dollar Fundraising:** Coalition counteracts Small-Dollar Fundraising by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Coalition from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Coalition is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Coalition: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Why Civil Resistance Works](https://cup.columbia.edu/book/why-civil-resistance-works/9780231156820) — Erica Chenoweth and Maria J. Stephan, 2011. Comparative study of violent and nonviolent campaigns, with scope and coding limits.
- [Introduction to Political Science](https://openstax.org/details/books/introduction-political-science) — OpenStax, 2022. Comparative institutions, political behavior, and public policy foundations.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
