# MAGA

> the Make America Great Again movement and political identity organized around Donald Trump's leadership, nationalist-populist themes, and the contemporary Republican coalition

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:populism-nationalism:maga` |
| Family | Populism & Nationalism |
| Domain | Ideology |
| Kind | formation |
| Archetypal function | The People Named |
| Epistemic status | synthesis; supported |

## Concrete anchor

MAGA belongs to the **Populism & Nationalism** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

MAGA links leader-centered rallies, party control, media ecosystems, immigration and sovereignty politics, cultural grievance, and a restoration narrative; adherents are diverse and external classifications are contested.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use MAGA, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The People Named.** the Make America Great Again movement and political identity organized around Donald Trump's leadership, nationalist-populist themes, and the contemporary Republican coalition

## Gift

Belonging, anti-establishment mobilization, and a clear restoration story for supporters.

## Wound / Shadow

Personalist loyalty, exclusionary boundary-making, and attacks on institutional constraint can override pluralism.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use MAGA to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The People Named enters through MAGA. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** Who belongs to the promised restored nation, and who decides?

## Game function

**constraint.** Reveal one hidden dependency connected to MAGA; another player names a countermove. Initiative 2.

## Relationships

- **distributes costs to — Donald Trump:** Donald Trump distributes costs to MAGA by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Trumpism:** MAGA depends on Trumpism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **translates into — Interpretation:** MAGA translates into Interpretation by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **amplifies — Political Humor:** Political Humor amplifies MAGA by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read MAGA from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if MAGA is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
Sentinel factors: current political movement; real person; contested characterization. These are descriptive handoff annotations, not a verdict and not a mutation of Engine Output.

## Visual direction

A text-free enamel expression of MAGA: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Introduction to Political Science](https://openstax.org/details/books/introduction-political-science) — OpenStax, 2022. Comparative institutions, political behavior, and public policy foundations.
- [2024 Republican Party Platform](https://www.presidency.ucsb.edu/documents/2024-republican-party-platform) — Republican National Committee, 2024. Party self-description and program; not an external assessment.
- [Donald J. Trump Platform](https://www.donaldjtrump.com/platform) — Donald J. Trump campaign, 2024. Campaign self-description and policy claims; claims require independent verification.
- [President Donald J. Trump](https://www.whitehouse.gov/administration/donald-j-trump/) — White House, 2026. Official biography and administration self-description; evaluative claims are attributed to the administration.
- [Fascism](https://encyclopedia.ushmm.org/content/en/article/fascism-1) — United States Holocaust Memorial Museum, 2019. Historically bounded definition and features; avoid use as a generic insult.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
