# Drain the Swamp

> Drain the Swamp is mapped as the people named: it constructs a morally charged people against an elite, outsider, or betrayer.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:populism-nationalism:drain-the-swamp` |
| Family | Populism & Nationalism |
| Domain | Ideology |
| Kind | formation |
| Archetypal function | The People Named |
| Epistemic status | synthesis; supported |

## Concrete anchor

Drain the Swamp belongs to the **Populism & Nationalism** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Drain the Swamp constructs a morally charged people against an elite, outsider, or betrayer, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Drain the Swamp, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The People Named.** Drain the Swamp is mapped as the people named: it constructs a morally charged people against an elite, outsider, or betrayer.

## Gift

can mobilize excluded constituencies and challenge unaccountable elites; through Drain the Swamp, that capacity becomes available for deliberate use.

## Wound / Shadow

turns plural societies into one authentic people and scapegoated enemies; Drain the Swamp can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Drain the Swamp to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The People Named enters through Drain the Swamp. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Drain the Swamp becomes the unit of analysis rather than background?

## Game function

**constraint.** Reveal one hidden dependency connected to Drain the Swamp; another player names a countermove. Initiative 2.

## Relationships

- **amplifies — Anti-Elitism:** Anti-Elitism amplifies Drain the Swamp by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **translates into — National Rebirth:** Drain the Swamp translates into National Rebirth by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **counteracts — Rule of Law:** Drain the Swamp counteracts Rule of Law by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **enables — Chicago Seven:** Chicago Seven enables Drain the Swamp by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Drain the Swamp from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Drain the Swamp is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Drain the Swamp: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Introduction to Political Science](https://openstax.org/details/books/introduction-political-science) — OpenStax, 2022. Comparative institutions, political behavior, and public policy foundations.
- [2024 Republican Party Platform](https://www.presidency.ucsb.edu/documents/2024-republican-party-platform) — Republican National Committee, 2024. Party self-description and program; not an external assessment.
- [Donald J. Trump Platform](https://www.donaldjtrump.com/platform) — Donald J. Trump campaign, 2024. Campaign self-description and policy claims; claims require independent verification.
- [President Donald J. Trump](https://www.whitehouse.gov/administration/donald-j-trump/) — White House, 2026. Official biography and administration self-description; evaluative claims are attributed to the administration.
- [Fascism](https://encyclopedia.ushmm.org/content/en/article/fascism-1) — United States Holocaust Memorial Museum, 2019. Historically bounded definition and features; avoid use as a generic insult.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
