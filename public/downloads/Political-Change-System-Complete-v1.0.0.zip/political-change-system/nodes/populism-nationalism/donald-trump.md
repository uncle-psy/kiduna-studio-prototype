# Donald Trump

> the 45th and 47th president of the United States and the central leader around whom the contemporary MAGA coalition formed

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:populism-nationalism:donald-trump` |
| Family | Populism & Nationalism |
| Domain | Ideology |
| Kind | formation |
| Archetypal function | The People Named |
| Epistemic status | synthesis; supported |

## Concrete anchor

Donald Trump belongs to the **Populism & Nationalism** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Donald Trump converts celebrity, personal brand, rallies, direct media communication, party leadership, grievance, nationalist-populist rhetoric, litigation, executive authority, and loyalty into a personalist political formation. Official, supporter, opponent, journalistic, legal, and scholarly claims about him must remain separately attributed.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Donald Trump, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The People Named.** the 45th and 47th president of the United States and the central leader around whom the contemporary MAGA coalition formed

## Gift

For supporters, an unusually direct representative who breaks elite consensus and makes neglected grievances politically decisive.

## Wound / Shadow

Personal loyalty and permanent conflict can displace institutional constraint, plural citizenship, factual correction, and accountability.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Donald Trump to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The People Named enters through Donald Trump. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** Which power belongs to the office, the party, the media ecology, the movement, or the person—and what persists beyond him?

## Game function

**resource.** Reveal one hidden dependency connected to Donald Trump; another player names a countermove. Initiative 3.

## Relationships

- **mobilizes — America First:** America First mobilizes Donald Trump by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **distributes costs to — MAGA:** Donald Trump distributes costs to MAGA by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — The Agitator:** Donald Trump legitimizes The Agitator by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **constrains — Media Capture:** Media Capture constrains Donald Trump by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Donald Trump from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Donald Trump is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
Sentinel factors: current president; real person; contested political characterization; legal and factual claims require date and status. These are descriptive handoff annotations, not a verdict and not a mutation of Engine Output.

## Visual direction

A text-free enamel expression of Donald Trump: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Introduction to Political Science](https://openstax.org/details/books/introduction-political-science) — OpenStax, 2022. Comparative institutions, political behavior, and public policy foundations.
- [2024 Republican Party Platform](https://www.presidency.ucsb.edu/documents/2024-republican-party-platform) — Republican National Committee, 2024. Party self-description and program; not an external assessment.
- [Donald J. Trump Platform](https://www.donaldjtrump.com/platform) — Donald J. Trump campaign, 2024. Campaign self-description and policy claims; claims require independent verification.
- [President Donald J. Trump](https://www.whitehouse.gov/administration/donald-j-trump/) — White House, 2026. Official biography and administration self-description; evaluative claims are attributed to the administration.
- [Fascism](https://encyclopedia.ushmm.org/content/en/article/fascism-1) — United States Holocaust Memorial Museum, 2019. Historically bounded definition and features; avoid use as a generic insult.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
