# Liquid Democracy

> Liquid Democracy is mapped as the prototype: it tests new arrangements for participation, coordination, identity, law, and public intelligence.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:future-governance:liquid-democracy` |
| Family | Future Governance & Political Technology |
| Domain | Futures |
| Kind | technology |
| Archetypal function | The Prototype |
| Epistemic status | synthesis; supported |

## Concrete anchor

Liquid Democracy belongs to the **Future Governance & Political Technology** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Liquid Democracy tests new arrangements for participation, coordination, identity, law, and public intelligence, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Liquid Democracy, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Prototype.** Liquid Democracy is mapped as the prototype: it tests new arrangements for participation, coordination, identity, law, and public intelligence.

## Gift

opens institutional imagination before crisis makes change compulsory; through Liquid Democracy, that capacity becomes available for deliberate use.

## Wound / Shadow

mistakes technical novelty for legitimacy and scales untested assumptions; Liquid Democracy can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Liquid Democracy to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Prototype enters through Liquid Democracy. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Liquid Democracy becomes the unit of analysis rather than background?

## Game function

**resource.** Reveal one hidden dependency connected to Liquid Democracy; another player names a countermove. Initiative 3.

## Relationships

- **constrains — Digital Democracy:** Digital Democracy constrains Liquid Democracy by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — Quadratic Voting:** Liquid Democracy legitimizes Quadratic Voting by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **distributes costs to — School Board:** School Board distributes costs to Liquid Democracy by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **depends on — Citizen Journalism:** Liquid Democracy depends on Citizen Journalism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Liquid Democracy from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Liquid Democracy is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Liquid Democracy: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Guidance for Regulation of Digital Platforms](https://unesdoc.unesco.org/ark:/48223/pf0000387339) — UNESCO, 2023. Platform governance, expression, information integrity, and rights.
- [Electoral System Design: The New International IDEA Handbook](https://www.idea.int/publications/catalogue/electoral-system-design-new-international-idea-handbook) — International IDEA, 2005. Comparative electoral-system design and consequences.
- [Introduction to Political Science](https://openstax.org/details/books/introduction-political-science) — OpenStax, 2022. Comparative institutions, political behavior, and public policy foundations.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
