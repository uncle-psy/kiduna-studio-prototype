# Public Algorithm Register

> Public Algorithm Register is mapped as the prototype: it tests new arrangements for participation, coordination, identity, law, and public intelligence.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:future-governance:public-algorithm-register` |
| Family | Future Governance & Political Technology |
| Domain | Futures |
| Kind | technology |
| Archetypal function | The Prototype |
| Epistemic status | synthesis; supported |

## Concrete anchor

Public Algorithm Register belongs to the **Future Governance & Political Technology** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Public Algorithm Register tests new arrangements for participation, coordination, identity, law, and public intelligence, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Public Algorithm Register, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Prototype.** Public Algorithm Register is mapped as the prototype: it tests new arrangements for participation, coordination, identity, law, and public intelligence.

## Gift

opens institutional imagination before crisis makes change compulsory; through Public Algorithm Register, that capacity becomes available for deliberate use.

## Wound / Shadow

mistakes technical novelty for legitimacy and scales untested assumptions; Public Algorithm Register can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Public Algorithm Register to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Prototype enters through Public Algorithm Register. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Public Algorithm Register becomes the unit of analysis rather than background?

## Game function

**role.** Reveal one hidden dependency connected to Public Algorithm Register; another player names a countermove. Initiative 5.

## Relationships

- **depends on — AI-Assisted Policymaking:** AI-Assisted Policymaking depends on Public Algorithm Register by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **institutionalizes — Civic Simulation:** Public Algorithm Register institutionalizes Civic Simulation by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **enables — Scapegoating:** Scapegoating enables Public Algorithm Register by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **mobilizes — Antitrust:** Public Algorithm Register mobilizes Antitrust by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Public Algorithm Register from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Public Algorithm Register is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Public Algorithm Register: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Guidance for Regulation of Digital Platforms](https://unesdoc.unesco.org/ark:/48223/pf0000387339) — UNESCO, 2023. Platform governance, expression, information integrity, and rights.
- [Electoral System Design: The New International IDEA Handbook](https://www.idea.int/publications/catalogue/electoral-system-design-new-international-idea-handbook) — International IDEA, 2005. Comparative electoral-system design and consequences.
- [Introduction to Political Science](https://openstax.org/details/books/introduction-political-science) — OpenStax, 2022. Comparative institutions, political behavior, and public policy foundations.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
