# Algorithmic Governance

> Algorithmic Governance is mapped as the prototype: it tests new arrangements for participation, coordination, identity, law, and public intelligence.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:future-governance:algorithmic-governance` |
| Family | Future Governance & Political Technology |
| Domain | Futures |
| Kind | technology |
| Archetypal function | The Prototype |
| Epistemic status | synthesis; supported |

## Concrete anchor

Algorithmic Governance belongs to the **Future Governance & Political Technology** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Algorithmic Governance tests new arrangements for participation, coordination, identity, law, and public intelligence, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Algorithmic Governance, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Prototype.** Algorithmic Governance is mapped as the prototype: it tests new arrangements for participation, coordination, identity, law, and public intelligence.

## Gift

opens institutional imagination before crisis makes change compulsory; through Algorithmic Governance, that capacity becomes available for deliberate use.

## Wound / Shadow

mistakes technical novelty for legitimacy and scales untested assumptions; Algorithmic Governance can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Algorithmic Governance to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Prototype enters through Algorithmic Governance. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Algorithmic Governance becomes the unit of analysis rather than background?

## Game function

**leverage.** Reveal one hidden dependency connected to Algorithmic Governance; another player names a countermove. Initiative 1.

## Relationships

- **mobilizes — Decentralized Autonomous Organization:** Decentralized Autonomous Organization mobilizes Algorithmic Governance by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **distributes costs to — AI-Assisted Policymaking:** Algorithmic Governance distributes costs to AI-Assisted Policymaking by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **institutionalizes — Slowdown:** Slowdown institutionalizes Algorithmic Governance by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **translates into — Proxy War:** Algorithmic Governance translates into Proxy War by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Algorithmic Governance from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Algorithmic Governance is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Algorithmic Governance: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Guidance for Regulation of Digital Platforms](https://unesdoc.unesco.org/ark:/48223/pf0000387339) — UNESCO, 2023. Platform governance, expression, information integrity, and rights.
- [Electoral System Design: The New International IDEA Handbook](https://www.idea.int/publications/catalogue/electoral-system-design-new-international-idea-handbook) — International IDEA, 2005. Comparative electoral-system design and consequences.
- [Introduction to Political Science](https://openstax.org/details/books/introduction-political-science) — OpenStax, 2022. Comparative institutions, political behavior, and public policy foundations.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
