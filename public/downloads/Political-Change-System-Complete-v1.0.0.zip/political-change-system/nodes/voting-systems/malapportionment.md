# Malapportionment

> Malapportionment is mapped as the count: it translates votes into offices and thereby shapes parties, coalitions, and strategic behavior.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:voting-systems:malapportionment` |
| Family | Voting Systems & Districts |
| Domain | Elections |
| Kind | mechanism |
| Archetypal function | The Count |
| Epistemic status | synthesis; supported |

## Concrete anchor

Malapportionment belongs to the **Voting Systems & Districts** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Malapportionment translates votes into offices and thereby shapes parties, coalitions, and strategic behavior, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Malapportionment, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Count.** Malapportionment is mapped as the count: it translates votes into offices and thereby shapes parties, coalitions, and strategic behavior.

## Gift

can broaden representation and make preferences legible; through Malapportionment, that capacity becomes available for deliberate use.

## Wound / Shadow

creates mechanical distortions that voters experience as natural; Malapportionment can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Malapportionment to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Count enters through Malapportionment. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Malapportionment becomes the unit of analysis rather than background?

## Game function

**constraint.** Reveal one hidden dependency connected to Malapportionment; another player names a countermove. Initiative 2.

## Relationships

- **counteracts — Gerrymandering:** Gerrymandering counteracts Malapportionment by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **amplifies — Majority-Minority District:** Malapportionment amplifies Majority-Minority District by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **mobilizes — Gaza War:** Malapportionment mobilizes Gaza War by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **distributes costs to — Conservatism:** Conservatism distributes costs to Malapportionment by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Malapportionment from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Malapportionment is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Malapportionment: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Electoral System Design: The New International IDEA Handbook](https://www.idea.int/publications/catalogue/electoral-system-design-new-international-idea-handbook) — International IDEA, 2005. Comparative electoral-system design and consequences.
- [Redistricting Law 2020](https://www.ncsl.org/redistricting-and-census/redistricting-law-2020) — National Conference of State Legislatures, 2020. U.S. redistricting institutions, rules, and litigation.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
