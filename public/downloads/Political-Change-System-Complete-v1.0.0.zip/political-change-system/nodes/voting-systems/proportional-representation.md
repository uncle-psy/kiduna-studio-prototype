# Proportional Representation

> Proportional Representation is mapped as the count: it translates votes into offices and thereby shapes parties, coalitions, and strategic behavior.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:voting-systems:proportional-representation` |
| Family | Voting Systems & Districts |
| Domain | Elections |
| Kind | mechanism |
| Archetypal function | The Count |
| Epistemic status | synthesis; supported |

## Concrete anchor

Proportional Representation belongs to the **Voting Systems & Districts** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Proportional Representation translates votes into offices and thereby shapes parties, coalitions, and strategic behavior, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Proportional Representation, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Count.** Proportional Representation is mapped as the count: it translates votes into offices and thereby shapes parties, coalitions, and strategic behavior.

## Gift

can broaden representation and make preferences legible; through Proportional Representation, that capacity becomes available for deliberate use.

## Wound / Shadow

creates mechanical distortions that voters experience as natural; Proportional Representation can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Proportional Representation to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Count enters through Proportional Representation. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Proportional Representation becomes the unit of analysis rather than background?

## Game function

**resource.** Reveal one hidden dependency connected to Proportional Representation; another player names a countermove. Initiative 3.

## Relationships

- **depends on — First-Past-the-Post:** First-Past-the-Post depends on Proportional Representation by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **institutionalizes — Mixed-Member Proportional:** Proportional Representation institutionalizes Mixed-Member Proportional by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **legitimizes — Representative Democracy:** Representative Democracy legitimizes Proportional Representation by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **translates into — Social Democracy:** Proportional Representation translates into Social Democracy by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Proportional Representation from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Proportional Representation is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Proportional Representation: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Electoral System Design: The New International IDEA Handbook](https://www.idea.int/publications/catalogue/electoral-system-design-new-international-idea-handbook) — International IDEA, 2005. Comparative electoral-system design and consequences.
- [Redistricting Law 2020](https://www.ncsl.org/redistricting-and-census/redistricting-law-2020) — National Conference of State Legislatures, 2020. U.S. redistricting institutions, rules, and litigation.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
