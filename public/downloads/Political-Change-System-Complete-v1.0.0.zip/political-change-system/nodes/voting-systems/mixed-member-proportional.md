# Mixed-Member Proportional

> Mixed-Member Proportional is mapped as the count: it translates votes into offices and thereby shapes parties, coalitions, and strategic behavior.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:voting-systems:mixed-member-proportional` |
| Family | Voting Systems & Districts |
| Domain | Elections |
| Kind | mechanism |
| Archetypal function | The Count |
| Epistemic status | synthesis; supported |

## Concrete anchor

Mixed-Member Proportional belongs to the **Voting Systems & Districts** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Mixed-Member Proportional translates votes into offices and thereby shapes parties, coalitions, and strategic behavior, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Mixed-Member Proportional, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Count.** Mixed-Member Proportional is mapped as the count: it translates votes into offices and thereby shapes parties, coalitions, and strategic behavior.

## Gift

can broaden representation and make preferences legible; through Mixed-Member Proportional, that capacity becomes available for deliberate use.

## Wound / Shadow

creates mechanical distortions that voters experience as natural; Mixed-Member Proportional can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Mixed-Member Proportional to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Count enters through Mixed-Member Proportional. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Mixed-Member Proportional becomes the unit of analysis rather than background?

## Game function

**resource.** Reveal one hidden dependency connected to Mixed-Member Proportional; another player names a countermove. Initiative 3.

## Relationships

- **institutionalizes — Proportional Representation:** Proportional Representation institutionalizes Mixed-Member Proportional by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **counteracts — Ranked-Choice Voting:** Mixed-Member Proportional counteracts Ranked-Choice Voting by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **institutionalizes — Communitarianism:** Mixed-Member Proportional institutionalizes Communitarianism by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **translates into — Matching Funds:** Matching Funds translates into Mixed-Member Proportional by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Mixed-Member Proportional from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Mixed-Member Proportional is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Mixed-Member Proportional: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Electoral System Design: The New International IDEA Handbook](https://www.idea.int/publications/catalogue/electoral-system-design-new-international-idea-handbook) — International IDEA, 2005. Comparative electoral-system design and consequences.
- [Redistricting Law 2020](https://www.ncsl.org/redistricting-and-census/redistricting-law-2020) — National Conference of State Legislatures, 2020. U.S. redistricting institutions, rules, and litigation.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
