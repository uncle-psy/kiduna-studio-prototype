# Negotiated Settlement

> Negotiated Settlement is mapped as the broken bargain: it moves political conflict into organized force, deterrence, negotiation, or settlement.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:war-peace:negotiated-settlement` |
| Family | War, Peace & Settlement |
| Domain | Conflict |
| Kind | process |
| Archetypal function | The Broken Bargain |
| Epistemic status | synthesis; supported |

## Concrete anchor

Negotiated Settlement belongs to the **War, Peace & Settlement** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Negotiated Settlement moves political conflict into organized force, deterrence, negotiation, or settlement, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Negotiated Settlement, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Broken Bargain.** Negotiated Settlement is mapped as the broken bargain: it moves political conflict into organized force, deterrence, negotiation, or settlement.

## Gift

can resist aggression and protect communities when other means fail; through Negotiated Settlement, that capacity becomes available for deliberate use.

## Wound / Shadow

destroys lives, institutions, truth, and the future while empowering coercive organizations; Negotiated Settlement can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Negotiated Settlement to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Broken Bargain enters through Negotiated Settlement. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Negotiated Settlement becomes the unit of analysis rather than background?

## Game function

**resource.** Reveal one hidden dependency connected to Negotiated Settlement; another player names a countermove. Initiative 3.

## Relationships

- **distributes costs to — Peace Process:** Peace Process distributes costs to Negotiated Settlement by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Power Sharing:** Negotiated Settlement depends on Power Sharing by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **enables — People Power Revolution:** People Power Revolution enables Negotiated Settlement by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **constrains — Failure:** Negotiated Settlement constrains Failure by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Negotiated Settlement from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Negotiated Settlement is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Negotiated Settlement: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Charter of the United Nations](https://www.un.org/en/about-us/un-charter/full-text) — United Nations, 1945. International institutional order, sovereignty, security, and cooperation.
- [Rome Statute of the International Criminal Court](https://www.icc-cpi.int/sites/default/files/Publications/Rome-Statute.pdf) — International Criminal Court, 1998. International criminal jurisdiction and definitions.
- [United Nations Peacekeeping](https://peacekeeping.un.org/en) — United Nations, ongoing. Mission, mandates, operations, and limitations from the institution's perspective.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
