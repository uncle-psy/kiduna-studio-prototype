# Black Lives Matter

> Black Lives Matter is mapped as the unfinished promise: it forces formal equality, lived dignity, and unequal state power into public contest.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:civil-rights-racial-justice:black-lives-matter` |
| Family | Civil Rights & Racial Justice |
| Domain | Rights |
| Kind | movement |
| Archetypal function | The Unfinished Promise |
| Epistemic status | synthesis; supported |

## Concrete anchor

Black Lives Matter belongs to the **Civil Rights & Racial Justice** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Black Lives Matter forces formal equality, lived dignity, and unequal state power into public contest, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Black Lives Matter, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Unfinished Promise.** Black Lives Matter is mapped as the unfinished promise: it forces formal equality, lived dignity, and unequal state power into public contest.

## Gift

expands membership, rights, and democratic participation; through Black Lives Matter, that capacity becomes available for deliberate use.

## Wound / Shadow

invites co-optation, backlash, symbolic inclusion, or selective memory; Black Lives Matter can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Black Lives Matter to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Unfinished Promise enters through Black Lives Matter. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Black Lives Matter becomes the unit of analysis rather than background?

## Game function

**role.** Reveal one hidden dependency connected to Black Lives Matter; another player names a countermove. Initiative 5.

## Relationships

- **counteracts — Black Panther Party:** Black Panther Party counteracts Black Lives Matter by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **amplifies — Movement for Black Lives:** Black Lives Matter amplifies Movement for Black Lives by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **translates into — Critical Theory:** Critical Theory translates into Black Lives Matter by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **distributes costs to — America First:** Black Lives Matter distributes costs to America First by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Black Lives Matter from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Black Lives Matter is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Black Lives Matter: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Civil Rights History Project](https://www.loc.gov/collections/civil-rights-history-project/) — Library of Congress and Smithsonian, ongoing. Participant accounts of the U.S. civil-rights movement.
- [Letter from Birmingham Jail](https://kinginstitute.stanford.edu/king-papers/documents/letter-birmingham-jail) — Martin Luther King, Jr. Research and Education Institute, 1963. Direct action, constructive tension, law, justice, and timing.
- [Universal Declaration of Human Rights](https://www.un.org/en/about-us/universal-declaration-of-human-rights) — United Nations, 1948. International human-rights framework.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
