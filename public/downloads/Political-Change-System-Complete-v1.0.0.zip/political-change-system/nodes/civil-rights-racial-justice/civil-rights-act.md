# Civil Rights Act

> Civil Rights Act is mapped as the unfinished promise: it forces formal equality, lived dignity, and unequal state power into public contest.

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:political-change:civil-rights-racial-justice:civil-rights-act` |
| Family | Civil Rights & Racial Justice |
| Domain | Rights |
| Kind | movement |
| Archetypal function | The Unfinished Promise |
| Epistemic status | synthesis; supported |

## Concrete anchor

Civil Rights Act belongs to the **Civil Rights & Racial Justice** family. It is treated as a specific political object, role, institution, tactic, event, ideology, or mechanism before any symbolic transfer is made.

## What it does

Civil Rights Act forces formal equality, lived dignity, and unequal state power into public contest, changing who can act, what becomes visible, and which costs are distributed to others.

## Who gains and who loses power

The mechanism can increase the capacity of actors able to use Civil Rights Act, while shifting cost, delay, risk, exclusion, or dependence toward actors with less authority, information, organization, money, or safe access. The distribution is conditional, not an essence of the node.

## Archetypal function

**The Unfinished Promise.** Civil Rights Act is mapped as the unfinished promise: it forces formal equality, lived dignity, and unequal state power into public contest.

## Gift

expands membership, rights, and democratic participation; through Civil Rights Act, that capacity becomes available for deliberate use.

## Wound / Shadow

invites co-optation, backlash, symbolic inclusion, or selective memory; Civil Rights Act can then reproduce the very arrangement it claims to change.

## Conditions

- scale and jurisdiction are explicit
- affected people and absent stakeholders are named
- time horizon and countermoves are considered

## Strategic meaning

Use Civil Rights Act to identify the operative target, resource, dependency, decision forum, and likely countermove. Ask what would make the mechanism stronger, weaker, more legitimate, or less necessary.

## Divinatory meaning

The Unfinished Promise enters through Civil Rights Act. Read for the capacity seeking expression, the cost displaced from view, and the relationship that changes if the frame moves.

**Question:** What changes when Civil Rights Act becomes the unit of analysis rather than background?

## Game function

**role.** Reveal one hidden dependency connected to Civil Rights Act; another player names a countermove. Initiative 5.

## Relationships

- **distributes costs to — Voting Rights Act:** Voting Rights Act distributes costs to Civil Rights Act by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **depends on — Black Power:** Civil Rights Act depends on Black Power by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(synthesis; supported)_
- **mobilizes — Digital Organizing:** Civil Rights Act mobilizes Digital Organizing by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_
- **distributes costs to — Interest:** Interest distributes costs to Civil Rights Act by changing authority, participation, resources, information, legitimacy, timing, or the cost of cooperation. _(interpretive; tentative)_

## Countermaps and polarity prompts

- Read Civil Rights Act from the viewpoint of the actor who bears its cost.
- Reverse cause and symptom: what if Civil Rights Act is an effect of the system it appears to drive?
- Change the clock: what looks different over a day, an election cycle, a generation, and a century?
- Ask when the Gift becomes the Wound through scale, secrecy, intensity, latency, or unequal reciprocity.

## Epistemic and Sentinel note

Claim layers: synthesis, interpretive, symbolic_divinatory. Scope, jurisdiction, period, and source perspective may change the claim.
No node-specific Sentinel factors were recorded; ordinary source, audience, and context checks still apply.

## Visual direction

A text-free enamel expression of Civil Rights Act: one dominant mechanism, one counterforce, raised warm-metal linework, midnight field, restrained civic red, teal, ivory, and amber. No party logo, national flag, sacred symbol, or recognizable person.

## Research / provenance

- [Civil Rights History Project](https://www.loc.gov/collections/civil-rights-history-project/) — Library of Congress and Smithsonian, ongoing. Participant accounts of the U.S. civil-rights movement.
- [Letter from Birmingham Jail](https://kinginstitute.stanford.edu/king-papers/documents/letter-birmingham-jail) — Martin Luther King, Jr. Research and Education Institute, 1963. Direct action, constructive tension, law, justice, and timing.
- [Universal Declaration of Human Rights](https://www.un.org/en/about-us/universal-declaration-of-human-rights) — United Nations, 1948. International human-rights framework.

---

Engine Output version 1.0.0; generated 2026-08-24T00:00:00Z. Sentinel annotations are stored separately in `sentinel/handoffs.json`.
