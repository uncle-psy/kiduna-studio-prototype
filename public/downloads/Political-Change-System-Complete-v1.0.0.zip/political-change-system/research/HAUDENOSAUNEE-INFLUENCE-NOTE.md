# Haudenosaunee Influence Note

The Haudenosaunee Confederacy and Great Law of Peace are living Indigenous political traditions, not prefaces to the U.S. Constitution. Documented diplomatic interaction, colonial observation, later congressional acknowledgment, and scholarly claims of direct constitutional influence are different kinds of evidence. The package marks the degree and route of influence as contested while treating encounter and admiration as historically grounded. Contemporary Haudenosaunee sources are primary for self-description.
