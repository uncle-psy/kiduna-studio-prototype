# Current Topics Research Note

Freshness date: **2026-08-24**.

No Kings and Indivisible are recorded as current U.S. pro-democracy/resistance formations through coalition and organization sources. Participation numbers are not silently converted from organizer estimates into established counts. ICE is described through the agency's mission alongside ACLU findings and litigation-oriented civil-liberties criticism. Anti-ICE activism is not treated as one organization.

MAGA is described through Republican and Trump campaign primary sources plus mechanism-level synthesis. The package does not equate MAGA, conservatism, authoritarianism, fascism, QAnon, or violent extremism. Connections among them must be typed and conditional. QAnon is recorded as a conspiracy movement; protected belief is distinguished from unlawful violence.

Current entries should be reviewed before operational, journalistic, or legal use. The package is an educational and strategic map, not a live news service.
