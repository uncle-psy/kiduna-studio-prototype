# Extremism Classification Note

The package avoids using “extremist” as a synonym for disliked politics. U.S. government domestic-violent-extremism categories concern unlawful force or violence in pursuit of political or social goals; the FBI states that protected speech, protest, association, and political activity are not investigated as terrorism solely for their content.

Fascism is treated as a historically grounded comparative concept, not a generic insult. White supremacy, neo-Nazism, accelerationism, militia movements, sovereign-citizen movements, QAnon, religious extremism, and lone-actor violence are separate nodes because ideology, organization, belief, and conduct differ.
