# Israel / Palestine Claim Map

The system preserves multiple maps without treating every proposition as equally evidenced. It distinguishes Israeli and Palestinian peoples; governments and armed groups; civilians and combatants; Israel, Gaza, the West Bank, and East Jerusalem; 1948, 1967, Oslo, 7 October 2023, the ensuing war, and later developments.

Source roles are explicit: the United Nations provides an institutional history and humanitarian reporting; Israel's Ministry of Foreign Affairs provides a party-government legal position; the ICJ record provides an advisory opinion and case documents; other legal proceedings have their own procedural status. The system does not convert allegation into final judgment or government denial into disproof.

Antisemitism, anti-Palestinian racism, Islamophobia, hostage suffering, Palestinian civilian harm, security, occupation, self-determination, settlement, blockade, armed resistance, terrorism, and international law are distinct nodes. Users should identify the exact claim, speaker, affected population, territory, period, and legal status.
