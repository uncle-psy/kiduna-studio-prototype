# Residual Limitations

This edition is unusually broad, not exhaustive. The curated core has uneven depth: goal-specified and contested nodes receive bespoke treatment, while many long-tail nodes use family-level mechanism templates and system-level sources. A truly definitive global political corpus would require multilingual regional experts, community review, case-specific bibliographies, archival work, live legal updating, and ongoing versioned maintenance.

Current information is frozen at 2026-08-24. The static site is dependency-free and intentionally simple; it is not a graph database or accessibility-audited production application. Generated enamel art is a design reference, not manufacturing-ready color separation. These limits are documented rather than concealed.
