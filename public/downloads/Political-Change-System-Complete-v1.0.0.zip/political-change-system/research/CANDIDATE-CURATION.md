# Candidate Curation

The ledger contains 4672 evaluated candidates. The 1168 selected-core records were retained because each supplies a distinct mechanism, object, institution, event, ideology, role, lineage, or interpretive lens and supports at least one required use. Three systematic variants per core node remain visible as facets, expansion reservations, or evidence-deferred crisis hypotheses.

Scores are deterministic editorial heuristics, not objective political importance. Selection required a minimum floor for political significance, connectivity, and distinctiveness; the rationale and lineage remain in each record. No candidate was deleted because of intensity, ideology, cultural specificity, or a Sentinel factor.
