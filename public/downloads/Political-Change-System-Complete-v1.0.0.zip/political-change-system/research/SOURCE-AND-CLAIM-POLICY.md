# Source and Claim Policy

Primary law, official archives, party and movement self-descriptions, institutional data, scholarship, advocacy research, and interpretive synthesis are kept distinct. A citation does not upgrade a metaphor or synthesis into fact. Government and organizational sources establish their own positions and records, not neutral truth about every disputed question.

Each current or contested claim should identify date, source perspective, record type, jurisdiction, and uncertainty. Crowd estimates, casualty figures, threat labels, legal allegations, and analytical classifications require special attribution. Stable edges cite sources and carry claim layer, confidence, perspective, conditions, and mechanism.
