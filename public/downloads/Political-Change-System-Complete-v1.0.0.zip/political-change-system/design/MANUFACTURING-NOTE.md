# Manufacturing Note

The included SVGs and raster proof sheet are reference artifacts. Before physical enamel manufacture, a production artist must simplify cell geometry, specify plating, Pantone or enamel equivalents, minimum channel widths, clutch placement, bleed, mold tolerances, and safety compliance. Do not treat generated highlights or microtexture as literal metal geometry.
