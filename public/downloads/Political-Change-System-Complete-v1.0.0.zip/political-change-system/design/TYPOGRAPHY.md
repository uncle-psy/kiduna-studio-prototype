# Typography

The master art is text-free. Interface titles use a sturdy humanist sans; body text uses an accessible serif or sans with 1.55 line height. Epistemic labels appear as plain language, not color-only badges. Minimum browser text 16 px.
