# Accessibility

Every visual requires alt text naming the mechanism, not merely the object. Interactions must be keyboard reachable; graph meaning must also be available as lists and detail text. Motion is optional and disabled by reduced-motion preference. Contrast is tested against WCAG AA targets; color is redundant with labels and shape.
