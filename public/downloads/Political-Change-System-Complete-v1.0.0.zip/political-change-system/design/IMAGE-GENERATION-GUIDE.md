# Image Generation Guide

Generate original abstract political mechanisms. Do not depict real people or protected symbols. Prompt structure: intended expression; concrete mechanism; one counterforce; enamel materials; composition; lighting; palette; prohibited elements. Human review must check unintended flags, letters, sacred forms, stereotypes, weapon glamorization, and false historical cues.
