# Color

- Midnight field #071426 — latent structure and unknown depth
- Antique brass #C69A45 — connection, office, constraint
- Oxidized teal #2E756F — distributed capacity and renewal
- Civic red #A63D35 — conflict, urgency, cost
- Parchment ivory #E8DFC5 — memory, record, public reason
- Amber #E0A43A — legitimacy, attention, possibility
- Charcoal #171A20 — boundary and uncertainty

Color never encodes truth, virtue, party, ethnicity, or legal status by itself.
