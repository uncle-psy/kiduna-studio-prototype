# Visual Constitution

The visual system expresses political mechanisms without endorsing a party, state, movement, religion, or leader. Every piece has one dominant mechanism and at most one counterforce. Meaning must survive monochrome and 96-pixel display. Raised warm metal indicates structured relation; enamel fields indicate distinct capacities; breaks, gates, channels, knots, balances, and withdrawals show mechanism.

Forbidden defaults: party logos, national flags, campaign slogans, protected marks, recognizable politicians, sacred or Indigenous motifs, uniforms copied from extremist groups, generic occult geometry, decorative weapons, and evidentiary badges baked into art. Text, title, claim status, and provenance remain live interface layers.
