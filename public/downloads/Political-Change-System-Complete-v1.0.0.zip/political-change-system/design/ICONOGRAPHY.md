# Iconography

Use mechanisms: many hands supporting an arch; gears halted by withdrawal; nested gates constraining a surge; a braided coalition with visible seams; a lens revealing the funder's path; a bridge with asymmetric loads; a public record entering a chamber; a pillar losing an internal support. Avoid portraits and tokenized cultural imagery.
