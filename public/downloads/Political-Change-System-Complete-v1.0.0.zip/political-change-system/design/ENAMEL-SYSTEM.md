# Enamel System

Master form: vertical 2:3 card, 2048 × 3072 px raster target; vector reference uses the same safe area. Border 4.5% of width; motif safe area 12%; minimum metal line 1.2% at master scale. Materials: vitreous midnight enamel, antique brass, oxidized teal, restrained civic red, parchment ivory, and amber.

Lighting is top-left, sober, museum-like. Microtexture may show material age but may not simulate archival authenticity. Files include expression ID, version, form, dimensions, variant, rights state, prompt/source, tool, date, and SHA-256 checksum.
