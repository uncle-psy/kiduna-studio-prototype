# Open House

> Open House coordinates discovery, negotiation, commitment, and transfer

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:listing-transaction:open-house` |
| Family | Listing & Transaction |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | place-or-property |
| Archetype | The Vessel |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Open House is a place or property in the Listing & Transaction family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Open House coordinates discovery, negotiation, commitment, and transfer.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Open House coordinates discovery, negotiation, commitment, and transfer
- **Gift:** Clarity about open house makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When open house is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when open house is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where open house appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Open House reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Open House changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Open House changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Open House can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Vessel enters the reading through Open House. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What relationships become visible when Open House is treated as a place rather than only an asset?

**Guidance:** Walk the physical, legal, financial, ecological, and human maps separately before recombining them.

## Game function

Occupies spatial capacity and generates use, cost, externality, identity, or cash flow. Initiative 4.

## Relationships

- **Subdivision Map documents Open House.** Subdivision Map documents Open House through a change in rights, information, cash flow, priority, timing, or physical use.
- **Showing is evidenced by Open House.** Showing is evidenced by Open House through a change in rights, information, cash flow, priority, timing, or physical use.
- **Open House is administered through Offer.** Open House is administered through Offer through a change in rights, information, cash flow, priority, timing, or physical use.
- **Open House transfers into Phase I ESA.** Open House transfers into Phase I ESA through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Open House through the lineage of Listing & Transaction: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Open House: a tactile architectural environment rendered in deep enamel, stone, vegetation, water, and fine metal lines; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [How to Buy a Home](https://www.gov.uk/government/publications/how-to-buy-a-home/how-to-buy) — Government of the United Kingdom; homebuying, tenure, searches, surveys, exchange, completion.
