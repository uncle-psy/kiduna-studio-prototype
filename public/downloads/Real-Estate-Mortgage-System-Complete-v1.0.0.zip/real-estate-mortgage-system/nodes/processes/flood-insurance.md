# Flood Insurance

> Flood Insurance tests whether the property can support the legal, physical, and market assumptions of the loan

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:collateral-underwriting:flood-insurance` |
| Family | Collateral Underwriting |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Tension |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Flood Insurance is a concept in the Collateral Underwriting family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Flood Insurance tests whether the property can support the legal, physical, and market assumptions of the loan.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Flood Insurance tests whether the property can support the legal, physical, and market assumptions of the loan
- **Gift:** Clarity about flood insurance makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When flood insurance is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when flood insurance is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where flood insurance appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Flood Insurance reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Flood Insurance changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Flood Insurance changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Flood Insurance can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tension enters the reading through Flood Insurance. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Flood Insurance becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 4.

## Relationships

- **Assets depends on Flood Insurance.** Assets depends on Flood Insurance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Property Insurance is evidenced by Flood Insurance.** Property Insurance is evidenced by Flood Insurance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Flood Insurance is administered through Mortgage Insurance.** Flood Insurance is administered through Mortgage Insurance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Flood Insurance constrains Notary.** Flood Insurance constrains Notary through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Flood Insurance through the lineage of Collateral Underwriting: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Flood Insurance: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Uniform Standards of Professional Appraisal Practice](https://appraisalfoundation.org/pages/uspap) — The Appraisal Foundation; appraisal ethics, development, reporting, review.
