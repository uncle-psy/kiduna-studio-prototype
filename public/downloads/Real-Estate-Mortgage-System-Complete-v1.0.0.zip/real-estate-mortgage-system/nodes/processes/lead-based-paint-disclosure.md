# Lead-Based Paint Disclosure

> Lead-Based Paint Disclosure reduces uncertainty before capital and authority become difficult to reverse

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:due-diligence:lead-based-paint-disclosure` |
| Family | Due Diligence & Inspection |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | record-or-instrument |
| Archetype | The Seal |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Lead-Based Paint Disclosure is a record or instrument in the Due Diligence & Inspection family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Lead-Based Paint Disclosure reduces uncertainty before capital and authority become difficult to reverse.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** borrower, lender, title professional, attorney, custodian, recorder
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** durable evidence, priority, notice, transferability
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Lead-Based Paint Disclosure reduces uncertainty before capital and authority become difficult to reverse
- **Gift:** Clarity about lead-based paint disclosure makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When lead-based paint disclosure is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when lead-based paint disclosure is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where lead-based paint disclosure appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Lead-Based Paint Disclosure reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Lead-Based Paint Disclosure changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Lead-Based Paint Disclosure changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Lead-Based Paint Disclosure can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Seal enters the reading through Lead-Based Paint Disclosure. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What must Lead-Based Paint Disclosure make durable before you can safely proceed?

**Guidance:** Resolve provenance, authority, custody, and ambiguity before relying on the artifact.

## Game function

Provides Evidence or Authority; missing custody or a defect blocks transfer. Initiative 4.

## Relationships

- **Seller Concession transfers into Lead-Based Paint Disclosure.** Seller Concession transfers into Lead-Based Paint Disclosure through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mold Assessment externalizes to Lead-Based Paint Disclosure.** Mold Assessment externalizes to Lead-Based Paint Disclosure through a change in rights, information, cash flow, priority, timing, or physical use.
- **Lead-Based Paint Disclosure amplifies Flood Determination.** Lead-Based Paint Disclosure amplifies Flood Determination through a change in rights, information, cash flow, priority, timing, or physical use.
- **Lead-Based Paint Disclosure is governed by Broker Price Opinion.** Lead-Based Paint Disclosure is governed by Broker Price Opinion through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Lead-Based Paint Disclosure through the lineage of Due Diligence & Inspection: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Lead-Based Paint Disclosure: engraved layers, signatures, parcel geometry, seals, and custody marks held inside a precise brass frame; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [Risk-Based Brownfields Cleanups](https://www.epa.gov/brownfields/risk-based-brownfields-cleanups) — U.S. Environmental Protection Agency; contamination, remediation, reuse, institutional controls.
