# Uniform Residential Loan Application

> Uniform Residential Loan Application turns borrower intent into a documented, priced loan file

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:origination:uniform-residential-loan-application` |
| Family | Mortgage Origination |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | financial-instrument |
| Archetype | The Promise |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Uniform Residential Loan Application is a financial instrument in the Mortgage Origination family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Uniform Residential Loan Application turns borrower intent into a documented, priced loan file.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Uniform Residential Loan Application turns borrower intent into a documented, priced loan file
- **Gift:** Clarity about uniform residential loan application makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When uniform residential loan application is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when uniform residential loan application is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where uniform residential loan application appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Uniform Residential Loan Application reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Uniform Residential Loan Application changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Uniform Residential Loan Application changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Uniform Residential Loan Application can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Promise enters the reading through Uniform Residential Loan Application. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Uniform Residential Loan Application, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 3.

## Relationships

- **Debt-Service-Coverage-Ratio Loan externalizes to Uniform Residential Loan Application.** Debt-Service-Coverage-Ratio Loan externalizes to Uniform Residential Loan Application through a change in rights, information, cash flow, priority, timing, or physical use.
- **Preapproval prices Uniform Residential Loan Application.** Preapproval prices Uniform Residential Loan Application through a change in rights, information, cash flow, priority, timing, or physical use.
- **Uniform Residential Loan Application documents Application.** Uniform Residential Loan Application documents Application through a change in rights, information, cash flow, priority, timing, or physical use.
- **Uniform Residential Loan Application amplifies Credit Report.** Uniform Residential Loan Application amplifies Credit Report through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Uniform Residential Loan Application through the lineage of Mortgage Origination: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Uniform Residential Loan Application: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [MISMO Standards & Resources](https://www.mismo.org/standards-resources) — Mortgage Industry Standards Maintenance Organization; residential and commercial mortgage data standards.
