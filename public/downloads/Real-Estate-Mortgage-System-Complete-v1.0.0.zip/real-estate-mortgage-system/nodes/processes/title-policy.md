# Title Policy

> Title Policy tests whether the property can support the legal, physical, and market assumptions of the loan

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:collateral-underwriting:title-policy` |
| Family | Collateral Underwriting |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | record-or-instrument |
| Archetype | The Memory |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Title Policy is a record or instrument in the Collateral Underwriting family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Title Policy tests whether the property can support the legal, physical, and market assumptions of the loan.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** borrower, lender, title professional, attorney, custodian, recorder
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** durable evidence, priority, notice, transferability
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Title Policy tests whether the property can support the legal, physical, and market assumptions of the loan
- **Gift:** Clarity about title policy makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When title policy is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when title policy is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where title policy appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Title Policy reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Title Policy changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Title Policy changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Title Policy can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Memory enters the reading through Title Policy. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What must Title Policy make durable before you can safely proceed?

**Guidance:** Resolve provenance, authority, custody, and ambiguity before relying on the artifact.

## Game function

Provides Evidence or Authority; missing custody or a defect blocks transfer. Initiative 2.

## Relationships

- **Reserves is governed by Title Policy.** Reserves is governed by Title Policy through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mortgage Insurance depends on Title Policy.** Mortgage Insurance depends on Title Policy through a change in rights, information, cash flow, priority, timing, or physical use.
- **Title Policy constrains Collateral Underwriter.** Title Policy constrains Collateral Underwriter through a change in rights, information, cash flow, priority, timing, or physical use.
- **Title Policy externalizes to Initial Escrow Statement.** Title Policy externalizes to Initial Escrow Statement through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Title Policy through the lineage of Collateral Underwriting: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Title Policy: engraved layers, signatures, parcel geometry, seals, and custody marks held inside a precise brass frame; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Uniform Standards of Professional Appraisal Practice](https://appraisalfoundation.org/pages/uspap) — The Appraisal Foundation; appraisal ethics, development, reporting, review.
