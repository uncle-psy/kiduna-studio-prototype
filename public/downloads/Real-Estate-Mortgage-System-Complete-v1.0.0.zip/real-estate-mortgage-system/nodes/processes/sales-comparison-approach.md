# Sales Comparison Approach

> Sales Comparison Approach translates a unique property into a supportable opinion of value

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:appraisal-valuation:sales-comparison-approach` |
| Family | Appraisal & Valuation |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Relation |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Sales Comparison Approach is a concept in the Appraisal & Valuation family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Sales Comparison Approach translates a unique property into a supportable opinion of value.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Sales Comparison Approach translates a unique property into a supportable opinion of value
- **Gift:** Clarity about sales comparison approach makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When sales comparison approach is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when sales comparison approach is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where sales comparison approach appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Sales Comparison Approach reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Sales Comparison Approach changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Sales Comparison Approach changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Sales Comparison Approach can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Relation enters the reading through Sales Comparison Approach. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Sales Comparison Approach becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 4.

## Relationships

- **Phase I ESA is governed by Sales Comparison Approach.** Phase I ESA is governed by Sales Comparison Approach through a change in rights, information, cash flow, priority, timing, or physical use.
- **Highest and Best Use depends on Sales Comparison Approach.** Highest and Best Use depends on Sales Comparison Approach through a change in rights, information, cash flow, priority, timing, or physical use.
- **Sales Comparison Approach constrains Income Approach.** Sales Comparison Approach constrains Income Approach through a change in rights, information, cash flow, priority, timing, or physical use.
- **Sales Comparison Approach externalizes to Adjustable-Rate Mortgage.** Sales Comparison Approach externalizes to Adjustable-Rate Mortgage through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Market Value versus Meaning
- Standardization versus Uniqueness

## Historical lineage and regulatory context

Read Sales Comparison Approach through the lineage of Appraisal & Valuation: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Sales Comparison Approach: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Uniform Standards of Professional Appraisal Practice](https://appraisalfoundation.org/pages/uspap) — The Appraisal Foundation; appraisal ethics, development, reporting, review.
- [Quality Control Standards for Automated Valuation Models](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/quality-control-standards-for-automated-valuation-models/) — Consumer Financial Protection Bureau; AVM controls and valuation technology.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
