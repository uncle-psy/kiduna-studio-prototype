# Promissory Note

> Promissory Note turns negotiated terms into executed, funded, and transferable obligations

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:closing-disclosures:promissory-note` |
| Family | Closing & Disclosures |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | record-or-instrument |
| Archetype | The Memory |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

A borrower's written promise to repay a debt according to stated principal, interest, timing, and default terms.

## What it actually does

Creates the payment obligation that the mortgage or deed of trust secures.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** borrower, lender, title professional, attorney, custodian, recorder
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** durable evidence, priority, notice, transferability
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Promissory Note turns negotiated terms into executed, funded, and transferable obligations
- **Gift:** Clarity about promissory note makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When promissory note is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when promissory note is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where promissory note appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Promissory Note reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Promissory Note changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Promissory Note changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Promissory Note can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Memory enters the reading through Promissory Note. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What must Promissory Note make durable before you can safely proceed?

**Guidance:** Resolve provenance, authority, custody, and ambiguity before relying on the artifact.

## Game function

Provides Evidence or Authority; missing custody or a defect blocks transfer. Initiative 2.

## Relationships

- **Combined Loan-to-Value Ratio externalizes to Promissory Note.** Combined Loan-to-Value Ratio externalizes to Promissory Note through a change in rights, information, cash flow, priority, timing, or physical use.
- **Closing Disclosure transfers into Promissory Note.** Closing Disclosure transfers into Promissory Note through a change in rights, information, cash flow, priority, timing, or physical use.
- **Promissory Note is governed by Security Instrument.** Promissory Note is governed by Security Instrument through a change in rights, information, cash flow, priority, timing, or physical use.
- **Promissory Note amplifies Monthly Payment.** Promissory Note amplifies Monthly Payment through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mortgage is evidenced by Promissory Note.** Mortgage is evidenced by Promissory Note through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Promissory Note through the lineage of Closing & Disclosures: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Promissory Note: engraved layers, signatures, parcel geometry, seals, and custody marks held inside a precise brass frame; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [12 CFR Part 1024 — Regulation X](https://www.consumerfinance.gov/rules-policy/regulations/1024/) — Consumer Financial Protection Bureau; RESPA, settlement, escrow, servicing, loss mitigation.
- [12 CFR Part 1026 — Regulation Z](https://www.consumerfinance.gov/rules-policy/regulations/1026/) — Consumer Financial Protection Bureau; TILA, APR, mortgage disclosures, servicing, ATR.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
