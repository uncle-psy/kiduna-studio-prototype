# Ability to Repay

> Ability to Repay tests whether the promised payment can be supported by the borrower's resources and obligations

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:borrower-underwriting:ability-to-repay` |
| Family | Borrower Underwriting |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Ability to Repay is a concept in the Borrower Underwriting family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Ability to Repay tests whether the promised payment can be supported by the borrower's resources and obligations.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Ability to Repay tests whether the promised payment can be supported by the borrower's resources and obligations
- **Gift:** Clarity about ability to repay makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When ability to repay is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when ability to repay is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where ability to repay appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Ability to Repay reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Ability to Repay changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Ability to Repay changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Ability to Repay can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Ability to Repay. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Ability to Repay becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **Prequalification enables Ability to Repay.** Prequalification enables Ability to Repay through a change in rights, information, cash flow, priority, timing, or physical use.
- **Ability to Repay prices Qualified Mortgage.** Ability to Repay prices Qualified Mortgage through a change in rights, information, cash flow, priority, timing, or physical use.
- **Ability to Repay prices Loan-to-Value Ratio.** Ability to Repay prices Loan-to-Value Ratio through a change in rights, information, cash flow, priority, timing, or physical use.
- **Underwriter tests Ability to Repay.** Underwriter tests Ability to Repay through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Ability to Repay through the lineage of Borrower Underwriting: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Ability to Repay: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Ability-to-Repay and Qualified Mortgage Rule](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/ability-repay-qualified-mortgage-rule/) — Consumer Financial Protection Bureau; ATR/QM and residential underwriting.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
