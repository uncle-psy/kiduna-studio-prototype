# Property Condition Assessment

> Property Condition Assessment reduces uncertainty before capital and authority become difficult to reverse

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:due-diligence:property-condition-assessment` |
| Family | Due Diligence & Inspection |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | place-or-property |
| Archetype | The Ground |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Property Condition Assessment is a place or property in the Due Diligence & Inspection family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Property Condition Assessment reduces uncertainty before capital and authority become difficult to reverse.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Property Condition Assessment reduces uncertainty before capital and authority become difficult to reverse
- **Gift:** Clarity about property condition assessment makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When property condition assessment is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when property condition assessment is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where property condition assessment appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Property Condition Assessment reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Property Condition Assessment changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Property Condition Assessment changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Property Condition Assessment can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Ground enters the reading through Property Condition Assessment. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What relationships become visible when Property Condition Assessment is treated as a place rather than only an asset?

**Guidance:** Walk the physical, legal, financial, ecological, and human maps separately before recombining them.

## Game function

Occupies spatial capacity and generates use, cost, externality, identity, or cash flow. Initiative 2.

## Relationships

- **Multiple Listing Service is administered through Property Condition Assessment.** Multiple Listing Service is administered through Property Condition Assessment through a change in rights, information, cash flow, priority, timing, or physical use.
- **Home Inspection conflicts with Property Condition Assessment.** Home Inspection conflicts with Property Condition Assessment through a change in rights, information, cash flow, priority, timing, or physical use.
- **Property Condition Assessment is evidenced by Environmental Site Assessment.** Property Condition Assessment is evidenced by Environmental Site Assessment through a change in rights, information, cash flow, priority, timing, or physical use.
- **Property Condition Assessment depends on Market Value.** Property Condition Assessment depends on Market Value through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Property Condition Assessment through the lineage of Due Diligence & Inspection: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Property Condition Assessment: a tactile architectural environment rendered in deep enamel, stone, vegetation, water, and fine metal lines; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [Risk-Based Brownfields Cleanups](https://www.epa.gov/brownfields/risk-based-brownfields-cleanups) — U.S. Environmental Protection Agency; contamination, remediation, reuse, institutional controls.
