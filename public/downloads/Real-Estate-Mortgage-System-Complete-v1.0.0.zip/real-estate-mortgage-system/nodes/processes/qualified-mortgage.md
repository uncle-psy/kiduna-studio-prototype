# Qualified Mortgage

> Qualified Mortgage tests whether the promised payment can be supported by the borrower's resources and obligations

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:borrower-underwriting:qualified-mortgage` |
| Family | Borrower Underwriting |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | financial-instrument |
| Archetype | The Claim |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Qualified Mortgage is a financial instrument in the Borrower Underwriting family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Qualified Mortgage tests whether the promised payment can be supported by the borrower's resources and obligations.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Qualified Mortgage tests whether the promised payment can be supported by the borrower's resources and obligations
- **Gift:** Clarity about qualified mortgage makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When qualified mortgage is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when qualified mortgage is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where qualified mortgage appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Qualified Mortgage reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Qualified Mortgage changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Qualified Mortgage changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Qualified Mortgage can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Claim enters the reading through Qualified Mortgage. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Qualified Mortgage, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 2.

## Relationships

- **Preapproval transfers into Qualified Mortgage.** Preapproval transfers into Qualified Mortgage through a change in rights, information, cash flow, priority, timing, or physical use.
- **Ability to Repay prices Qualified Mortgage.** Ability to Repay prices Qualified Mortgage through a change in rights, information, cash flow, priority, timing, or physical use.
- **Qualified Mortgage documents Credit Report.** Qualified Mortgage documents Credit Report through a change in rights, information, cash flow, priority, timing, or physical use.
- **Qualified Mortgage is governed by Combined Loan-to-Value Ratio.** Qualified Mortgage is governed by Combined Loan-to-Value Ratio through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Qualified Mortgage through the lineage of Borrower Underwriting: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Qualified Mortgage: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Ability-to-Repay and Qualified Mortgage Rule](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/ability-repay-qualified-mortgage-rule/) — Consumer Financial Protection Bureau; ATR/QM and residential underwriting.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
