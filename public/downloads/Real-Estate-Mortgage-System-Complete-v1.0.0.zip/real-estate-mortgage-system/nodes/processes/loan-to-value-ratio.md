# Loan-to-Value Ratio

> Loan-to-Value Ratio tests whether the property can support the legal, physical, and market assumptions of the loan

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:collateral-underwriting:loan-to-value-ratio` |
| Family | Collateral Underwriting |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | metric-or-force |
| Archetype | The Scale |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

The loan amount divided by the relevant property value, usually expressed as a percentage.

## What it actually does

Measures the collateral cushion and helps set eligibility, pricing, insurance, and risk controls.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Loan-to-Value Ratio tests whether the property can support the legal, physical, and market assumptions of the loan
- **Gift:** Clarity about loan-to-value ratio makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When loan-to-value ratio is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when loan-to-value ratio is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where loan-to-value ratio appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Loan-to-Value Ratio reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Loan-to-Value Ratio changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Loan-to-Value Ratio changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Loan-to-Value Ratio can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Scale enters the reading through Loan-to-Value Ratio. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Loan-to-Value Ratio measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 1.

## Relationships

- **Ability to Repay prices Loan-to-Value Ratio.** Ability to Repay prices Loan-to-Value Ratio through a change in rights, information, cash flow, priority, timing, or physical use.
- **Loan-to-Value Ratio documents Combined Loan-to-Value Ratio.** Loan-to-Value Ratio documents Combined Loan-to-Value Ratio through a change in rights, information, cash flow, priority, timing, or physical use.
- **Loan-to-Value Ratio documents Closing Disclosure.** Loan-to-Value Ratio documents Closing Disclosure through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Loan-to-Value Ratio through the lineage of Collateral Underwriting: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Loan-to-Value Ratio: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Uniform Standards of Professional Appraisal Practice](https://appraisalfoundation.org/pages/uspap) — The Appraisal Foundation; appraisal ethics, development, reporting, review.
