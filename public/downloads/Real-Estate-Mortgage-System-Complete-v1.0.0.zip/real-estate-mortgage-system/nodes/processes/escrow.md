# Escrow

> Escrow turns negotiated terms into executed, funded, and transferable obligations

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:closing-disclosures:escrow` |
| Family | Closing & Disclosures |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Pattern |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Escrow is a concept in the Closing & Disclosures family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Escrow turns negotiated terms into executed, funded, and transferable obligations.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Escrow turns negotiated terms into executed, funded, and transferable obligations
- **Gift:** Clarity about escrow makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When escrow is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when escrow is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where escrow appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Escrow reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Escrow changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Escrow changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Escrow can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Pattern enters the reading through Escrow. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Escrow becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 2.

## Relationships

- **Condo Warrantability externalizes to Escrow.** Condo Warrantability externalizes to Escrow through a change in rights, information, cash flow, priority, timing, or physical use.
- **Deed of Trust conflicts with Escrow.** Deed of Trust conflicts with Escrow through a change in rights, information, cash flow, priority, timing, or physical use.
- **Escrow is evidenced by Settlement Agent.** Escrow is evidenced by Settlement Agent through a change in rights, information, cash flow, priority, timing, or physical use.
- **Escrow amplifies Amortization.** Escrow amplifies Amortization through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Escrow through the lineage of Closing & Disclosures: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Escrow: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [12 CFR Part 1024 — Regulation X](https://www.consumerfinance.gov/rules-policy/regulations/1024/) — Consumer Financial Protection Bureau; RESPA, settlement, escrow, servicing, loss mitigation.
- [12 CFR Part 1026 — Regulation Z](https://www.consumerfinance.gov/rules-policy/regulations/1026/) — Consumer Financial Protection Bureau; TILA, APR, mortgage disclosures, servicing, ATR.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
