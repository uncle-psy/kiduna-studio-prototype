# Security Instrument

> Security Instrument turns negotiated terms into executed, funded, and transferable obligations

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:closing-disclosures:security-instrument` |
| Family | Closing & Disclosures |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | financial-instrument |
| Archetype | The Promise |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Security Instrument is a financial instrument in the Closing & Disclosures family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Security Instrument turns negotiated terms into executed, funded, and transferable obligations.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Security Instrument turns negotiated terms into executed, funded, and transferable obligations
- **Gift:** Clarity about security instrument makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When security instrument is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when security instrument is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where security instrument appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Security Instrument reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Security Instrument changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Security Instrument changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Security Instrument can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Promise enters the reading through Security Instrument. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Security Instrument, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 3.

## Relationships

- **Property Eligibility is evidenced by Security Instrument.** Property Eligibility is evidenced by Security Instrument through a change in rights, information, cash flow, priority, timing, or physical use.
- **Promissory Note is governed by Security Instrument.** Promissory Note is governed by Security Instrument through a change in rights, information, cash flow, priority, timing, or physical use.
- **Security Instrument externalizes to Mortgage Deed.** Security Instrument externalizes to Mortgage Deed through a change in rights, information, cash flow, priority, timing, or physical use.
- **Security Instrument is administered through Principal.** Security Instrument is administered through Principal through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mortgage is secured through Security Instrument.** Mortgage is secured through Security Instrument through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Security Instrument through the lineage of Closing & Disclosures: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Security Instrument: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [12 CFR Part 1024 — Regulation X](https://www.consumerfinance.gov/rules-policy/regulations/1024/) — Consumer Financial Protection Bureau; RESPA, settlement, escrow, servicing, loss mitigation.
- [12 CFR Part 1026 — Regulation Z](https://www.consumerfinance.gov/rules-policy/regulations/1026/) — Consumer Financial Protection Bureau; TILA, APR, mortgage disclosures, servicing, ATR.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
