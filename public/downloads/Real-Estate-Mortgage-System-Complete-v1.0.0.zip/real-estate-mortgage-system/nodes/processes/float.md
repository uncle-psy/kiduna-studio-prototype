# Float

> Float turns borrower intent into a documented, priced loan file

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:origination:float` |
| Family | Mortgage Origination |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Pattern |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Float is a concept in the Mortgage Origination family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Float turns borrower intent into a documented, priced loan file.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Float turns borrower intent into a documented, priced loan file
- **Gift:** Clarity about float makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When float is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when float is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where float appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Float reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Float changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Float changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Float can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Pattern enters the reading through Float. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Float becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 4.

## Relationships

- **Construction Loan is evidenced by Float.** Construction Loan is evidenced by Float through a change in rights, information, cash flow, priority, timing, or physical use.
- **Rate Lock amplifies Float.** Rate Lock amplifies Float through a change in rights, information, cash flow, priority, timing, or physical use.
- **Float conflicts with Lock Extension.** Float conflicts with Lock Extension through a change in rights, information, cash flow, priority, timing, or physical use.
- **Float is administered through Assets.** Float is administered through Assets through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Float through the lineage of Mortgage Origination: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Float: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [MISMO Standards & Resources](https://www.mismo.org/standards-resources) — Mortgage Industry Standards Maintenance Organization; residential and commercial mortgage data standards.
