# Market Value

> Market Value translates a unique property into a supportable opinion of value

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:appraisal-valuation:market-value` |
| Family | Appraisal & Valuation |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | metric-or-force |
| Archetype | The Clock |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

A value concept estimating the price a property interest should command under specified conditions of an open and competitive market.

## What it actually does

Provides a common comparison point while making assumptions about exposure, knowledge, motivation, and financing explicit.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Market Value translates a unique property into a supportable opinion of value
- **Gift:** Clarity about market value makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When market value is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when market value is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where market value appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Market Value reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Market Value changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Market Value changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Market Value can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Clock enters the reading through Market Value. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Market Value measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 2.

## Relationships

- **Property Condition Assessment depends on Market Value.** Property Condition Assessment depends on Market Value through a change in rights, information, cash flow, priority, timing, or physical use.
- **Appraisal is evidenced by Market Value.** Appraisal is evidenced by Market Value through a change in rights, information, cash flow, priority, timing, or physical use.
- **Market Value is administered through Highest and Best Use.** Market Value is administered through Highest and Best Use through a change in rights, information, cash flow, priority, timing, or physical use.
- **Market Value constrains Thirty-Year Fixed Mortgage.** Market Value constrains Thirty-Year Fixed Mortgage through a change in rights, information, cash flow, priority, timing, or physical use.
- **Appraisal reconciles into Market Value.** Appraisal reconciles into Market Value through a change in rights, information, cash flow, priority, timing, or physical use.
- **Automated Valuation Model estimates Market Value.** Automated Valuation Model estimates Market Value through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Market Value versus Meaning
- Standardization versus Uniqueness

## Historical lineage and regulatory context

Read Market Value through the lineage of Appraisal & Valuation: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Market Value: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Uniform Standards of Professional Appraisal Practice](https://appraisalfoundation.org/pages/uspap) — The Appraisal Foundation; appraisal ethics, development, reporting, review.
- [Quality Control Standards for Automated Valuation Models](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/quality-control-standards-for-automated-valuation-models/) — Consumer Financial Protection Bureau; AVM controls and valuation technology.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
