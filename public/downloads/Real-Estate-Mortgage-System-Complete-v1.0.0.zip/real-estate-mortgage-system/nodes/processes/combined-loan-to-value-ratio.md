# Combined Loan-to-Value Ratio

> Combined Loan-to-Value Ratio tests whether the property can support the legal, physical, and market assumptions of the loan

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:collateral-underwriting:combined-loan-to-value-ratio` |
| Family | Collateral Underwriting |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | metric-or-force |
| Archetype | The Tide |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Combined Loan-to-Value Ratio is a metric or force in the Collateral Underwriting family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Combined Loan-to-Value Ratio tests whether the property can support the legal, physical, and market assumptions of the loan.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Combined Loan-to-Value Ratio tests whether the property can support the legal, physical, and market assumptions of the loan
- **Gift:** Clarity about combined loan-to-value ratio makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When combined loan-to-value ratio is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when combined loan-to-value ratio is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where combined loan-to-value ratio appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Combined Loan-to-Value Ratio reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Combined Loan-to-Value Ratio changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Combined Loan-to-Value Ratio changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Combined Loan-to-Value Ratio can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tide enters the reading through Combined Loan-to-Value Ratio. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Combined Loan-to-Value Ratio measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 2.

## Relationships

- **Qualified Mortgage is governed by Combined Loan-to-Value Ratio.** Qualified Mortgage is governed by Combined Loan-to-Value Ratio through a change in rights, information, cash flow, priority, timing, or physical use.
- **Loan-to-Value Ratio documents Combined Loan-to-Value Ratio.** Loan-to-Value Ratio documents Combined Loan-to-Value Ratio through a change in rights, information, cash flow, priority, timing, or physical use.
- **Combined Loan-to-Value Ratio transfers into Property Eligibility.** Combined Loan-to-Value Ratio transfers into Property Eligibility through a change in rights, information, cash flow, priority, timing, or physical use.
- **Combined Loan-to-Value Ratio externalizes to Promissory Note.** Combined Loan-to-Value Ratio externalizes to Promissory Note through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Combined Loan-to-Value Ratio through the lineage of Collateral Underwriting: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Combined Loan-to-Value Ratio: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Uniform Standards of Professional Appraisal Practice](https://appraisalfoundation.org/pages/uspap) — The Appraisal Foundation; appraisal ethics, development, reporting, review.
