# Seller Concession

> Seller Concession coordinates discovery, negotiation, commitment, and transfer

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:listing-transaction:seller-concession` |
| Family | Listing & Transaction |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | actor-or-institution |
| Archetype | The Principal |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Seller Concession is a actor or institution in the Listing & Transaction family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Seller Concession coordinates discovery, negotiation, commitment, and transfer.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** counterparties, clients, members, regulators, investors
- **Incentives:** compensation, completion, risk control, reputation, authority
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Seller Concession coordinates discovery, negotiation, commitment, and transfer
- **Gift:** Clarity about seller concession makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When seller concession is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when seller concession is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where seller concession appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Seller Concession reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Seller Concession changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Seller Concession changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Seller Concession can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Principal enters the reading through Seller Concession. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What does Seller Concession know, want, control, and carry if the transaction fails?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a playable role with asymmetric information, incentives, authority, and accountability. Initiative 4.

## Relationships

- **Property Line documents Seller Concession.** Property Line documents Seller Concession through a change in rights, information, cash flow, priority, timing, or physical use.
- **Bidding War is governed by Seller Concession.** Bidding War is governed by Seller Concession through a change in rights, information, cash flow, priority, timing, or physical use.
- **Seller Concession externalizes to Buyer Representation.** Seller Concession externalizes to Buyer Representation through a change in rights, information, cash flow, priority, timing, or physical use.
- **Seller Concession transfers into Lead-Based Paint Disclosure.** Seller Concession transfers into Lead-Based Paint Disclosure through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Seller Concession through the lineage of Listing & Transaction: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Seller Concession: a central instrument surrounded by flows of information, authority, capital, and accountability; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [How to Buy a Home](https://www.gov.uk/government/publications/how-to-buy-a-home/how-to-buy) — Government of the United Kingdom; homebuying, tenure, searches, surveys, exchange, completion.
