# Purchase Agreement

> Purchase Agreement coordinates discovery, negotiation, commitment, and transfer

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:listing-transaction:purchase-agreement` |
| Family | Listing & Transaction |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | record-or-instrument |
| Archetype | The Memory |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Purchase Agreement is a record or instrument in the Listing & Transaction family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Purchase Agreement coordinates discovery, negotiation, commitment, and transfer.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** borrower, lender, title professional, attorney, custodian, recorder
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** durable evidence, priority, notice, transferability
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Purchase Agreement coordinates discovery, negotiation, commitment, and transfer
- **Gift:** Clarity about purchase agreement makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When purchase agreement is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when purchase agreement is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where purchase agreement appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Purchase Agreement reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Purchase Agreement changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Purchase Agreement changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Purchase Agreement can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Memory enters the reading through Purchase Agreement. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What must Purchase Agreement make durable before you can safely proceed?

**Guidance:** Resolve provenance, authority, custody, and ambiguity before relying on the artifact.

## Game function

Provides Evidence or Authority; missing custody or a defect blocks transfer. Initiative 4.

## Relationships

- **Benchmark documents Purchase Agreement.** Benchmark documents Purchase Agreement through a change in rights, information, cash flow, priority, timing, or physical use.
- **Earnest Money enables Purchase Agreement.** Earnest Money enables Purchase Agreement through a change in rights, information, cash flow, priority, timing, or physical use.
- **Purchase Agreement prices Contingency.** Purchase Agreement prices Contingency through a change in rights, information, cash flow, priority, timing, or physical use.
- **Purchase Agreement transfers into Sewer Scope.** Purchase Agreement transfers into Sewer Scope through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Purchase Agreement through the lineage of Listing & Transaction: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Purchase Agreement: engraved layers, signatures, parcel geometry, seals, and custody marks held inside a precise brass frame; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [How to Buy a Home](https://www.gov.uk/government/publications/how-to-buy-a-home/how-to-buy) — Government of the United Kingdom; homebuying, tenure, searches, surveys, exchange, completion.
