# Income

> Income tests whether the promised payment can be supported by the borrower's resources and obligations

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:borrower-underwriting:income` |
| Family | Borrower Underwriting |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | metric-or-force |
| Archetype | The Tide |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Income is a metric or force in the Borrower Underwriting family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Income tests whether the promised payment can be supported by the borrower's resources and obligations.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Income tests whether the promised payment can be supported by the borrower's resources and obligations
- **Gift:** Clarity about income makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When income is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when income is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where income appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Income reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Income changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Income changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Income can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tide enters the reading through Income. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Income measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 3.

## Relationships

- **Rate Lock amplifies Income.** Rate Lock amplifies Income through a change in rights, information, cash flow, priority, timing, or physical use.
- **Housing Expense Ratio amplifies Income.** Housing Expense Ratio amplifies Income through a change in rights, information, cash flow, priority, timing, or physical use.
- **Income conflicts with Assets.** Income conflicts with Assets through a change in rights, information, cash flow, priority, timing, or physical use.
- **Income conflicts with Property Insurance.** Income conflicts with Property Insurance through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Income through the lineage of Borrower Underwriting: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Income: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Ability-to-Repay and Qualified Mortgage Rule](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/ability-repay-qualified-mortgage-rule/) — Consumer Financial Protection Bureau; ATR/QM and residential underwriting.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
