# Right of Rescission

> Right of Rescission turns negotiated terms into executed, funded, and transferable obligations

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:closing-disclosures:right-of-rescission` |
| Family | Closing & Disclosures |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Right of Rescission is a concept in the Closing & Disclosures family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Right of Rescission turns negotiated terms into executed, funded, and transferable obligations.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Right of Rescission turns negotiated terms into executed, funded, and transferable obligations
- **Gift:** Clarity about right of rescission makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When right of rescission is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when right of rescission is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where right of rescission appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Right of Rescission reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Right of Rescission changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Right of Rescission changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Right of Rescission can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Right of Rescission. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Right of Rescission becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **Mortgage Insurance documents Right of Rescission.** Mortgage Insurance documents Right of Rescission through a change in rights, information, cash flow, priority, timing, or physical use.
- **Notary depends on Right of Rescission.** Notary depends on Right of Rescission through a change in rights, information, cash flow, priority, timing, or physical use.
- **Right of Rescission constrains Initial Escrow Statement.** Right of Rescission constrains Initial Escrow Statement through a change in rights, information, cash flow, priority, timing, or physical use.
- **Right of Rescission transfers into Payoff Statement.** Right of Rescission transfers into Payoff Statement through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Right of Rescission through the lineage of Closing & Disclosures: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Right of Rescission: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [12 CFR Part 1024 — Regulation X](https://www.consumerfinance.gov/rules-policy/regulations/1024/) — Consumer Financial Protection Bureau; RESPA, settlement, escrow, servicing, loss mitigation.
- [12 CFR Part 1026 — Regulation Z](https://www.consumerfinance.gov/rules-policy/regulations/1026/) — Consumer Financial Protection Bureau; TILA, APR, mortgage disclosures, servicing, ATR.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
