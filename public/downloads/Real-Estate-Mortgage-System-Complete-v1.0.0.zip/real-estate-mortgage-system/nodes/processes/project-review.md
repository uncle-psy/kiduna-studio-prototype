# Project Review

> Project Review tests whether the property can support the legal, physical, and market assumptions of the loan

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:collateral-underwriting:project-review` |
| Family | Collateral Underwriting |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | process |
| Archetype | The Passage |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Project Review is a process in the Collateral Underwriting family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Project Review tests whether the property can support the legal, physical, and market assumptions of the loan.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** certainty, speed, compliance, completion, error reduction
- **Inputs:** participants, documents, conditions, authority, time
- **Outputs:** decision, changed state, record, new obligations
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Project Review tests whether the property can support the legal, physical, and market assumptions of the loan
- **Gift:** Clarity about project review makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When project review is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when project review is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where project review appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Project Review reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Project Review changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Project Review changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Project Review can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Passage enters the reading through Project Review. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What information or condition must Project Review translate before the next commitment becomes safe?

**Guidance:** Make conditions, exceptions, handoffs, and completion criteria explicit.

## Game function

Creates a gated action requiring inputs, a decision, and a resulting Record. Initiative 1.

## Relationships

- **Debt-to-Income Ratio prices Project Review.** Debt-to-Income Ratio prices Project Review through a change in rights, information, cash flow, priority, timing, or physical use.
- **Occupancy Classification externalizes to Project Review.** Occupancy Classification externalizes to Project Review through a change in rights, information, cash flow, priority, timing, or physical use.
- **Project Review amplifies Condo Warrantability.** Project Review amplifies Condo Warrantability through a change in rights, information, cash flow, priority, timing, or physical use.
- **Project Review documents Deed of Trust.** Project Review documents Deed of Trust through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Project Review through the lineage of Collateral Underwriting: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Project Review: a sequence of thresholds connected by a single bright path, with conditions represented as gates; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Uniform Standards of Professional Appraisal Practice](https://appraisalfoundation.org/pages/uspap) — The Appraisal Foundation; appraisal ethics, development, reporting, review.
