# Funding

> Funding turns negotiated terms into executed, funded, and transferable obligations

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:closing-disclosures:funding` |
| Family | Closing & Disclosures |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | financial-instrument |
| Archetype | The Bridge |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Funding is a financial instrument in the Closing & Disclosures family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Funding turns negotiated terms into executed, funded, and transferable obligations.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Funding turns negotiated terms into executed, funded, and transferable obligations
- **Gift:** Clarity about funding makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When funding is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when funding is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where funding appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Funding reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Funding changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Funding changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Funding can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Bridge enters the reading through Funding. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Funding, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 1.

## Relationships

- **Property Data Collection documents Funding.** Property Data Collection documents Funding through a change in rights, information, cash flow, priority, timing, or physical use.
- **Closing Protection Letter documents Funding.** Closing Protection Letter documents Funding through a change in rights, information, cash flow, priority, timing, or physical use.
- **Funding transfers into Periodic Statement.** Funding transfers into Periodic Statement through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Funding through the lineage of Closing & Disclosures: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Funding: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [12 CFR Part 1024 — Regulation X](https://www.consumerfinance.gov/rules-policy/regulations/1024/) — Consumer Financial Protection Bureau; RESPA, settlement, escrow, servicing, loss mitigation.
- [12 CFR Part 1026 — Regulation Z](https://www.consumerfinance.gov/rules-policy/regulations/1026/) — Consumer Financial Protection Bureau; TILA, APR, mortgage disclosures, servicing, ATR.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
