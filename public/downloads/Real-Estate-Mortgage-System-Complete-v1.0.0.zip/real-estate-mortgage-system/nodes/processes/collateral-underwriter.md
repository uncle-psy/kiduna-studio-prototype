# Collateral Underwriter

> Collateral Underwriter tests whether the property can support the legal, physical, and market assumptions of the loan

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:collateral-underwriting:collateral-underwriter` |
| Family | Collateral Underwriting |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | actor-or-institution |
| Archetype | The Intermediary |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Collateral Underwriter is a actor or institution in the Collateral Underwriting family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Collateral Underwriter tests whether the property can support the legal, physical, and market assumptions of the loan.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** counterparties, clients, members, regulators, investors
- **Incentives:** compensation, completion, risk control, reputation, authority
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Collateral Underwriter tests whether the property can support the legal, physical, and market assumptions of the loan
- **Gift:** Clarity about collateral underwriter makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When collateral underwriter is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when collateral underwriter is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where collateral underwriter appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Collateral Underwriter reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Collateral Underwriter changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Collateral Underwriter changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Collateral Underwriter can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Intermediary enters the reading through Collateral Underwriter. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What does Collateral Underwriter know, want, control, and carry if the transaction fails?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a playable role with asymmetric information, incentives, authority, and accountability. Initiative 3.

## Relationships

- **Gift Funds conflicts with Collateral Underwriter.** Gift Funds conflicts with Collateral Underwriter through a change in rights, information, cash flow, priority, timing, or physical use.
- **Title Policy constrains Collateral Underwriter.** Title Policy constrains Collateral Underwriter through a change in rights, information, cash flow, priority, timing, or physical use.
- **Collateral Underwriter enables Value Acceptance.** Collateral Underwriter enables Value Acceptance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Collateral Underwriter is evidenced by Affiliated Business Disclosure.** Collateral Underwriter is evidenced by Affiliated Business Disclosure through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Collateral Underwriter through the lineage of Collateral Underwriting: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Collateral Underwriter: a central instrument surrounded by flows of information, authority, capital, and accountability; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Uniform Standards of Professional Appraisal Practice](https://appraisalfoundation.org/pages/uspap) — The Appraisal Foundation; appraisal ethics, development, reporting, review.
