# Paid in Full

> Paid in Full gives tangible form to otherwise abstract changes in belonging and authority

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:rituals-relics:paid-in-full` |
| Family | Rituals & Relics |
| Domain | Culture |
| Era | Kinship Age → Collective Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Paid in Full is a concept in the Rituals & Relics family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Paid in Full gives tangible form to otherwise abstract changes in belonging and authority.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Paid in Full gives tangible form to otherwise abstract changes in belonging and authority
- **Gift:** Clarity about paid in full makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When paid in full is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when paid in full is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where paid in full appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Paid in Full reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Paid in Full changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Paid in Full changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Paid in Full can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Paid in Full. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Paid in Full becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 2.

## Relationships

- **Ghost Subdivision conflicts with Paid in Full.** Ghost Subdivision conflicts with Paid in Full through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mortgage Burning prices Paid in Full.** Mortgage Burning prices Paid in Full through a change in rights, information, cash flow, priority, timing, or physical use.
- **Paid in Full documents Groundbreaking Ritual.** Paid in Full documents Groundbreaking Ritual through a change in rights, information, cash flow, priority, timing, or physical use.
- **Paid in Full is evidenced by Shelter versus Investment.** Paid in Full is evidenced by Shelter versus Investment through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Paid in Full through the lineage of Rituals & Relics: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Paid in Full: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [How to Buy a Home](https://www.gov.uk/government/publications/how-to-buy-a-home/how-to-buy) — Government of the United Kingdom; homebuying, tenure, searches, surveys, exchange, completion.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
