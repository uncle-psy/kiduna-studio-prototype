# Bailee Receipt

> Bailee Receipt preserves the evidence needed for claims to survive time, transfer, and dispute

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:documents-custody:bailee-receipt` |
| Family | Documents, Custody & Evidence |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Tension |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Bailee Receipt is a concept in the Documents, Custody & Evidence family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Bailee Receipt preserves the evidence needed for claims to survive time, transfer, and dispute.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Bailee Receipt preserves the evidence needed for claims to survive time, transfer, and dispute
- **Gift:** Clarity about bailee receipt makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When bailee receipt is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when bailee receipt is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where bailee receipt appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Bailee Receipt reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Bailee Receipt changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Bailee Receipt changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Bailee Receipt can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tension enters the reading through Bailee Receipt. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Bailee Receipt becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **Property Management depends on Bailee Receipt.** Property Management depends on Bailee Receipt through a change in rights, information, cash flow, priority, timing, or physical use.
- **Servicing Notes depends on Bailee Receipt.** Servicing Notes depends on Bailee Receipt through a change in rights, information, cash flow, priority, timing, or physical use.
- **Bailee Receipt constrains Subsurface.** Bailee Receipt constrains Subsurface through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Bailee Receipt through the lineage of Documents, Custody & Evidence: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Bailee Receipt: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
