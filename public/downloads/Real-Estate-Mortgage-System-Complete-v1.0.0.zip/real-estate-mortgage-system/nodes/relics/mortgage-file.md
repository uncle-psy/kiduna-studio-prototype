# Mortgage File

> Mortgage File preserves the evidence needed for claims to survive time, transfer, and dispute

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:documents-custody:mortgage-file` |
| Family | Documents, Custody & Evidence |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | financial-instrument |
| Archetype | The Reservoir |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Mortgage File is a financial instrument in the Documents, Custody & Evidence family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Mortgage File preserves the evidence needed for claims to survive time, transfer, and dispute.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Mortgage File preserves the evidence needed for claims to survive time, transfer, and dispute
- **Gift:** Clarity about mortgage file makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When mortgage file is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when mortgage file is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where mortgage file appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Mortgage File reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Mortgage File changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Mortgage File changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Mortgage File can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Reservoir enters the reading through Mortgage File. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Mortgage File, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 1.

## Relationships

- **Lease-Up depends on Mortgage File.** Lease-Up depends on Mortgage File through a change in rights, information, cash flow, priority, timing, or physical use.
- **Custodial Certification amplifies Mortgage File.** Custodial Certification amplifies Mortgage File through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mortgage File conflicts with Loan Boarding File.** Mortgage File conflicts with Loan Boarding File through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mortgage File constrains Bedrock.** Mortgage File constrains Bedrock through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Mortgage File through the lineage of Documents, Custody & Evidence: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Mortgage File: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
