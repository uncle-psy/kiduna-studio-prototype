# Freehold

> Freehold defines the duration and quality of a person's interest in land

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:estates-tenure:freehold` |
| Family | Estates & Tenure |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Pattern |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Freehold is a concept in the Estates & Tenure family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Freehold defines the duration and quality of a person's interest in land.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Freehold defines the duration and quality of a person's interest in land
- **Gift:** Clarity about freehold makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When freehold is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when freehold is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where freehold appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Freehold reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Freehold changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Freehold changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Freehold can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Pattern enters the reading through Freehold. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Freehold becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 2.

## Relationships

- **Office is governed by Freehold.** Office is governed by Freehold through a change in rights, information, cash flow, priority, timing, or physical use.
- **Fee Simple documents Freehold.** Fee Simple documents Freehold through a change in rights, information, cash flow, priority, timing, or physical use.
- **Freehold transfers into Leasehold.** Freehold transfers into Leasehold through a change in rights, information, cash flow, priority, timing, or physical use.
- **Freehold externalizes to Possession.** Freehold externalizes to Possession through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Freehold through the lineage of Estates & Tenure: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Freehold: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, legal variation, regulatory sensitivity. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
- [Housing Discrimination Under the Fair Housing Act](https://www.hud.gov/helping-americans/fair-housing-act-overview) — U.S. Department of Housing and Urban Development; housing discrimination and protected classes.
