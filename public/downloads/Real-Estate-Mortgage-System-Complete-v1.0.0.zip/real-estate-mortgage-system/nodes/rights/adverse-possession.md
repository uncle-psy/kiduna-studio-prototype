# Adverse Possession

> Adverse Possession makes visible the moments when maps, records, use, and physical reality disagree

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:strange-property:adverse-possession` |
| Family | Strange Property Law |
| Domain | Governance |
| Era | Kinship Age → Agentic Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

A doctrine that can vest title in a possessor whose occupation satisfies jurisdiction-specific requirements over the statutory period.

## What it actually does

Allows long, visible, nonpermissive possession to overcome stale record ownership when all legal elements are proved.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Adverse Possession makes visible the moments when maps, records, use, and physical reality disagree
- **Gift:** Clarity about adverse possession makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When adverse possession is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when adverse possession is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where adverse possession appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Adverse Possession reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Adverse Possession changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Adverse Possession changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Adverse Possession can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Adverse Possession. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Adverse Possession becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **English Freehold transfers into Adverse Possession.** English Freehold transfers into Adverse Possession through a change in rights, information, cash flow, priority, timing, or physical use.
- **Adverse Possession is governed by Accretion.** Adverse Possession is governed by Accretion through a change in rights, information, cash flow, priority, timing, or physical use.
- **Adverse Possession is governed by Key.** Adverse Possession is governed by Key through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Adverse Possession through the lineage of Strange Property Law: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Adverse Possession: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
