# Property Line

> Property Line translates physical land into measurable and contestable geometry

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:survey-boundary:property-line` |
| Family | Survey & Boundary |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | financial-instrument |
| Archetype | The Claim |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Property Line is a financial instrument in the Survey & Boundary family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Property Line translates physical land into measurable and contestable geometry.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Property Line translates physical land into measurable and contestable geometry
- **Gift:** Clarity about property line makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When property line is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when property line is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where property line appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Property Line reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Property Line changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Property Line changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Property Line can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Claim enters the reading through Property Line. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Property Line, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 4.

## Relationships

- **Land Registry prices Property Line.** Land Registry prices Property Line through a change in rights, information, cash flow, priority, timing, or physical use.
- **Setback transfers into Property Line.** Setback transfers into Property Line through a change in rights, information, cash flow, priority, timing, or physical use.
- **Property Line is governed by Party Wall.** Property Line is governed by Party Wall through a change in rights, information, cash flow, priority, timing, or physical use.
- **Property Line documents Seller Concession.** Property Line documents Seller Concession through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Property Line through the lineage of Survey & Boundary: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Property Line: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
