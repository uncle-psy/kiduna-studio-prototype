# Land Registry

> Land Registry links present claims to durable evidence and past transfers

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:title-deeds:land-registry` |
| Family | Title, Deeds & Recording |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | place-or-property |
| Archetype | The Threshold |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Land Registry is a place or property in the Title, Deeds & Recording family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Land Registry links present claims to durable evidence and past transfers.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Legal Description, Recording, Chain of Title, Authority

## Archetypal reading

- **Essence:** Land Registry links present claims to durable evidence and past transfers
- **Gift:** Clarity about land registry makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When land registry is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when land registry is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where land registry appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Land Registry reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Land Registry changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Land Registry changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Land Registry can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Threshold enters the reading through Land Registry. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What relationships become visible when Land Registry is treated as a place rather than only an asset?

**Guidance:** Walk the physical, legal, financial, ecological, and human maps separately before recombining them.

## Game function

Occupies spatial capacity and generates use, cost, externality, identity, or cash flow. Initiative 4.

## Relationships

- **Riparian Rights enables Land Registry.** Riparian Rights enables Land Registry through a change in rights, information, cash flow, priority, timing, or physical use.
- **Recording documents Land Registry.** Recording documents Land Registry through a change in rights, information, cash flow, priority, timing, or physical use.
- **Land Registry transfers into Legal Description.** Land Registry transfers into Legal Description through a change in rights, information, cash flow, priority, timing, or physical use.
- **Land Registry prices Property Line.** Land Registry prices Property Line through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Land Registry through the lineage of Title, Deeds & Recording: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Land Registry: a tactile architectural environment rendered in deep enamel, stone, vegetation, water, and fine metal lines; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, legal variation, regulatory sensitivity. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
