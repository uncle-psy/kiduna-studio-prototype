# Metes and Bounds

> Metes and Bounds translates physical land into measurable and contestable geometry

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:survey-boundary:metes-and-bounds` |
| Family | Survey & Boundary |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Metes and Bounds is a concept in the Survey & Boundary family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Metes and Bounds translates physical land into measurable and contestable geometry.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Metes and Bounds translates physical land into measurable and contestable geometry
- **Gift:** Clarity about metes and bounds makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When metes and bounds is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when metes and bounds is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where metes and bounds appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Metes and Bounds reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Metes and Bounds changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Metes and Bounds changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Metes and Bounds can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Metes and Bounds. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Metes and Bounds becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **Grant Deed is governed by Metes and Bounds.** Grant Deed is governed by Metes and Bounds through a change in rights, information, cash flow, priority, timing, or physical use.
- **Subdivision Map is evidenced by Metes and Bounds.** Subdivision Map is evidenced by Metes and Bounds through a change in rights, information, cash flow, priority, timing, or physical use.
- **Metes and Bounds is administered through Lot and Block.** Metes and Bounds is administered through Lot and Block through a change in rights, information, cash flow, priority, timing, or physical use.
- **Metes and Bounds externalizes to Offer.** Metes and Bounds externalizes to Offer through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Metes and Bounds through the lineage of Survey & Boundary: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Metes and Bounds: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
