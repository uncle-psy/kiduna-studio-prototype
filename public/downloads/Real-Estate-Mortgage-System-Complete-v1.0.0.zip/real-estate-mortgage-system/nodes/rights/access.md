# Access

> Access separates ownership into particular powers that may be shared, limited, or transferred

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:property-rights:access` |
| Family | Property Rights |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Relation |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Access is a concept in the Property Rights family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Access separates ownership into particular powers that may be shared, limited, or transferred.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Access separates ownership into particular powers that may be shared, limited, or transferred
- **Gift:** Clarity about access makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When access is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when access is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where access appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Access reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Access changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Access changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Access can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Relation enters the reading through Access. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Access becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 2.

## Relationships

- **Reversion externalizes to Access.** Reversion externalizes to Access through a change in rights, information, cash flow, priority, timing, or physical use.
- **Transfer conflicts with Access.** Transfer conflicts with Access through a change in rights, information, cash flow, priority, timing, or physical use.
- **Access is evidenced by Easement.** Access is evidenced by Easement through a change in rights, information, cash flow, priority, timing, or physical use.
- **Access amplifies Bargain and Sale Deed.** Access amplifies Bargain and Sale Deed through a change in rights, information, cash flow, priority, timing, or physical use.
- **Key symbolically grants Access.** Key symbolically grants Access through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Ownership versus Access
- Private Property versus Commons

## Historical lineage and regulatory context

Read Access through the lineage of Property Rights: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Access: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, legal variation, regulatory sensitivity. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
