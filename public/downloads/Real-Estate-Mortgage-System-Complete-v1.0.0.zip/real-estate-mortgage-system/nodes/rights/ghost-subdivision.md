# Ghost Subdivision

> Ghost Subdivision makes visible the moments when maps, records, use, and physical reality disagree

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:strange-property:ghost-subdivision` |
| Family | Strange Property Law |
| Domain | Governance |
| Era | Kinship Age → Agentic Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Ghost Subdivision is a concept in the Strange Property Law family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Ghost Subdivision makes visible the moments when maps, records, use, and physical reality disagree.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Ghost Subdivision makes visible the moments when maps, records, use, and physical reality disagree
- **Gift:** Clarity about ghost subdivision makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When ghost subdivision is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when ghost subdivision is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where ghost subdivision appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Ghost Subdivision reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Ghost Subdivision changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Ghost Subdivision changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Ghost Subdivision can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Ghost Subdivision. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Ghost Subdivision becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 2.

## Relationships

- **Hong Kong Government Lease amplifies Ghost Subdivision.** Hong Kong Government Lease amplifies Ghost Subdivision through a change in rights, information, cash flow, priority, timing, or physical use.
- **Paper Street enables Ghost Subdivision.** Paper Street enables Ghost Subdivision through a change in rights, information, cash flow, priority, timing, or physical use.
- **Ghost Subdivision prices Covenant Running with the Land.** Ghost Subdivision prices Covenant Running with the Land through a change in rights, information, cash flow, priority, timing, or physical use.
- **Ghost Subdivision conflicts with Paid in Full.** Ghost Subdivision conflicts with Paid in Full through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Ghost Subdivision through the lineage of Strange Property Law: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Ghost Subdivision: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
