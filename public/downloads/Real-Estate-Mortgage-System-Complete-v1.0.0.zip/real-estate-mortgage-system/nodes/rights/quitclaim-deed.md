# Quitclaim Deed

> Quitclaim Deed links present claims to durable evidence and past transfers

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:title-deeds:quitclaim-deed` |
| Family | Title, Deeds & Recording |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | record-or-instrument |
| Archetype | The Memory |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Quitclaim Deed is a record or instrument in the Title, Deeds & Recording family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Quitclaim Deed links present claims to durable evidence and past transfers.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** borrower, lender, title professional, attorney, custodian, recorder
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** durable evidence, priority, notice, transferability
- **Dependencies:** Legal Description, Recording, Chain of Title, Authority

## Archetypal reading

- **Essence:** Quitclaim Deed links present claims to durable evidence and past transfers
- **Gift:** Clarity about quitclaim deed makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When quitclaim deed is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when quitclaim deed is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where quitclaim deed appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Quitclaim Deed reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Quitclaim Deed changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Quitclaim Deed changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Quitclaim Deed can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Memory enters the reading through Quitclaim Deed. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What must Quitclaim Deed make durable before you can safely proceed?

**Guidance:** Resolve provenance, authority, custody, and ambiguity before relying on the artifact.

## Game function

Provides Evidence or Authority; missing custody or a defect blocks transfer. Initiative 4.

## Relationships

- **Exclusion enables Quitclaim Deed.** Exclusion enables Quitclaim Deed through a change in rights, information, cash flow, priority, timing, or physical use.
- **Warranty Deed amplifies Quitclaim Deed.** Warranty Deed amplifies Quitclaim Deed through a change in rights, information, cash flow, priority, timing, or physical use.
- **Quitclaim Deed conflicts with Grant Deed.** Quitclaim Deed conflicts with Grant Deed through a change in rights, information, cash flow, priority, timing, or physical use.
- **Quitclaim Deed prices Subdivision Map.** Quitclaim Deed prices Subdivision Map through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Quitclaim Deed through the lineage of Title, Deeds & Recording: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Quitclaim Deed: engraved layers, signatures, parcel geometry, seals, and custody marks held inside a precise brass frame; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, legal variation, regulatory sensitivity. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
