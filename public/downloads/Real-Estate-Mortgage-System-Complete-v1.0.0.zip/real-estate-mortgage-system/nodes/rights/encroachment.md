# Encroachment

> Encroachment translates physical land into measurable and contestable geometry

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:survey-boundary:encroachment` |
| Family | Survey & Boundary |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Tension |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Encroachment is a concept in the Survey & Boundary family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Encroachment translates physical land into measurable and contestable geometry.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Encroachment translates physical land into measurable and contestable geometry
- **Gift:** Clarity about encroachment makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When encroachment is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when encroachment is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where encroachment appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Encroachment reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Encroachment changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Encroachment changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Encroachment can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tension enters the reading through Encroachment. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Encroachment becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 2.

## Relationships

- **Title Insurance conflicts with Encroachment.** Title Insurance conflicts with Encroachment through a change in rights, information, cash flow, priority, timing, or physical use.
- **Monument prices Encroachment.** Monument prices Encroachment through a change in rights, information, cash flow, priority, timing, or physical use.
- **Encroachment documents Setback.** Encroachment documents Setback through a change in rights, information, cash flow, priority, timing, or physical use.
- **Encroachment is evidenced by Escalation Clause.** Encroachment is evidenced by Escalation Clause through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Encroachment through the lineage of Survey & Boundary: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Encroachment: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
