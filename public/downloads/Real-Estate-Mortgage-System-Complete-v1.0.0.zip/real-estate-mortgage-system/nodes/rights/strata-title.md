# Strata Title

> Strata Title demonstrates that ownership and mortgage conventions vary by jurisdiction and history

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:global-models:strata-title` |
| Family | Global Property Systems |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | governance-mechanism |
| Archetype | The Gatekeeper |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Strata Title is a governance mechanism in the Global Property Systems family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Strata Title demonstrates that ownership and mortgage conventions vary by jurisdiction and history.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** legitimacy, clarity, enforceability, administrative efficiency
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Strata Title demonstrates that ownership and mortgage conventions vary by jurisdiction and history
- **Gift:** Clarity about strata title makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When strata title is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when strata title is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where strata title appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Strata Title reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Strata Title changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Strata Title changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Strata Title can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Gatekeeper enters the reading through Strata Title. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** Who has legitimate authority under Strata Title, and where does that authority stop?

**Guidance:** Name the source, scope, duration, appeal path, and release of authority.

## Game function

Changes what actions are permitted and who may authorize them. Initiative 4.

## Relationships

- **Tenement Era constrains Strata Title.** Tenement Era constrains Strata Title through a change in rights, information, cash flow, priority, timing, or physical use.
- **Scottish Feudal Abolition externalizes to Strata Title.** Scottish Feudal Abolition externalizes to Strata Title through a change in rights, information, cash flow, priority, timing, or physical use.
- **Strata Title amplifies Australian Torrens Title.** Strata Title amplifies Australian Torrens Title through a change in rights, information, cash flow, priority, timing, or physical use.
- **Strata Title enables Reliction.** Strata Title enables Reliction through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Strata Title through the lineage of Global Property Systems: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Strata Title: a cadastral grid overlaid with colored permissions, gates, and invisible boundaries made visible; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
- [Covered Bonds in the EU Financial System](https://www.ecb.europa.eu/pub/pdf/other/coverbondsintheeufinancialsystem200812en_en.pdf) — European Central Bank; covered bonds and European mortgage funding.
