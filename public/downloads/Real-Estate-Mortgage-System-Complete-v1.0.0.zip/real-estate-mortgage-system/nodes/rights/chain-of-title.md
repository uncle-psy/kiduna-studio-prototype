# Chain of Title

> Chain of Title links present claims to durable evidence and past transfers

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:title-deeds:chain-of-title` |
| Family | Title, Deeds & Recording |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | governance-mechanism |
| Archetype | The Boundary |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

The sequence of recorded and sometimes unrecorded transfers and claims through which present ownership is traced.

## What it actually does

Makes title auditable, revealing gaps, conflicts, clouds, and the evidence needed to insure or cure ownership.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** legitimacy, clarity, enforceability, administrative efficiency
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Legal Description, Recording, Chain of Title, Authority

## Archetypal reading

- **Essence:** Chain of Title links present claims to durable evidence and past transfers
- **Gift:** Clarity about chain of title makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When chain of title is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when chain of title is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where chain of title appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Chain of Title reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Chain of Title changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Chain of Title changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Chain of Title can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Boundary enters the reading through Chain of Title. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** Who has legitimate authority under Chain of Title, and where does that authority stop?

**Guidance:** Name the source, scope, duration, appeal path, and release of authority.

## Game function

Changes what actions are permitted and who may authorize them. Initiative 3.

## Relationships

- **Easement is administered through Chain of Title.** Easement is administered through Chain of Title through a change in rights, information, cash flow, priority, timing, or physical use.
- **Bargain and Sale Deed is administered through Chain of Title.** Bargain and Sale Deed is administered through Chain of Title through a change in rights, information, cash flow, priority, timing, or physical use.
- **Chain of Title depends on Title Search.** Chain of Title depends on Title Search through a change in rights, information, cash flow, priority, timing, or physical use.
- **Chain of Title depends on Cadastral Map.** Chain of Title depends on Cadastral Map through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Chain of Title through the lineage of Title, Deeds & Recording: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Chain of Title: a cadastral grid overlaid with colored permissions, gates, and invisible boundaries made visible; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, legal variation, regulatory sensitivity. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
