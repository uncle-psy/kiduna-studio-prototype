# Deed

> Deed links present claims to durable evidence and past transfers

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:title-deeds:deed` |
| Family | Title, Deeds & Recording |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | record-or-instrument |
| Archetype | The Memory |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

A formal instrument used to convey an interest in real property.

## What it actually does

Records the grantor, grantee, interest, legal description, and warranties needed to move title through a recognized ceremony of transfer.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** borrower, lender, title professional, attorney, custodian, recorder
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** durable evidence, priority, notice, transferability
- **Dependencies:** Legal Description, Recording, Chain of Title, Authority

## Archetypal reading

- **Essence:** Deed links present claims to durable evidence and past transfers
- **Gift:** Clarity about deed makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When deed is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when deed is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where deed appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Deed reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Deed changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Deed changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Deed can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Memory enters the reading through Deed. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What must Deed make durable before you can safely proceed?

**Guidance:** Resolve provenance, authority, custody, and ambiguity before relying on the artifact.

## Game function

Provides Evidence or Authority; missing custody or a defect blocks transfer. Initiative 2.

## Relationships

- **Possession amplifies Deed.** Possession amplifies Deed through a change in rights, information, cash flow, priority, timing, or physical use.
- **Title is governed by Deed.** Title is governed by Deed through a change in rights, information, cash flow, priority, timing, or physical use.
- **Deed externalizes to Warranty Deed.** Deed externalizes to Warranty Deed through a change in rights, information, cash flow, priority, timing, or physical use.
- **Deed conflicts with ALTA Survey.** Deed conflicts with ALTA Survey through a change in rights, information, cash flow, priority, timing, or physical use.
- **Title is transferred by Deed.** Title is transferred by Deed through a change in rights, information, cash flow, priority, timing, or physical use.
- **Deed is located through Recording.** Deed is located through Recording through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Deed through the lineage of Title, Deeds & Recording: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Deed: engraved layers, signatures, parcel geometry, seals, and custody marks held inside a precise brass frame; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, legal variation, regulatory sensitivity. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
