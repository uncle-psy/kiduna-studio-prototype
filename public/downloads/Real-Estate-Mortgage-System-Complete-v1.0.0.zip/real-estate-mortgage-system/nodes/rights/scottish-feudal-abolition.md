# Scottish Feudal Abolition

> Scottish Feudal Abolition demonstrates that ownership and mortgage conventions vary by jurisdiction and history

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:global-models:scottish-feudal-abolition` |
| Family | Global Property Systems |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Tension |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Scottish Feudal Abolition is a concept in the Global Property Systems family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Scottish Feudal Abolition demonstrates that ownership and mortgage conventions vary by jurisdiction and history.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Scottish Feudal Abolition demonstrates that ownership and mortgage conventions vary by jurisdiction and history
- **Gift:** Clarity about scottish feudal abolition makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When scottish feudal abolition is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when scottish feudal abolition is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where scottish feudal abolition appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Scottish Feudal Abolition reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Scottish Feudal Abolition changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Scottish Feudal Abolition changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Scottish Feudal Abolition can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tension enters the reading through Scottish Feudal Abolition. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Scottish Feudal Abolition becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 3.

## Relationships

- **Cadastral Survey is evidenced by Scottish Feudal Abolition.** Cadastral Survey is evidenced by Scottish Feudal Abolition through a change in rights, information, cash flow, priority, timing, or physical use.
- **English Leasehold is governed by Scottish Feudal Abolition.** English Leasehold is governed by Scottish Feudal Abolition through a change in rights, information, cash flow, priority, timing, or physical use.
- **Scottish Feudal Abolition externalizes to Strata Title.** Scottish Feudal Abolition externalizes to Strata Title through a change in rights, information, cash flow, priority, timing, or physical use.
- **Scottish Feudal Abolition is administered through Avulsion.** Scottish Feudal Abolition is administered through Avulsion through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Scottish Feudal Abolition through the lineage of Global Property Systems: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Scottish Feudal Abolition: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
- [Covered Bonds in the EU Financial System](https://www.ecb.europa.eu/pub/pdf/other/coverbondsintheeufinancialsystem200812en_en.pdf) — European Central Bank; covered bonds and European mortgage funding.
