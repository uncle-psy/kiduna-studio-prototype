# Easement

> Easement separates ownership into particular powers that may be shared, limited, or transferred

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:property-rights:easement` |
| Family | Property Rights |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Tension |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

A nonpossessory right to use or restrict another parcel for a defined purpose.

## What it actually does

Lets access, utilities, conservation, light, or other benefits cross ownership boundaries without transferring the land itself.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Easement separates ownership into particular powers that may be shared, limited, or transferred
- **Gift:** Clarity about easement makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When easement is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when easement is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where easement appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Easement reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Easement changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Easement changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Easement can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tension enters the reading through Easement. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Easement becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 3.

## Relationships

- **Remainder is evidenced by Easement.** Remainder is evidenced by Easement through a change in rights, information, cash flow, priority, timing, or physical use.
- **Access is evidenced by Easement.** Access is evidenced by Easement through a change in rights, information, cash flow, priority, timing, or physical use.
- **Easement is administered through Right-of-Way.** Easement is administered through Right-of-Way through a change in rights, information, cash flow, priority, timing, or physical use.
- **Easement is administered through Chain of Title.** Easement is administered through Chain of Title through a change in rights, information, cash flow, priority, timing, or physical use.
- **Easement encumbers Parcel.** Easement encumbers Parcel through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Ownership versus Access
- Private Property versus Commons

## Historical lineage and regulatory context

Read Easement through the lineage of Property Rights: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Easement: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, legal variation, regulatory sensitivity. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
