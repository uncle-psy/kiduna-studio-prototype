# Air Rights

> Air Rights separates ownership into particular powers that may be shared, limited, or transferred

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:property-rights:air-rights` |
| Family | Property Rights |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | governance-mechanism |
| Archetype | The Boundary |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Air Rights is a governance mechanism in the Property Rights family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Air Rights separates ownership into particular powers that may be shared, limited, or transferred.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** legitimacy, clarity, enforceability, administrative efficiency
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Air Rights separates ownership into particular powers that may be shared, limited, or transferred
- **Gift:** Clarity about air rights makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When air rights is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when air rights is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where air rights appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Air Rights reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Air Rights changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Air Rights changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Air Rights can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Boundary enters the reading through Air Rights. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** Who has legitimate authority under Air Rights, and where does that authority stop?

**Guidance:** Name the source, scope, duration, appeal path, and release of authority.

## Game function

Changes what actions are permitted and who may authorize them. Initiative 1.

## Relationships

- **Joint Tenancy documents Air Rights.** Joint Tenancy documents Air Rights through a change in rights, information, cash flow, priority, timing, or physical use.
- **Right-of-Way depends on Air Rights.** Right-of-Way depends on Air Rights through a change in rights, information, cash flow, priority, timing, or physical use.
- **Air Rights constrains Mineral Rights.** Air Rights constrains Mineral Rights through a change in rights, information, cash flow, priority, timing, or physical use.
- **Air Rights transfers into Title Commitment.** Air Rights transfers into Title Commitment through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Ownership versus Access
- Private Property versus Commons

## Historical lineage and regulatory context

Read Air Rights through the lineage of Property Rights: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Air Rights: a cadastral grid overlaid with colored permissions, gates, and invisible boundaries made visible; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, legal variation, regulatory sensitivity. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
