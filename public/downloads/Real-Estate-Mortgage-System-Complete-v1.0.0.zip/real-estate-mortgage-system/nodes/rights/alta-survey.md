# ALTA Survey

> ALTA Survey translates physical land into measurable and contestable geometry

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:survey-boundary:alta-survey` |
| Family | Survey & Boundary |
| Domain | Technology |
| Era | Institutional Age → Agentic Age |
| Kind | record-or-instrument |
| Archetype | The Ledger |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

ALTA Survey is a record or instrument in the Survey & Boundary family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

ALTA Survey translates physical land into measurable and contestable geometry.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** borrower, lender, title professional, attorney, custodian, recorder
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** durable evidence, priority, notice, transferability
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** ALTA Survey translates physical land into measurable and contestable geometry
- **Gift:** Clarity about alta survey makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When alta survey is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when alta survey is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where alta survey appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** ALTA Survey reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** ALTA Survey changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** ALTA Survey changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** ALTA Survey can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Ledger enters the reading through ALTA Survey. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What must ALTA Survey make durable before you can safely proceed?

**Guidance:** Resolve provenance, authority, custody, and ambiguity before relying on the artifact.

## Game function

Provides Evidence or Authority; missing custody or a defect blocks transfer. Initiative 2.

## Relationships

- **Deed conflicts with ALTA Survey.** Deed conflicts with ALTA Survey through a change in rights, information, cash flow, priority, timing, or physical use.
- **Boundary Survey externalizes to ALTA Survey.** Boundary Survey externalizes to ALTA Survey through a change in rights, information, cash flow, priority, timing, or physical use.
- **ALTA Survey amplifies Plat.** ALTA Survey amplifies Plat through a change in rights, information, cash flow, priority, timing, or physical use.
- **ALTA Survey is evidenced by Multiple Listing Service.** ALTA Survey is evidenced by Multiple Listing Service through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read ALTA Survey through the lineage of Survey & Boundary: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for ALTA Survey: engraved layers, signatures, parcel geometry, seals, and custody marks held inside a precise brass frame; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
