# Canadian Insured Mortgage

> Canadian Insured Mortgage demonstrates that ownership and mortgage conventions vary by jurisdiction and history

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:global-models:canadian-insured-mortgage` |
| Family | Global Property Systems |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | financial-instrument |
| Archetype | The Promise |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Canadian Insured Mortgage is a financial instrument in the Global Property Systems family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Canadian Insured Mortgage demonstrates that ownership and mortgage conventions vary by jurisdiction and history.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Canadian Insured Mortgage demonstrates that ownership and mortgage conventions vary by jurisdiction and history
- **Gift:** Clarity about canadian insured mortgage makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When canadian insured mortgage is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when canadian insured mortgage is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where canadian insured mortgage appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Canadian Insured Mortgage reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Canadian Insured Mortgage changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Canadian Insured Mortgage changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Canadian Insured Mortgage can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Promise enters the reading through Canadian Insured Mortgage. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Canadian Insured Mortgage, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 2.

## Relationships

- **Federal Housing Administration — 1934 externalizes to Canadian Insured Mortgage.** Federal Housing Administration — 1934 externalizes to Canadian Insured Mortgage through a change in rights, information, cash flow, priority, timing, or physical use.
- **Australian Torrens Title conflicts with Canadian Insured Mortgage.** Australian Torrens Title conflicts with Canadian Insured Mortgage through a change in rights, information, cash flow, priority, timing, or physical use.
- **Canadian Insured Mortgage is evidenced by German Pfandbrief.** Canadian Insured Mortgage is evidenced by German Pfandbrief through a change in rights, information, cash flow, priority, timing, or physical use.
- **Canadian Insured Mortgage amplifies Ancient Lights.** Canadian Insured Mortgage amplifies Ancient Lights through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Canadian Insured Mortgage through the lineage of Global Property Systems: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Canadian Insured Mortgage: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
- [Covered Bonds in the EU Financial System](https://www.ecb.europa.eu/pub/pdf/other/coverbondsintheeufinancialsystem200812en_en.pdf) — European Central Bank; covered bonds and European mortgage funding.
