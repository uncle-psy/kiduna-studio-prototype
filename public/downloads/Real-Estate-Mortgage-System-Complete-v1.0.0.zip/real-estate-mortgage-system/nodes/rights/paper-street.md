# Paper Street

> Paper Street makes visible the moments when maps, records, use, and physical reality disagree

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:strange-property:paper-street` |
| Family | Strange Property Law |
| Domain | Governance |
| Era | Kinship Age → Agentic Age |
| Kind | place-or-property |
| Archetype | The Habitat |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

A street or right-of-way shown on a recorded plan but never physically opened or improved for travel.

## What it actually does

Leaves a legal map of access or dedication suspended between record and ground, affecting title and development.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Paper Street makes visible the moments when maps, records, use, and physical reality disagree
- **Gift:** Clarity about paper street makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When paper street is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when paper street is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where paper street appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Paper Street reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Paper Street changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Paper Street changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Paper Street can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Habitat enters the reading through Paper Street. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What relationships become visible when Paper Street is treated as a place rather than only an asset?

**Guidance:** Walk the physical, legal, financial, ecological, and human maps separately before recombining them.

## Game function

Occupies spatial capacity and generates use, cost, externality, identity, or cash flow. Initiative 1.

## Relationships

- **Singapore Public Housing transfers into Paper Street.** Singapore Public Housing transfers into Paper Street through a change in rights, information, cash flow, priority, timing, or physical use.
- **Spite House constrains Paper Street.** Spite House constrains Paper Street through a change in rights, information, cash flow, priority, timing, or physical use.
- **Paper Street enables Ghost Subdivision.** Paper Street enables Ghost Subdivision through a change in rights, information, cash flow, priority, timing, or physical use.
- **Paper Street is governed by Mortgage Burning.** Paper Street is governed by Mortgage Burning through a change in rights, information, cash flow, priority, timing, or physical use.
- **Paper Street contrasts record with Place.** Paper Street contrasts record with Place through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Paper Street through the lineage of Strange Property Law: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Paper Street: a tactile architectural environment rendered in deep enamel, stone, vegetation, water, and fine metal lines; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
