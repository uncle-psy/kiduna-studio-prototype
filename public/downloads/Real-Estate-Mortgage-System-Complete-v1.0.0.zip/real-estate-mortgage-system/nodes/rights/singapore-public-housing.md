# Singapore Public Housing

> Singapore Public Housing demonstrates that ownership and mortgage conventions vary by jurisdiction and history

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:global-models:singapore-public-housing` |
| Family | Global Property Systems |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | place-or-property |
| Archetype | The Vessel |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Singapore Public Housing is a place or property in the Global Property Systems family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Singapore Public Housing demonstrates that ownership and mortgage conventions vary by jurisdiction and history.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Singapore Public Housing demonstrates that ownership and mortgage conventions vary by jurisdiction and history
- **Gift:** Clarity about singapore public housing makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When singapore public housing is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when singapore public housing is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where singapore public housing appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Singapore Public Housing reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Singapore Public Housing changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Singapore Public Housing changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Singapore Public Housing can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Vessel enters the reading through Singapore Public Housing. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What relationships become visible when Singapore Public Housing is treated as a place rather than only an asset?

**Guidance:** Walk the physical, legal, financial, ecological, and human maps separately before recombining them.

## Game function

Occupies spatial capacity and generates use, cost, externality, identity, or cash flow. Initiative 1.

## Relationships

- **Savings and Loan Crisis documents Singapore Public Housing.** Savings and Loan Crisis documents Singapore Public Housing through a change in rights, information, cash flow, priority, timing, or physical use.
- **European Covered Bond depends on Singapore Public Housing.** European Covered Bond depends on Singapore Public Housing through a change in rights, information, cash flow, priority, timing, or physical use.
- **Singapore Public Housing constrains Hong Kong Government Lease.** Singapore Public Housing constrains Hong Kong Government Lease through a change in rights, information, cash flow, priority, timing, or physical use.
- **Singapore Public Housing transfers into Paper Street.** Singapore Public Housing transfers into Paper Street through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Singapore Public Housing through the lineage of Global Property Systems: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Singapore Public Housing: a tactile architectural environment rendered in deep enamel, stone, vegetation, water, and fine metal lines; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
- [Covered Bonds in the EU Financial System](https://www.ecb.europa.eu/pub/pdf/other/coverbondsintheeufinancialsystem200812en_en.pdf) — European Central Bank; covered bonds and European mortgage funding.
