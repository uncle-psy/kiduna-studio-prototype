# Right-of-Way

> Right-of-Way separates ownership into particular powers that may be shared, limited, or transferred

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:property-rights:right-of-way` |
| Family | Property Rights |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Right-of-Way is a concept in the Property Rights family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Right-of-Way separates ownership into particular powers that may be shared, limited, or transferred.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Right-of-Way separates ownership into particular powers that may be shared, limited, or transferred
- **Gift:** Clarity about right-of-way makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When right-of-way is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when right-of-way is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where right-of-way appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Right-of-Way reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Right-of-Way changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Right-of-Way changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Right-of-Way can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Right-of-Way. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Right-of-Way becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 4.

## Relationships

- **Tenancy in Common constrains Right-of-Way.** Tenancy in Common constrains Right-of-Way through a change in rights, information, cash flow, priority, timing, or physical use.
- **Easement is administered through Right-of-Way.** Easement is administered through Right-of-Way through a change in rights, information, cash flow, priority, timing, or physical use.
- **Right-of-Way depends on Air Rights.** Right-of-Way depends on Air Rights through a change in rights, information, cash flow, priority, timing, or physical use.
- **Right-of-Way enables Title Search.** Right-of-Way enables Title Search through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Ownership versus Access
- Private Property versus Commons

## Historical lineage and regulatory context

Read Right-of-Way through the lineage of Property Rights: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Right-of-Way: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, legal variation, regulatory sensitivity. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
- [American Land Title Association](https://www.alta.org/) — American Land Title Association; title, escrow, closing, title insurance practice.
