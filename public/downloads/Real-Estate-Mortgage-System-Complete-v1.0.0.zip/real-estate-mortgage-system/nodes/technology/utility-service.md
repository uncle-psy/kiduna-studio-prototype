# Utility Service

> Utility Service keeps the physical vessel safe, useful, comfortable, and capable of renewal

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:building-systems:utility-service` |
| Family | Building Systems & Stewardship |
| Domain | Technology |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Utility Service is a concept in the Building Systems & Stewardship family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Utility Service keeps the physical vessel safe, useful, comfortable, and capable of renewal.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, developer, architect, engineer, contractor, inspector
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Utility Service keeps the physical vessel safe, useful, comfortable, and capable of renewal
- **Gift:** Clarity about utility service makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When utility service is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when utility service is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where utility service appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Utility Service reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Utility Service changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Utility Service changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Utility Service can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Utility Service. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Utility Service becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **Draw Request transfers into Utility Service.** Draw Request transfers into Utility Service through a change in rights, information, cash flow, priority, timing, or physical use.
- **Building Envelope — System constrains Utility Service.** Building Envelope — System constrains Utility Service through a change in rights, information, cash flow, priority, timing, or physical use.
- **Utility Service enables Preventive Maintenance.** Utility Service enables Preventive Maintenance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Utility Service is governed by Limited-Equity Cooperative.** Utility Service is governed by Limited-Equity Cooperative through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Utility Service through the lineage of Building Systems & Stewardship: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Utility Service: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Commercial Building Performance Monitoring and Evaluation](https://www.energy.gov/cmei/buildings/commercial-building-performance-monitoring-and-evaluation) — U.S. Department of Energy; building performance metrics and evaluation.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
