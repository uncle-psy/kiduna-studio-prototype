# SMART Doc

> SMART Doc turns documents, observations, decisions, and physical assets into computational workflows

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:proptech-digital:smart-doc` |
| Family | PropTech & Digital Mortgage |
| Domain | Technology |
| Era | Agentic Age → Collective Age |
| Kind | concept |
| Archetype | The Pattern |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

SMART Doc is a concept in the PropTech & Digital Mortgage family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

SMART Doc turns documents, observations, decisions, and physical assets into computational workflows.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** SMART Doc turns documents, observations, decisions, and physical assets into computational workflows
- **Gift:** Clarity about smart doc makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When smart doc is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when smart doc is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where smart doc appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** SMART Doc reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** SMART Doc changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** SMART Doc changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** SMART Doc can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Pattern enters the reading through SMART Doc. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when SMART Doc becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 2.

## Relationships

- **Appraiser prices SMART Doc.** Appraiser prices SMART Doc through a change in rights, information, cash flow, priority, timing, or physical use.
- **eRecording conflicts with SMART Doc.** eRecording conflicts with SMART Doc through a change in rights, information, cash flow, priority, timing, or physical use.
- **SMART Doc is evidenced by Digital Twin.** SMART Doc is evidenced by Digital Twin through a change in rights, information, cash flow, priority, timing, or physical use.
- **SMART Doc documents Synthetic Identity.** SMART Doc documents Synthetic Identity through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read SMART Doc through the lineage of PropTech & Digital Mortgage: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for SMART Doc: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
- [MISMO Standards & Resources](https://www.mismo.org/standards-resources) — Mortgage Industry Standards Maintenance Organization; residential and commercial mortgage data standards.
- [Quality Control Standards for Automated Valuation Models](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/quality-control-standards-for-automated-valuation-models/) — Consumer Financial Protection Bureau; AVM controls and valuation technology.
