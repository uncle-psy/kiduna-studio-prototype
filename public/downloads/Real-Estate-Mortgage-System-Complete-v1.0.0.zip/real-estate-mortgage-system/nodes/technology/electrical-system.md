# Electrical System

> Electrical System keeps the physical vessel safe, useful, comfortable, and capable of renewal

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:building-systems:electrical-system` |
| Family | Building Systems & Stewardship |
| Domain | Technology |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Relation |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Electrical System is a concept in the Building Systems & Stewardship family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Electrical System keeps the physical vessel safe, useful, comfortable, and capable of renewal.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, developer, architect, engineer, contractor, inspector
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Electrical System keeps the physical vessel safe, useful, comfortable, and capable of renewal
- **Gift:** Clarity about electrical system makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When electrical system is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when electrical system is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where electrical system appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Electrical System reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Electrical System changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Electrical System changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Electrical System can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Relation enters the reading through Electrical System. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Electrical System becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 4.

## Relationships

- **Building Envelope enables Electrical System.** Building Envelope enables Electrical System through a change in rights, information, cash flow, priority, timing, or physical use.
- **Plumbing amplifies Electrical System.** Plumbing amplifies Electrical System through a change in rights, information, cash flow, priority, timing, or physical use.
- **Electrical System conflicts with HVAC.** Electrical System conflicts with HVAC through a change in rights, information, cash flow, priority, timing, or physical use.
- **Electrical System prices Low-Income Housing Tax Credit.** Electrical System prices Low-Income Housing Tax Credit through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Electrical System through the lineage of Building Systems & Stewardship: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Electrical System: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Commercial Building Performance Monitoring and Evaluation](https://www.energy.gov/cmei/buildings/commercial-building-performance-monitoring-and-evaluation) — U.S. Department of Energy; building performance metrics and evaluation.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
