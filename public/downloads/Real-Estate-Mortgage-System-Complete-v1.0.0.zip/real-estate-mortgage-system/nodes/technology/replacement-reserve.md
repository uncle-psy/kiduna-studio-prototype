# Replacement Reserve

> Replacement Reserve keeps the physical vessel safe, useful, comfortable, and capable of renewal

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:building-systems:replacement-reserve` |
| Family | Building Systems & Stewardship |
| Domain | Technology |
| Era | Institutional Age → Collective Age |
| Kind | actor-or-institution |
| Archetype | The Intermediary |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Replacement Reserve is a actor or institution in the Building Systems & Stewardship family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Replacement Reserve keeps the physical vessel safe, useful, comfortable, and capable of renewal.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** counterparties, clients, members, regulators, investors
- **Incentives:** compensation, completion, risk control, reputation, authority
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Replacement Reserve keeps the physical vessel safe, useful, comfortable, and capable of renewal
- **Gift:** Clarity about replacement reserve makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When replacement reserve is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when replacement reserve is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where replacement reserve appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Replacement Reserve reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Replacement Reserve changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Replacement Reserve changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Replacement Reserve can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Intermediary enters the reading through Replacement Reserve. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What does Replacement Reserve know, want, control, and carry if the transaction fails?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a playable role with asymmetric information, incentives, authority, and accountability. Initiative 1.

## Relationships

- **Mechanic's Lien transfers into Replacement Reserve.** Mechanic's Lien transfers into Replacement Reserve through a change in rights, information, cash flow, priority, timing, or physical use.
- **Capital Expenditure transfers into Replacement Reserve.** Capital Expenditure transfers into Replacement Reserve through a change in rights, information, cash flow, priority, timing, or physical use.
- **Replacement Reserve is governed by Supportive Housing.** Replacement Reserve is governed by Supportive Housing through a change in rights, information, cash flow, priority, timing, or physical use.
- **Replacement Reserve buffers Capital Expenditure.** Replacement Reserve buffers Capital Expenditure through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Replacement Reserve through the lineage of Building Systems & Stewardship: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Replacement Reserve: a central instrument surrounded by flows of information, authority, capital, and accountability; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Commercial Building Performance Monitoring and Evaluation](https://www.energy.gov/cmei/buildings/commercial-building-performance-monitoring-and-evaluation) — U.S. Department of Energy; building performance metrics and evaluation.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
