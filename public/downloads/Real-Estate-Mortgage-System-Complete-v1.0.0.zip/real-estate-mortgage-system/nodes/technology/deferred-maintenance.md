# Deferred Maintenance

> Deferred Maintenance keeps the physical vessel safe, useful, comfortable, and capable of renewal

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:building-systems:deferred-maintenance` |
| Family | Building Systems & Stewardship |
| Domain | Technology |
| Era | Institutional Age → Collective Age |
| Kind | process |
| Archetype | The Settlement |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Deferred Maintenance is a process in the Building Systems & Stewardship family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Deferred Maintenance keeps the physical vessel safe, useful, comfortable, and capable of renewal.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, developer, architect, engineer, contractor, inspector
- **Incentives:** certainty, speed, compliance, completion, error reduction
- **Inputs:** participants, documents, conditions, authority, time
- **Outputs:** decision, changed state, record, new obligations
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Deferred Maintenance keeps the physical vessel safe, useful, comfortable, and capable of renewal
- **Gift:** Clarity about deferred maintenance makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When deferred maintenance is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when deferred maintenance is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where deferred maintenance appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Deferred Maintenance reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Deferred Maintenance changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Deferred Maintenance changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Deferred Maintenance can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Settlement enters the reading through Deferred Maintenance. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What information or condition must Deferred Maintenance translate before the next commitment becomes safe?

**Guidance:** Make conditions, exceptions, handoffs, and completion criteria explicit.

## Game function

Creates a gated action requiring inputs, a decision, and a resulting Record. Initiative 3.

## Relationships

- **Punch List is administered through Deferred Maintenance.** Punch List is administered through Deferred Maintenance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Preventive Maintenance prices Deferred Maintenance.** Preventive Maintenance prices Deferred Maintenance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Deferred Maintenance documents Capital Expenditure.** Deferred Maintenance documents Capital Expenditure through a change in rights, information, cash flow, priority, timing, or physical use.
- **Deferred Maintenance depends on Social Housing.** Deferred Maintenance depends on Social Housing through a change in rights, information, cash flow, priority, timing, or physical use.
- **Deferred Maintenance transforms into Capital Expenditure.** Deferred Maintenance transforms into Capital Expenditure through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Deferred Maintenance through the lineage of Building Systems & Stewardship: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Deferred Maintenance: a sequence of thresholds connected by a single bright path, with conditions represented as gates; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Commercial Building Performance Monitoring and Evaluation](https://www.energy.gov/cmei/buildings/commercial-building-performance-monitoring-and-evaluation) — U.S. Department of Energy; building performance metrics and evaluation.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
