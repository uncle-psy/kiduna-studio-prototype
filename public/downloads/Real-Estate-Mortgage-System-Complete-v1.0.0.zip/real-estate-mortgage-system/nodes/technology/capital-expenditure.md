# Capital Expenditure

> Capital Expenditure keeps the physical vessel safe, useful, comfortable, and capable of renewal

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:building-systems:capital-expenditure` |
| Family | Building Systems & Stewardship |
| Domain | Technology |
| Era | Institutional Age → Collective Age |
| Kind | financial-instrument |
| Archetype | The Bridge |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Capital Expenditure is a financial instrument in the Building Systems & Stewardship family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Capital Expenditure keeps the physical vessel safe, useful, comfortable, and capable of renewal.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, developer, architect, engineer, contractor, inspector
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Capital Expenditure keeps the physical vessel safe, useful, comfortable, and capable of renewal
- **Gift:** Clarity about capital expenditure makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When capital expenditure is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when capital expenditure is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where capital expenditure appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Capital Expenditure reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Capital Expenditure changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Capital Expenditure changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Capital Expenditure can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Bridge enters the reading through Capital Expenditure. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Capital Expenditure, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 4.

## Relationships

- **Substantial Completion enables Capital Expenditure.** Substantial Completion enables Capital Expenditure through a change in rights, information, cash flow, priority, timing, or physical use.
- **Deferred Maintenance documents Capital Expenditure.** Deferred Maintenance documents Capital Expenditure through a change in rights, information, cash flow, priority, timing, or physical use.
- **Capital Expenditure transfers into Replacement Reserve.** Capital Expenditure transfers into Replacement Reserve through a change in rights, information, cash flow, priority, timing, or physical use.
- **Capital Expenditure prices Council Housing.** Capital Expenditure prices Council Housing through a change in rights, information, cash flow, priority, timing, or physical use.
- **Deferred Maintenance transforms into Capital Expenditure.** Deferred Maintenance transforms into Capital Expenditure through a change in rights, information, cash flow, priority, timing, or physical use.
- **Replacement Reserve buffers Capital Expenditure.** Replacement Reserve buffers Capital Expenditure through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Capital Expenditure through the lineage of Building Systems & Stewardship: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Capital Expenditure: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Commercial Building Performance Monitoring and Evaluation](https://www.energy.gov/cmei/buildings/commercial-building-performance-monitoring-and-evaluation) — U.S. Department of Energy; building performance metrics and evaluation.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
