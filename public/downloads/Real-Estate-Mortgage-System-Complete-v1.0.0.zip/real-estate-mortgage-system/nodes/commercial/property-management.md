# Property Management

> Property Management turns possession and use into a continuing exchange rather than a one-time transfer

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:leasing-operations:property-management` |
| Family | Leasing & Operations |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | place-or-property |
| Archetype | The Habitat |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Property Management is a place or property in the Leasing & Operations family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Property Management turns possession and use into a continuing exchange rather than a one-time transfer.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Property Management turns possession and use into a continuing exchange rather than a one-time transfer
- **Gift:** Clarity about property management makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When property management is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when property management is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where property management appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Property Management reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Property Management changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Property Management changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Property Management can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Habitat enters the reading through Property Management. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What relationships become visible when Property Management is treated as a place rather than only an asset?

**Guidance:** Walk the physical, legal, financial, ecological, and human maps separately before recombining them.

## Game function

Occupies spatial capacity and generates use, cost, externality, identity, or cash flow. Initiative 1.

## Relationships

- **Housing Demand is administered through Property Management.** Housing Demand is administered through Property Management through a change in rights, information, cash flow, priority, timing, or physical use.
- **Common Area Maintenance is administered through Property Management.** Common Area Maintenance is administered through Property Management through a change in rights, information, cash flow, priority, timing, or physical use.
- **Property Management depends on Bailee Receipt.** Property Management depends on Bailee Receipt through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Property Management through the lineage of Leasing & Operations: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Property Management: a tactile architectural environment rendered in deep enamel, stone, vegetation, water, and fine metal lines; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
- [Leasehold Property Overview](https://www.gov.uk/leasehold-property/overview) — Government of the United Kingdom; leasehold and freehold tenure.
