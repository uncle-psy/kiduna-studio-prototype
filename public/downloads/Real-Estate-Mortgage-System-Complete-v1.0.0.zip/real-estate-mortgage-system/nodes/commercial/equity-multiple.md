# Equity Multiple

> Equity Multiple compresses property operations and risk into decision-making measures

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:cre-metrics:equity-multiple` |
| Family | Commercial Real Estate Metrics |
| Domain | Economics |
| Era | Agentic Age |
| Kind | metric-or-force |
| Archetype | The Tide |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Equity Multiple is a metric or force in the Commercial Real Estate Metrics family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Equity Multiple compresses property operations and risk into decision-making measures.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Equity Multiple compresses property operations and risk into decision-making measures
- **Gift:** Clarity about equity multiple makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When equity multiple is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when equity multiple is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where equity multiple appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Equity Multiple reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Equity Multiple changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Equity Multiple changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Equity Multiple can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tide enters the reading through Equity Multiple. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Equity Multiple measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 4.

## Relationships

- **Compensatory Fee conflicts with Equity Multiple.** Compensatory Fee conflicts with Equity Multiple through a change in rights, information, cash flow, priority, timing, or physical use.
- **Internal Rate of Return is administered through Equity Multiple.** Internal Rate of Return is administered through Equity Multiple through a change in rights, information, cash flow, priority, timing, or physical use.
- **Equity Multiple depends on Cash-on-Cash Return.** Equity Multiple depends on Cash-on-Cash Return through a change in rights, information, cash flow, priority, timing, or physical use.
- **Equity Multiple is evidenced by Syndicated Loan.** Equity Multiple is evidenced by Syndicated Loan through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Equity Multiple through the lineage of Commercial Real Estate Metrics: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Equity Multiple: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
