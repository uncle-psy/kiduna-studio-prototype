# Funds from Operations

> Funds from Operations compresses property operations and risk into decision-making measures

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:cre-metrics:funds-from-operations` |
| Family | Commercial Real Estate Metrics |
| Domain | Economics |
| Era | Agentic Age |
| Kind | metric-or-force |
| Archetype | The Gauge |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Funds from Operations is a metric or force in the Commercial Real Estate Metrics family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Funds from Operations compresses property operations and risk into decision-making measures.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Funds from Operations compresses property operations and risk into decision-making measures
- **Gift:** Clarity about funds from operations makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When funds from operations is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when funds from operations is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where funds from operations appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Funds from Operations reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Funds from Operations changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Funds from Operations changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Funds from Operations can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Gauge enters the reading through Funds from Operations. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Funds from Operations measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 2.

## Relationships

- **Delinquency Cost prices Funds from Operations.** Delinquency Cost prices Funds from Operations through a change in rights, information, cash flow, priority, timing, or physical use.
- **Operating Expense Ratio conflicts with Funds from Operations.** Operating Expense Ratio conflicts with Funds from Operations through a change in rights, information, cash flow, priority, timing, or physical use.
- **Funds from Operations is evidenced by Internal Rate of Return.** Funds from Operations is evidenced by Internal Rate of Return through a change in rights, information, cash flow, priority, timing, or physical use.
- **Funds from Operations documents B-Note.** Funds from Operations documents B-Note through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Funds from Operations through the lineage of Commercial Real Estate Metrics: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Funds from Operations: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
