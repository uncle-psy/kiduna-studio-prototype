# Bridge Loan — CRE

> Bridge Loan — CRE allocates priority, control, recourse, and return across a commercial capital stack

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:cre-finance:bridge-loan-cre` |
| Family | Commercial Real Estate Finance |
| Domain | Economics |
| Era | Agentic Age |
| Kind | financial-instrument |
| Archetype | The Promise |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Bridge Loan — CRE is a financial instrument in the Commercial Real Estate Finance family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Bridge Loan — CRE allocates priority, control, recourse, and return across a commercial capital stack.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Net Operating Income, Appraisal, Capital Stack, Exit

## Archetypal reading

- **Essence:** Bridge Loan — CRE allocates priority, control, recourse, and return across a commercial capital stack
- **Gift:** Clarity about bridge loan — cre makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When bridge loan — cre is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when bridge loan — cre is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where bridge loan — cre appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Bridge Loan — CRE reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Bridge Loan — CRE changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Bridge Loan — CRE changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Bridge Loan — CRE can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Promise enters the reading through Bridge Loan — CRE. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Bridge Loan — CRE, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 2.

## Relationships

- **Vacancy Rate documents Bridge Loan — CRE.** Vacancy Rate documents Bridge Loan — CRE through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mini-Perm Loan is governed by Bridge Loan — CRE.** Mini-Perm Loan is governed by Bridge Loan — CRE through a change in rights, information, cash flow, priority, timing, or physical use.
- **Bridge Loan — CRE externalizes to Mezzanine Loan.** Bridge Loan — CRE externalizes to Mezzanine Loan through a change in rights, information, cash flow, priority, timing, or physical use.
- **Bridge Loan — CRE transfers into Variance.** Bridge Loan — CRE transfers into Variance through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Bridge Loan — CRE through the lineage of Commercial Real Estate Finance: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Bridge Loan — CRE: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, financial risk. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
- [Dodd-Frank Act Rulemaking: Asset-Backed Securities](https://www.sec.gov/spotlight/dodd-frank/assetbackedsecurities.shtml) — U.S. Securities and Exchange Commission; ABS and RMBS securitization, tranching, disclosure.
