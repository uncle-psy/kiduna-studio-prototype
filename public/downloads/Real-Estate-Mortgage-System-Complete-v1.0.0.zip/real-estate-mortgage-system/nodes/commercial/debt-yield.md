# Debt Yield

> Debt Yield compresses property operations and risk into decision-making measures

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:cre-metrics:debt-yield` |
| Family | Commercial Real Estate Metrics |
| Domain | Economics |
| Era | Agentic Age |
| Kind | metric-or-force |
| Archetype | The Gauge |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Debt Yield is a metric or force in the Commercial Real Estate Metrics family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Debt Yield compresses property operations and risk into decision-making measures.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Debt Yield compresses property operations and risk into decision-making measures
- **Gift:** Clarity about debt yield makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When debt yield is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when debt yield is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where debt yield appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Debt Yield reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Debt Yield changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Debt Yield changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Debt Yield can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Gauge enters the reading through Debt Yield. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Debt Yield measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 4.

## Relationships

- **Excess Servicing conflicts with Debt Yield.** Excess Servicing conflicts with Debt Yield through a change in rights, information, cash flow, priority, timing, or physical use.
- **Debt-Service Coverage Ratio prices Debt Yield.** Debt-Service Coverage Ratio prices Debt Yield through a change in rights, information, cash flow, priority, timing, or physical use.
- **Debt Yield documents Occupancy Rate.** Debt Yield documents Occupancy Rate through a change in rights, information, cash flow, priority, timing, or physical use.
- **Debt Yield is evidenced by Construction Loan — CRE.** Debt Yield is evidenced by Construction Loan — CRE through a change in rights, information, cash flow, priority, timing, or physical use.
- **Debt Yield stress tests Leverage.** Debt Yield stress tests Leverage through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Debt Yield through the lineage of Commercial Real Estate Metrics: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Debt Yield: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
