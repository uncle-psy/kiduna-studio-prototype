# B-Note

> B-Note allocates priority, control, recourse, and return across a commercial capital stack

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:cre-finance:b-note` |
| Family | Commercial Real Estate Finance |
| Domain | Economics |
| Era | Agentic Age |
| Kind | record-or-instrument |
| Archetype | The Memory |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

B-Note is a record or instrument in the Commercial Real Estate Finance family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

B-Note allocates priority, control, recourse, and return across a commercial capital stack.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** borrower, lender, title professional, attorney, custodian, recorder
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** durable evidence, priority, notice, transferability
- **Dependencies:** Net Operating Income, Appraisal, Capital Stack, Exit

## Archetypal reading

- **Essence:** B-Note allocates priority, control, recourse, and return across a commercial capital stack
- **Gift:** Clarity about b-note makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When b-note is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when b-note is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where b-note appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** B-Note reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** B-Note changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** B-Note changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** B-Note can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Memory enters the reading through B-Note. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What must B-Note make durable before you can safely proceed?

**Guidance:** Resolve provenance, authority, custody, and ambiguity before relying on the artifact.

## Game function

Provides Evidence or Authority; missing custody or a defect blocks transfer. Initiative 2.

## Relationships

- **Funds from Operations documents B-Note.** Funds from Operations documents B-Note through a change in rights, information, cash flow, priority, timing, or physical use.
- **Senior Debt is evidenced by B-Note.** Senior Debt is evidenced by B-Note through a change in rights, information, cash flow, priority, timing, or physical use.
- **B-Note is administered through Participation Loan.** B-Note is administered through Participation Loan through a change in rights, information, cash flow, priority, timing, or physical use.
- **B-Note transfers into Development Agreement.** B-Note transfers into Development Agreement through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read B-Note through the lineage of Commercial Real Estate Finance: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for B-Note: engraved layers, signatures, parcel geometry, seals, and custody marks held inside a precise brass frame; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, financial risk. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
- [Dodd-Frank Act Rulemaking: Asset-Backed Securities](https://www.sec.gov/spotlight/dodd-frank/assetbackedsecurities.shtml) — U.S. Securities and Exchange Commission; ABS and RMBS securitization, tranching, disclosure.
