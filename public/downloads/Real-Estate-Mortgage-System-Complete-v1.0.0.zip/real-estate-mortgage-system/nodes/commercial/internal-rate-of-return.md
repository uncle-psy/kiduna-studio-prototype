# Internal Rate of Return

> Internal Rate of Return compresses property operations and risk into decision-making measures

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:cre-metrics:internal-rate-of-return` |
| Family | Commercial Real Estate Metrics |
| Domain | Economics |
| Era | Agentic Age |
| Kind | concept |
| Archetype | The Tension |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Internal Rate of Return is a concept in the Commercial Real Estate Metrics family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Internal Rate of Return compresses property operations and risk into decision-making measures.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Internal Rate of Return compresses property operations and risk into decision-making measures
- **Gift:** Clarity about internal rate of return makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When internal rate of return is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when internal rate of return is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where internal rate of return appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Internal Rate of Return reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Internal Rate of Return changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Internal Rate of Return changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Internal Rate of Return can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tension enters the reading through Internal Rate of Return. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Internal Rate of Return becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 3.

## Relationships

- **Float Income is governed by Internal Rate of Return.** Float Income is governed by Internal Rate of Return through a change in rights, information, cash flow, priority, timing, or physical use.
- **Funds from Operations is evidenced by Internal Rate of Return.** Funds from Operations is evidenced by Internal Rate of Return through a change in rights, information, cash flow, priority, timing, or physical use.
- **Internal Rate of Return is administered through Equity Multiple.** Internal Rate of Return is administered through Equity Multiple through a change in rights, information, cash flow, priority, timing, or physical use.
- **Internal Rate of Return externalizes to Participation Loan.** Internal Rate of Return externalizes to Participation Loan through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Internal Rate of Return through the lineage of Commercial Real Estate Metrics: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Internal Rate of Return: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
