# Senior Living

> Senior Living joins a physical asset to an operating use and income stream

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:commercial-property:senior-living` |
| Family | Commercial Property |
| Domain | Economics |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Senior Living is a concept in the Commercial Property family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Senior Living joins a physical asset to an operating use and income stream.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Senior Living joins a physical asset to an operating use and income stream
- **Gift:** Clarity about senior living makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When senior living is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when senior living is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where senior living appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Senior Living reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Senior Living changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Senior Living changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Senior Living can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Senior Living. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Senior Living becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **Investment Property enables Senior Living.** Investment Property enables Senior Living through a change in rights, information, cash flow, priority, timing, or physical use.
- **Student Housing enables Senior Living.** Student Housing enables Senior Living through a change in rights, information, cash flow, priority, timing, or physical use.
- **Senior Living prices Cooperative Ownership.** Senior Living prices Cooperative Ownership through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Senior Living through the lineage of Commercial Property: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Senior Living: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
