# Commercial Mortgage-Backed Security

> Commercial Mortgage-Backed Security turns pools of individual promises into tradable capital-market claims

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:securitization:commercial-mortgage-backed-security` |
| Family | Securitization & MBS |
| Domain | Economics |
| Era | Agentic Age |
| Kind | financial-instrument |
| Archetype | The Reservoir |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Commercial Mortgage-Backed Security is a financial instrument in the Securitization & MBS family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Commercial Mortgage-Backed Security turns pools of individual promises into tradable capital-market claims.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Pool, Loan Delivery, Servicing, Investor, Disclosure

## Archetypal reading

- **Essence:** Commercial Mortgage-Backed Security turns pools of individual promises into tradable capital-market claims
- **Gift:** Clarity about commercial mortgage-backed security makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When commercial mortgage-backed security is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when commercial mortgage-backed security is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where commercial mortgage-backed security appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Commercial Mortgage-Backed Security reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Commercial Mortgage-Backed Security changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Commercial Mortgage-Backed Security changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Commercial Mortgage-Backed Security can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Reservoir enters the reading through Commercial Mortgage-Backed Security. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Commercial Mortgage-Backed Security, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 4.

## Relationships

- **Ginnie Mae transfers into Commercial Mortgage-Backed Security.** Ginnie Mae transfers into Commercial Mortgage-Backed Security through a change in rights, information, cash flow, priority, timing, or physical use.
- **Private-Label RMBS is administered through Commercial Mortgage-Backed Security.** Private-Label RMBS is administered through Commercial Mortgage-Backed Security through a change in rights, information, cash flow, priority, timing, or physical use.
- **Commercial Mortgage-Backed Security depends on Pool.** Commercial Mortgage-Backed Security depends on Pool through a change in rights, information, cash flow, priority, timing, or physical use.
- **Commercial Mortgage-Backed Security is governed by Coupon Swap.** Commercial Mortgage-Backed Security is governed by Coupon Swap through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Commercial Mortgage-Backed Security through the lineage of Securitization & MBS: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Commercial Mortgage-Backed Security: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, financial risk. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Dodd-Frank Act Rulemaking: Asset-Backed Securities](https://www.sec.gov/spotlight/dodd-frank/assetbackedsecurities.shtml) — U.S. Securities and Exchange Commission; ABS and RMBS securitization, tranching, disclosure.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
- [TBA Trading and Liquidity in the Agency MBS Market](https://www.newyorkfed.org/research/epr/2013/1212vick.html) — Federal Reserve Bank of New York; TBA mechanics and liquidity.
