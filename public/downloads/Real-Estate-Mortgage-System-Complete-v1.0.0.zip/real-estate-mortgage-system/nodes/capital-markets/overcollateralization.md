# Overcollateralization

> Overcollateralization turns pools of individual promises into tradable capital-market claims

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:securitization:overcollateralization` |
| Family | Securitization & MBS |
| Domain | Economics |
| Era | Agentic Age |
| Kind | concept |
| Archetype | The Relation |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Overcollateralization is a concept in the Securitization & MBS family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Overcollateralization turns pools of individual promises into tradable capital-market claims.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Pool, Loan Delivery, Servicing, Investor, Disclosure

## Archetypal reading

- **Essence:** Overcollateralization turns pools of individual promises into tradable capital-market claims
- **Gift:** Clarity about overcollateralization makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When overcollateralization is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when overcollateralization is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where overcollateralization appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Overcollateralization reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Overcollateralization changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Overcollateralization changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Overcollateralization can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Relation enters the reading through Overcollateralization. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Overcollateralization becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 4.

## Relationships

- **Aggregator transfers into Overcollateralization.** Aggregator transfers into Overcollateralization through a change in rights, information, cash flow, priority, timing, or physical use.
- **Credit Enhancement externalizes to Overcollateralization.** Credit Enhancement externalizes to Overcollateralization through a change in rights, information, cash flow, priority, timing, or physical use.
- **Overcollateralization amplifies Subordination.** Overcollateralization amplifies Subordination through a change in rights, information, cash flow, priority, timing, or physical use.
- **Overcollateralization is governed by Convexity.** Overcollateralization is governed by Convexity through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Overcollateralization through the lineage of Securitization & MBS: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Overcollateralization: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, financial risk. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Dodd-Frank Act Rulemaking: Asset-Backed Securities](https://www.sec.gov/spotlight/dodd-frank/assetbackedsecurities.shtml) — U.S. Securities and Exchange Commission; ABS and RMBS securitization, tranching, disclosure.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
- [TBA Trading and Liquidity in the Agency MBS Market](https://www.newyorkfed.org/research/epr/2013/1212vick.html) — Federal Reserve Bank of New York; TBA mechanics and liquidity.
