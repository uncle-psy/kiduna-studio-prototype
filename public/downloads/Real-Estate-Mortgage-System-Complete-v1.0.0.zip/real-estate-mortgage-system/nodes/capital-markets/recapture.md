# Recapture

> Recapture separates the right and obligation to administer a loan from ownership of its principal cash flow

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:msr-economics:recapture` |
| Family | Mortgage Servicing Rights & Economics |
| Domain | Economics |
| Era | Agentic Age |
| Kind | pathology-or-event |
| Archetype | The Fracture |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Recapture is a pathology or event in the Mortgage Servicing Rights & Economics family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Recapture separates the right and obligation to administer a loan from ownership of its principal cash flow.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Recapture separates the right and obligation to administer a loan from ownership of its principal cash flow
- **Gift:** Clarity about recapture makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When recapture is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when recapture is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where recapture appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Recapture reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Recapture changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Recapture changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Recapture can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Fracture enters the reading through Recapture. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** Which earlier warning became visible only after Recapture arrived?

**Guidance:** Trace the failure backward through incentives, information, leverage, timing, and feedback rather than locating blame at the final visible event.

## Game function

Enters as a systemic event that exposes hidden leverage, deferred cost, or misaligned incentives. Initiative 2.

## Relationships

- **Warehouse Line enables Recapture.** Warehouse Line enables Recapture through a change in rights, information, cash flow, priority, timing, or physical use.
- **Subservicing documents Recapture.** Subservicing documents Recapture through a change in rights, information, cash flow, priority, timing, or physical use.
- **Recapture transfers into Prepayment Speed.** Recapture transfers into Prepayment Speed through a change in rights, information, cash flow, priority, timing, or physical use.
- **Recapture prices Vacancy Rate.** Recapture prices Vacancy Rate through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Recapture through the lineage of Mortgage Servicing Rights & Economics: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Recapture: a beautiful structure whose hidden fracture propagates through claims, cash flows, and neighboring parcels; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Servicing Guide](https://singlefamily.fanniemae.com/servicing) — Fannie Mae; servicing, delinquency, loss mitigation, investor reporting.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
- [About Fannie Mae & Freddie Mac](https://www.fhfa.gov/about/fannie-mae-freddie-mac) — Federal Housing Finance Agency; GSE liquidity, stability, affordability, MBS.
