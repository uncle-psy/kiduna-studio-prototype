# Best-Efforts Delivery

> Best-Efforts Delivery funds and transfers loans between production and permanent capital

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:whole-loan-warehouse:best-efforts-delivery` |
| Family | Whole Loans, Warehouse & Correspondent |
| Domain | Economics |
| Era | Agentic Age |
| Kind | concept |
| Archetype | The Tension |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Best-Efforts Delivery is a concept in the Whole Loans, Warehouse & Correspondent family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Best-Efforts Delivery funds and transfers loans between production and permanent capital.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Best-Efforts Delivery funds and transfers loans between production and permanent capital
- **Gift:** Clarity about best-efforts delivery makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When best-efforts delivery is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when best-efforts delivery is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where best-efforts delivery appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Best-Efforts Delivery reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Best-Efforts Delivery changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Best-Efforts Delivery changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Best-Efforts Delivery can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tension enters the reading through Best-Efforts Delivery. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Best-Efforts Delivery becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **Negative Convexity is evidenced by Best-Efforts Delivery.** Negative Convexity is evidenced by Best-Efforts Delivery through a change in rights, information, cash flow, priority, timing, or physical use.
- **Gestation Repo is evidenced by Best-Efforts Delivery.** Gestation Repo is evidenced by Best-Efforts Delivery through a change in rights, information, cash flow, priority, timing, or physical use.
- **Best-Efforts Delivery is administered through Servicing Release Premium.** Best-Efforts Delivery is administered through Servicing Release Premium through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Best-Efforts Delivery through the lineage of Whole Loans, Warehouse & Correspondent: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Best-Efforts Delivery: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
