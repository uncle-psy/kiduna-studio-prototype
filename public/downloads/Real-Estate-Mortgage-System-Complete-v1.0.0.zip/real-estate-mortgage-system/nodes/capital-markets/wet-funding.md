# Wet Funding

> Wet Funding funds and transfers loans between production and permanent capital

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:whole-loan-warehouse:wet-funding` |
| Family | Whole Loans, Warehouse & Correspondent |
| Domain | Economics |
| Era | Agentic Age |
| Kind | financial-instrument |
| Archetype | The Bridge |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Wet Funding is a financial instrument in the Whole Loans, Warehouse & Correspondent family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Wet Funding funds and transfers loans between production and permanent capital.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Wet Funding funds and transfers loans between production and permanent capital
- **Gift:** Clarity about wet funding makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When wet funding is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when wet funding is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where wet funding appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Wet Funding reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Wet Funding changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Wet Funding changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Wet Funding can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Bridge enters the reading through Wet Funding. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Wet Funding, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 1.

## Relationships

- **Single Monthly Mortality is evidenced by Wet Funding.** Single Monthly Mortality is evidenced by Wet Funding through a change in rights, information, cash flow, priority, timing, or physical use.
- **Bailee Letter is governed by Wet Funding.** Bailee Letter is governed by Wet Funding through a change in rights, information, cash flow, priority, timing, or physical use.
- **Wet Funding externalizes to Dry Funding.** Wet Funding externalizes to Dry Funding through a change in rights, information, cash flow, priority, timing, or physical use.
- **Wet Funding is administered through Advance Obligation.** Wet Funding is administered through Advance Obligation through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Wet Funding through the lineage of Whole Loans, Warehouse & Correspondent: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Wet Funding: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
