# Table Funding

> Table Funding funds and transfers loans between production and permanent capital

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:whole-loan-warehouse:table-funding` |
| Family | Whole Loans, Warehouse & Correspondent |
| Domain | Economics |
| Era | Agentic Age |
| Kind | financial-instrument |
| Archetype | The Promise |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Table Funding is a financial instrument in the Whole Loans, Warehouse & Correspondent family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Table Funding funds and transfers loans between production and permanent capital.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Table Funding funds and transfers loans between production and permanent capital
- **Gift:** Clarity about table funding makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When table funding is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when table funding is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where table funding appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Table Funding reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Table Funding changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Table Funding changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Table Funding can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Promise enters the reading through Table Funding. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Table Funding, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 3.

## Relationships

- **Duration documents Table Funding.** Duration documents Table Funding through a change in rights, information, cash flow, priority, timing, or physical use.
- **Dry Funding amplifies Table Funding.** Dry Funding amplifies Table Funding through a change in rights, information, cash flow, priority, timing, or physical use.
- **Table Funding conflicts with Gestation Repo.** Table Funding conflicts with Gestation Repo through a change in rights, information, cash flow, priority, timing, or physical use.
- **Table Funding transfers into Float Income.** Table Funding transfers into Float Income through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Table Funding through the lineage of Whole Loans, Warehouse & Correspondent: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Table Funding: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
