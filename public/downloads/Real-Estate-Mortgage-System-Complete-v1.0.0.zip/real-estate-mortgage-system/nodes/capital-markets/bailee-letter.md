# Bailee Letter

> Bailee Letter funds and transfers loans between production and permanent capital

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:whole-loan-warehouse:bailee-letter` |
| Family | Whole Loans, Warehouse & Correspondent |
| Domain | Economics |
| Era | Agentic Age |
| Kind | record-or-instrument |
| Archetype | The Witness |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Bailee Letter is a record or instrument in the Whole Loans, Warehouse & Correspondent family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Bailee Letter funds and transfers loans between production and permanent capital.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** borrower, lender, title professional, attorney, custodian, recorder
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** durable evidence, priority, notice, transferability
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Bailee Letter funds and transfers loans between production and permanent capital
- **Gift:** Clarity about bailee letter makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When bailee letter is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when bailee letter is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where bailee letter appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Bailee Letter reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Bailee Letter changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Bailee Letter changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Bailee Letter can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Witness enters the reading through Bailee Letter. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What must Bailee Letter make durable before you can safely proceed?

**Guidance:** Resolve provenance, authority, custody, and ambiguity before relying on the artifact.

## Game function

Provides Evidence or Authority; missing custody or a defect blocks transfer. Initiative 4.

## Relationships

- **Conditional Prepayment Rate externalizes to Bailee Letter.** Conditional Prepayment Rate externalizes to Bailee Letter through a change in rights, information, cash flow, priority, timing, or physical use.
- **Borrowing Base transfers into Bailee Letter.** Borrowing Base transfers into Bailee Letter through a change in rights, information, cash flow, priority, timing, or physical use.
- **Bailee Letter is governed by Wet Funding.** Bailee Letter is governed by Wet Funding through a change in rights, information, cash flow, priority, timing, or physical use.
- **Bailee Letter amplifies Servicing Valuation.** Bailee Letter amplifies Servicing Valuation through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Bailee Letter through the lineage of Whole Loans, Warehouse & Correspondent: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Bailee Letter: engraved layers, signatures, parcel geometry, seals, and custody marks held inside a precise brass frame; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
