# Servicing Strip

> Servicing Strip separates the right and obligation to administer a loan from ownership of its principal cash flow

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:msr-economics:servicing-strip` |
| Family | Mortgage Servicing Rights & Economics |
| Domain | Economics |
| Era | Agentic Age |
| Kind | process |
| Archetype | The Translation |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Servicing Strip is a process in the Mortgage Servicing Rights & Economics family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Servicing Strip separates the right and obligation to administer a loan from ownership of its principal cash flow.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** certainty, speed, compliance, completion, error reduction
- **Inputs:** participants, documents, conditions, authority, time
- **Outputs:** decision, changed state, record, new obligations
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Servicing Strip separates the right and obligation to administer a loan from ownership of its principal cash flow
- **Gift:** Clarity about servicing strip makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When servicing strip is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when servicing strip is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where servicing strip appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Servicing Strip reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Servicing Strip changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Servicing Strip changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Servicing Strip can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Translation enters the reading through Servicing Strip. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What information or condition must Servicing Strip translate before the next commitment becomes safe?

**Guidance:** Make conditions, exceptions, handoffs, and completion criteria explicit.

## Game function

Creates a gated action requiring inputs, a decision, and a resulting Record. Initiative 2.

## Relationships

- **Mortgage Loan Purchase Agreement enables Servicing Strip.** Mortgage Loan Purchase Agreement enables Servicing Strip through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mortgage Servicing Right depends on Servicing Strip.** Mortgage Servicing Right depends on Servicing Strip through a change in rights, information, cash flow, priority, timing, or physical use.
- **Servicing Strip constrains Servicing Fee.** Servicing Strip constrains Servicing Fee through a change in rights, information, cash flow, priority, timing, or physical use.
- **Servicing Strip prices Capitalization Rate.** Servicing Strip prices Capitalization Rate through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Servicing Strip through the lineage of Mortgage Servicing Rights & Economics: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Servicing Strip: a sequence of thresholds connected by a single bright path, with conditions represented as gates; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Servicing Guide](https://singlefamily.fanniemae.com/servicing) — Fannie Mae; servicing, delinquency, loss mitigation, investor reporting.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
- [About Fannie Mae & Freddie Mac](https://www.fhfa.gov/about/fannie-mae-freddie-mac) — Federal Housing Finance Agency; GSE liquidity, stability, affordability, MBS.
