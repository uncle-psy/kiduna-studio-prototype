# Dollar Roll

> Dollar Roll prices uncertain timing and optionality inside mortgage cash flows

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:bond-math-tba:dollar-roll` |
| Family | Bond Math & TBA Market |
| Domain | Economics |
| Era | Agentic Age |
| Kind | concept |
| Archetype | The Relation |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Dollar Roll is a concept in the Bond Math & TBA Market family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Dollar Roll prices uncertain timing and optionality inside mortgage cash flows.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Dollar Roll prices uncertain timing and optionality inside mortgage cash flows
- **Gift:** Clarity about dollar roll makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When dollar roll is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when dollar roll is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where dollar roll appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Dollar Roll reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Dollar Roll changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Dollar Roll changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Dollar Roll can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Relation enters the reading through Dollar Roll. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Dollar Roll becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 3.

## Relationships

- **Private-Label RMBS prices Dollar Roll.** Private-Label RMBS prices Dollar Roll through a change in rights, information, cash flow, priority, timing, or physical use.
- **Specified Pool is administered through Dollar Roll.** Specified Pool is administered through Dollar Roll through a change in rights, information, cash flow, priority, timing, or physical use.
- **Dollar Roll depends on Coupon Swap.** Dollar Roll depends on Coupon Swap through a change in rights, information, cash flow, priority, timing, or physical use.
- **Dollar Roll documents Correspondent Lending.** Dollar Roll documents Correspondent Lending through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Dollar Roll through the lineage of Bond Math & TBA Market: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Dollar Roll: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [TBA Trading and Liquidity in the Agency MBS Market](https://www.newyorkfed.org/research/epr/2013/1212vick.html) — Federal Reserve Bank of New York; TBA mechanics and liquidity.
- [Agency Mortgage-Backed Securities Operations](https://www.newyorkfed.org/markets/desk-operations/ambs) — Federal Reserve Bank of New York; agency MBS operations, dollar rolls, coupon swaps.
- [Dodd-Frank Act Rulemaking: Asset-Backed Securities](https://www.sec.gov/spotlight/dodd-frank/assetbackedsecurities.shtml) — U.S. Securities and Exchange Commission; ABS and RMBS securitization, tranching, disclosure.
