# Float Income

> Float Income separates the right and obligation to administer a loan from ownership of its principal cash flow

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:msr-economics:float-income` |
| Family | Mortgage Servicing Rights & Economics |
| Domain | Economics |
| Era | Agentic Age |
| Kind | metric-or-force |
| Archetype | The Scale |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Float Income is a metric or force in the Mortgage Servicing Rights & Economics family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Float Income separates the right and obligation to administer a loan from ownership of its principal cash flow.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Float Income separates the right and obligation to administer a loan from ownership of its principal cash flow
- **Gift:** Clarity about float income makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When float income is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when float income is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where float income appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Float Income reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Float Income changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Float Income changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Float Income can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Scale enters the reading through Float Income. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Float Income measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 3.

## Relationships

- **Table Funding transfers into Float Income.** Table Funding transfers into Float Income through a change in rights, information, cash flow, priority, timing, or physical use.
- **Delinquency Cost conflicts with Float Income.** Delinquency Cost conflicts with Float Income through a change in rights, information, cash flow, priority, timing, or physical use.
- **Float Income is evidenced by Compensatory Fee.** Float Income is evidenced by Compensatory Fee through a change in rights, information, cash flow, priority, timing, or physical use.
- **Float Income is governed by Internal Rate of Return.** Float Income is governed by Internal Rate of Return through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Float Income through the lineage of Mortgage Servicing Rights & Economics: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Float Income: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Servicing Guide](https://singlefamily.fanniemae.com/servicing) — Fannie Mae; servicing, delinquency, loss mitigation, investor reporting.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
- [About Fannie Mae & Freddie Mac](https://www.fhfa.gov/about/fannie-mae-freddie-mac) — Federal Housing Finance Agency; GSE liquidity, stability, affordability, MBS.
