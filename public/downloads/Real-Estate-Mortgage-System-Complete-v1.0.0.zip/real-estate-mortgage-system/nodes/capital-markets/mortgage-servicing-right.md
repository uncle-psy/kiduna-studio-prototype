# Mortgage Servicing Right

> Mortgage Servicing Right separates the right and obligation to administer a loan from ownership of its principal cash flow

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:msr-economics:mortgage-servicing-right` |
| Family | Mortgage Servicing Rights & Economics |
| Domain | Economics |
| Era | Agentic Age |
| Kind | financial-instrument |
| Archetype | The Bridge |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

The contractual right and obligation to service mortgage loans in exchange for servicing compensation and ancillary economics.

## What it actually does

Separates loan administration from credit ownership and makes the timing of borrower payments, prepayments, advances, and defaults an asset.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Mortgage Servicing Right separates the right and obligation to administer a loan from ownership of its principal cash flow
- **Gift:** Clarity about mortgage servicing right makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When mortgage servicing right is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when mortgage servicing right is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where mortgage servicing right appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Mortgage Servicing Right reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Mortgage Servicing Right changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Mortgage Servicing Right changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Mortgage Servicing Right can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Bridge enters the reading through Mortgage Servicing Right. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Mortgage Servicing Right, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 1.

## Relationships

- **Whole-Loan Sale is administered through Mortgage Servicing Right.** Whole-Loan Sale is administered through Mortgage Servicing Right through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mortgage Servicing Right depends on Servicing Strip.** Mortgage Servicing Right depends on Servicing Strip through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mortgage Servicing Right depends on Net Operating Income.** Mortgage Servicing Right depends on Net Operating Income through a change in rights, information, cash flow, priority, timing, or physical use.
- **Mortgage Servicing Right separates administration from Mortgage.** Mortgage Servicing Right separates administration from Mortgage through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Mortgage Servicing Right through the lineage of Mortgage Servicing Rights & Economics: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Mortgage Servicing Right: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Servicing Guide](https://singlefamily.fanniemae.com/servicing) — Fannie Mae; servicing, delinquency, loss mitigation, investor reporting.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
- [About Fannie Mae & Freddie Mac](https://www.fhfa.gov/about/fannie-mae-freddie-mac) — Federal Housing Finance Agency; GSE liquidity, stability, affordability, MBS.
