# Private Equity Real Estate

> Private Equity Real Estate organizes who contributes capital, who controls it, and who receives return

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:investment-capital:private-equity-real-estate` |
| Family | Investment & Capital |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | financial-instrument |
| Archetype | The Reservoir |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Private Equity Real Estate is a financial instrument in the Investment & Capital family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Private Equity Real Estate organizes who contributes capital, who controls it, and who receives return.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Private Equity Real Estate organizes who contributes capital, who controls it, and who receives return
- **Gift:** Clarity about private equity real estate makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When private equity real estate is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when private equity real estate is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where private equity real estate appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Private Equity Real Estate reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Private Equity Real Estate changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Private Equity Real Estate changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Private Equity Real Estate can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Reservoir enters the reading through Private Equity Real Estate. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Private Equity Real Estate, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 4.

## Relationships

- **Tax Sale externalizes to Private Equity Real Estate.** Tax Sale externalizes to Private Equity Real Estate through a change in rights, information, cash flow, priority, timing, or physical use.
- **Real Estate Investment Trust constrains Private Equity Real Estate.** Real Estate Investment Trust constrains Private Equity Real Estate through a change in rights, information, cash flow, priority, timing, or physical use.
- **Private Equity Real Estate enables Real Estate Fund.** Private Equity Real Estate enables Real Estate Fund through a change in rights, information, cash flow, priority, timing, or physical use.
- **Private Equity Real Estate amplifies Lender.** Private Equity Real Estate amplifies Lender through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Private Equity Real Estate through the lineage of Investment & Capital: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Private Equity Real Estate: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, financial risk. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Dodd-Frank Act Rulemaking: Asset-Backed Securities](https://www.sec.gov/spotlight/dodd-frank/assetbackedsecurities.shtml) — U.S. Securities and Exchange Commission; ABS and RMBS securitization, tranching, disclosure.
- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
