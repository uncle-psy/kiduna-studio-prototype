# Compensatory Fee

> Compensatory Fee separates the right and obligation to administer a loan from ownership of its principal cash flow

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:msr-economics:compensatory-fee` |
| Family | Mortgage Servicing Rights & Economics |
| Domain | Economics |
| Era | Agentic Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Compensatory Fee is a concept in the Mortgage Servicing Rights & Economics family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Compensatory Fee separates the right and obligation to administer a loan from ownership of its principal cash flow.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Compensatory Fee separates the right and obligation to administer a loan from ownership of its principal cash flow
- **Gift:** Clarity about compensatory fee makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When compensatory fee is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when compensatory fee is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where compensatory fee appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Compensatory Fee reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Compensatory Fee changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Compensatory Fee changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Compensatory Fee can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Compensatory Fee. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Compensatory Fee becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 4.

## Relationships

- **Gestation Repo amplifies Compensatory Fee.** Gestation Repo amplifies Compensatory Fee through a change in rights, information, cash flow, priority, timing, or physical use.
- **Float Income is evidenced by Compensatory Fee.** Float Income is evidenced by Compensatory Fee through a change in rights, information, cash flow, priority, timing, or physical use.
- **Compensatory Fee is administered through Servicing Release Premium.** Compensatory Fee is administered through Servicing Release Premium through a change in rights, information, cash flow, priority, timing, or physical use.
- **Compensatory Fee conflicts with Equity Multiple.** Compensatory Fee conflicts with Equity Multiple through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Compensatory Fee through the lineage of Mortgage Servicing Rights & Economics: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Compensatory Fee: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Fannie Mae Servicing Guide](https://singlefamily.fanniemae.com/servicing) — Fannie Mae; servicing, delinquency, loss mitigation, investor reporting.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
- [About Fannie Mae & Freddie Mac](https://www.fhfa.gov/about/fannie-mae-freddie-mac) — Federal Housing Finance Agency; GSE liquidity, stability, affordability, MBS.
