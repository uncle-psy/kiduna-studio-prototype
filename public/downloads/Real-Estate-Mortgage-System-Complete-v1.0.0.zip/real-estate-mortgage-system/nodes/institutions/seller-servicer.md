# Seller-Servicer

> Seller-Servicer recycles lender capital and standardizes loans for investors beyond the local transaction

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:secondary-market:seller-servicer` |
| Family | Secondary Mortgage Market |
| Domain | Economics |
| Era | Agentic Age |
| Kind | actor-or-institution |
| Archetype | The Intermediary |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Seller-Servicer is a actor or institution in the Secondary Mortgage Market family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Seller-Servicer recycles lender capital and standardizes loans for investors beyond the local transaction.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** counterparties, clients, members, regulators, investors
- **Incentives:** compensation, completion, risk control, reputation, authority
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Seller-Servicer recycles lender capital and standardizes loans for investors beyond the local transaction
- **Gift:** Clarity about seller-servicer makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When seller-servicer is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when seller-servicer is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where seller-servicer appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Seller-Servicer reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Seller-Servicer changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Seller-Servicer changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Seller-Servicer can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Intermediary enters the reading through Seller-Servicer. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What does Seller-Servicer know, want, control, and carry if the transaction fails?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a playable role with asymmetric information, incentives, authority, and accountability. Initiative 1.

## Relationships

- **Nonjudicial Foreclosure externalizes to Seller-Servicer.** Nonjudicial Foreclosure externalizes to Seller-Servicer through a change in rights, information, cash flow, priority, timing, or physical use.
- **Aggregator externalizes to Seller-Servicer.** Aggregator externalizes to Seller-Servicer through a change in rights, information, cash flow, priority, timing, or physical use.
- **Seller-Servicer amplifies Subordination.** Seller-Servicer amplifies Subordination through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Local Knowledge versus Algorithm
- Liquidity versus Rootedness

## Historical lineage and regulatory context

Read Seller-Servicer through the lineage of Secondary Mortgage Market: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Seller-Servicer: a central instrument surrounded by flows of information, authority, capital, and accountability; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [About Fannie Mae & Freddie Mac](https://www.fhfa.gov/about/fannie-mae-freddie-mac) — Federal Housing Finance Agency; GSE liquidity, stability, affordability, MBS.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
