# Federal Housing Finance Agency

> Federal Housing Finance Agency recycles lender capital and standardizes loans for investors beyond the local transaction

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:secondary-market:federal-housing-finance-agency` |
| Family | Secondary Mortgage Market |
| Domain | Economics |
| Era | Agentic Age |
| Kind | financial-instrument |
| Archetype | The Claim |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Federal Housing Finance Agency is a financial instrument in the Secondary Mortgage Market family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Federal Housing Finance Agency recycles lender capital and standardizes loans for investors beyond the local transaction.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Federal Housing Finance Agency recycles lender capital and standardizes loans for investors beyond the local transaction
- **Gift:** Clarity about federal housing finance agency makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When federal housing finance agency is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when federal housing finance agency is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where federal housing finance agency appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Federal Housing Finance Agency reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Federal Housing Finance Agency changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Federal Housing Finance Agency changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Federal Housing Finance Agency can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Claim enters the reading through Federal Housing Finance Agency. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Federal Housing Finance Agency, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 4.

## Relationships

- **Partial Claim documents Federal Housing Finance Agency.** Partial Claim documents Federal Housing Finance Agency through a change in rights, information, cash flow, priority, timing, or physical use.
- **USDA Rural Development enables Federal Housing Finance Agency.** USDA Rural Development enables Federal Housing Finance Agency through a change in rights, information, cash flow, priority, timing, or physical use.
- **Federal Housing Finance Agency prices Loan Sale.** Federal Housing Finance Agency prices Loan Sale through a change in rights, information, cash flow, priority, timing, or physical use.
- **Federal Housing Finance Agency transfers into Trust.** Federal Housing Finance Agency transfers into Trust through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Local Knowledge versus Algorithm
- Liquidity versus Rootedness

## Historical lineage and regulatory context

Read Federal Housing Finance Agency through the lineage of Secondary Mortgage Market: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Federal Housing Finance Agency: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [About Fannie Mae & Freddie Mac](https://www.fhfa.gov/about/fannie-mae-freddie-mac) — Federal Housing Finance Agency; GSE liquidity, stability, affordability, MBS.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Freddie Mac Single-Family Seller/Servicer Guide](https://guide.freddiemac.com/) — Freddie Mac; loan eligibility, Loan Product Advisor, servicing.
- [Ginnie Mae MBS Guide](https://www.ginniemae.gov/issuers/program_guidelines/Pages/mbs_guide.aspx) — Ginnie Mae; pooling, issuance, custody, servicing, investor reporting.
