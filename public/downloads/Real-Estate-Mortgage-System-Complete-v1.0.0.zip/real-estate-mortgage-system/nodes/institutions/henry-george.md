# Henry George

> Henry George locates enduring theories of property, housing, planning, and community in human argument

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:people-ideas:henry-george` |
| Family | People & Ideas |
| Domain | Culture |
| Era | Institutional Age → Agentic Age |
| Kind | person |
| Archetype | The Builder |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Henry George is a person in the People & Ideas family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Henry George locates enduring theories of property, housing, planning, and community in human argument.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Henry George locates enduring theories of property, housing, planning, and community in human argument
- **Gift:** Clarity about henry george makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When henry george is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when henry george is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where henry george appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Henry George reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Henry George changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Henry George changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Henry George can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Builder enters the reading through Henry George. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Henry George becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **Neighborhood conflicts with Henry George.** Neighborhood conflicts with Henry George through a change in rights, information, cash flow, priority, timing, or physical use.
- **Henry George is evidenced by Jane Jacobs.** Henry George is evidenced by Jane Jacobs through a change in rights, information, cash flow, priority, timing, or physical use.
- **Henry George is evidenced by Housing Cycle.** Henry George is evidenced by Housing Cycle through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Henry George through the lineage of People & Ideas: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Henry George: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, real individuals, historical context. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [The Financial Crisis Inquiry Report](https://www.govinfo.gov/features/financial-crisis-inquiry-report) — Financial Crisis Inquiry Commission / U.S. Government Publishing Office; causes and mechanisms of the 2007–2009 financial crisis.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
