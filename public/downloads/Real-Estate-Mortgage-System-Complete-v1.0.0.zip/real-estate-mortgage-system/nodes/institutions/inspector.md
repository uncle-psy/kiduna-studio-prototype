# Inspector

> Inspector makes the division of labor, authority, information, and incentive visible

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:roles-institutions:inspector` |
| Family | Roles & Institutions |
| Domain | Culture |
| Era | Institutional Age → Agentic Age |
| Kind | actor-or-institution |
| Archetype | The Custodian |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Inspector is a actor or institution in the Roles & Institutions family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Inspector makes the division of labor, authority, information, and incentive visible.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** counterparties, clients, members, regulators, investors
- **Incentives:** compensation, completion, risk control, reputation, authority
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Inspector makes the division of labor, authority, information, and incentive visible
- **Gift:** Clarity about inspector makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When inspector is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when inspector is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where inspector appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Inspector reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Inspector changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Inspector changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Inspector can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Custodian enters the reading through Inspector. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What does Inspector know, want, control, and carry if the transaction fails?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a playable role with asymmetric information, incentives, authority, and accountability. Initiative 3.

## Relationships

- **Pension Capital transfers into Inspector.** Pension Capital transfers into Inspector through a change in rights, information, cash flow, priority, timing, or physical use.
- **Appraiser conflicts with Inspector.** Appraiser conflicts with Inspector through a change in rights, information, cash flow, priority, timing, or physical use.
- **Inspector is evidenced by Surveyor.** Inspector is evidenced by Surveyor through a change in rights, information, cash flow, priority, timing, or physical use.
- **Inspector is governed by Digital Twin.** Inspector is governed by Digital Twin through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Inspector through the lineage of Roles & Institutions: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Inspector: a central instrument surrounded by flows of information, authority, capital, and accountability; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
