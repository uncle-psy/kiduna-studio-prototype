# Real Estate Agent

> Real Estate Agent makes the division of labor, authority, information, and incentive visible

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:roles-institutions:real-estate-agent` |
| Family | Roles & Institutions |
| Domain | Culture |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Real Estate Agent is a concept in the Roles & Institutions family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Real Estate Agent makes the division of labor, authority, information, and incentive visible.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Real Estate Agent makes the division of labor, authority, information, and incentive visible
- **Gift:** Clarity about real estate agent makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When real estate agent is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when real estate agent is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where real estate agent appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Real Estate Agent reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Real Estate Agent changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Real Estate Agent changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Real Estate Agent can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Real Estate Agent. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Real Estate Agent becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 3.

## Relationships

- **General Partner transfers into Real Estate Agent.** General Partner transfers into Real Estate Agent through a change in rights, information, cash flow, priority, timing, or physical use.
- **Developer transfers into Real Estate Agent.** Developer transfers into Real Estate Agent through a change in rights, information, cash flow, priority, timing, or physical use.
- **Real Estate Agent is governed by Broker.** Real Estate Agent is governed by Broker through a change in rights, information, cash flow, priority, timing, or physical use.
- **Real Estate Agent is governed by MERS eRegistry.** Real Estate Agent is governed by MERS eRegistry through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Real Estate Agent through the lineage of Roles & Institutions: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Real Estate Agent: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
