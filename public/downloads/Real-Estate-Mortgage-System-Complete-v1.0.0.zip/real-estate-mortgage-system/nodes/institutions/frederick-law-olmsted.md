# Frederick Law Olmsted

> Frederick Law Olmsted locates enduring theories of property, housing, planning, and community in human argument

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:people-ideas:frederick-law-olmsted` |
| Family | People & Ideas |
| Domain | Culture |
| Era | Institutional Age → Agentic Age |
| Kind | person |
| Archetype | The Cartographer |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Frederick Law Olmsted is a person in the People & Ideas family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Frederick Law Olmsted locates enduring theories of property, housing, planning, and community in human argument.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Frederick Law Olmsted locates enduring theories of property, housing, planning, and community in human argument
- **Gift:** Clarity about frederick law olmsted makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When frederick law olmsted is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when frederick law olmsted is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where frederick law olmsted appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Frederick Law Olmsted reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Frederick Law Olmsted changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Frederick Law Olmsted changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Frederick Law Olmsted can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Cartographer enters the reading through Frederick Law Olmsted. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Frederick Law Olmsted becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 3.

## Relationships

- **Cul-de-Sac prices Frederick Law Olmsted.** Cul-de-Sac prices Frederick Law Olmsted through a change in rights, information, cash flow, priority, timing, or physical use.
- **Ebenezer Howard prices Frederick Law Olmsted.** Ebenezer Howard prices Frederick Law Olmsted through a change in rights, information, cash flow, priority, timing, or physical use.
- **Frederick Law Olmsted documents Frank Lloyd Wright.** Frederick Law Olmsted documents Frank Lloyd Wright through a change in rights, information, cash flow, priority, timing, or physical use.
- **Frederick Law Olmsted documents Yield Curve.** Frederick Law Olmsted documents Yield Curve through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Frederick Law Olmsted through the lineage of People & Ideas: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Frederick Law Olmsted: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty, real individuals, historical context. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [The Financial Crisis Inquiry Report](https://www.govinfo.gov/features/financial-crisis-inquiry-report) — Financial Crisis Inquiry Commission / U.S. Government Publishing Office; causes and mechanisms of the 2007–2009 financial crisis.
- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
