# Floor Area Ratio

> Floor Area Ratio programs which spatial uses may occur, where, and at what intensity

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:zoning-urbanism:floor-area-ratio` |
| Family | Zoning, Planning & Urbanism |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | metric-or-force |
| Archetype | The Gauge |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Floor Area Ratio is a metric or force in the Zoning, Planning & Urbanism family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Floor Area Ratio programs which spatial uses may occur, where, and at what intensity.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Floor Area Ratio programs which spatial uses may occur, where, and at what intensity
- **Gift:** Clarity about floor area ratio makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When floor area ratio is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when floor area ratio is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where floor area ratio appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Floor Area Ratio reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Floor Area Ratio changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Floor Area Ratio changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Floor Area Ratio can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Gauge enters the reading through Floor Area Ratio. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Floor Area Ratio measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 4.

## Relationships

- **Site Plan Approval depends on Floor Area Ratio.** Site Plan Approval depends on Floor Area Ratio through a change in rights, information, cash flow, priority, timing, or physical use.
- **Downzoning is evidenced by Floor Area Ratio.** Downzoning is evidenced by Floor Area Ratio through a change in rights, information, cash flow, priority, timing, or physical use.
- **Floor Area Ratio is administered through Density.** Floor Area Ratio is administered through Density through a change in rights, information, cash flow, priority, timing, or physical use.
- **Floor Area Ratio constrains Change Order.** Floor Area Ratio constrains Change Order through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Preservation versus Growth
- Market versus Planning

## Historical lineage and regulatory context

Read Floor Area Ratio through the lineage of Zoning, Planning & Urbanism: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Floor Area Ratio: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Housing Discrimination Under the Fair Housing Act](https://www.hud.gov/helping-americans/fair-housing-act-overview) — U.S. Department of Housing and Urban Development; housing discrimination and protected classes.
