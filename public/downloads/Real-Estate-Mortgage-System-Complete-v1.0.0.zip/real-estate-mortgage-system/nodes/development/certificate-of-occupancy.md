# Certificate of Occupancy

> Certificate of Occupancy turns plans, labor, materials, and capital into built form

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:construction:certificate-of-occupancy` |
| Family | Construction |
| Domain | Technology |
| Era | Kinship Age → Collective Age |
| Kind | metric-or-force |
| Archetype | The Scale |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Certificate of Occupancy is a metric or force in the Construction family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Certificate of Occupancy turns plans, labor, materials, and capital into built form.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Certificate of Occupancy turns plans, labor, materials, and capital into built form
- **Gift:** Clarity about certificate of occupancy makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When certificate of occupancy is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when certificate of occupancy is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where certificate of occupancy appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Certificate of Occupancy reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Certificate of Occupancy changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Certificate of Occupancy changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Certificate of Occupancy can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Scale enters the reading through Certificate of Occupancy. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Certificate of Occupancy measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 3.

## Relationships

- **Downzoning is evidenced by Certificate of Occupancy.** Downzoning is evidenced by Certificate of Occupancy through a change in rights, information, cash flow, priority, timing, or physical use.
- **Topping Out is evidenced by Certificate of Occupancy.** Topping Out is evidenced by Certificate of Occupancy through a change in rights, information, cash flow, priority, timing, or physical use.
- **Certificate of Occupancy is administered through Change Order.** Certificate of Occupancy is administered through Change Order through a change in rights, information, cash flow, priority, timing, or physical use.
- **Certificate of Occupancy is administered through Fire Protection.** Certificate of Occupancy is administered through Fire Protection through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Certificate of Occupancy through the lineage of Construction: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Certificate of Occupancy: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
