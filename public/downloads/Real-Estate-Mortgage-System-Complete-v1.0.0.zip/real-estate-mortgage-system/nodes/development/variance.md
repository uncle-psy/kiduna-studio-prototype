# Variance

> Variance converts land's present condition into a permitted future use

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:development-entitlement:variance` |
| Family | Development & Entitlement |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Variance is a concept in the Development & Entitlement family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Variance converts land's present condition into a permitted future use.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Site Control, Zoning, Capital, Construction

## Archetypal reading

- **Essence:** Variance converts land's present condition into a permitted future use
- **Gift:** Clarity about variance makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When variance is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when variance is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where variance appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Variance reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Variance changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Variance changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Variance can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Variance. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Variance becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 2.

## Relationships

- **Bridge Loan — CRE transfers into Variance.** Bridge Loan — CRE transfers into Variance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Rezoning externalizes to Variance.** Rezoning externalizes to Variance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Variance amplifies Conditional Use Permit.** Variance amplifies Conditional Use Permit through a change in rights, information, cash flow, priority, timing, or physical use.
- **Variance is governed by Upzoning.** Variance is governed by Upzoning through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Variance through the lineage of Development & Entitlement: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Variance: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Risk-Based Brownfields Cleanups](https://www.epa.gov/brownfields/risk-based-brownfields-cleanups) — U.S. Environmental Protection Agency; contamination, remediation, reuse, institutional controls.
