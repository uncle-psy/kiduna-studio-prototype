# Rezoning

> Rezoning converts land's present condition into a permitted future use

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:development-entitlement:rezoning` |
| Family | Development & Entitlement |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | governance-mechanism |
| Archetype | The Gatekeeper |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Rezoning is a governance mechanism in the Development & Entitlement family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Rezoning converts land's present condition into a permitted future use.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** legitimacy, clarity, enforceability, administrative efficiency
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Site Control, Zoning, Capital, Construction

## Archetypal reading

- **Essence:** Rezoning converts land's present condition into a permitted future use
- **Gift:** Clarity about rezoning makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When rezoning is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when rezoning is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where rezoning appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Rezoning reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Rezoning changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Rezoning changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Rezoning can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Gatekeeper enters the reading through Rezoning. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** Who has legitimate authority under Rezoning, and where does that authority stop?

**Guidance:** Name the source, scope, duration, appeal path, and release of authority.

## Game function

Changes what actions are permitted and who may authorize them. Initiative 1.

## Relationships

- **Mini-Perm Loan enables Rezoning.** Mini-Perm Loan enables Rezoning through a change in rights, information, cash flow, priority, timing, or physical use.
- **Entitlement is governed by Rezoning.** Entitlement is governed by Rezoning through a change in rights, information, cash flow, priority, timing, or physical use.
- **Rezoning externalizes to Variance.** Rezoning externalizes to Variance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Rezoning prices Single-Family Zoning.** Rezoning prices Single-Family Zoning through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Rezoning through the lineage of Development & Entitlement: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Rezoning: a cadastral grid overlaid with colored permissions, gates, and invisible boundaries made visible; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Risk-Based Brownfields Cleanups](https://www.epa.gov/brownfields/risk-based-brownfields-cleanups) — U.S. Environmental Protection Agency; contamination, remediation, reuse, institutional controls.
