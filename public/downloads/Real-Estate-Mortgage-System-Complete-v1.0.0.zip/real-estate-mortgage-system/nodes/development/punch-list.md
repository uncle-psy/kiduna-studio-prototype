# Punch List

> Punch List turns plans, labor, materials, and capital into built form

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:construction:punch-list` |
| Family | Construction |
| Domain | Technology |
| Era | Kinship Age → Collective Age |
| Kind | concept |
| Archetype | The Pattern |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Punch List is a concept in the Construction family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Punch List turns plans, labor, materials, and capital into built form.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, developer, architect, engineer, contractor, inspector
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Punch List turns plans, labor, materials, and capital into built form
- **Gift:** Clarity about punch list makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When punch list is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when punch list is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where punch list appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Punch List reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Punch List changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Punch List changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Punch List can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Pattern enters the reading through Punch List. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Punch List becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 3.

## Relationships

- **Urban Growth Boundary is evidenced by Punch List.** Urban Growth Boundary is evidenced by Punch List through a change in rights, information, cash flow, priority, timing, or physical use.
- **Retainage enables Punch List.** Retainage enables Punch List through a change in rights, information, cash flow, priority, timing, or physical use.
- **Punch List prices Substantial Completion.** Punch List prices Substantial Completion through a change in rights, information, cash flow, priority, timing, or physical use.
- **Punch List is administered through Deferred Maintenance.** Punch List is administered through Deferred Maintenance through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Punch List through the lineage of Construction: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Punch List: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Comptroller's Handbook — Commercial Real Estate Lending](https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/files/commercial-real-estate-lending/pub-ch-commercial-real-estate.pdf) — Office of the Comptroller of the Currency; CRE lending, DSCR, debt yield, cap rate, valuation, risk.
