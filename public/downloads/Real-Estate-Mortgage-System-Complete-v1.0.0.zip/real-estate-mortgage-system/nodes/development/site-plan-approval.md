# Site Plan Approval

> Site Plan Approval converts land's present condition into a permitted future use

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:development-entitlement:site-plan-approval` |
| Family | Development & Entitlement |
| Domain | Governance |
| Era | Institutional Age → Agentic Age |
| Kind | process |
| Archetype | The Translation |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Site Plan Approval is a process in the Development & Entitlement family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Site Plan Approval converts land's present condition into a permitted future use.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** certainty, speed, compliance, completion, error reduction
- **Inputs:** participants, documents, conditions, authority, time
- **Outputs:** decision, changed state, record, new obligations
- **Dependencies:** Land, Site Control, Zoning, Capital, Construction

## Archetypal reading

- **Essence:** Site Plan Approval converts land's present condition into a permitted future use
- **Gift:** Clarity about site plan approval makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When site plan approval is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when site plan approval is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where site plan approval appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Site Plan Approval reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Site Plan Approval changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Site Plan Approval changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Site Plan Approval can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Translation enters the reading through Site Plan Approval. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What information or condition must Site Plan Approval translate before the next commitment becomes safe?

**Guidance:** Make conditions, exceptions, handoffs, and completion criteria explicit.

## Game function

Creates a gated action requiring inputs, a decision, and a resulting Record. Initiative 4.

## Relationships

- **Preferred Equity is administered through Site Plan Approval.** Preferred Equity is administered through Site Plan Approval through a change in rights, information, cash flow, priority, timing, or physical use.
- **Conditional Use Permit conflicts with Site Plan Approval.** Conditional Use Permit conflicts with Site Plan Approval through a change in rights, information, cash flow, priority, timing, or physical use.
- **Site Plan Approval is evidenced by Subdivision Approval.** Site Plan Approval is evidenced by Subdivision Approval through a change in rights, information, cash flow, priority, timing, or physical use.
- **Site Plan Approval depends on Floor Area Ratio.** Site Plan Approval depends on Floor Area Ratio through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Site Plan Approval through the lineage of Development & Entitlement: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Site Plan Approval: a sequence of thresholds connected by a single bright path, with conditions represented as gates; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Risk-Based Brownfields Cleanups](https://www.epa.gov/brownfields/risk-based-brownfields-cleanups) — U.S. Environmental Protection Agency; contamination, remediation, reuse, institutional controls.
