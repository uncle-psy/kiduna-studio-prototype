# Transit-Oriented Development

> Transit-Oriented Development programs which spatial uses may occur, where, and at what intensity

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:zoning-urbanism:transit-oriented-development` |
| Family | Zoning, Planning & Urbanism |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | process |
| Archetype | The Settlement |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Transit-Oriented Development is a process in the Zoning, Planning & Urbanism family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Transit-Oriented Development programs which spatial uses may occur, where, and at what intensity.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** certainty, speed, compliance, completion, error reduction
- **Inputs:** participants, documents, conditions, authority, time
- **Outputs:** decision, changed state, record, new obligations
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Transit-Oriented Development programs which spatial uses may occur, where, and at what intensity
- **Gift:** Clarity about transit-oriented development makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When transit-oriented development is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when transit-oriented development is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where transit-oriented development appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Transit-Oriented Development reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Transit-Oriented Development changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Transit-Oriented Development changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Transit-Oriented Development can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Settlement enters the reading through Transit-Oriented Development. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What information or condition must Transit-Oriented Development translate before the next commitment becomes safe?

**Guidance:** Make conditions, exceptions, handoffs, and completion criteria explicit.

## Game function

Creates a gated action requiring inputs, a decision, and a resulting Record. Initiative 1.

## Relationships

- **Density Bonus prices Transit-Oriented Development.** Density Bonus prices Transit-Oriented Development through a change in rights, information, cash flow, priority, timing, or physical use.
- **Comprehensive Plan prices Transit-Oriented Development.** Comprehensive Plan prices Transit-Oriented Development through a change in rights, information, cash flow, priority, timing, or physical use.
- **Transit-Oriented Development documents Mechanic's Lien.** Transit-Oriented Development documents Mechanic's Lien through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Preservation versus Growth
- Market versus Planning

## Historical lineage and regulatory context

Read Transit-Oriented Development through the lineage of Zoning, Planning & Urbanism: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Transit-Oriented Development: a sequence of thresholds connected by a single bright path, with conditions represented as gates; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Housing Discrimination Under the Fair Housing Act](https://www.hud.gov/helping-americans/fair-housing-act-overview) — U.S. Department of Housing and Urban Development; housing discrimination and protected classes.
