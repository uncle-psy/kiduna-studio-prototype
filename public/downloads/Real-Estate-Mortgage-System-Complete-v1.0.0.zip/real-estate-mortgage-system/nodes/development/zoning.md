# Zoning

> Zoning programs which spatial uses may occur, where, and at what intensity

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:zoning-urbanism:zoning` |
| Family | Zoning, Planning & Urbanism |
| Domain | Governance |
| Era | Institutional Age → Collective Age |
| Kind | governance-mechanism |
| Archetype | The Charter |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Local regulation dividing land into districts and governing uses, dimensions, density, form, and development conditions.

## What it actually does

Converts public planning and political choices into parcel-level permissions, constraints, scarcity, and bargaining power.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** legitimacy, clarity, enforceability, administrative efficiency
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Zoning programs which spatial uses may occur, where, and at what intensity
- **Gift:** Clarity about zoning makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When zoning is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when zoning is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where zoning appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Zoning reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Zoning changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Zoning changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Zoning can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Charter enters the reading through Zoning. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** Who has legitimate authority under Zoning, and where does that authority stop?

**Guidance:** Name the source, scope, duration, appeal path, and release of authority.

## Game function

Changes what actions are permitted and who may authorize them. Initiative 1.

## Relationships

- **Development prices Zoning.** Development prices Zoning through a change in rights, information, cash flow, priority, timing, or physical use.
- **Zoning documents Euclidean Zoning.** Zoning documents Euclidean Zoning through a change in rights, information, cash flow, priority, timing, or physical use.
- **Zoning documents Groundbreaking.** Zoning documents Groundbreaking through a change in rights, information, cash flow, priority, timing, or physical use.
- **Zoning constrains Development.** Zoning constrains Development through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Preservation versus Growth
- Market versus Planning

## Historical lineage and regulatory context

Read Zoning through the lineage of Zoning, Planning & Urbanism: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Zoning: a cadastral grid overlaid with colored permissions, gates, and invisible boundaries made visible; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Housing Discrimination Under the Fair Housing Act](https://www.hud.gov/helping-americans/fair-housing-act-overview) — U.S. Department of Housing and Urban Development; housing discrimination and protected classes.
