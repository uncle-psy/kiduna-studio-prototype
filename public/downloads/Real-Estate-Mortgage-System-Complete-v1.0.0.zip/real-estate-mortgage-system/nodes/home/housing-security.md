# Housing Security

> Housing Security connects occupancy to safety, identity, memory, and belonging

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:home-shelter:housing-security` |
| Family | Home & Shelter |
| Domain | Culture |
| Era | Kinship Age → Collective Age |
| Kind | financial-instrument |
| Archetype | The Claim |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Housing Security is a financial instrument in the Home & Shelter family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Housing Security connects occupancy to safety, identity, memory, and belonging.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Housing Security connects occupancy to safety, identity, memory, and belonging
- **Gift:** Clarity about housing security makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When housing security is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when housing security is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where housing security appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Housing Security reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Housing Security changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Housing Security changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Housing Security can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Claim enters the reading through Housing Security. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Housing Security, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 1.

## Relationships

- **Subsurface depends on Housing Security.** Subsurface depends on Housing Security through a change in rights, information, cash flow, priority, timing, or physical use.
- **Inheritance depends on Housing Security.** Inheritance depends on Housing Security through a change in rights, information, cash flow, priority, timing, or physical use.
- **Housing Security constrains Investment Property.** Housing Security constrains Investment Property through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Home versus Collateral
- Shelter versus Investment

## Historical lineage and regulatory context

Read Housing Security through the lineage of Home & Shelter: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Housing Security: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Housing Discrimination Under the Fair Housing Act](https://www.hud.gov/helping-americans/fair-housing-act-overview) — U.S. Department of Housing and Urban Development; housing discrimination and protected classes.
- [Housing Data](https://www.census.gov/topics/housing.html) — U.S. Census Bureau; housing stock, tenure, construction, vacancies.
