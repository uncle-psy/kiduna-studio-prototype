# Triplex

> Triplex packages domestic space into a legally and financially recognizable asset

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:residential-property:triplex` |
| Family | Residential Property |
| Domain | Economics |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Relation |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Triplex is a concept in the Residential Property family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Triplex packages domestic space into a legally and financially recognizable asset.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Triplex packages domestic space into a legally and financially recognizable asset
- **Gift:** Clarity about triplex makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When triplex is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when triplex is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where triplex appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Triplex reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Triplex changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Triplex changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Triplex can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Relation enters the reading through Triplex. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Triplex becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 2.

## Relationships

- **Homestead documents Triplex.** Homestead documents Triplex through a change in rights, information, cash flow, priority, timing, or physical use.
- **Duplex is governed by Triplex.** Duplex is governed by Triplex through a change in rights, information, cash flow, priority, timing, or physical use.
- **Triplex externalizes to Fourplex.** Triplex externalizes to Fourplex through a change in rights, information, cash flow, priority, timing, or physical use.
- **Triplex transfers into Logistics Facility.** Triplex transfers into Logistics Facility through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Triplex through the lineage of Residential Property: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Triplex: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [FHA Single Family Housing Policy Handbook 4000.1](https://www.hud.gov/hud-partners/single-family-handbook-4000-1) — U.S. Department of Housing and Urban Development; FHA approval, origination, underwriting, appraisal, servicing, quality control.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
