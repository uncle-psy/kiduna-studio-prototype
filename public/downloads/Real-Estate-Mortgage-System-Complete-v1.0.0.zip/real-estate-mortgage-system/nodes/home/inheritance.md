# Inheritance

> Inheritance connects occupancy to safety, identity, memory, and belonging

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:home-shelter:inheritance` |
| Family | Home & Shelter |
| Domain | Culture |
| Era | Kinship Age → Collective Age |
| Kind | concept |
| Archetype | The Relation |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Inheritance is a concept in the Home & Shelter family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Inheritance connects occupancy to safety, identity, memory, and belonging.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Inheritance connects occupancy to safety, identity, memory, and belonging
- **Gift:** Clarity about inheritance makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When inheritance is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when inheritance is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where inheritance appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Inheritance reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Inheritance changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Inheritance changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Inheritance can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Relation enters the reading through Inheritance. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Inheritance becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 4.

## Relationships

- **Airspace conflicts with Inheritance.** Airspace conflicts with Inheritance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Domesticity is administered through Inheritance.** Domesticity is administered through Inheritance through a change in rights, information, cash flow, priority, timing, or physical use.
- **Inheritance depends on Housing Security.** Inheritance depends on Housing Security through a change in rights, information, cash flow, priority, timing, or physical use.
- **Inheritance is evidenced by Vacation Home.** Inheritance is evidenced by Vacation Home through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Home versus Collateral
- Shelter versus Investment

## Historical lineage and regulatory context

Read Inheritance through the lineage of Home & Shelter: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Inheritance: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Housing Discrimination Under the Fair Housing Act](https://www.hud.gov/helping-americans/fair-housing-act-overview) — U.S. Department of Housing and Urban Development; housing discrimination and protected classes.
- [Housing Data](https://www.census.gov/topics/housing.html) — U.S. Census Bureau; housing stock, tenure, construction, vacancies.
