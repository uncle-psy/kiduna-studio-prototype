# Townhouse

> Townhouse packages domestic space into a legally and financially recognizable asset

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:residential-property:townhouse` |
| Family | Residential Property |
| Domain | Economics |
| Era | Institutional Age → Collective Age |
| Kind | place-or-property |
| Archetype | The Vessel |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Townhouse is a place or property in the Residential Property family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Townhouse packages domestic space into a legally and financially recognizable asset.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Townhouse packages domestic space into a legally and financially recognizable asset
- **Gift:** Clarity about townhouse makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When townhouse is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when townhouse is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where townhouse appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Townhouse reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Townhouse changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Townhouse changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Townhouse can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Vessel enters the reading through Townhouse. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What relationships become visible when Townhouse is treated as a place rather than only an asset?

**Guidance:** Walk the physical, legal, financial, ecological, and human maps separately before recombining them.

## Game function

Occupies spatial capacity and generates use, cost, externality, identity, or cash flow. Initiative 2.

## Relationships

- **Home documents Townhouse.** Home documents Townhouse through a change in rights, information, cash flow, priority, timing, or physical use.
- **Single-Family Detached enables Townhouse.** Single-Family Detached enables Townhouse through a change in rights, information, cash flow, priority, timing, or physical use.
- **Townhouse prices Condominium.** Townhouse prices Condominium through a change in rights, information, cash flow, priority, timing, or physical use.
- **Townhouse transfers into Office.** Townhouse transfers into Office through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Townhouse through the lineage of Residential Property: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Townhouse: a tactile architectural environment rendered in deep enamel, stone, vegetation, water, and fine metal lines; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [FHA Single Family Housing Policy Handbook 4000.1](https://www.hud.gov/hud-partners/single-family-handbook-4000-1) — U.S. Department of Housing and Urban Development; FHA approval, origination, underwriting, appraisal, servicing, quality control.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
