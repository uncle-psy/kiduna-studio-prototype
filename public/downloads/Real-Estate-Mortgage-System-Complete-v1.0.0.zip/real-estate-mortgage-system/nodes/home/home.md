# Home

> Home connects occupancy to safety, identity, memory, and belonging

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:home-shelter:home` |
| Family | Home & Shelter |
| Domain | Culture |
| Era | Kinship Age → Collective Age |
| Kind | place-or-property |
| Archetype | The Habitat |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

A place of dwelling, identity, safety, memory, and belonging; it may be owned, rented, shared, temporary, or insecure.

## What it actually does

Anchors daily life and social identity while exposing the gap between shelter's human use and property's exchange value.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Home connects occupancy to safety, identity, memory, and belonging
- **Gift:** Clarity about home makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When home is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when home is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where home appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Home reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Home changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Home changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Home can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Habitat enters the reading through Home. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What relationships become visible when Home is treated as a place rather than only an asset?

**Guidance:** Walk the physical, legal, financial, ecological, and human maps separately before recombining them.

## Game function

Occupies spatial capacity and generates use, cost, externality, identity, or cash flow. Initiative 2.

## Relationships

- **Parcel prices Home.** Parcel prices Home through a change in rights, information, cash flow, priority, timing, or physical use.
- **House constrains Home.** House constrains Home through a change in rights, information, cash flow, priority, timing, or physical use.
- **Home enables Shelter.** Home enables Shelter through a change in rights, information, cash flow, priority, timing, or physical use.
- **Home documents Townhouse.** Home documents Townhouse through a change in rights, information, cash flow, priority, timing, or physical use.
- **Home can be collateral for Mortgage.** Home can be collateral for Mortgage through a change in rights, information, cash flow, priority, timing, or physical use.
- **Home symbolically carries Belonging.** Home symbolically carries Belonging through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Home versus Collateral
- Shelter versus Investment

## Historical lineage and regulatory context

Read Home through the lineage of Home & Shelter: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Home: a tactile architectural environment rendered in deep enamel, stone, vegetation, water, and fine metal lines; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Housing Discrimination Under the Fair Housing Act](https://www.hud.gov/helping-americans/fair-housing-act-overview) — U.S. Department of Housing and Urban Development; housing discrimination and protected classes.
- [Housing Data](https://www.census.gov/topics/housing.html) — U.S. Census Bureau; housing stock, tenure, construction, vacancies.
