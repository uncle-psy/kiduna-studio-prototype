# Broadband

> Broadband connects private parcels through shared services, externalities, identity, and fate

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:neighborhood-infrastructure:broadband` |
| Family | Neighborhood & Infrastructure |
| Domain | Culture |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Tension |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Broadband is a concept in the Neighborhood & Infrastructure family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Broadband connects private parcels through shared services, externalities, identity, and fate.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Broadband connects private parcels through shared services, externalities, identity, and fate
- **Gift:** Clarity about broadband makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When broadband is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when broadband is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where broadband appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Broadband reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Broadband changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Broadband changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Broadband can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Tension enters the reading through Broadband. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Broadband becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **Preservation versus Growth amplifies Broadband.** Preservation versus Growth amplifies Broadband through a change in rights, information, cash flow, priority, timing, or physical use.
- **Private Well amplifies Broadband.** Private Well amplifies Broadband through a change in rights, information, cash flow, priority, timing, or physical use.
- **Broadband conflicts with Clarence Perry.** Broadband conflicts with Clarence Perry through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Broadband through the lineage of Neighborhood & Infrastructure: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Broadband: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Housing Discrimination Under the Fair Housing Act](https://www.hud.gov/helping-americans/fair-housing-act-overview) — U.S. Department of Housing and Urban Development; housing discrimination and protected classes.
