# Tenure

> Tenure connects occupancy to safety, identity, memory, and belonging

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:home-shelter:tenure` |
| Family | Home & Shelter |
| Domain | Culture |
| Era | Kinship Age → Collective Age |
| Kind | governance-mechanism |
| Archetype | The Covenant |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Tenure is a governance mechanism in the Home & Shelter family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Tenure connects occupancy to safety, identity, memory, and belonging.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** legitimacy, clarity, enforceability, administrative efficiency
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Tenure connects occupancy to safety, identity, memory, and belonging
- **Gift:** Clarity about tenure makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When tenure is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when tenure is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where tenure appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Tenure reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Tenure changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Tenure changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Tenure can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Covenant enters the reading through Tenure. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** Who has legitimate authority under Tenure, and where does that authority stop?

**Guidance:** Name the source, scope, duration, appeal path, and release of authority.

## Game function

Changes what actions are permitted and who may authorize them. Initiative 4.

## Relationships

- **Soil conflicts with Tenure.** Soil conflicts with Tenure through a change in rights, information, cash flow, priority, timing, or physical use.
- **Household externalizes to Tenure.** Household externalizes to Tenure through a change in rights, information, cash flow, priority, timing, or physical use.
- **Tenure amplifies Occupancy.** Tenure amplifies Occupancy through a change in rights, information, cash flow, priority, timing, or physical use.
- **Tenure is evidenced by Manufactured Home.** Tenure is evidenced by Manufactured Home through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Home versus Collateral
- Shelter versus Investment

## Historical lineage and regulatory context

Read Tenure through the lineage of Home & Shelter: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Tenure: a cadastral grid overlaid with colored permissions, gates, and invisible boundaries made visible; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Housing Discrimination Under the Fair Housing Act](https://www.hud.gov/helping-americans/fair-housing-act-overview) — U.S. Department of Housing and Urban Development; housing discrimination and protected classes.
- [Housing Data](https://www.census.gov/topics/housing.html) — U.S. Census Bureau; housing stock, tenure, construction, vacancies.
