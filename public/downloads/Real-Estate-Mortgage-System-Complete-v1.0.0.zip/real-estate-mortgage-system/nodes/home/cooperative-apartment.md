# Cooperative Apartment

> Cooperative Apartment packages domestic space into a legally and financially recognizable asset

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:residential-property:cooperative-apartment` |
| Family | Residential Property |
| Domain | Economics |
| Era | Institutional Age → Collective Age |
| Kind | concept |
| Archetype | The Pattern |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Cooperative Apartment is a concept in the Residential Property family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Cooperative Apartment packages domestic space into a legally and financially recognizable asset.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Cooperative Apartment packages domestic space into a legally and financially recognizable asset
- **Gift:** Clarity about cooperative apartment makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When cooperative apartment is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when cooperative apartment is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where cooperative apartment appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Cooperative Apartment reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Cooperative Apartment changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Cooperative Apartment changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Cooperative Apartment can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Pattern enters the reading through Cooperative Apartment. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Cooperative Apartment becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 4.

## Relationships

- **Dwelling is evidenced by Cooperative Apartment.** Dwelling is evidenced by Cooperative Apartment through a change in rights, information, cash flow, priority, timing, or physical use.
- **Condominium documents Cooperative Apartment.** Condominium documents Cooperative Apartment through a change in rights, information, cash flow, priority, timing, or physical use.
- **Cooperative Apartment transfers into Duplex.** Cooperative Apartment transfers into Duplex through a change in rights, information, cash flow, priority, timing, or physical use.
- **Cooperative Apartment is administered through Industrial.** Cooperative Apartment is administered through Industrial through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Cooperative Apartment through the lineage of Residential Property: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Cooperative Apartment: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [FHA Single Family Housing Policy Handbook 4000.1](https://www.hud.gov/hud-partners/single-family-handbook-4000-1) — U.S. Department of Housing and Urban Development; FHA approval, origination, underwriting, appraisal, servicing, quality control.
- [Fannie Mae Selling Guide](https://singlefamily.fanniemae.com/media/document/pdf/selling-guide-february-4-2026) — Fannie Mae; loan eligibility, underwriting, appraisal, delivery.
