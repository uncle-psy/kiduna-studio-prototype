# Lot

> Lot holds the physical conditions beneath every later claim

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:land-place:lot` |
| Family | Land & Place |
| Domain | Culture |
| Era | Kinship Age → Collective Age |
| Kind | place-or-property |
| Archetype | The Habitat |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Lot is a place or property in the Land & Place family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Lot holds the physical conditions beneath every later claim.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Lot holds the physical conditions beneath every later claim
- **Gift:** Clarity about lot makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When lot is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when lot is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where lot appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Lot reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Lot changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Lot changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Lot can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Habitat enters the reading through Lot. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What relationships become visible when Lot is treated as a place rather than only an asset?

**Guidance:** Walk the physical, legal, financial, ecological, and human maps separately before recombining them.

## Game function

Occupies spatial capacity and generates use, cost, externality, identity, or cash flow. Initiative 3.

## Relationships

- **Parcel constrains Lot.** Parcel constrains Lot through a change in rights, information, cash flow, priority, timing, or physical use.
- **Lot enables Site.** Lot enables Site through a change in rights, information, cash flow, priority, timing, or physical use.
- **Lot is governed by Shelter.** Lot is governed by Shelter through a change in rights, information, cash flow, priority, timing, or physical use.
- **Allonge externalizes to Lot.** Allonge externalizes to Lot through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Lot through the lineage of Land & Place: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Lot: a tactile architectural environment rendered in deep enamel, stone, vegetation, water, and fine metal lines; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Risk-Based Brownfields Cleanups](https://www.epa.gov/brownfields/risk-based-brownfields-cleanups) — U.S. Environmental Protection Agency; contamination, remediation, reuse, institutional controls.
