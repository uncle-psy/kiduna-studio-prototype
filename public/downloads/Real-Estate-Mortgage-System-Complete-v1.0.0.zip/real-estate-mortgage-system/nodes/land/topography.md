# Topography

> Topography holds the physical conditions beneath every later claim

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:land-place:topography` |
| Family | Land & Place |
| Domain | Culture |
| Era | Kinship Age → Collective Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Topography is a concept in the Land & Place family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Topography holds the physical conditions beneath every later claim.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Topography holds the physical conditions beneath every later claim
- **Gift:** Clarity about topography makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When topography is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when topography is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where topography appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Topography reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Topography changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Topography changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Topography can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Topography. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Topography becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 3.

## Relationships

- **Location transfers into Topography.** Location transfers into Topography through a change in rights, information, cash flow, priority, timing, or physical use.
- **Topography is governed by Soil.** Topography is governed by Soil through a change in rights, information, cash flow, priority, timing, or physical use.
- **Topography is governed by Household.** Topography is governed by Household through a change in rights, information, cash flow, priority, timing, or physical use.
- **Trailing Document externalizes to Topography.** Trailing Document externalizes to Topography through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Topography through the lineage of Land & Place: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Topography: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Energy Codes 101](https://www.energy.gov/cmei/buildings/articles/energy-codes-101-what-are-they-and-what-does-role) — U.S. Department of Energy; model codes, adoption, enforcement, building systems.
- [Risk-Based Brownfields Cleanups](https://www.epa.gov/brownfields/risk-based-brownfields-cleanups) — U.S. Environmental Protection Agency; contamination, remediation, reuse, institutional controls.
