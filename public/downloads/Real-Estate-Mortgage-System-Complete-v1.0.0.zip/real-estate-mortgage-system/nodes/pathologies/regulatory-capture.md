# Regulatory Capture

> Regulatory Capture shows how individually rational actions can compound into systemic harm

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:market-pathologies:regulatory-capture` |
| Family | Market Pathologies |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | pathology-or-event |
| Archetype | The Hidden Cost |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Regulatory Capture is a pathology or event in the Market Pathologies family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Regulatory Capture shows how individually rational actions can compound into systemic harm.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Regulatory Capture shows how individually rational actions can compound into systemic harm
- **Gift:** Clarity about regulatory capture makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When regulatory capture is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when regulatory capture is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where regulatory capture appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Regulatory Capture reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Regulatory Capture changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Regulatory Capture changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Regulatory Capture can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Hidden Cost enters the reading through Regulatory Capture. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** Which earlier warning became visible only after Regulatory Capture arrived?

**Guidance:** Trace the failure backward through incentives, information, leverage, timing, and feedback rather than locating blame at the final visible event.

## Game function

Enters as a systemic event that exposes hidden leverage, deferred cost, or misaligned incentives. Initiative 4.

## Relationships

- **Wire Fraud is administered through Regulatory Capture.** Wire Fraud is administered through Regulatory Capture through a change in rights, information, cash flow, priority, timing, or physical use.
- **Moral Hazard conflicts with Regulatory Capture.** Moral Hazard conflicts with Regulatory Capture through a change in rights, information, cash flow, priority, timing, or physical use.
- **Regulatory Capture is evidenced by Liquidity Crisis.** Regulatory Capture is evidenced by Liquidity Crisis through a change in rights, information, cash flow, priority, timing, or physical use.
- **Regulatory Capture depends on Postwar Suburbanization.** Regulatory Capture depends on Postwar Suburbanization through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Regulatory Capture through the lineage of Market Pathologies: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Regulatory Capture: a beautiful structure whose hidden fracture propagates through claims, cash flows, and neighboring parcels; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [The Financial Crisis Inquiry Report](https://www.govinfo.gov/features/financial-crisis-inquiry-report) — Financial Crisis Inquiry Commission / U.S. Government Publishing Office; causes and mechanisms of the 2007–2009 financial crisis.
- [The Future of Mortgage Finance in the United States](https://www.federalreserve.gov/newsevents/speech/bernanke20081031a.htm) — Board of Governors of the Federal Reserve System; securitization, GSEs, underwriting, leverage, crisis.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
