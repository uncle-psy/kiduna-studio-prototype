# Wire Fraud

> Wire Fraud shows where trust, identity, data, money, and documents can be manipulated

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:fraud-cyber:wire-fraud` |
| Family | Fraud, Cyber & Operational Failure |
| Domain | Technology |
| Era | Agentic Age |
| Kind | pathology-or-event |
| Archetype | The Hidden Cost |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Wire Fraud is a pathology or event in the Fraud, Cyber & Operational Failure family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Wire Fraud shows where trust, identity, data, money, and documents can be manipulated.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Wire Fraud shows where trust, identity, data, money, and documents can be manipulated
- **Gift:** Clarity about wire fraud makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When wire fraud is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when wire fraud is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where wire fraud appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Wire Fraud reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Wire Fraud changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Wire Fraud changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Wire Fraud can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Hidden Cost enters the reading through Wire Fraud. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** Which earlier warning became visible only after Wire Fraud arrived?

**Guidance:** Trace the failure backward through incentives, information, leverage, timing, and feedback rather than locating blame at the final visible event.

## Game function

Enters as a systemic event that exposes hidden leverage, deferred cost, or misaligned incentives. Initiative 4.

## Relationships

- **Remote Online Notarization is evidenced by Wire Fraud.** Remote Online Notarization is evidenced by Wire Fraud through a change in rights, information, cash flow, priority, timing, or physical use.
- **Deed Fraud amplifies Wire Fraud.** Deed Fraud amplifies Wire Fraud through a change in rights, information, cash flow, priority, timing, or physical use.
- **Wire Fraud conflicts with Identity Theft.** Wire Fraud conflicts with Identity Theft through a change in rights, information, cash flow, priority, timing, or physical use.
- **Wire Fraud is administered through Regulatory Capture.** Wire Fraud is administered through Regulatory Capture through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Wire Fraud through the lineage of Fraud, Cyber & Operational Failure: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Wire Fraud: a beautiful structure whose hidden fracture propagates through claims, cash flows, and neighboring parcels; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
