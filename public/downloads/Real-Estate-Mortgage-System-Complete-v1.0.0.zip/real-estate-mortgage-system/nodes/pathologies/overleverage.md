# Overleverage

> Overleverage shows how individually rational actions can compound into systemic harm

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:market-pathologies:overleverage` |
| Family | Market Pathologies |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | concept |
| Archetype | The Field |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Overleverage is a concept in the Market Pathologies family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Overleverage shows how individually rational actions can compound into systemic harm.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Overleverage shows how individually rational actions can compound into systemic harm
- **Gift:** Clarity about overleverage makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When overleverage is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when overleverage is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where overleverage appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Overleverage reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Overleverage changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Overleverage changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Overleverage can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Field enters the reading through Overleverage. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Overleverage becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 3.

## Relationships

- **Income Fraud amplifies Overleverage.** Income Fraud amplifies Overleverage through a change in rights, information, cash flow, priority, timing, or physical use.
- **Speculation documents Overleverage.** Speculation documents Overleverage through a change in rights, information, cash flow, priority, timing, or physical use.
- **Overleverage transfers into Negative Amortization.** Overleverage transfers into Negative Amortization through a change in rights, information, cash flow, priority, timing, or physical use.
- **Overleverage conflicts with Cadastral Survey.** Overleverage conflicts with Cadastral Survey through a change in rights, information, cash flow, priority, timing, or physical use.
- **Overleverage amplifies Default.** Overleverage amplifies Default through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Overleverage through the lineage of Market Pathologies: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Overleverage: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [The Financial Crisis Inquiry Report](https://www.govinfo.gov/features/financial-crisis-inquiry-report) — Financial Crisis Inquiry Commission / U.S. Government Publishing Office; causes and mechanisms of the 2007–2009 financial crisis.
- [The Future of Mortgage Finance in the United States](https://www.federalreserve.gov/newsevents/speech/bernanke20081031a.htm) — Board of Governors of the Federal Reserve System; securitization, GSEs, underwriting, leverage, crisis.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
