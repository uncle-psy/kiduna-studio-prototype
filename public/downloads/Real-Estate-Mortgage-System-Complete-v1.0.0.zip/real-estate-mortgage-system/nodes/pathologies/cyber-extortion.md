# Cyber Extortion

> Cyber Extortion shows where trust, identity, data, money, and documents can be manipulated

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:fraud-cyber:cyber-extortion` |
| Family | Fraud, Cyber & Operational Failure |
| Domain | Technology |
| Era | Agentic Age |
| Kind | concept |
| Archetype | The Pattern |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Cyber Extortion is a concept in the Fraud, Cyber & Operational Failure family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Cyber Extortion shows where trust, identity, data, money, and documents can be manipulated.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Cyber Extortion shows where trust, identity, data, money, and documents can be manipulated
- **Gift:** Clarity about cyber extortion makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When cyber extortion is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when cyber extortion is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where cyber extortion appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Cyber Extortion reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Cyber Extortion changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Cyber Extortion changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Cyber Extortion can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Pattern enters the reading through Cyber Extortion. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Cyber Extortion becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 1.

## Relationships

- **Automated Underwriting System constrains Cyber Extortion.** Automated Underwriting System constrains Cyber Extortion through a change in rights, information, cash flow, priority, timing, or physical use.
- **Data Breach constrains Cyber Extortion.** Data Breach constrains Cyber Extortion through a change in rights, information, cash flow, priority, timing, or physical use.
- **Cyber Extortion enables Vacancy.** Cyber Extortion enables Vacancy through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Cyber Extortion through the lineage of Fraud, Cyber & Operational Failure: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Cyber Extortion: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
