# Vacancy

> Vacancy shows how individually rational actions can compound into systemic harm

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:market-pathologies:vacancy` |
| Family | Market Pathologies |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | metric-or-force |
| Archetype | The Scale |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Vacancy is a metric or force in the Market Pathologies family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Vacancy shows how individually rational actions can compound into systemic harm.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** underwriter, appraiser, investor, developer, regulator
- **Incentives:** comparability, predictive usefulness, decision speed, auditability
- **Inputs:** observations, definitions, time period, comparison set
- **Outputs:** signal, comparison, threshold, decision input
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Vacancy shows how individually rational actions can compound into systemic harm
- **Gift:** Clarity about vacancy makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When vacancy is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when vacancy is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where vacancy appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Vacancy reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Vacancy changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Vacancy changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Vacancy can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Scale enters the reading through Vacancy. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What is Vacancy measuring—and which important reality has been left outside the denominator?

**Guidance:** Change the denominator, time horizon, and stakeholder. If the conclusion changes, the map—not only the number—was doing the work.

## Game function

Sets or modifies a threshold; players may stress it by changing rates, time, or cash flow. Initiative 1.

## Relationships

- **Cyber Extortion enables Vacancy.** Cyber Extortion enables Vacancy through a change in rights, information, cash flow, priority, timing, or physical use.
- **Underbuilding enables Vacancy.** Underbuilding enables Vacancy through a change in rights, information, cash flow, priority, timing, or physical use.
- **Vacancy prices Dodd-Frank Reform.** Vacancy prices Dodd-Frank Reform through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Vacancy through the lineage of Market Pathologies: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Vacancy: a calibrated enamel field where one measured boundary visibly changes the exposed and submerged portions of an asset; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [The Financial Crisis Inquiry Report](https://www.govinfo.gov/features/financial-crisis-inquiry-report) — Financial Crisis Inquiry Commission / U.S. Government Publishing Office; causes and mechanisms of the 2007–2009 financial crisis.
- [The Future of Mortgage Finance in the United States](https://www.federalreserve.gov/newsevents/speech/bernanke20081031a.htm) — Board of Governors of the Federal Reserve System; securitization, GSEs, underwriting, leverage, crisis.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
