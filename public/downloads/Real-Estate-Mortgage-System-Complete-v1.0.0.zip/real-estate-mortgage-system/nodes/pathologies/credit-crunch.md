# Credit Crunch

> Credit Crunch shows how individually rational actions can compound into systemic harm

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:market-pathologies:credit-crunch` |
| Family | Market Pathologies |
| Domain | Economics |
| Era | Institutional Age → Agentic Age |
| Kind | financial-instrument |
| Archetype | The Claim |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Credit Crunch is a financial instrument in the Market Pathologies family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Credit Crunch shows how individually rational actions can compound into systemic harm.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access to capital, yield, liquidity, risk allocation
- **Inputs:** capital, terms, collateral or cash flow, counterparties, risk assumptions
- **Outputs:** funding, cash-flow claims, obligations, risk allocation
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Credit Crunch shows how individually rational actions can compound into systemic harm
- **Gift:** Clarity about credit crunch makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When credit crunch is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when credit crunch is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where credit crunch appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Credit Crunch reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Credit Crunch changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Credit Crunch changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Credit Crunch can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Claim enters the reading through Credit Crunch. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What future is being pledged through Credit Crunch, and who receives protection if conditions change?

**Guidance:** Separate access from cost, payment from principal, and temporary liquidity from permanent viability.

## Game function

Moves Capital now and creates a future Claim with explicit priority and failure consequences. Initiative 2.

## Relationships

- **Synthetic Identity transfers into Credit Crunch.** Synthetic Identity transfers into Credit Crunch through a change in rights, information, cash flow, priority, timing, or physical use.
- **Liquidity Crisis is administered through Credit Crunch.** Liquidity Crisis is administered through Credit Crunch through a change in rights, information, cash flow, priority, timing, or physical use.
- **Credit Crunch depends on Overbuilding.** Credit Crunch depends on Overbuilding through a change in rights, information, cash flow, priority, timing, or physical use.
- **Credit Crunch is governed by Securitization Era.** Credit Crunch is governed by Securitization Era through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Credit Crunch through the lineage of Market Pathologies: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Credit Crunch: a luminous claim-line descending from a built form into layered earth and extending across a long brass timeline; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [The Financial Crisis Inquiry Report](https://www.govinfo.gov/features/financial-crisis-inquiry-report) — Financial Crisis Inquiry Commission / U.S. Government Publishing Office; causes and mechanisms of the 2007–2009 financial crisis.
- [The Future of Mortgage Finance in the United States](https://www.federalreserve.gov/newsevents/speech/bernanke20081031a.htm) — Board of Governors of the Federal Reserve System; securitization, GSEs, underwriting, leverage, crisis.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
