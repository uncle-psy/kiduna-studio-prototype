# Synthetic Identity

> Synthetic Identity shows where trust, identity, data, money, and documents can be manipulated

| Field | Value |
|---|---|
| Stable ID | `node:kiduna:real-estate-mortgage:fraud-cyber:synthetic-identity` |
| Family | Fraud, Cyber & Operational Failure |
| Domain | Technology |
| Era | Agentic Age |
| Kind | concept |
| Archetype | The Pattern |
| Claim layers | empirical, cultural_historical, synthesis, interpretive, symbolic_divinatory |

## What it is

Synthetic Identity is a concept in the Fraud, Cyber & Operational Failure family, defined here by the function it performs in the property system rather than by label alone.

## What it actually does

Synthetic Identity shows where trust, identity, data, money, and documents can be manipulated.

## Why it exists

It exists because place is unique and immovable while law, capital, information, and human lives must still coordinate around it across time.

## System mechanics

- **Who uses it:** owner, occupant, buyer, seller, lender, investor, steward, regulator
- **Incentives:** access, certainty, control, value, continuity
- **Inputs:** place, people, records, rules, resources, time
- **Outputs:** rights, constraints, uses, relationships, consequences
- **Dependencies:** Land, Authority, Information, Capital, Time

## Archetypal reading

- **Essence:** Synthetic Identity shows where trust, identity, data, money, and documents can be manipulated
- **Gift:** Clarity about synthetic identity makes a hidden allocation of place, time, authority, value, or risk available for deliberate choice.
- **Wound / Shadow:** When synthetic identity is treated as neutral or inevitable, its costs can be shifted to people who hold less information, authority, liquidity, or mobility.
- **Failure mode:** The failure mode appears when synthetic identity is stale, opaque, mispriced, misrecorded, overextended, or applied outside the conditions that made it useful.

## Lenses

- **Personal:** Notice where synthetic identity appears as a structure in your own commitments: what is held, promised, priced, protected, excluded, or deferred?
- **Business:** Synthetic Identity reveals a handoff among information, authority, incentives, operating work, and capital. Make the owner of each handoff explicit.
- **Financial:** Synthetic Identity changes the timing, priority, comparability, liquidity, or distribution of cash flow and risk.
- **Property:** Synthetic Identity changes how a physical place can be used, valued, financed, transferred, occupied, maintained, or reclaimed.
- **Community:** Synthetic Identity can create benefits inside one parcel while exporting costs or opportunity to neighbors, institutions, or future residents.

## Divination

The Pattern enters the reading through Synthetic Identity. The issue is not only what is visible; it is which map of ownership, time, risk, authority, or belonging currently governs the situation.

**Question:** What changes when Synthetic Identity becomes the unit of analysis?

**Guidance:** Shift scale, clock, stakeholder, boundary, and claim layer before choosing a move.

## Game function

Creates a graph move that changes the active map. Initiative 2.

## Relationships

- **SMART Doc documents Synthetic Identity.** SMART Doc documents Synthetic Identity through a change in rights, information, cash flow, priority, timing, or physical use.
- **Identity Theft is evidenced by Synthetic Identity.** Identity Theft is evidenced by Synthetic Identity through a change in rights, information, cash flow, priority, timing, or physical use.
- **Synthetic Identity is administered through Business Email Compromise.** Synthetic Identity is administered through Business Email Compromise through a change in rights, information, cash flow, priority, timing, or physical use.
- **Synthetic Identity transfers into Credit Crunch.** Synthetic Identity transfers into Credit Crunch through a change in rights, information, cash flow, priority, timing, or physical use.

## Oppositions

- Use Value versus Exchange Value
- Speed versus Diligence

## Historical lineage and regulatory context

Read Synthetic Identity through the lineage of Fraud, Cyber & Operational Failure: earlier customary or local arrangements became recorded, standardized, financed, regulated, digitized, or contested over time.

Rules vary by jurisdiction and transaction. Use the cited primary sources as starting points and verify current local law, program guides, contracts, and professional standards before operational use.

## Visual direction

Text-free rounded-square enamel artifact for Synthetic Identity: one dominant symbolic mechanism with a restrained secondary counterforce; vitreous midnight enamel, blackened steel, warm brass, copper accents, mortgage-paper cream, deep green, slate, and sky blue.

## Engine output / Sentinel handoff

The generative interpretation above is preserved as Engine Output. Sentinel factors: jurisdiction-specific rules, factual uncertainty. These factors request contextual review; they do not delete or silently rewrite the candidate.

## Research / provenance

- [Mortgage Resources](https://www.consumerfinance.gov/compliance/compliance-resources/mortgage-resources/) — Consumer Financial Protection Bureau; origination, disclosures, appraisal, servicing, mortgage regulation.
- [eMortgage Standards and Specifications](https://www.mismo.org/standards-resources/emortgage-standards-and-specifications) — Mortgage Industry Standards Maintenance Organization; eMortgage, SMART Doc, RON, eVault, eRecording.
- [Risk Management Manual — Commercial Real Estate Lending](https://www.fdic.gov/risk-management-manual-examination-policies/commercial-real-estate-lending) — Federal Deposit Insurance Corporation; CRE underwriting and risk management.
