# VISUAL CONSTITUTION

The visual system is architectural, jewel-like, tactile, precise, and materially rich. Every artifact begins with one dominant mechanism and one restrained counterforce. The semantic kernel survives grayscale and thumbnail scale before enamel, ornament, or glow is added.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
