# ICONOGRAPHY

Blend cadastral lines, architectural sections, parcel geometry, street grids, blueprint notation, cash-flow paths, priority layers, and time bands. Avoid generic occult symbols and copied institutional logos.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
