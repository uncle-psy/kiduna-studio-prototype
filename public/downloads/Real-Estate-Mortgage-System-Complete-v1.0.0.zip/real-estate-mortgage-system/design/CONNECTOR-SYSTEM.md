# CONNECTOR SYSTEM

Connectors carry typed predicates. Shape encodes edge family; arrow and gate encode direction; enamel dots encode claim layer; no connector means merely related.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
