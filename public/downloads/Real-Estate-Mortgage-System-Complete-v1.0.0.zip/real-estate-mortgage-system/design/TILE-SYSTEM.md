# TILE SYSTEM

Rounded-square tiles are modular node expressions. A 1:1 tile has a 9% corner radius, 7% safe area, brass perimeter, and one central symbolic environment. Class is expressed through border geometry and accent—not explanatory text.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
