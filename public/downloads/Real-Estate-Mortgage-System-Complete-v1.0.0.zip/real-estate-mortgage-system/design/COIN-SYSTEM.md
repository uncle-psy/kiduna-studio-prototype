# COIN SYSTEM

Coins represent forces and metrics such as Interest Rate, Cap Rate, LTV, DTI, Equity, Liquidity, Leverage, and Inflation. The obverse shows the measure; the reverse shows what the measure excludes.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
