# TYPOGRAPHY

Use a high-contrast editorial serif for titles and a restrained humanist sans for interface and data. Master art remains text-free; labels are live, accessible, and localizable.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
