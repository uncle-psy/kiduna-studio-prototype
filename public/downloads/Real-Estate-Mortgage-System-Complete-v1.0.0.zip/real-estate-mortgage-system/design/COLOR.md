# COLOR

The default emotional register is life, safety, family, agency, liquidity, and possibility. Lead with sunlit celadon, jade, turquoise, sky #8FCFE3, warm ivory #F2E7CE, botanical green #4F8A54, terracotta #C86F4A, honey amber #E0A83E, coral #D97C68, pale lilac #B9A7D5, and polished brass #C79A4A. Use midnight #071018, blackened steel #161A1C, and deep red selectively for genuine warnings, constraints, wounds, or adverse states—not as the system-wide default. Never use color alone for meaning.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
