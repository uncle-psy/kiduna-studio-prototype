# RELIC SYSTEM

Keys and small relics represent permissions, evidence, authority, release, custody, and threshold. Deed-shaped pieces represent ownership instruments. Narrow metal bars represent claims crossing space or time.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
