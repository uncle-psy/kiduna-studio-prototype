# ENAMEL SYSTEM

Use vitreous midnight, deep green, slate, sky, brick, ivory, and mortgage-paper cream fields with warm brass, copper, nickel, and blackened-steel lines. Metal denotes durable claims, boundaries, custody, and calibrated measures; enamel denotes place, use, uncertainty, atmosphere, and living conditions.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
