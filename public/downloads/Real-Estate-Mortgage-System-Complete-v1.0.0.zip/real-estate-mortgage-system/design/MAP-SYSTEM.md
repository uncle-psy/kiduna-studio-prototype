# MAP SYSTEM

Physical maps combine landscape cards, modular tiles, claim bars, coins, keys, and typed connectors. Financial and human maps may coexist, but layers must remain togglable.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
