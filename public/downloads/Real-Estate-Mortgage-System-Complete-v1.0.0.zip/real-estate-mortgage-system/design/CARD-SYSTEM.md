# CARD SYSTEM

Vertical cards hold focal archetypes, roles, places, and instruments. Horizontal cards hold transactions, passages, comparisons, lineages, and multi-party dynamics. Live labels remain outside text-free master art.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
