# IMAGE GENERATION GUIDE

Prompt for text-free physical enamel artifacts photographed straight-on in luminous museum daylight. Make the default emotional register shelter, belonging, family continuity, access, stewardship, circulation, renewal, and possibility. Use warm windows, living greens, open skies, clear water, gardens, and illuminated paths where conceptually appropriate. Reserve deep shadow and warning colors for genuine harms, constraints, exclusions, failures, and adverse states. Specify one dominant mechanism, exact material palette, no labels, no screenshots, no brand marks, no tarot cliché, and a square master at 2048px or larger. Preserve prompt, model, date, rights state, and checksum.

## Accessibility and QA

Test silhouette, optical center, contrast, grayscale, small-size survival, edge artifacts, color profile, text absence, safe area, rights metadata, and checksum.
