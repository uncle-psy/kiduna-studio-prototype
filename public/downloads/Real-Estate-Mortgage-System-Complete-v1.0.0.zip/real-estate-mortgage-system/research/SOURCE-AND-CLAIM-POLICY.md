# Source and claim policy

This System separates source fact, historical interpretation, industry practice, original synthesis, symbolic/divinatory meaning, and open questions. A citation near a node does not make every interpretive sentence a sourced factual claim.

## Claim layers

- **Empirical:** definitions, rules, program mechanics, observations, or data supported by identified sources.
- **Cultural-historical:** historically situated accounts and institutional lineages.
- **Synthesis:** cross-source structural interpretation produced by the Mapshifting Engine.
- **Interpretive:** a proposed lens or mapshift, not a legal or factual equivalence.
- **Symbolic/divinatory:** an expression for reflection, reading, or game play; not prediction, legal advice, credit advice, investment advice, or appraisal.

## Freshness and jurisdiction

Mortgage rules, agency guides, lending programs, standards, and local property law change. Every node retains source references and a Sentinel handoff for jurisdiction and freshness where appropriate. Verify operational decisions against current primary authority.

## Candidate preservation

The longlist is append-preserving. Selection, merge, deferral, and release status do not delete discovery. Sentinel annotations create linked reviews and never mutate the candidate ledger.
