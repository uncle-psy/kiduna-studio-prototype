# 2008 mortgage crisis lineage

This lineage is preserved as a multi-causal graph, not a single villain story.

1. Global savings, low rates, demand for yield, and abundant liquidity increased capacity for mortgage credit.
2. Originate-to-distribute incentives separated fee generation from long-duration credit exposure.
3. Underwriting deterioration, higher leverage, weak documentation, and reliance on continued appreciation increased fragility.
4. Private-label securitization pooled loans, tranched cash flows, and distributed risks whose dependence on common housing conditions was underestimated.
5. Ratings, models, short performance histories, and information asymmetries obscured correlation and tail risk.
6. Falling house prices removed the refinance-and-sale escape route; delinquencies and defaults rose.
7. Structured-product uncertainty and mark-to-market losses impaired funding, collateral, and confidence.
8. Liquidity contraction, deleveraging, institutional failure, foreclosure, and neighborhood spillovers fed back into prices and credit.
9. Conservatorship, emergency liquidity, public guarantees, foreclosure response, and later Dodd-Frank/ATR-QM reforms changed the system.

Primary lineage sources: [Financial Crisis Inquiry Report](https://www.govinfo.gov/features/financial-crisis-inquiry-report) and [Federal Reserve analysis](https://www.federalreserve.gov/newsevents/speech/bernanke20081031a.htm).
