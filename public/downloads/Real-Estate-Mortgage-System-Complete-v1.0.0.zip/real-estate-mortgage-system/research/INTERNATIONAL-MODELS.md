# International property and mortgage models

The U.S. mortgage/title model is one jurisdictional arrangement, not the definition of real estate. This System therefore separates freehold, leasehold, strata/Torrens registration, covered-bond funding, government land leases, social and public housing, Islamic structures, collective/Indigenous tenure, and land-value taxation.

Each international node is a starting point for jurisdiction-specific research. It does not imply that a term has identical legal effect across countries. The graph uses translation, contrast, and shared-mechanism edges rather than equivalence.

Primary anchors include [UK leasehold guidance](https://www.gov.uk/leasehold-property/overview) and [European Central Bank covered-bond research](https://www.ecb.europa.eu/pub/pdf/other/coverbondsintheeufinancialsystem200812en_en.pdf).
