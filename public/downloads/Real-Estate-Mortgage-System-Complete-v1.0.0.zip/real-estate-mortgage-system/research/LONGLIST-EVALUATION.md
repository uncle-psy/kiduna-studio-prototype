# Longlist evaluation

The candidate ledger contains **1,723 distinct candidates**. It combines 659 curated stable nodes with 1064 structured variants across asset lifecycle, mortgage lifecycle, rights, document custody, risk control, metrics, institutional functions, technology states, policy effects, urban transformation, market phases, role incentives, and capital-stack behavior.

No synonym-only candidates were intentionally added. Matrix variants are retained only when the paired axes change function, timing, authority, priority, risk, or use.

## Decisions

- **selected-core:** 658
- **reserved-expansion:** 160
- **deferred-evidence:** 455
- **merged-as-facet:** 450

## Evaluation axes

Industry significance; archetypal depth; graph connectivity; historical value; educational usefulness; divination usefulness; game potential; visual potential; distinctiveness. Scores are diagnostics, not truth or release authority.

## Ontology decision

The final ontology contains **659 nodes** across **50 native families**. This is near the high end of the requested 400–700 range because the brief requires simultaneous professional depth in residential mortgages, commercial finance, property law, development, policy, technology, history, human meaning, and game expression. The final roster preserves native family distinctions and maps them to shared traversal kinds without flattening them.
