# Scale and Mapshifting


## What Mapshifting does

Mapshifting changes the scale, boundary, time horizon, or relationship map used to understand a situation. It does not mean that every viewpoint is equally accurate. A useful shift makes additional evidence visible, clarifies assumptions, and changes what action appears responsible.

The deck uses nine bands: **Fundamental; Atomic and molecular; Microscopic and cellular; Organism; Community and ecosystem; Landscape and regional system; Geologic and continental; Planetary and orbital; Stellar and cosmic.** These are practical bands, not claims that nature has exactly nine levels.

## The four movements

1. **Move inward:** identify smaller constituents, local interactions, and short time scales.
2. **Move outward:** identify containing systems, downstream recipients, and indirect effects.
3. **Move through time:** compare the immediate event, developmental sequence, and deep-time record.
4. **Move across relationship:** redraw the map around a carrier, boundary, feedback, resource, or shared vulnerability.

## A disciplined scale shift

Start with a concrete observation. Name the present scale. Identify one smaller process and one larger container. State what changes when the boundary moves. Then check whether the comparison is structural or merely poetic. For example, watershed nesting is an observed hydrological fact. Using it to explore accumulated consequence is deck metaphor. Claiming that personal emotion controls watershed behavior would be unsupported.

## Deterministic and probabilistic perspectives

Some models make highly precise predictions under defined conditions; eclipse timing is an example. Other systems are deterministic in principle but sensitive, incompletely observed, or too complex for exact forecasts. Still others require probability at the core of the scientific description. A participant should not convert uncertainty into magic or certainty into fate.

Use four labels:

- **Observed:** measured or directly documented within stated limits.
- **Model:** a structured representation tested against evidence.
- **Inference:** a conclusion drawn from observations and models.
- **Open question:** unresolved, debated, or beyond current measurement.

## Visible and invisible

Invisible does not mean spiritual. Electrons, groundwater, mantle flow, dark matter effects, and microbial communities are inferred or measured through instruments, traces, models, and consequences. The relevant question is how the claim is supported and with what uncertainty.

## Example: river to watershed

[River](cards/047-river.md) emphasizes flow along a channel. [Watershed](cards/046-watershed.md) emphasizes the entire contributing area and routing boundary. [Aquifer](cards/050-aquifer.md) adds hidden storage and subsurface flow. [Delta](cards/048-delta.md) emphasizes distribution and deposition at a threshold. Drawing any one card changes which relationships are foregrounded without declaring the others unreal.

## Example: photon to galaxy

[Photon](cards/001-photon.md) foregrounds transmission and interaction. [Star](cards/073-star.md) foregrounds sustained fusion and radiation. [Galaxy](cards/078-galaxy.md) foregrounds gravitational assembly and generational turnover. The photon can carry evidence from the galaxy, but it is not a miniature galaxy and the galaxy is not merely “light.” A good scale shift preserves difference.
