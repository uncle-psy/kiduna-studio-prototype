---
card_number: 66
name: "Orbit"
slug: "orbit"
scale_band: "8. Planetary and orbital"
scientific_domains: ["orbital mechanics","gravitation"]
natural_processes: ["orbit","feedback"]
system_functions: ["relationship","clock"]
spatial_scale: "satellite systems to galaxies"
time_scale: "minutes to billions of years"
core_archetype: "Falling Around"
primary_gifts: ["rhythm","dynamic balance","return"]
primary_wounds: ["repetition","capture","decaying path"]
related_cards: ["expanding-universe", "fault", "star", "mantle-convection", "gravity", "moon", "comet", "black-hole"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Orbit

## Essence

Continuity can arise from moving forward while continually yielding to a center.

## Keywords

orbit · feedback · relationship · clock · rhythm · dynamic balance · return

## What it is

An orbit is the curved trajectory of a body moving under gravity, often approximated by an ellipse in a two-body system. Real orbits are perturbed by additional bodies, drag, radiation, and changing mass. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** satellite systems to galaxies.
- **Characteristic time:** minutes to billions of years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Gravity](009-gravity.md).
- **Larger container:** A useful containing or consequence-level bridge is [Star](073-star.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Orbital energy and angular momentum determine shape and period. Resonances, tides, encounters, and dissipation can stabilize, migrate, or destabilize paths. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Balance may be sustained motion, not rest; repetition can be stable while the relation slowly evolves.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Falling Around.** Orbit deserves its own card because it makes **relationship and clock** legible through **orbit and feedback** at the planetary and orbital scale. It differs from [Planetary Ring](069-planetary-ring.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Rhythm.** Balance may be sustained motion, not rest; repetition can be stable while the relation slowly evolves.
- **Dynamic Balance.** This capacity becomes available when dynamic balance fits the timing, limits, and needs of the larger system.
- **Return.** This capacity becomes available when return fits the timing, limits, and needs of the larger system.

## Wounds

- **Repetition.** The pattern distorts when repetition replaces responsive relationship.
- **Capture.** Capture appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Decaying Path.** Decaying Path appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **rhythm** becomes **repetition** when scale, timing, boundary, or reciprocity is ignored. Orbit asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

rhythm remains connected to dynamic balance while limits are respected; repetition is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **repetition, capture, decaying path**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **rhythm, dynamic balance, return** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Gravity](009-gravity.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to orbit and feedback as they actually operate in Orbit; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Star](073-star.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Orbit.
- **Deep time:** Consider minutes to billions of years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with falling around: examine both rhythm and repetition. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support dynamic balance or produce capture. |
| Creativity | Work with the card's actual process—orbit and feedback—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **rhythm** already present, even in a small or quiet form?
2. Where might **repetition** be shaping the situation?
3. Where do you observe **orbit**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Falling Around** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Orbit**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Balance may be sustained motion, not rest; repetition can be stable while the relation slowly evolves.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **rhythm** while reducing **repetition**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Long-term stability in many-body systems, chaotic transitions, and the detailed formation of orbital architectures remain active research.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Orbit. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Falling Around** as the original synthesis for Orbit: Balance may be sustained motion, not rest; repetition can be stable while the relation slowly evolves. This meaning arises from the sourced description of orbit and feedback, then becomes a reflective lens through the gift of **rhythm** and the wound of **repetition**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Moon](065-moon.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Expanding Universe](081-expanding-universe.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Gravity](009-gravity.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Star](073-star.md) helps identify containing systems and downstream effects.
- **Shared process:** [Gravity](009-gravity.md) also expresses orbit, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Star](073-star.md) offers a nearby systems comparison.
- **Natural cycle:** [Ecological Succession](040-ecological-succession.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Planetary Ring](069-planetary-ring.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Orbit at its characteristic scale, with the central visual emphasis on **orbit and feedback** and **relationship and clock**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Solar System Exploration](https://science.nasa.gov/solar-system/). Accessed 2026-08-23.
- **S02 — NASA Space Place.** [What Is Gravity?](https://spaceplace.nasa.gov/what-is-gravity/en/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Long-term stability in many-body systems, chaotic transitions, and the detailed formation of orbital architectures remain active research.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Orbit is retained because **Falling Around** is not duplicated by Planetary Ring, even where their processes overlap.
