---
card_number: 36
name: "Keystone Species"
slug: "keystone-species"
scale_band: "4. Organism"
scientific_domains: ["community ecology","conservation biology"]
natural_processes: ["regulation","feedback"]
system_functions: ["regulator","center"]
spatial_scale: "population influence across an ecosystem"
time_scale: "seasons to evolutionary time"
core_archetype: "Disproportionate Influence"
primary_gifts: ["regulation","leverage","support of diversity"]
primary_wounds: ["overcentralization","fragility around one role","misplaced hero narrative"]
related_cards: ["microbiome", "cell-membrane", "forest-canopy", "kelp-forest", "food-web", "ocean-current", "proton", "neutron"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Keystone Species

## Essence

Importance is measured by systemic consequence, not size or abundance.

## Keywords

regulation · feedback · regulator · center · leverage · support of diversity

## What it is

A keystone species has an ecological effect disproportionately large relative to its abundance, often by regulating consumers, competitors, habitat, or mutualisms. The designation is evidence-based and context-specific. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** population influence across an ecosystem.
- **Characteristic time:** seasons to evolutionary time.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Microbiome](027-microbiome.md).
- **Larger container:** A useful containing or consequence-level bridge is [Food Web](038-food-web.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Removing or restoring a keystone species can propagate indirect effects through a food web or habitat. The same species may not be keystone in every place or time. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Leverage lives in relationships, and systemic importance must be tested rather than assumed.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Disproportionate Influence.** Keystone Species deserves its own card because it makes **regulator and center** legible through **regulation and feedback** at the organism scale. It differs from [Lichen](031-lichen.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Regulation.** Leverage lives in relationships, and systemic importance must be tested rather than assumed.
- **Leverage.** This capacity becomes available when leverage fits the timing, limits, and needs of the larger system.
- **Support Of Diversity.** This capacity becomes available when support of diversity fits the timing, limits, and needs of the larger system.

## Wounds

- **Overcentralization.** The pattern distorts when overcentralization replaces responsive relationship.
- **Fragility Around One Role.** Fragility Around One Role appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Misplaced Hero Narrative.** Misplaced Hero Narrative appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **regulation** becomes **overcentralization** when scale, timing, boundary, or reciprocity is ignored. Keystone Species asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

regulation remains connected to leverage while limits are respected; overcentralization is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **overcentralization, fragility around one role, misplaced hero narrative**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **regulation, leverage, support of diversity** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Microbiome](027-microbiome.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to regulation and feedback as they actually operate in Keystone Species; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Food Web](038-food-web.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Keystone Species.
- **Deep time:** Consider seasons to evolutionary time. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with disproportionate influence: examine both regulation and overcentralization. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support leverage or produce fragility around one role. |
| Creativity | Work with the card's actual process—regulation and feedback—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **regulation** already present, even in a small or quiet form?
2. Where might **overcentralization** be shaping the situation?
3. Where do you observe **regulation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Disproportionate Influence** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Keystone Species**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Leverage lives in relationships, and systemic importance must be tested rather than assumed.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **regulation** while reducing **overcentralization**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Keystone effects can shift with climate, invasion, harvest, spatial scale, and community composition; causal attribution is often difficult.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Keystone Species. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Disproportionate Influence** as the original synthesis for Keystone Species: Leverage lives in relationships, and systemic importance must be tested rather than assumed. This meaning arises from the sourced description of regulation and feedback, then becomes a reflective lens through the gift of **regulation** and the wound of **overcentralization**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Microbiome](027-microbiome.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Ocean Current](053-ocean-current.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Microbiome](027-microbiome.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Food Web](038-food-web.md) helps identify containing systems and downstream effects.
- **Shared process:** [Cell Membrane](019-cell-membrane.md) also expresses regulation, but with different constraints.
- **Shared wound:** [Gravity](009-gravity.md) also carries the wound **overcentralization**.
- **Natural cycle:** [Proton](003-proton.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Lichen](031-lichen.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Keystone Species at its characteristic scale, with the central visual emphasis on **regulation and feedback** and **regulator and center**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — Smithsonian National Museum of Natural History.** [What Is Biodiversity?](https://naturalhistory.si.edu/education/teaching-resources/life-science/what-biodiversity). Accessed 2026-08-23.
- **S02 — USDA Forest Service.** [Pollinators](https://www.fs.usda.gov/wildflowers/pollinators/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Keystone effects can shift with climate, invasion, harvest, spatial scale, and community composition; causal attribution is often difficult.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Keystone Species is retained because **Disproportionate Influence** is not duplicated by Lichen, even where their processes overlap.
