---
card_number: 55
name: "Fault"
slug: "fault"
scale_band: "7. Geologic and continental"
scientific_domains: ["structural geology","seismology"]
natural_processes: ["strain","rupture"]
system_functions: ["boundary","memory"]
spatial_scale: "small fracture to plate-boundary system"
time_scale: "creep to recurrence over centuries or longer"
core_archetype: "Stored Difference"
primary_gifts: ["necessary movement","clarity of boundary","release"]
primary_wounds: ["accumulated strain","repeated rupture","false stillness"]
related_cards: ["earthquake", "watershed", "planet", "aquifer", "planetary-ring", "magnetosphere", "glacier", "mountain-range"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Fault

## Essence

A break records motion and may hold strain before it releases.

## Keywords

strain · rupture · boundary · memory · necessary movement · clarity of boundary · release

## What it is

A fault is a fracture or zone of fractures in rock across which displacement has occurred. Faults differ by geometry, motion, depth, material, and whether they creep or lock. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** small fracture to plate-boundary system.
- **Characteristic time:** creep to recurrence over centuries or longer.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Crystal Lattice](015-crystal-lattice.md).
- **Larger container:** A useful containing or consequence-level bridge is [Tectonic Plate](057-tectonic-plate.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Stress changes deform surrounding rock; friction and fluid pressure affect slip. Faults can move slowly, rupture suddenly, reactivate, or transfer stress to connected structures. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Stillness at a boundary may be stored difference rather than agreement.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Stored Difference.** Fault deserves its own card because it makes **boundary and memory** legible through **strain and rupture** at the geologic and continental scale. It differs from [Tectonic Plate](057-tectonic-plate.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Necessary Movement.** Stillness at a boundary may be stored difference rather than agreement.
- **Clarity Of Boundary.** This capacity becomes available when clarity of boundary fits the timing, limits, and needs of the larger system.
- **Release.** This capacity becomes available when release fits the timing, limits, and needs of the larger system.

## Wounds

- **Accumulated Strain.** The pattern distorts when accumulated strain replaces responsive relationship.
- **Repeated Rupture.** Repeated Rupture appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **False Stillness.** False Stillness appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **necessary movement** becomes **accumulated strain** when scale, timing, boundary, or reciprocity is ignored. Fault asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

necessary movement remains connected to clarity of boundary while limits are respected; accumulated strain is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **accumulated strain, repeated rupture, false stillness**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **necessary movement, clarity of boundary, release** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Crystal Lattice](015-crystal-lattice.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to strain and rupture as they actually operate in Fault; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Tectonic Plate](057-tectonic-plate.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Fault.
- **Deep time:** Consider creep to recurrence over centuries or longer. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with stored difference: examine both necessary movement and accumulated strain. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support clarity of boundary or produce repeated rupture. |
| Creativity | Work with the card's actual process—strain and rupture—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **necessary movement** already present, even in a small or quiet form?
2. Where might **accumulated strain** be shaping the situation?
3. Where do you observe **strain**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Stored Difference** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Fault**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Stillness at a boundary may be stored difference rather than agreement.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **necessary movement** while reducing **accumulated strain**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Earthquake timing on individual faults cannot be predicted precisely; subsurface geometry, friction, fluids, and interaction among faults remain uncertain.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Fault. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Stored Difference** as the original synthesis for Fault: Stillness at a boundary may be stored difference rather than agreement. This meaning arises from the sourced description of strain and rupture, then becomes a reflective lens through the gift of **necessary movement** and the wound of **accumulated strain**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Earthquake](056-earthquake.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Earthquake](056-earthquake.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Crystal Lattice](015-crystal-lattice.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Tectonic Plate](057-tectonic-plate.md) helps identify containing systems and downstream effects.
- **Shared process:** [Earthquake](056-earthquake.md) also expresses rupture, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Planet](064-planet.md) offers a nearby systems comparison.
- **Natural cycle:** [Electron](002-electron.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Tectonic Plate](057-tectonic-plate.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Fault at its characteristic scale, with the central visual emphasis on **strain and rupture** and **boundary and memory**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [The Science of Earthquakes](https://www.usgs.gov/programs/earthquake-hazards/science-earthquakes). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Plate Tectonics in a Nutshell](https://volcanoes.usgs.gov/about/edu/dynamicplanet/nutshell.php). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Earthquake timing on individual faults cannot be predicted precisely; subsurface geometry, friction, fluids, and interaction among faults remain uncertain.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Fault is retained because **Stored Difference** is not duplicated by Tectonic Plate, even where their processes overlap.
