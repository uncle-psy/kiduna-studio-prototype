---
card_number: 58
name: "Subduction Zone"
slug: "subduction-zone"
scale_band: "7. Geologic and continental"
scientific_domains: ["geodynamics","volcanology"]
natural_processes: ["descent","recycling"]
system_functions: ["dissolver","transformer"]
spatial_scale: "hundreds to thousands of kilometres long"
time_scale: "millions of years with sudden earthquakes"
core_archetype: "Deep Return"
primary_gifts: ["recycling","renewal","deep transformation"]
primary_wounds: ["megathrust rupture","buried conflict","destructive return"]
related_cards: ["decomposition", "watershed", "planet", "star", "mitochondrion", "archaeon", "oxygen", "tectonic-plate"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "process"
status: complete
---

# Subduction Zone

## Essence

What descends is transformed and may reappear far from where it entered.

## Keywords

descent · recycling · dissolver · transformer · renewal · deep transformation

## What it is

A subduction zone is a convergent plate boundary where one lithospheric plate descends beneath another into the mantle. It creates trenches, earthquakes, volcanism, deformation, and material cycling. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** hundreds to thousands of kilometres long.
- **Characteristic time:** millions of years with sudden earthquakes.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Tectonic Plate](057-tectonic-plate.md).
- **Larger container:** A useful containing or consequence-level bridge is [Planet](064-planet.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

The slab bends and releases fluids, alters mantle melting, hosts earthquakes from shallow to great depth, and may drive mountain building and volcanic arcs. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Return to depth is not disappearance; transformed material and force re-enter the larger cycle.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Deep Return.** Subduction Zone deserves its own card because it makes **dissolver and transformer** legible through **descent and recycling** at the geologic and continental scale. It differs from [Earthquake](056-earthquake.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Recycling.** Return to depth is not disappearance; transformed material and force re-enter the larger cycle.
- **Renewal.** This capacity becomes available when renewal fits the timing, limits, and needs of the larger system.
- **Deep Transformation.** This capacity becomes available when deep transformation fits the timing, limits, and needs of the larger system.

## Wounds

- **Megathrust Rupture.** The pattern distorts when megathrust rupture replaces responsive relationship.
- **Buried Conflict.** Buried Conflict appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Destructive Return.** Destructive Return appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **recycling** becomes **megathrust rupture** when scale, timing, boundary, or reciprocity is ignored. Subduction Zone asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

recycling remains connected to renewal while limits are respected; megathrust rupture is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **megathrust rupture, buried conflict, destructive return**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **recycling, renewal, deep transformation** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Tectonic Plate](057-tectonic-plate.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to descent and recycling as they actually operate in Subduction Zone; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Planet](064-planet.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Subduction Zone.
- **Deep time:** Consider millions of years with sudden earthquakes. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with deep return: examine both recycling and megathrust rupture. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support renewal or produce buried conflict. |
| Creativity | Work with the card's actual process—descent and recycling—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **recycling** already present, even in a small or quiet form?
2. Where might **megathrust rupture** be shaping the situation?
3. Where do you observe **descent**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Deep Return** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Subduction Zone**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Return to depth is not disappearance; transformed material and force re-enter the larger cycle.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **recycling** while reducing **megathrust rupture**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Megathrust behavior, slow slip, fluid pathways, earthquake segmentation, and long-term slab–mantle interaction remain uncertain.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Subduction Zone. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Deep Return** as the original synthesis for Subduction Zone: Return to depth is not disappearance; transformed material and force re-enter the larger cycle. This meaning arises from the sourced description of descent and recycling, then becomes a reflective lens through the gift of **recycling** and the wound of **megathrust rupture**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Decomposition](039-decomposition.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Watershed](046-watershed.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Tectonic Plate](057-tectonic-plate.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Planet](064-planet.md) helps identify containing systems and downstream effects.
- **Shared process:** [Decomposition](039-decomposition.md) also expresses recycling, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Planet](064-planet.md) offers a nearby systems comparison.
- **Natural cycle:** [Oxygen](012-oxygen.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Earthquake](056-earthquake.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Subduction Zone at its characteristic scale, with the central visual emphasis on **descent and recycling** and **dissolver and transformer**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [Plate Tectonics in a Nutshell](https://volcanoes.usgs.gov/about/edu/dynamicplanet/nutshell.php). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Volcanoes: Principal Types and Processes](https://pubs.usgs.gov/gip/volc/text.html). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Megathrust behavior, slow slip, fluid pathways, earthquake segmentation, and long-term slab–mantle interaction remain uncertain.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Subduction Zone is retained because **Deep Return** is not duplicated by Earthquake, even where their processes overlap.
