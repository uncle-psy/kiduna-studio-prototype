---
card_number: 75
name: "Supernova"
slug: "supernova"
scale_band: "9. Stellar and cosmic"
scientific_domains: ["astrophysics","nuclear astrophysics"]
natural_processes: ["collapse","dispersion"]
system_functions: ["disruptor","recycler"]
spatial_scale: "stellar core to expanding remnant light-years wide"
time_scale: "seconds of explosion to millennia of remnant evolution"
core_archetype: "Explosive Distribution"
primary_gifts: ["release","distribution","new ingredients"]
primary_wounds: ["catastrophic disruption","shock","identity tied to final brilliance"]
related_cards: ["stellar-nursery", "planet", "neutron-star", "black-hole", "fungal-fruiting-body", "spore", "soil-community", "bacterium"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "process"
status: complete
---

# Supernova

## Essence

An ending can disperse forged material and reorganize a vast neighborhood.

## Keywords

collapse · dispersion · disruptor · recycler · release · distribution · new ingredients

## What it is

A supernova is a stellar explosion produced by core collapse in some massive stars or thermonuclear disruption in certain white-dwarf systems. Different mechanisms produce distinct observations and remnants. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** stellar core to expanding remnant light-years wide.
- **Characteristic time:** seconds of explosion to millennia of remnant evolution.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Star](073-star.md).
- **Larger container:** A useful containing or consequence-level bridge is [Galaxy](078-galaxy.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Energy and shock waves eject material, synthesize or disperse elements, accelerate particles, and may leave a neutron star or black hole. Remnants interact with interstellar gas for millennia. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

The final release may become material and pressure for systems not yet formed.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Explosive Distribution.** Supernova deserves its own card because it makes **disruptor and recycler** legible through **collapse and dispersion** at the stellar and cosmic scale. It differs from [Expanding Universe](081-expanding-universe.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Release.** The final release may become material and pressure for systems not yet formed.
- **Distribution.** This capacity becomes available when distribution fits the timing, limits, and needs of the larger system.
- **New Ingredients.** This capacity becomes available when new ingredients fits the timing, limits, and needs of the larger system.

## Wounds

- **Catastrophic Disruption.** The pattern distorts when catastrophic disruption replaces responsive relationship.
- **Shock.** Shock appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Identity Tied To Final Brilliance.** Identity Tied To Final Brilliance appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **release** becomes **catastrophic disruption** when scale, timing, boundary, or reciprocity is ignored. Supernova asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

release remains connected to distribution while limits are respected; catastrophic disruption is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **catastrophic disruption, shock, identity tied to final brilliance**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **release, distribution, new ingredients** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Star](073-star.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to collapse and dispersion as they actually operate in Supernova; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Galaxy](078-galaxy.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Supernova.
- **Deep time:** Consider seconds of explosion to millennia of remnant evolution. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with explosive distribution: examine both release and catastrophic disruption. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support distribution or produce shock. |
| Creativity | Work with the card's actual process—collapse and dispersion—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **release** already present, even in a small or quiet form?
2. Where might **catastrophic disruption** be shaping the situation?
3. Where do you observe **collapse**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Explosive Distribution** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Supernova**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **The final release may become material and pressure for systems not yet formed.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **release** while reducing **catastrophic disruption**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Explosion mechanisms, progenitors for some classes, asymmetry, element yields, and outcomes of failed explosions remain research frontiers.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Supernova. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Explosive Distribution** as the original synthesis for Supernova: The final release may become material and pressure for systems not yet formed. This meaning arises from the sourced description of collapse and dispersion, then becomes a reflective lens through the gift of **release** and the wound of **catastrophic disruption**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Spore](025-spore.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Stellar Nursery](074-stellar-nursery.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Star](073-star.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Galaxy](078-galaxy.md) helps identify containing systems and downstream effects.
- **Shared process:** [Spore](025-spore.md) also expresses dispersion, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Neutron Star](076-neutron-star.md) offers a nearby systems comparison.
- **Natural cycle:** [Bacterium](022-bacterium.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Expanding Universe](081-expanding-universe.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Supernova at its characteristic scale, with the central visual emphasis on **collapse and dispersion** and **disruptor and recycler**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Universe Glossary](https://science.nasa.gov/universe/glossary/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Stars](https://science.nasa.gov/universe/stars/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Explosion mechanisms, progenitors for some classes, asymmetry, element yields, and outcomes of failed explosions remain research frontiers.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Supernova is retained because **Explosive Distribution** is not duplicated by Expanding Universe, even where their processes overlap.
