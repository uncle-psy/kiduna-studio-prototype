---
card_number: 16
name: "Plasma"
slug: "plasma"
scale_band: "2. Atomic and molecular"
scientific_domains: ["plasma physics","astrophysics"]
natural_processes: ["ionization","flow"]
system_functions: ["field","carrier"]
spatial_scale: "microscopic discharges to stellar interiors"
time_scale: "nanoseconds to stellar lifetimes"
core_archetype: "Collective Charge"
primary_gifts: ["collective response","conductivity","radiance"]
primary_wounds: ["instability","discharge","loss of containment"]
related_cards: ["kelp", "photon", "cell-membrane", "river", "glacier", "higgs-field", "gravity", "plankton"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Plasma

## Essence

When enough parts become mobile, the system behaves as a field.

## Keywords

ionization · flow · field · carrier · collective response · conductivity · radiance

## What it is

Plasma is an ionized state of matter containing mobile charged particles. Although often nearly electrically neutral overall, it responds collectively to electric and magnetic fields. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** microscopic discharges to stellar interiors.
- **Characteristic time:** nanoseconds to stellar lifetimes.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Electron](002-electron.md).
- **Larger container:** A useful containing or consequence-level bridge is [Star](073-star.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Plasmas conduct current, support waves, form filaments and sheaths, and can become turbulent. They occur in lightning, auroras, laboratory discharges, the solar wind, and stars. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A threshold of mobility turns isolated reactions into collective behavior.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Collective Charge.** Plasma deserves its own card because it makes **field and carrier** legible through **ionization and flow** at the atomic and molecular scale. It differs from [Hydrogen](010-hydrogen.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Collective Response.** A threshold of mobility turns isolated reactions into collective behavior.
- **Conductivity.** This capacity becomes available when conductivity fits the timing, limits, and needs of the larger system.
- **Radiance.** This capacity becomes available when radiance fits the timing, limits, and needs of the larger system.

## Wounds

- **Instability.** The pattern distorts when instability replaces responsive relationship.
- **Discharge.** Discharge appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Loss Of Containment.** Loss Of Containment appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **collective response** becomes **instability** when scale, timing, boundary, or reciprocity is ignored. Plasma asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

collective response remains connected to conductivity while limits are respected; instability is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **instability, discharge, loss of containment**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **collective response, conductivity, radiance** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Electron](002-electron.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to ionization and flow as they actually operate in Plasma; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Star](073-star.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Plasma.
- **Deep time:** Consider nanoseconds to stellar lifetimes. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with collective charge: examine both collective response and instability. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support conductivity or produce discharge. |
| Creativity | Work with the card's actual process—ionization and flow—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **collective response** already present, even in a small or quiet form?
2. Where might **instability** be shaping the situation?
3. Where do you observe **ionization**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Collective Charge** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Plasma**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A threshold of mobility turns isolated reactions into collective behavior.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **collective response** while reducing **instability**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Turbulence, magnetic reconnection, and multiscale energy transfer in plasmas remain difficult and active research problems.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Plasma. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Collective Charge** as the original synthesis for Plasma: A threshold of mobility turns isolated reactions into collective behavior. This meaning arises from the sourced description of ionization and flow, then becomes a reflective lens through the gift of **collective response** and the wound of **instability**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Cosmic Web](080-cosmic-web.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Cell Membrane](019-cell-membrane.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Electron](002-electron.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Star](073-star.md) helps identify containing systems and downstream effects.
- **Shared process:** [Kelp](032-kelp.md) also expresses flow, but with different constraints.
- **Shared wound:** [Star](073-star.md) also carries the wound **instability**.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Hydrogen](010-hydrogen.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Plasma at its characteristic scale, with the central visual emphasis on **ionization and flow** and **field and carrier**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Earth's Magnetosphere](https://science.nasa.gov/heliophysics/focus-areas/magnetosphere-ionosphere/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Stars](https://science.nasa.gov/universe/stars/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Turbulence, magnetic reconnection, and multiscale energy transfer in plasmas remain difficult and active research problems.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Plasma is retained because **Collective Charge** is not duplicated by Hydrogen, even where their processes overlap.
