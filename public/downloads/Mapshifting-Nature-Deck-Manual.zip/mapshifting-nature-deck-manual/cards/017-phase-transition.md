---
card_number: 17
name: "Phase Transition"
slug: "phase-transition"
scale_band: "2. Atomic and molecular"
scientific_domains: ["thermodynamics","materials science"]
natural_processes: ["threshold crossing","transformation"]
system_functions: ["threshold","transformer"]
spatial_scale: "molecular ensembles to planetary materials"
time_scale: "abrupt instants to slow geologic transitions"
core_archetype: "Threshold"
primary_gifts: ["transformation","timely change","new organization"]
primary_wounds: ["premature forcing","hysteresis","unstable transition"]
related_cards: ["quark", "cell-membrane", "mitochondrion", "archaeon", "oxygen", "catalysis", "fungal-fruiting-body", "wetland"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "process"
status: complete
---

# Phase Transition

## Essence

Accumulation can produce a new kind of order rather than more of the old.

## Keywords

threshold crossing · transformation · threshold · transformer · timely change · new organization

## What it is

A phase transition is a change in a system's collective state, such as melting, boiling, crystallization, magnetic ordering, or ionization. Control variables include temperature, pressure, composition, and fields. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** molecular ensembles to planetary materials.
- **Characteristic time:** abrupt instants to slow geologic transitions.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Photon](001-photon.md).
- **Larger container:** A useful containing or consequence-level bridge is [Cell Membrane](019-cell-membrane.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Near a transition, small changes can reorganize many components. Some transitions are discontinuous and release latent heat; others develop continuously with growing correlations and fluctuations. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Beyond a threshold, the relevant question changes from quantity to kind.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Threshold.** Phase Transition deserves its own card because it makes **threshold and transformer** legible through **threshold crossing and transformation** at the atomic and molecular scale. It differs from [Catalysis](018-catalysis.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Transformation.** Beyond a threshold, the relevant question changes from quantity to kind.
- **Timely Change.** This capacity becomes available when timely change fits the timing, limits, and needs of the larger system.
- **New Organization.** This capacity becomes available when new organization fits the timing, limits, and needs of the larger system.

## Wounds

- **Premature Forcing.** The pattern distorts when premature forcing replaces responsive relationship.
- **Hysteresis.** Hysteresis appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Unstable Transition.** Unstable Transition appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **transformation** becomes **premature forcing** when scale, timing, boundary, or reciprocity is ignored. Phase Transition asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

transformation remains connected to timely change while limits are respected; premature forcing is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **premature forcing, hysteresis, unstable transition**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **transformation, timely change, new organization** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Photon](001-photon.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to threshold crossing and transformation as they actually operate in Phase Transition; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Cell Membrane](019-cell-membrane.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Phase Transition.
- **Deep time:** Consider abrupt instants to slow geologic transitions. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with threshold: examine both transformation and premature forcing. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support timely change or produce hysteresis. |
| Creativity | Work with the card's actual process—threshold crossing and transformation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **transformation** already present, even in a small or quiet form?
2. Where might **premature forcing** be shaping the situation?
3. Where do you observe **threshold crossing**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Threshold** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Phase Transition**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Beyond a threshold, the relevant question changes from quantity to kind.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **transformation** while reducing **premature forcing**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Nucleation, glass transitions, nonequilibrium phases, and critical behavior in complex systems remain major research areas.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Phase Transition. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Threshold** as the original synthesis for Phase Transition: Beyond a threshold, the relevant question changes from quantity to kind. This meaning arises from the sourced description of threshold crossing and transformation, then becomes a reflective lens through the gift of **transformation** and the wound of **premature forcing**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Quark](006-quark.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Quark](006-quark.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Photon](001-photon.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Cell Membrane](019-cell-membrane.md) helps identify containing systems and downstream effects.
- **Shared process:** [Quark](006-quark.md) also expresses transformation, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Mitochondrion](021-mitochondrion.md) offers a nearby systems comparison.
- **Natural cycle:** [Mitochondrion](021-mitochondrion.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Catalysis](018-catalysis.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Phase Transition at its characteristic scale, with the central visual emphasis on **threshold crossing and transformation** and **threshold and transformer**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — International Union of Pure and Applied Chemistry.** [Compendium of Chemical Terminology (Gold Book)](https://goldbook.iupac.org/). Accessed 2026-08-23.
- **S02 — National Institute of Standards and Technology.** [NIST Chemistry WebBook](https://webbook.nist.gov/chemistry/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Nucleation, glass transitions, nonequilibrium phases, and critical behavior in complex systems remain major research areas.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Phase Transition is retained because **Threshold** is not duplicated by Catalysis, even where their processes overlap.
