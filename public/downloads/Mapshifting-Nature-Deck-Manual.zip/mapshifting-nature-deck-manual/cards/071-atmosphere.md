---
card_number: 71
name: "Atmosphere"
slug: "atmosphere"
scale_band: "8. Planetary and orbital"
scientific_domains: ["atmospheric science","planetary science"]
natural_processes: ["circulation","exchange"]
system_functions: ["container","filter"]
spatial_scale: "surface boundary layer to planetary exosphere"
time_scale: "seconds of turbulence to billion-year evolution"
core_archetype: "Breathing Envelope"
primary_gifts: ["protection","circulation","climate regulation"]
primary_wounds: ["pollution accumulation","runaway feedback","boundary loss"]
related_cards: ["mantle-convection", "galaxy", "cell-membrane", "planet", "tide", "stellar-nursery", "galaxy-cluster", "ocean-current"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Atmosphere

## Essence

A containing layer sustains conditions by constantly moving and exchanging.

## Keywords

circulation · exchange · container · filter · protection · climate regulation

## What it is

An atmosphere is a gravitationally bound envelope of gas and suspended particles around a world. Composition and structure depend on gravity, temperature, geology, biology, radiation, and escape. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** surface boundary layer to planetary exosphere.
- **Characteristic time:** seconds of turbulence to billion-year evolution.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Water Molecule](013-water-molecule.md).
- **Larger container:** A useful containing or consequence-level bridge is [Planet](064-planet.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Atmospheres absorb and emit radiation, circulate heat and moisture, weather rocks, exchange with surfaces and space, and can be gained, transformed, or lost. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Containment is a dynamic balance of retention, circulation, filtering, and escape.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Breathing Envelope.** Atmosphere deserves its own card because it makes **container and filter** legible through **circulation and exchange** at the planetary and orbital scale. It differs from [Orbit](066-orbit.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Protection.** Containment is a dynamic balance of retention, circulation, filtering, and escape.
- **Circulation.** This capacity becomes available when circulation fits the timing, limits, and needs of the larger system.
- **Climate Regulation.** This capacity becomes available when climate regulation fits the timing, limits, and needs of the larger system.

## Wounds

- **Pollution Accumulation.** The pattern distorts when pollution accumulation replaces responsive relationship.
- **Runaway Feedback.** Runaway Feedback appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Boundary Loss.** Boundary Loss appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **protection** becomes **pollution accumulation** when scale, timing, boundary, or reciprocity is ignored. Atmosphere asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

protection remains connected to circulation while limits are respected; pollution accumulation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **pollution accumulation, runaway feedback, boundary loss**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **protection, circulation, climate regulation** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Water Molecule](013-water-molecule.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to circulation and exchange as they actually operate in Atmosphere; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Planet](064-planet.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Atmosphere.
- **Deep time:** Consider seconds of turbulence to billion-year evolution. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with breathing envelope: examine both protection and pollution accumulation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support circulation or produce runaway feedback. |
| Creativity | Work with the card's actual process—circulation and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **protection** already present, even in a small or quiet form?
2. Where might **pollution accumulation** be shaping the situation?
3. Where do you observe **circulation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Breathing Envelope** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Atmosphere**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Containment is a dynamic balance of retention, circulation, filtering, and escape.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **protection** while reducing **pollution accumulation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Cloud feedbacks, circulation extremes, atmospheric escape, exoplanet composition, and coupled climate thresholds remain uncertain.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Atmosphere. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Breathing Envelope** as the original synthesis for Atmosphere: Containment is a dynamic balance of retention, circulation, filtering, and escape. This meaning arises from the sourced description of circulation and exchange, then becomes a reflective lens through the gift of **protection** and the wound of **pollution accumulation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Electron](002-electron.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Mantle Convection](060-mantle-convection.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Water Molecule](013-water-molecule.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Planet](064-planet.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Cell Membrane](019-cell-membrane.md) offers a nearby systems comparison.
- **Natural cycle:** [Cell Membrane](019-cell-membrane.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Orbit](066-orbit.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Atmosphere at its characteristic scale, with the central visual emphasis on **circulation and exchange** and **container and filter**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Earth System Science Research](https://science.nasa.gov/earth-science/research/). Accessed 2026-08-23.
- **S02 — NASA Science.** [About the Planets](https://science.nasa.gov/solar-system/planets/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Cloud feedbacks, circulation extremes, atmospheric escape, exoplanet composition, and coupled climate thresholds remain uncertain.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Atmosphere is retained because **Breathing Envelope** is not duplicated by Orbit, even where their processes overlap.
