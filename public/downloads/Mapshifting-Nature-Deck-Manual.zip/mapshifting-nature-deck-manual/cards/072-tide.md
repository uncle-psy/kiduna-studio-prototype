---
card_number: 72
name: "Tide"
slug: "tide"
scale_band: "8. Planetary and orbital"
scientific_domains: ["oceanography","orbital dynamics"]
natural_processes: ["oscillation","exchange"]
system_functions: ["clock","carrier"]
spatial_scale: "local shore to global ocean and solid Earth"
time_scale: "hours to geological orbital evolution"
core_archetype: "Relational Pulse"
primary_gifts: ["rhythm","exchange","revealed interdependence"]
primary_wounds: ["inundation","rigid timing","ignoring local modulation"]
related_cards: ["mantle-convection", "fault", "star", "food-web", "electron", "estuary", "tectonic-plate", "plankton"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "process"
status: complete
---

# Tide

## Essence

A distant relationship can become a local rhythm through the shape of the container.

## Keywords

oscillation · exchange · clock · carrier · rhythm · revealed interdependence

## What it is

Tides are periodic deformations driven mainly by differences in the Moon's and Sun's gravitational pull across Earth, expressed in oceans, solid Earth, and atmosphere. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** local shore to global ocean and solid Earth.
- **Characteristic time:** hours to geological orbital evolution.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Gravity](009-gravity.md).
- **Larger container:** A useful containing or consequence-level bridge is [Moon](065-moon.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Earth's rotation, orbital geometry, coastlines, depth, resonance, weather, and friction turn astronomical forcing into locally varied timing and height while exchanging angular momentum. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A common force becomes a different lived rhythm in every basin and boundary.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Relational Pulse.** Tide deserves its own card because it makes **clock and carrier** legible through **oscillation and exchange** at the planetary and orbital scale. It differs from [Eclipse](067-eclipse.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Rhythm.** A common force becomes a different lived rhythm in every basin and boundary.
- **Exchange.** This capacity becomes available when exchange fits the timing, limits, and needs of the larger system.
- **Revealed Interdependence.** This capacity becomes available when revealed interdependence fits the timing, limits, and needs of the larger system.

## Wounds

- **Inundation.** The pattern distorts when inundation replaces responsive relationship.
- **Rigid Timing.** Rigid Timing appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Ignoring Local Modulation.** Ignoring Local Modulation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **rhythm** becomes **inundation** when scale, timing, boundary, or reciprocity is ignored. Tide asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

rhythm remains connected to exchange while limits are respected; inundation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **inundation, rigid timing, ignoring local modulation**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **rhythm, exchange, revealed interdependence** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Gravity](009-gravity.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to oscillation and exchange as they actually operate in Tide; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Moon](065-moon.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Tide.
- **Deep time:** Consider hours to geological orbital evolution. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with relational pulse: examine both rhythm and inundation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support exchange or produce rigid timing. |
| Creativity | Work with the card's actual process—oscillation and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **rhythm** already present, even in a small or quiet form?
2. Where might **inundation** be shaping the situation?
3. Where do you observe **oscillation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Relational Pulse** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Tide**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A common force becomes a different lived rhythm in every basin and boundary.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **rhythm** while reducing **inundation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Local tide prediction is strong with observations, while long-term coastal extremes combine uncertain sea level, storms, morphology, and changing resonance.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Tide. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Relational Pulse** as the original synthesis for Tide: A common force becomes a different lived rhythm in every basin and boundary. This meaning arises from the sourced description of oscillation and exchange, then becomes a reflective lens through the gift of **rhythm** and the wound of **inundation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Electron](002-electron.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Fault](055-fault.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Gravity](009-gravity.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Moon](065-moon.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Star](073-star.md) offers a nearby systems comparison.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Eclipse](067-eclipse.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Tide at its characteristic scale, with the central visual emphasis on **oscillation and exchange** and **clock and carrier**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NOAA National Ocean Service.** [What are tides?](https://oceanservice.noaa.gov/facts/tides.html). Accessed 2026-08-23.
- **S02 — NASA Science.** [Earth's Moon](https://science.nasa.gov/moon/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Local tide prediction is strong with observations, while long-term coastal extremes combine uncertain sea level, storms, morphology, and changing resonance.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Tide is retained because **Relational Pulse** is not duplicated by Eclipse, even where their processes overlap.
