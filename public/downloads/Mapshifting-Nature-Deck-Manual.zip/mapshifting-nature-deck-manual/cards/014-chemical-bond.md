---
card_number: 14
name: "Chemical Bond"
slug: "chemical-bond"
scale_band: "2. Atomic and molecular"
scientific_domains: ["chemistry","materials science"]
natural_processes: ["binding","exchange"]
system_functions: ["bridge","builder"]
spatial_scale: "sub-nanometre"
time_scale: "femtoseconds to geological persistence"
core_archetype: "Commitment"
primary_gifts: ["connection","stability","shared structure"]
primary_wounds: ["rigidity","energetic entrapment","bonding without fit"]
related_cards: ["gluon", "electron", "cell-membrane", "carbon", "proton", "hydrogen", "oxygen", "water-molecule"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Chemical Bond

## Essence

Stable relation is a redistribution of energy and possibility.

## Keywords

binding · exchange · bridge · builder · connection · stability · shared structure

## What it is

A chemical bond is a persistent attractive interaction among atoms or ions associated with a lower-energy arrangement. Covalent, ionic, metallic, and intermolecular descriptions emphasize different electron distributions and collective behavior. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** sub-nanometre.
- **Characteristic time:** femtoseconds to geological persistence.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Electron](002-electron.md).
- **Larger container:** A useful containing or consequence-level bridge is [DNA](020-dna.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Bonds form and break through energy exchange and electron rearrangement. Bond strength is contextual: solvent, temperature, pressure, geometry, and neighboring atoms change stability and reactivity. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Connection is an energetic arrangement, not a moral promise; conditions determine whether it should persist.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Commitment.** Chemical Bond deserves its own card because it makes **bridge and builder** legible through **binding and exchange** at the atomic and molecular scale. It differs from [Crystal Lattice](015-crystal-lattice.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Connection.** Connection is an energetic arrangement, not a moral promise; conditions determine whether it should persist.
- **Stability.** This capacity becomes available when stability fits the timing, limits, and needs of the larger system.
- **Shared Structure.** This capacity becomes available when shared structure fits the timing, limits, and needs of the larger system.

## Wounds

- **Rigidity.** The pattern distorts when rigidity replaces responsive relationship.
- **Energetic Entrapment.** Energetic Entrapment appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Bonding Without Fit.** Bonding Without Fit appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **connection** becomes **rigidity** when scale, timing, boundary, or reciprocity is ignored. Chemical Bond asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

connection remains connected to stability while limits are respected; rigidity is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **rigidity, energetic entrapment, bonding without fit**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **connection, stability, shared structure** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Electron](002-electron.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to binding and exchange as they actually operate in Chemical Bond; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [DNA](020-dna.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Chemical Bond.
- **Deep time:** Consider femtoseconds to geological persistence. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with commitment: examine both connection and rigidity. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support stability or produce energetic entrapment. |
| Creativity | Work with the card's actual process—binding and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **connection** already present, even in a small or quiet form?
2. Where might **rigidity** be shaping the situation?
3. Where do you observe **binding**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Commitment** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Chemical Bond**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Connection is an energetic arrangement, not a moral promise; conditions determine whether it should persist.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **connection** while reducing **rigidity**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Bond categories are models with fuzzy boundaries, and accurate bonding descriptions in complex materials often require advanced quantum calculation.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Chemical Bond. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Commitment** as the original synthesis for Chemical Bond: Connection is an energetic arrangement, not a moral promise; conditions determine whether it should persist. This meaning arises from the sourced description of binding and exchange, then becomes a reflective lens through the gift of **connection** and the wound of **rigidity**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Electron](002-electron.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Gluon](007-gluon.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Electron](002-electron.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [DNA](020-dna.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** [Crystal Lattice](015-crystal-lattice.md) also carries the wound **rigidity**.
- **Natural cycle:** [Proton](003-proton.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Crystal Lattice](015-crystal-lattice.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Chemical Bond at its characteristic scale, with the central visual emphasis on **binding and exchange** and **bridge and builder**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — International Union of Pure and Applied Chemistry.** [Compendium of Chemical Terminology (Gold Book)](https://goldbook.iupac.org/). Accessed 2026-08-23.
- **S02 — National Institute of Standards and Technology.** [NIST Chemistry WebBook](https://webbook.nist.gov/chemistry/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Bond categories are models with fuzzy boundaries, and accurate bonding descriptions in complex materials often require advanced quantum calculation.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Chemical Bond is retained because **Commitment** is not duplicated by Crystal Lattice, even where their processes overlap.
