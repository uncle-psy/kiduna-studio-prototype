---
card_number: 79
name: "Galaxy Cluster"
slug: "galaxy-cluster"
scale_band: "9. Stellar and cosmic"
scientific_domains: ["astrophysics","cosmology"]
natural_processes: ["aggregation","interaction"]
system_functions: ["container","lens"]
spatial_scale: "millions of light-years"
time_scale: "billions of years"
core_archetype: "Massive Assembly"
primary_gifts: ["coordination","amplification","revealed structure"]
primary_wounds: ["crowding","stripping","gravity well"]
related_cards: ["planet", "stellar-nursery", "atmosphere", "tectonic-plate", "galaxy", "higgs-field", "star", "supernova"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Galaxy Cluster

## Essence

A larger container changes trajectories and makes hidden mass legible.

## Keywords

aggregation · interaction · container · lens · coordination · amplification · revealed structure

## What it is

A galaxy cluster is a gravitationally bound assembly of hundreds to thousands of galaxies, hot intracluster plasma, and much more mass in dark matter than in visible stars. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** millions of light-years.
- **Characteristic time:** billions of years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Galaxy](078-galaxy.md).
- **Larger container:** A useful containing or consequence-level bridge is [Cosmic Web](080-cosmic-web.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Galaxies orbit, interact, merge, and lose gas; cluster mergers shock and stir plasma. Cluster gravity bends background light, enabling mass mapping through gravitational lensing. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A containing field can reveal invisible structure by how it redirects what passes behind it.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Massive Assembly.** Galaxy Cluster deserves its own card because it makes **container and lens** legible through **aggregation and interaction** at the stellar and cosmic scale. It differs from [Stellar Nursery](074-stellar-nursery.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Coordination.** A containing field can reveal invisible structure by how it redirects what passes behind it.
- **Amplification.** This capacity becomes available when amplification fits the timing, limits, and needs of the larger system.
- **Revealed Structure.** This capacity becomes available when revealed structure fits the timing, limits, and needs of the larger system.

## Wounds

- **Crowding.** The pattern distorts when crowding replaces responsive relationship.
- **Stripping.** Stripping appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Gravity Well.** Gravity Well appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **coordination** becomes **crowding** when scale, timing, boundary, or reciprocity is ignored. Galaxy Cluster asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

coordination remains connected to amplification while limits are respected; crowding is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **crowding, stripping, gravity well**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **coordination, amplification, revealed structure** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Galaxy](078-galaxy.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to aggregation and interaction as they actually operate in Galaxy Cluster; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Cosmic Web](080-cosmic-web.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Galaxy Cluster.
- **Deep time:** Consider billions of years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with massive assembly: examine both coordination and crowding. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support amplification or produce stripping. |
| Creativity | Work with the card's actual process—aggregation and interaction—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **coordination** already present, even in a small or quiet form?
2. Where might **crowding** be shaping the situation?
3. Where do you observe **aggregation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Massive Assembly** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Galaxy Cluster**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A containing field can reveal invisible structure by how it redirects what passes behind it.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **coordination** while reducing **crowding**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Cluster mass calibration, plasma microphysics, merger history, dark-matter properties, and feedback remain research areas.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Galaxy Cluster. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Massive Assembly** as the original synthesis for Galaxy Cluster: A containing field can reveal invisible structure by how it redirects what passes behind it. This meaning arises from the sourced description of aggregation and interaction, then becomes a reflective lens through the gift of **coordination** and the wound of **crowding**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Tectonic Plate](057-tectonic-plate.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Planet](064-planet.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Galaxy](078-galaxy.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Cosmic Web](080-cosmic-web.md) helps identify containing systems and downstream effects.
- **Shared process:** [Higgs Field](008-higgs-field.md) also expresses interaction, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Atmosphere](071-atmosphere.md) offers a nearby systems comparison.
- **Natural cycle:** [Watershed](046-watershed.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Stellar Nursery](074-stellar-nursery.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Galaxy Cluster at its characteristic scale, with the central visual emphasis on **aggregation and interaction** and **container and lens**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Galaxies](https://science.nasa.gov/universe/galaxies/). Accessed 2026-08-23.
- **S02 — NASA Science.** [What Is the Universe?](https://science.nasa.gov/exoplanets/what-is-the-universe/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Cluster mass calibration, plasma microphysics, merger history, dark-matter properties, and feedback remain research areas.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Galaxy Cluster is retained because **Massive Assembly** is not duplicated by Stellar Nursery, even where their processes overlap.
