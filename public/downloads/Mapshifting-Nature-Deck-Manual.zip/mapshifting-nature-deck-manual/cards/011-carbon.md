---
card_number: 11
name: "Carbon"
slug: "carbon"
scale_band: "2. Atomic and molecular"
scientific_domains: ["chemistry","biogeochemistry"]
natural_processes: ["binding","cycling"]
system_functions: ["builder","network"]
spatial_scale: "atomic bonds to planetary cycles"
time_scale: "rapid metabolism to multimillion-year storage"
core_archetype: "Versatile Builder"
primary_gifts: ["versatility","complexity","structural imagination"]
primary_wounds: ["overaccumulation","locked storage","complexity without function"]
related_cards: ["chemical-bond", "proton", "cell-membrane", "coral-colony", "kelp-forest", "hydrogen", "water-molecule", "neutron"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Carbon

## Essence

Range comes from forming many stable relationships, not from standing apart.

## Keywords

binding · cycling · builder · network · versatility · complexity · structural imagination

## What it is

Carbon is element 6. Its four valence electrons support diverse covalent bonds, chains, rings, networks, and multiple allotropes, making it central to known biochemistry and many minerals. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** atomic bonds to planetary cycles.
- **Characteristic time:** rapid metabolism to multimillion-year storage.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Quark](006-quark.md).
- **Larger container:** A useful containing or consequence-level bridge is [DNA](020-dna.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Carbon moves among atmosphere, oceans, rocks, soils, and organisms. It can be rapidly exchanged biologically or stored for geologic time in carbonates and organic deposits. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Versatility grows from a capacity to bond in several directions while retaining structure.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Versatile Builder.** Carbon deserves its own card because it makes **builder and network** legible through **binding and cycling** at the atomic and molecular scale. It differs from [Hydrogen](010-hydrogen.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Versatility.** Versatility grows from a capacity to bond in several directions while retaining structure.
- **Complexity.** This capacity becomes available when complexity fits the timing, limits, and needs of the larger system.
- **Structural Imagination.** This capacity becomes available when structural imagination fits the timing, limits, and needs of the larger system.

## Wounds

- **Overaccumulation.** The pattern distorts when overaccumulation replaces responsive relationship.
- **Locked Storage.** Locked Storage appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Complexity Without Function.** Complexity Without Function appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **versatility** becomes **overaccumulation** when scale, timing, boundary, or reciprocity is ignored. Carbon asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

versatility remains connected to complexity while limits are respected; overaccumulation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **overaccumulation, locked storage, complexity without function**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **versatility, complexity, structural imagination** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Quark](006-quark.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to binding and cycling as they actually operate in Carbon; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [DNA](020-dna.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Carbon.
- **Deep time:** Consider rapid metabolism to multimillion-year storage. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with versatile builder: examine both versatility and overaccumulation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support complexity or produce locked storage. |
| Creativity | Work with the card's actual process—binding and cycling—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **versatility** already present, even in a small or quiet form?
2. Where might **overaccumulation** be shaping the situation?
3. Where do you observe **binding**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Versatile Builder** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Carbon**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Versatility grows from a capacity to bond in several directions while retaining structure.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **versatility** while reducing **overaccumulation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

The details of the global carbon cycle, feedbacks, and carbon behavior under extreme planetary conditions remain active research.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Carbon. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Versatile Builder** as the original synthesis for Carbon: Versatility grows from a capacity to bond in several directions while retaining structure. This meaning arises from the sourced description of binding and cycling, then becomes a reflective lens through the gift of **versatility** and the wound of **overaccumulation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Chemical Bond](014-chemical-bond.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Chemical Bond](014-chemical-bond.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Quark](006-quark.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [DNA](020-dna.md) helps identify containing systems and downstream effects.
- **Shared process:** [Proton](003-proton.md) also expresses binding, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Cell Membrane](019-cell-membrane.md) offers a nearby systems comparison.
- **Natural cycle:** [Proton](003-proton.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Hydrogen](010-hydrogen.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Carbon at its characteristic scale, with the central visual emphasis on **binding and cycling** and **builder and network**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — National Institute of Standards and Technology.** [Periodic Table of the Elements](https://www.nist.gov/pml/periodic-table-elements). Accessed 2026-08-23.
- **S02 — NASA Science.** [Earth System Science Research](https://science.nasa.gov/earth-science/research/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** The details of the global carbon cycle, feedbacks, and carbon behavior under extreme planetary conditions remain active research.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Carbon is retained because **Versatile Builder** is not duplicated by Hydrogen, even where their processes overlap.
