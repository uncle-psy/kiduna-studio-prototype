---
card_number: 19
name: "Cell Membrane"
slug: "cell-membrane"
scale_band: "3. Microscopic and cellular"
scientific_domains: ["cell biology","biophysics"]
natural_processes: ["exchange","regulation"]
system_functions: ["boundary","filter"]
spatial_scale: "about 5–10 nanometres thick"
time_scale: "microseconds to a cell lifetime"
core_archetype: "Selective Boundary"
primary_gifts: ["discernment","protection","regulated exchange"]
primary_wounds: ["isolation","leakage","indiscriminate permeability"]
related_cards: ["forest-canopy", "oxygen", "root", "electron", "mitochondrion", "atmosphere", "chemical-bond", "pollinator"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Cell Membrane

## Essence

Life depends on a boundary that exchanges rather than merely excludes.

## Keywords

exchange · regulation · boundary · filter · discernment · protection · regulated exchange

## What it is

A cell membrane is a dynamic lipid bilayer containing proteins, carbohydrates, and other molecules. It separates cellular compartments while enabling controlled transport, signaling, adhesion, and energy conversion. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** about 5–10 nanometres thick.
- **Characteristic time:** microseconds to a cell lifetime.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Water Molecule](013-water-molecule.md).
- **Larger container:** A useful containing or consequence-level bridge is [Root](029-root.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Lipids and proteins diffuse, assemble, bend, and reorganize. Channels, pumps, receptors, and transporters make the membrane selectively permeable rather than simply sealed. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A living boundary maintains difference through active, selective relationship.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Selective Boundary.** Cell Membrane deserves its own card because it makes **boundary and filter** legible through **exchange and regulation** at the microscopic and cellular scale. It differs from [Plankton](026-plankton.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Discernment.** A living boundary maintains difference through active, selective relationship.
- **Protection.** This capacity becomes available when protection fits the timing, limits, and needs of the larger system.
- **Regulated Exchange.** This capacity becomes available when regulated exchange fits the timing, limits, and needs of the larger system.

## Wounds

- **Isolation.** The pattern distorts when isolation replaces responsive relationship.
- **Leakage.** Leakage appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Indiscriminate Permeability.** Indiscriminate Permeability appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **discernment** becomes **isolation** when scale, timing, boundary, or reciprocity is ignored. Cell Membrane asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

discernment remains connected to protection while limits are respected; isolation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **isolation, leakage, indiscriminate permeability**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **discernment, protection, regulated exchange** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Water Molecule](013-water-molecule.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to exchange and regulation as they actually operate in Cell Membrane; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Root](029-root.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Cell Membrane.
- **Deep time:** Consider microseconds to a cell lifetime. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with selective boundary: examine both discernment and isolation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support protection or produce leakage. |
| Creativity | Work with the card's actual process—exchange and regulation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **discernment** already present, even in a small or quiet form?
2. Where might **isolation** be shaping the situation?
3. Where do you observe **exchange**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Selective Boundary** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Cell Membrane**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A living boundary maintains difference through active, selective relationship.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **discernment** while reducing **isolation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Membrane organization is highly heterogeneous and dynamic; many nanoscale domains and protein–lipid interactions remain difficult to observe directly.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Cell Membrane. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Selective Boundary** as the original synthesis for Cell Membrane: A living boundary maintains difference through active, selective relationship. This meaning arises from the sourced description of exchange and regulation, then becomes a reflective lens through the gift of **discernment** and the wound of **isolation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Electron](002-electron.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Oxygen](012-oxygen.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Water Molecule](013-water-molecule.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Root](029-root.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** [Mountain Range](054-mountain-range.md) also carries the wound **isolation**.
- **Natural cycle:** [Electron](002-electron.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Plankton](026-plankton.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Cell Membrane at its characteristic scale, with the central visual emphasis on **exchange and regulation** and **boundary and filter**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NCBI Bookshelf.** [Molecular Biology of the Cell](https://www.ncbi.nlm.nih.gov/books/NBK21054/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Earth System Science Research](https://science.nasa.gov/earth-science/research/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Membrane organization is highly heterogeneous and dynamic; many nanoscale domains and protein–lipid interactions remain difficult to observe directly.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Cell Membrane is retained because **Selective Boundary** is not duplicated by Plankton, even where their processes overlap.
