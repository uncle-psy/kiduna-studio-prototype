---
card_number: 34
name: "Fungal Fruiting Body"
slug: "fungal-fruiting-body"
scale_band: "4. Organism"
scientific_domains: ["mycology","ecology"]
natural_processes: ["emergence","dispersion"]
system_functions: ["messenger","threshold"]
spatial_scale: "millimetres to metres"
time_scale: "hours to weeks aboveground; longer mycelial life"
core_archetype: "Visible Emergence"
primary_gifts: ["timely emergence","reproduction","revelation"]
primary_wounds: ["surface fixation","missed timing","mistaking display for whole"]
related_cards: ["spore", "symbiosis", "pollinator", "wetland", "lichen", "plankton", "decomposition", "ecological-succession"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Fungal Fruiting Body

## Essence

The visible event may be only a brief expression of a larger hidden body.

## Keywords

emergence · dispersion · messenger · threshold · timely emergence · reproduction · revelation

## What it is

A fungal fruiting body is a reproductive structure made by a fungus, often arising from a much larger network of hyphae in soil, wood, hosts, or other substrates. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** millimetres to metres.
- **Characteristic time:** hours to weeks aboveground; longer mycelial life.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Spore](025-spore.md).
- **Larger container:** A useful containing or consequence-level bridge is [Decomposition](039-decomposition.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Environmental cues and stored resources trigger development; tissues expand, mature, release spores, and decay while the underlying mycelium may persist. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

What appears suddenly may be the culmination of long invisible preparation.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Visible Emergence.** Fungal Fruiting Body deserves its own card because it makes **messenger and threshold** legible through **emergence and dispersion** at the organism scale. It differs from [Seed](028-seed.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Timely Emergence.** What appears suddenly may be the culmination of long invisible preparation.
- **Reproduction.** This capacity becomes available when reproduction fits the timing, limits, and needs of the larger system.
- **Revelation.** This capacity becomes available when revelation fits the timing, limits, and needs of the larger system.

## Wounds

- **Surface Fixation.** The pattern distorts when surface fixation replaces responsive relationship.
- **Missed Timing.** Missed Timing appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Mistaking Display For Whole.** Mistaking Display For Whole appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **timely emergence** becomes **surface fixation** when scale, timing, boundary, or reciprocity is ignored. Fungal Fruiting Body asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

timely emergence remains connected to reproduction while limits are respected; surface fixation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **surface fixation, missed timing, mistaking display for whole**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **timely emergence, reproduction, revelation** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Spore](025-spore.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to emergence and dispersion as they actually operate in Fungal Fruiting Body; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Decomposition](039-decomposition.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Fungal Fruiting Body.
- **Deep time:** Consider hours to weeks aboveground; longer mycelial life. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with visible emergence: examine both timely emergence and surface fixation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support reproduction or produce missed timing. |
| Creativity | Work with the card's actual process—emergence and dispersion—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **timely emergence** already present, even in a small or quiet form?
2. Where might **surface fixation** be shaping the situation?
3. Where do you observe **emergence**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Visible Emergence** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Fungal Fruiting Body**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **What appears suddenly may be the culmination of long invisible preparation.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **timely emergence** while reducing **surface fixation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Fungal diversity is vastly undersampled, and fruiting triggers, underground network extent, and organism boundaries are often uncertain.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Fungal Fruiting Body. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Visible Emergence** as the original synthesis for Fungal Fruiting Body: What appears suddenly may be the culmination of long invisible preparation. This meaning arises from the sourced description of emergence and dispersion, then becomes a reflective lens through the gift of **timely emergence** and the wound of **surface fixation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Higgs Field](008-higgs-field.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Symbiosis](037-symbiosis.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Spore](025-spore.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Decomposition](039-decomposition.md) helps identify containing systems and downstream effects.
- **Shared process:** [Higgs Field](008-higgs-field.md) also expresses emergence, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Pollinator](035-pollinator.md) offers a nearby systems comparison.
- **Natural cycle:** [Neutrino](005-neutrino.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Seed](028-seed.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Fungal Fruiting Body at its characteristic scale, with the central visual emphasis on **emergence and dispersion** and **messenger and threshold**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — USDA Forest Service Research.** [Field guide to common macrofungi in eastern forests and their ecosystem functions](https://research.fs.usda.gov/treesearch/38089). Accessed 2026-08-23.
- **S02 — USDA Forest Service.** [Plant of the Week and Plant Biology Resources](https://www.fs.usda.gov/wildflowers/plant-of-the-week/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Fungal diversity is vastly undersampled, and fruiting triggers, underground network extent, and organism boundaries are often uncertain.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Fungal Fruiting Body is retained because **Visible Emergence** is not duplicated by Seed, even where their processes overlap.
