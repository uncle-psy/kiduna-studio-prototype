---
card_number: 15
name: "Crystal Lattice"
slug: "crystal-lattice"
scale_band: "2. Atomic and molecular"
scientific_domains: ["crystallography","materials science"]
natural_processes: ["crystallization","repetition"]
system_functions: ["pattern","builder"]
spatial_scale: "atomic spacing to macroscopic crystal"
time_scale: "rapid nucleation to billion-year persistence"
core_archetype: "Repeating Order"
primary_gifts: ["order","clarity","load-bearing pattern"]
primary_wounds: ["rigidity","defect intolerance","brittleness"]
related_cards: ["proton", "photon", "cell-membrane", "dna", "bacterium", "chemical-bond", "carbon", "kelp"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Crystal Lattice

## Essence

Clarity emerges when a local rule can repeat across distance.

## Keywords

crystallization · repetition · pattern · builder · order · clarity · load-bearing pattern

## What it is

A crystal lattice is an idealized periodic arrangement used to describe crystalline solids. Real crystals contain defects, boundaries, substitutions, and thermal motion that strongly influence their properties. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** atomic spacing to macroscopic crystal.
- **Characteristic time:** rapid nucleation to billion-year persistence.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Electron](002-electron.md).
- **Larger container:** A useful containing or consequence-level bridge is [Cell Membrane](019-cell-membrane.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Crystals nucleate and grow when conditions favor ordered phases. Repeating units transmit symmetry through a solid, while dislocations permit deformation and defects can create useful electrical, optical, or mechanical behavior. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Order becomes resilient when it can include imperfection rather than pretend it is absent.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Repeating Order.** Crystal Lattice deserves its own card because it makes **pattern and builder** legible through **crystallization and repetition** at the atomic and molecular scale. It differs from [Chemical Bond](014-chemical-bond.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Order.** Order becomes resilient when it can include imperfection rather than pretend it is absent.
- **Clarity.** This capacity becomes available when clarity fits the timing, limits, and needs of the larger system.
- **Load-Bearing Pattern.** This capacity becomes available when load-bearing pattern fits the timing, limits, and needs of the larger system.

## Wounds

- **Rigidity.** The pattern distorts when rigidity replaces responsive relationship.
- **Defect Intolerance.** Defect Intolerance appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Brittleness.** Brittleness appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **order** becomes **rigidity** when scale, timing, boundary, or reciprocity is ignored. Crystal Lattice asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

order remains connected to clarity while limits are respected; rigidity is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **rigidity, defect intolerance, brittleness**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **order, clarity, load-bearing pattern** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Electron](002-electron.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to crystallization and repetition as they actually operate in Crystal Lattice; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Cell Membrane](019-cell-membrane.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Crystal Lattice.
- **Deep time:** Consider rapid nucleation to billion-year persistence. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with repeating order: examine both order and rigidity. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support clarity or produce defect intolerance. |
| Creativity | Work with the card's actual process—crystallization and repetition—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **order** already present, even in a small or quiet form?
2. Where might **rigidity** be shaping the situation?
3. Where do you observe **crystallization**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Repeating Order** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Crystal Lattice**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Order becomes resilient when it can include imperfection rather than pretend it is absent.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **order** while reducing **rigidity**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Nucleation pathways and defect behavior can be difficult to predict, especially in complex, rapidly formed, or nanoscale materials.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Crystal Lattice. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Repeating Order** as the original synthesis for Crystal Lattice: Order becomes resilient when it can include imperfection rather than pretend it is absent. This meaning arises from the sourced description of crystallization and repetition, then becomes a reflective lens through the gift of **order** and the wound of **rigidity**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Proton](003-proton.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Proton](003-proton.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Electron](002-electron.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Cell Membrane](019-cell-membrane.md) helps identify containing systems and downstream effects.
- **Shared process:** No other core card uses the exact process labels **crystallization / repetition**; [Proton](003-proton.md) is retained as a contrast, not an equivalence.
- **Shared wound:** [Chemical Bond](014-chemical-bond.md) also carries the wound **rigidity**.
- **Natural cycle:** [Proton](003-proton.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Chemical Bond](014-chemical-bond.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Crystal Lattice at its characteristic scale, with the central visual emphasis on **crystallization and repetition** and **pattern and builder**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — International Union of Pure and Applied Chemistry.** [Compendium of Chemical Terminology (Gold Book)](https://goldbook.iupac.org/). Accessed 2026-08-23.
- **S02 — National Institute of Standards and Technology.** [NIST Chemistry WebBook](https://webbook.nist.gov/chemistry/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Nucleation pathways and defect behavior can be difficult to predict, especially in complex, rapidly formed, or nanoscale materials.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Crystal Lattice is retained because **Repeating Order** is not duplicated by Chemical Bond, even where their processes overlap.
