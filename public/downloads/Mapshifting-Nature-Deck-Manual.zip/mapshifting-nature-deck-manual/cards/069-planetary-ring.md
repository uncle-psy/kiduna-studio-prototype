---
card_number: 69
name: "Planetary Ring"
slug: "planetary-ring"
scale_band: "8. Planetary and orbital"
scientific_domains: ["planetary science","orbital dynamics"]
natural_processes: ["orbit","fragmentation"]
system_functions: ["boundary","pattern"]
spatial_scale: "thousands to hundreds of thousands of kilometres wide"
time_scale: "years to uncertain millions or longer"
core_archetype: "Distributed Boundary"
primary_gifts: ["collective order","visible limit","dynamic structure"]
primary_wounds: ["collision","dispersion","apparent solidity"]
related_cards: ["moon", "fault", "star", "comet", "cosmic-web", "orbit", "mountain-range", "dna"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Planetary Ring

## Essence

A boundary can be made of countless separate paths held in one pattern.

## Keywords

orbit · fragmentation · boundary · pattern · collective order · visible limit · dynamic structure

## What it is

A planetary ring is a disk of orbiting particles ranging from dust to boulders, shaped by the planet, moons, collisions, resonances, and electromagnetic effects. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** thousands to hundreds of thousands of kilometres wide.
- **Characteristic time:** years to uncertain millions or longer.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Crystal Lattice](015-crystal-lattice.md).
- **Larger container:** A useful containing or consequence-level bridge is [Planet](064-planet.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Particles orbit individually, collide, clump temporarily, spread, and form gaps or waves under moon resonances. Rings can exchange material with moons and atmospheres. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A coherent form may be statistical and relational rather than a single object.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Distributed Boundary.** Planetary Ring deserves its own card because it makes **boundary and pattern** legible through **orbit and fragmentation** at the planetary and orbital scale. It differs from [Orbit](066-orbit.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Collective Order.** A coherent form may be statistical and relational rather than a single object.
- **Visible Limit.** This capacity becomes available when visible limit fits the timing, limits, and needs of the larger system.
- **Dynamic Structure.** This capacity becomes available when dynamic structure fits the timing, limits, and needs of the larger system.

## Wounds

- **Collision.** The pattern distorts when collision replaces responsive relationship.
- **Dispersion.** Dispersion appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Apparent Solidity.** Apparent Solidity appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **collective order** becomes **collision** when scale, timing, boundary, or reciprocity is ignored. Planetary Ring asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

collective order remains connected to visible limit while limits are respected; collision is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **collision, dispersion, apparent solidity**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **collective order, visible limit, dynamic structure** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Crystal Lattice](015-crystal-lattice.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to orbit and fragmentation as they actually operate in Planetary Ring; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Planet](064-planet.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Planetary Ring.
- **Deep time:** Consider years to uncertain millions or longer. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with distributed boundary: examine both collective order and collision. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support visible limit or produce dispersion. |
| Creativity | Work with the card's actual process—orbit and fragmentation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **collective order** already present, even in a small or quiet form?
2. Where might **collision** be shaping the situation?
3. Where do you observe **orbit**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Distributed Boundary** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Planetary Ring**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A coherent form may be statistical and relational rather than a single object.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **collective order** while reducing **collision**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Ring ages, origins, recycling, mass, and lifetimes—especially for Saturn's rings—remain debated.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Planetary Ring. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Distributed Boundary** as the original synthesis for Planetary Ring: A coherent form may be statistical and relational rather than a single object. This meaning arises from the sourced description of orbit and fragmentation, then becomes a reflective lens through the gift of **collective order** and the wound of **collision**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Moon](065-moon.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Moon](065-moon.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Crystal Lattice](015-crystal-lattice.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Planet](064-planet.md) helps identify containing systems and downstream effects.
- **Shared process:** [Gravity](009-gravity.md) also expresses orbit, but with different constraints.
- **Shared wound:** [Tectonic Plate](057-tectonic-plate.md) also carries the wound **collision**.
- **Natural cycle:** [Electron](002-electron.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Orbit](066-orbit.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Planetary Ring at its characteristic scale, with the central visual emphasis on **orbit and fragmentation** and **boundary and pattern**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Solar System Exploration](https://science.nasa.gov/solar-system/). Accessed 2026-08-23.
- **S02 — NASA Science.** [About the Planets](https://science.nasa.gov/solar-system/planets/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Ring ages, origins, recycling, mass, and lifetimes—especially for Saturn's rings—remain debated.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Planetary Ring is retained because **Distributed Boundary** is not duplicated by Orbit, even where their processes overlap.
