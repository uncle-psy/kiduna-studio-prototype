---
card_number: 74
name: "Stellar Nursery"
slug: "stellar-nursery"
scale_band: "9. Stellar and cosmic"
scientific_domains: ["astrophysics","interstellar-medium physics"]
natural_processes: ["collapse","emergence"]
system_functions: ["container","seed"]
spatial_scale: "light-years to hundreds of light-years"
time_scale: "hundreds of thousands to millions of years"
core_archetype: "Generative Cloud"
primary_gifts: ["gestation","multiplicity","new centers"]
primary_wounds: ["obscuration","fragmentation","collapse without formation"]
related_cards: ["supernova", "planet", "neutron-star", "black-hole", "hydrogen", "galaxy-cluster", "atmosphere", "fungal-fruiting-body"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Stellar Nursery

## Essence

Creation begins in uneven density, turbulence, and shared material.

## Keywords

collapse · emergence · container · seed · gestation · multiplicity · new centers

## What it is

A stellar nursery is a cold, dense region of interstellar gas and dust where gravity can overcome support and form protostars, often within a turbulent molecular cloud. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** light-years to hundreds of light-years.
- **Characteristic time:** hundreds of thousands to millions of years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Water Molecule](013-water-molecule.md).
- **Larger container:** A useful containing or consequence-level bridge is [Galaxy](078-galaxy.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Clouds fragment into cores, collapse, spin into disks, launch outflows, and are reshaped or dispersed by radiation, winds, and explosions from young massive stars. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A shared field can generate many centers when variation crosses local thresholds.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Generative Cloud.** Stellar Nursery deserves its own card because it makes **container and seed** legible through **collapse and emergence** at the stellar and cosmic scale. It differs from [Galaxy](078-galaxy.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Gestation.** A shared field can generate many centers when variation crosses local thresholds.
- **Multiplicity.** This capacity becomes available when multiplicity fits the timing, limits, and needs of the larger system.
- **New Centers.** This capacity becomes available when new centers fits the timing, limits, and needs of the larger system.

## Wounds

- **Obscuration.** The pattern distorts when obscuration replaces responsive relationship.
- **Fragmentation.** Fragmentation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Collapse Without Formation.** Collapse Without Formation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **gestation** becomes **obscuration** when scale, timing, boundary, or reciprocity is ignored. Stellar Nursery asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

gestation remains connected to multiplicity while limits are respected; obscuration is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **obscuration, fragmentation, collapse without formation**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **gestation, multiplicity, new centers** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Water Molecule](013-water-molecule.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to collapse and emergence as they actually operate in Stellar Nursery; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Galaxy](078-galaxy.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Stellar Nursery.
- **Deep time:** Consider hundreds of thousands to millions of years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with generative cloud: examine both gestation and obscuration. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support multiplicity or produce fragmentation. |
| Creativity | Work with the card's actual process—collapse and emergence—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **gestation** already present, even in a small or quiet form?
2. Where might **obscuration** be shaping the situation?
3. Where do you observe **collapse**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Generative Cloud** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Stellar Nursery**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A shared field can generate many centers when variation crosses local thresholds.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **gestation** while reducing **obscuration**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

What initiates collapse, sets stellar masses, regulates efficiency, and determines feedback across scales remains active research.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Stellar Nursery. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Generative Cloud** as the original synthesis for Stellar Nursery: A shared field can generate many centers when variation crosses local thresholds. This meaning arises from the sourced description of collapse and emergence, then becomes a reflective lens through the gift of **gestation** and the wound of **obscuration**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Fungal Fruiting Body](034-fungal-fruiting-body.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Supernova](075-supernova.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Water Molecule](013-water-molecule.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Galaxy](078-galaxy.md) helps identify containing systems and downstream effects.
- **Shared process:** [Higgs Field](008-higgs-field.md) also expresses emergence, but with different constraints.
- **Shared wound:** [Quark](006-quark.md) also carries the wound **fragmentation**.
- **Natural cycle:** [Quark](006-quark.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Galaxy](078-galaxy.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Stellar Nursery at its characteristic scale, with the central visual emphasis on **collapse and emergence** and **container and seed**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Hubble's Nebulae](https://science.nasa.gov/mission/hubble/science/universe-uncovered/hubble-nebulae/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Stars](https://science.nasa.gov/universe/stars/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** What initiates collapse, sets stellar masses, regulates efficiency, and determines feedback across scales remains active research.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Stellar Nursery is retained because **Generative Cloud** is not duplicated by Galaxy, even where their processes overlap.
