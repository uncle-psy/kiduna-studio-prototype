---
card_number: 65
name: "Moon"
slug: "moon"
scale_band: "8. Planetary and orbital"
scientific_domains: ["planetary science","orbital dynamics"]
natural_processes: ["orbit","tidal interaction"]
system_functions: ["companion","mirror"]
spatial_scale: "kilometres to planet-sized satellites"
time_scale: "millions to billions of years"
core_archetype: "Orbital Companion"
primary_gifts: ["rhythm","stabilizing relationship","reflected perspective"]
primary_wounds: ["dependency","locked face","cycles mistaken for commands"]
related_cards: ["planetary-ring", "fault", "star", "comet", "orbit", "gravity", "atmosphere", "tide"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Moon

## Essence

A companion changes the system through repeated presence, not just proximity.

## Keywords

orbit · tidal interaction · companion · mirror · rhythm · stabilizing relationship · reflected perspective

## What it is

A moon is a natural satellite gravitationally bound to a planet, dwarf planet, or small body. Moons vary from captured irregular fragments to differentiated worlds with atmospheres or internal oceans. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** kilometres to planet-sized satellites.
- **Characteristic time:** millions to billions of years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Volcano](059-volcano.md).
- **Larger container:** A useful containing or consequence-level bridge is [Star](073-star.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Moons orbit, rotate, exchange angular momentum through tides, undergo impacts and heating, and can drive rings, eclipses, resonances, and surface activity. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Repeated relationship creates rhythm and may reshape both partners over time.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Orbital Companion.** Moon deserves its own card because it makes **companion and mirror** legible through **orbit and tidal interaction** at the planetary and orbital scale. It differs from [Planet](064-planet.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Rhythm.** Repeated relationship creates rhythm and may reshape both partners over time.
- **Stabilizing Relationship.** This capacity becomes available when stabilizing relationship fits the timing, limits, and needs of the larger system.
- **Reflected Perspective.** This capacity becomes available when reflected perspective fits the timing, limits, and needs of the larger system.

## Wounds

- **Dependency.** The pattern distorts when dependency replaces responsive relationship.
- **Locked Face.** Locked Face appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Cycles Mistaken For Commands.** Cycles Mistaken For Commands appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **rhythm** becomes **dependency** when scale, timing, boundary, or reciprocity is ignored. Moon asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

rhythm remains connected to stabilizing relationship while limits are respected; dependency is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **dependency, locked face, cycles mistaken for commands**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **rhythm, stabilizing relationship, reflected perspective** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Volcano](059-volcano.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to orbit and tidal interaction as they actually operate in Moon; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Star](073-star.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Moon.
- **Deep time:** Consider millions to billions of years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with orbital companion: examine both rhythm and dependency. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support stabilizing relationship or produce locked face. |
| Creativity | Work with the card's actual process—orbit and tidal interaction—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **rhythm** already present, even in a small or quiet form?
2. Where might **dependency** be shaping the situation?
3. Where do you observe **orbit**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Orbital Companion** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Moon**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Repeated relationship creates rhythm and may reshape both partners over time.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **rhythm** while reducing **dependency**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Formation histories, hidden oceans, geologic activity, and long-term orbital evolution remain uncertain for many moons.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Moon. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Orbital Companion** as the original synthesis for Moon: Repeated relationship creates rhythm and may reshape both partners over time. This meaning arises from the sourced description of orbit and tidal interaction, then becomes a reflective lens through the gift of **rhythm** and the wound of **dependency**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Gravity](009-gravity.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Planetary Ring](069-planetary-ring.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Volcano](059-volcano.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Star](073-star.md) helps identify containing systems and downstream effects.
- **Shared process:** [Gravity](009-gravity.md) also expresses orbit, but with different constraints.
- **Shared wound:** [Oxygen](012-oxygen.md) also carries the wound **dependency**.
- **Natural cycle:** [Comet](068-comet.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Planet](064-planet.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Moon at its characteristic scale, with the central visual emphasis on **orbit and tidal interaction** and **companion and mirror**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Earth's Moon](https://science.nasa.gov/moon/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Solar System Exploration](https://science.nasa.gov/solar-system/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Formation histories, hidden oceans, geologic activity, and long-term orbital evolution remain uncertain for many moons.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Moon is retained because **Orbital Companion** is not duplicated by Planet, even where their processes overlap.
