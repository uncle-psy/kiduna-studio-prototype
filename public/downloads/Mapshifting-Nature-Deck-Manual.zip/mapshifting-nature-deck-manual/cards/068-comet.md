---
card_number: 68
name: "Comet"
slug: "comet"
scale_band: "8. Planetary and orbital"
scientific_domains: ["planetary science","astrochemistry"]
natural_processes: ["orbit","sublimation"]
system_functions: ["messenger","memory"]
spatial_scale: "kilometre-scale nucleus with tails millions of kilometres long"
time_scale: "orbital periods from years to millions of years"
core_archetype: "Returning Messenger"
primary_gifts: ["renewal","deep-system memory","visible response"]
primary_wounds: ["volatile release","disruption","identity defined by spectacle"]
related_cards: ["planetary-ring", "fault", "star", "moon", "orbit", "canyon", "fossil", "neutron-star"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Comet

## Essence

Dormant material becomes expressive when it crosses a threshold of warmth.

## Keywords

orbit · sublimation · messenger · memory · renewal · deep-system memory · visible response

## What it is

A comet is an icy small body orbiting the Sun. Its nucleus contains volatile ices, dust, and rock; heating near the Sun creates a coma and tails. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** kilometre-scale nucleus with tails millions of kilometres long.
- **Characteristic time:** orbital periods from years to millions of years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Crystal Lattice](015-crystal-lattice.md).
- **Larger container:** A useful containing or consequence-level bridge is [Star](073-star.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Sublimating gases carry dust outward, jets alter spin and orbit, and solar wind and radiation shape distinct tails. Repeated passages modify or fragment nuclei. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

An old body can become newly visible when changing context activates stored material.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Returning Messenger.** Comet deserves its own card because it makes **messenger and memory** legible through **orbit and sublimation** at the planetary and orbital scale. It differs from [Planet](064-planet.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Renewal.** An old body can become newly visible when changing context activates stored material.
- **Deep-System Memory.** This capacity becomes available when deep-system memory fits the timing, limits, and needs of the larger system.
- **Visible Response.** This capacity becomes available when visible response fits the timing, limits, and needs of the larger system.

## Wounds

- **Volatile Release.** The pattern distorts when volatile release replaces responsive relationship.
- **Disruption.** Disruption appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Identity Defined By Spectacle.** Identity Defined By Spectacle appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **renewal** becomes **volatile release** when scale, timing, boundary, or reciprocity is ignored. Comet asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

renewal remains connected to deep-system memory while limits are respected; volatile release is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **volatile release, disruption, identity defined by spectacle**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **renewal, deep-system memory, visible response** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Crystal Lattice](015-crystal-lattice.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to orbit and sublimation as they actually operate in Comet; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Star](073-star.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Comet.
- **Deep time:** Consider orbital periods from years to millions of years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with returning messenger: examine both renewal and volatile release. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support deep-system memory or produce disruption. |
| Creativity | Work with the card's actual process—orbit and sublimation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **renewal** already present, even in a small or quiet form?
2. Where might **volatile release** be shaping the situation?
3. Where do you observe **orbit**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Returning Messenger** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Comet**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **An old body can become newly visible when changing context activates stored material.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **renewal** while reducing **volatile release**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Comet interiors, formation reservoirs, chemical diversity, activity at large distances, and fragmentation remain incompletely understood.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Comet. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Returning Messenger** as the original synthesis for Comet: An old body can become newly visible when changing context activates stored material. This meaning arises from the sourced description of orbit and sublimation, then becomes a reflective lens through the gift of **renewal** and the wound of **volatile release**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Gravity](009-gravity.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Planetary Ring](069-planetary-ring.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Crystal Lattice](015-crystal-lattice.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Star](073-star.md) helps identify containing systems and downstream effects.
- **Shared process:** [Gravity](009-gravity.md) also expresses orbit, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Star](073-star.md) offers a nearby systems comparison.
- **Natural cycle:** [Neutrino](005-neutrino.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Planet](064-planet.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Comet at its characteristic scale, with the central visual emphasis on **orbit and sublimation** and **messenger and memory**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Comets](https://science.nasa.gov/solar-system/comets/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Solar System Exploration](https://science.nasa.gov/solar-system/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Comet interiors, formation reservoirs, chemical diversity, activity at large distances, and fragmentation remain incompletely understood.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Comet is retained because **Returning Messenger** is not duplicated by Planet, even where their processes overlap.
