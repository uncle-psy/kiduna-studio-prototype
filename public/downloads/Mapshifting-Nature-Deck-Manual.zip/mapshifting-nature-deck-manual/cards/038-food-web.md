---
card_number: 38
name: "Food Web"
slug: "food-web"
scale_band: "5. Community and ecosystem"
scientific_domains: ["community ecology","network science"]
natural_processes: ["predation","exchange"]
system_functions: ["network","carrier"]
spatial_scale: "local habitat to ocean basin"
time_scale: "feeding moments to long-term restructuring"
core_archetype: "Living Network"
primary_gifts: ["interdependence","energy routing","redundancy"]
primary_wounds: ["cascade","bottleneck","simplification"]
related_cards: ["root", "estuary", "tide", "electron", "symbiosis", "soil-community", "kelp", "pollinator"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Food Web

## Essence

Every intake and loss is routed through more relationships than the visible pair.

## Keywords

predation · exchange · network · carrier · interdependence · energy routing · redundancy

## What it is

A food web represents feeding relationships and the movement of energy and matter among producers, consumers, decomposers, and detrital pathways. Real webs vary across time and life stage. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** local habitat to ocean basin.
- **Characteristic time:** feeding moments to long-term restructuring.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Plankton](026-plankton.md).
- **Larger container:** A useful containing or consequence-level bridge is [Watershed](046-watershed.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Energy is transformed and dissipated while nutrients circulate. Changes in abundance, behavior, or habitat can trigger direct and indirect effects through many paths. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A consequence rarely stops with the first relationship; trace where energy and pressure go next.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Living Network.** Food Web deserves its own card because it makes **network and carrier** legible through **predation and exchange** at the community and ecosystem scale. It differs from [Symbiosis](037-symbiosis.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Interdependence.** A consequence rarely stops with the first relationship; trace where energy and pressure go next.
- **Energy Routing.** This capacity becomes available when energy routing fits the timing, limits, and needs of the larger system.
- **Redundancy.** This capacity becomes available when redundancy fits the timing, limits, and needs of the larger system.

## Wounds

- **Cascade.** The pattern distorts when cascade replaces responsive relationship.
- **Bottleneck.** Bottleneck appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Simplification.** Simplification appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **interdependence** becomes **cascade** when scale, timing, boundary, or reciprocity is ignored. Food Web asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

interdependence remains connected to energy routing while limits are respected; cascade is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **cascade, bottleneck, simplification**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **interdependence, energy routing, redundancy** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Plankton](026-plankton.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to predation and exchange as they actually operate in Food Web; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Watershed](046-watershed.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Food Web.
- **Deep time:** Consider feeding moments to long-term restructuring. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with living network: examine both interdependence and cascade. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support energy routing or produce bottleneck. |
| Creativity | Work with the card's actual process—predation and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **interdependence** already present, even in a small or quiet form?
2. Where might **cascade** be shaping the situation?
3. Where do you observe **predation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Living Network** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Food Web**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A consequence rarely stops with the first relationship; trace where energy and pressure go next.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **interdependence** while reducing **cascade**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Complete food webs are rarely observed, interaction strengths are hard to measure, and climate and behavior continually rewire them.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Food Web. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Living Network** as the original synthesis for Food Web: A consequence rarely stops with the first relationship; trace where energy and pressure go next. This meaning arises from the sourced description of predation and exchange, then becomes a reflective lens through the gift of **interdependence** and the wound of **cascade**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Electron](002-electron.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Root](029-root.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Plankton](026-plankton.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Watershed](046-watershed.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** [Mass Extinction](063-mass-extinction.md) also carries the wound **cascade**.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Symbiosis](037-symbiosis.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Food Web at its characteristic scale, with the central visual emphasis on **predation and exchange** and **network and carrier**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Environmental Protection Agency.** [How do Wetlands Function and Why are they Valuable?](https://www.epa.gov/wetlands/how-do-wetlands-function-and-why-are-they-valuable). Accessed 2026-08-23.
- **S02 — Smithsonian National Museum of Natural History.** [What Is Biodiversity?](https://naturalhistory.si.edu/education/teaching-resources/life-science/what-biodiversity). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Complete food webs are rarely observed, interaction strengths are hard to measure, and climate and behavior continually rewire them.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Food Web is retained because **Living Network** is not duplicated by Symbiosis, even where their processes overlap.
