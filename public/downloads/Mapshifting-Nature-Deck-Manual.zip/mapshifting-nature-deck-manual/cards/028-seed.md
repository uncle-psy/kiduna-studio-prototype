---
card_number: 28
name: "Seed"
slug: "seed"
scale_band: "4. Organism"
scientific_domains: ["botany","ecology"]
natural_processes: ["dormancy","germination"]
system_functions: ["seed","memory"]
spatial_scale: "millimetres to large seeds"
time_scale: "days to centuries depending on species and storage"
core_archetype: "Condensed Future"
primary_gifts: ["potential","preparedness","continuity"]
primary_wounds: ["dormancy without end","poor timing","inherited constraint"]
related_cards: ["spore", "symbiosis", "dna", "plankton", "decomposition", "ecological-succession", "bacterium", "aquifer"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Seed

## Essence

A beginning carries history, provision, and a test of conditions.

## Keywords

dormancy · germination · seed · memory · potential · preparedness · continuity

## What it is

A seed is a mature plant ovule containing an embryo, stored resources or supporting tissue, and a protective coat. Seed traits reflect reproduction, dispersal, dormancy, and habitat. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** millimetres to large seeds.
- **Characteristic time:** days to centuries depending on species and storage.
- **Smaller structures:** A useful composing or mechanism-level bridge is [DNA](020-dna.md).
- **Larger container:** A useful containing or consequence-level bridge is [Ecological Succession](040-ecological-succession.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Seeds disperse, detect moisture, temperature, light, fire, or other cues, and germinate when physiology and conditions align. Many die; some persist in seed banks. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Potential is not abstract: it is embodied preparation meeting a particular environment.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Condensed Future.** Seed deserves its own card because it makes **seed and memory** legible through **dormancy and germination** at the organism scale. It differs from [Root](029-root.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Potential.** Potential is not abstract: it is embodied preparation meeting a particular environment.
- **Preparedness.** This capacity becomes available when preparedness fits the timing, limits, and needs of the larger system.
- **Continuity.** This capacity becomes available when continuity fits the timing, limits, and needs of the larger system.

## Wounds

- **Dormancy Without End.** The pattern distorts when dormancy without end replaces responsive relationship.
- **Poor Timing.** Poor Timing appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Inherited Constraint.** Inherited Constraint appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **potential** becomes **dormancy without end** when scale, timing, boundary, or reciprocity is ignored. Seed asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

potential remains connected to preparedness while limits are respected; dormancy without end is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **dormancy without end, poor timing, inherited constraint**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **potential, preparedness, continuity** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [DNA](020-dna.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to dormancy and germination as they actually operate in Seed; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Ecological Succession](040-ecological-succession.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Seed.
- **Deep time:** Consider days to centuries depending on species and storage. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with condensed future: examine both potential and dormancy without end. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support preparedness or produce poor timing. |
| Creativity | Work with the card's actual process—dormancy and germination—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **potential** already present, even in a small or quiet form?
2. Where might **dormancy without end** be shaping the situation?
3. Where do you observe **dormancy**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Condensed Future** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Seed**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Potential is not abstract: it is embodied preparation meeting a particular environment.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **potential** while reducing **dormancy without end**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Dormancy mechanisms, longevity in natural seed banks, and germination responses under changing climates vary widely and remain incompletely known.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Seed. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Condensed Future** as the original synthesis for Seed: Potential is not abstract: it is embodied preparation meeting a particular environment. This meaning arises from the sourced description of dormancy and germination, then becomes a reflective lens through the gift of **potential** and the wound of **dormancy without end**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Spore](025-spore.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Symbiosis](037-symbiosis.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [DNA](020-dna.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Ecological Succession](040-ecological-succession.md) helps identify containing systems and downstream effects.
- **Shared process:** [Spore](025-spore.md) also expresses dormancy, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [DNA](020-dna.md) offers a nearby systems comparison.
- **Natural cycle:** [Quark](006-quark.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Root](029-root.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Seed at its characteristic scale, with the central visual emphasis on **dormancy and germination** and **seed and memory**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — USDA Forest Service.** [Plant of the Week and Plant Biology Resources](https://www.fs.usda.gov/wildflowers/plant-of-the-week/). Accessed 2026-08-23.
- **S02 — Smithsonian National Museum of Natural History.** [What Is Biodiversity?](https://naturalhistory.si.edu/education/teaching-resources/life-science/what-biodiversity). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Dormancy mechanisms, longevity in natural seed banks, and germination responses under changing climates vary widely and remain incompletely known.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Seed is retained because **Condensed Future** is not duplicated by Root, even where their processes overlap.
