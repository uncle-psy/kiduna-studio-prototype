---
card_number: 47
name: "River"
slug: "river"
scale_band: "6. Landscape and regional system"
scientific_domains: ["fluvial geomorphology","hydrology"]
natural_processes: ["flow","erosion"]
system_functions: ["carrier","path"]
spatial_scale: "small channel to transcontinental river"
time_scale: "seconds of flow to million-year valley evolution"
core_archetype: "Moving Path"
primary_gifts: ["movement","connection","adaptive routing"]
primary_wounds: ["channelization","flooding","carried pollution"]
related_cards: ["glacier", "symbiosis", "canyon", "kelp", "plasma", "food-web", "mantle-convection", "wetland"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# River

## Essence

A path persists by continually changing its contents and often its shape.

## Keywords

flow · erosion · carrier · path · movement · connection · adaptive routing

## What it is

A river is flowing water concentrated in a channel network, linked to a drainage basin, floodplain, groundwater, sediment, organisms, and climate. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** small channel to transcontinental river.
- **Characteristic time:** seconds of flow to million-year valley evolution.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Wetland](041-wetland.md).
- **Larger container:** A useful containing or consequence-level bridge is [Canyon](061-canyon.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Rivers erode, transport, and deposit sediment; exchange water with aquifers and floodplains; migrate laterally; flood; dry; branch; and join other channels. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Continuity can be a process of passage rather than sameness of substance.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Moving Path.** River deserves its own card because it makes **carrier and path** legible through **flow and erosion** at the landscape and regional system scale. It differs from [Glacier](052-glacier.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Movement.** Continuity can be a process of passage rather than sameness of substance.
- **Connection.** This capacity becomes available when connection fits the timing, limits, and needs of the larger system.
- **Adaptive Routing.** This capacity becomes available when adaptive routing fits the timing, limits, and needs of the larger system.

## Wounds

- **Channelization.** The pattern distorts when channelization replaces responsive relationship.
- **Flooding.** Flooding appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Carried Pollution.** Carried Pollution appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **movement** becomes **channelization** when scale, timing, boundary, or reciprocity is ignored. River asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

movement remains connected to connection while limits are respected; channelization is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **channelization, flooding, carried pollution**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **movement, connection, adaptive routing** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Wetland](041-wetland.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to flow and erosion as they actually operate in River; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Canyon](061-canyon.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of River.
- **Deep time:** Consider seconds of flow to million-year valley evolution. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with moving path: examine both movement and channelization. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support connection or produce flooding. |
| Creativity | Work with the card's actual process—flow and erosion—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **movement** already present, even in a small or quiet form?
2. Where might **channelization** be shaping the situation?
3. Where do you observe **flow**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Moving Path** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **River**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Continuity can be a process of passage rather than sameness of substance.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **movement** while reducing **channelization**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

River response to changing precipitation, dams, sediment supply, land use, and compound extremes remains difficult to forecast locally.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for River. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Moving Path** as the original synthesis for River: Continuity can be a process of passage rather than sameness of substance. This meaning arises from the sourced description of flow and erosion, then becomes a reflective lens through the gift of **movement** and the wound of **channelization**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Cosmic Web](080-cosmic-web.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Symbiosis](037-symbiosis.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Wetland](041-wetland.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Canyon](061-canyon.md) helps identify containing systems and downstream effects.
- **Shared process:** [Plasma](016-plasma.md) also expresses flow, but with different constraints.
- **Shared wound:** [Water Molecule](013-water-molecule.md) also carries the wound **flooding**.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Glacier](052-glacier.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of River at its characteristic scale, with the central visual emphasis on **flow and erosion** and **carrier and path**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [Water Science School](https://www.usgs.gov/special-topics/water-science-school). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Watersheds and Drainage Basins](https://www.usgs.gov/water-science-school/science/watersheds-and-drainage-basins). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** River response to changing precipitation, dams, sediment supply, land use, and compound extremes remains difficult to forecast locally.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** River is retained because **Moving Path** is not duplicated by Glacier, even where their processes overlap.
