---
card_number: 26
name: "Plankton"
slug: "plankton"
scale_band: "3. Microscopic and cellular"
scientific_domains: ["oceanography","ecology"]
natural_processes: ["drift","production"]
system_functions: ["carrier","foundation"]
spatial_scale: "microscopic cells to large drifting animals"
time_scale: "hours to seasonal and climate cycles"
core_archetype: "Drifter Community"
primary_gifts: ["adaptation to flow","foundation","distributed productivity"]
primary_wounds: ["drift without agency","bloom imbalance","vulnerability to currents"]
related_cards: ["tectonic-plate", "hydrogen", "seed", "water-molecule", "plasma", "kelp", "kelp-forest", "ocean-current"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Plankton

## Essence

Not controlling direction does not mean lacking influence.

## Keywords

drift · production · carrier · foundation · adaptation to flow · distributed productivity

## What it is

Plankton are organisms that drift with water movement more than they can oppose it. The category includes photosynthetic phytoplankton, animal zooplankton, microbes, and life stages of larger organisms. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** microscopic cells to large drifting animals.
- **Characteristic time:** hours to seasonal and climate cycles.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Water Molecule](013-water-molecule.md).
- **Larger container:** A useful containing or consequence-level bridge is [Food Web](038-food-web.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Plankton grow, graze, reproduce, sink, migrate vertically, and are transported by currents. They support aquatic food webs, oxygen production, carbon cycling, and nutrient exchange. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Agency can lie in timing, buoyancy, and life cycle when direction belongs to the current.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Drifter Community.** Plankton deserves its own card because it makes **carrier and foundation** legible through **drift and production** at the microscopic and cellular scale. It differs from [Cell Membrane](019-cell-membrane.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Adaptation To Flow.** Agency can lie in timing, buoyancy, and life cycle when direction belongs to the current.
- **Foundation.** This capacity becomes available when foundation fits the timing, limits, and needs of the larger system.
- **Distributed Productivity.** This capacity becomes available when distributed productivity fits the timing, limits, and needs of the larger system.

## Wounds

- **Drift Without Agency.** The pattern distorts when drift without agency replaces responsive relationship.
- **Bloom Imbalance.** Bloom Imbalance appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Vulnerability To Currents.** Vulnerability To Currents appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **adaptation to flow** becomes **drift without agency** when scale, timing, boundary, or reciprocity is ignored. Plankton asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

adaptation to flow remains connected to foundation while limits are respected; drift without agency is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **drift without agency, bloom imbalance, vulnerability to currents**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **adaptation to flow, foundation, distributed productivity** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Water Molecule](013-water-molecule.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to drift and production as they actually operate in Plankton; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Food Web](038-food-web.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Plankton.
- **Deep time:** Consider hours to seasonal and climate cycles. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with drifter community: examine both adaptation to flow and drift without agency. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support foundation or produce bloom imbalance. |
| Creativity | Work with the card's actual process—drift and production—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **adaptation to flow** already present, even in a small or quiet form?
2. Where might **drift without agency** be shaping the situation?
3. Where do you observe **drift**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Drifter Community** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Plankton**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Agency can lie in timing, buoyancy, and life cycle when direction belongs to the current.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **adaptation to flow** while reducing **drift without agency**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Plankton diversity, bloom dynamics, microbial interactions, and climate feedbacks are active, observation-limited research areas.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Plankton. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Drifter Community** as the original synthesis for Plankton: Agency can lie in timing, buoyancy, and life cycle when direction belongs to the current. This meaning arises from the sourced description of drift and production, then becomes a reflective lens through the gift of **adaptation to flow** and the wound of **drift without agency**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Tectonic Plate](057-tectonic-plate.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Tectonic Plate](057-tectonic-plate.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Water Molecule](013-water-molecule.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Food Web](038-food-web.md) helps identify containing systems and downstream effects.
- **Shared process:** [Kelp Forest](044-kelp-forest.md) also expresses production, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Seed](028-seed.md) offers a nearby systems comparison.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Cell Membrane](019-cell-membrane.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Plankton at its characteristic scale, with the central visual emphasis on **drift and production** and **carrier and foundation**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NOAA National Ocean Service.** [What are plankton?](https://oceanservice.noaa.gov/facts/plankton.html). Accessed 2026-08-23.
- **S02 — NOAA National Ocean Service.** [What is a current?](https://oceanservice.noaa.gov/facts/current.html). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Plankton diversity, bloom dynamics, microbial interactions, and climate feedbacks are active, observation-limited research areas.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Plankton is retained because **Drifter Community** is not duplicated by Cell Membrane, even where their processes overlap.
