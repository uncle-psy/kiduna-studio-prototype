---
card_number: 45
name: "Coral Reef"
slug: "coral-reef"
scale_band: "5. Community and ecosystem"
scientific_domains: ["marine ecology","biogeochemistry"]
natural_processes: ["construction","succession"]
system_functions: ["builder","whole"]
spatial_scale: "reef patch to structures thousands of kilometres long"
time_scale: "decades to millennia"
core_archetype: "Accumulated Commons"
primary_gifts: ["biodiversity","coastal protection","intergenerational building"]
primary_wounds: ["bleaching","erosion exceeding growth","fragile dependence"]
related_cards: ["coral-colony", "watershed", "ecological-succession", "kelp", "volcano", "carbon", "kelp-forest", "bacterium"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Coral Reef

## Essence

A living community can inherit and extend the mineral work of generations.

## Keywords

construction · succession · builder · whole · biodiversity · coastal protection · intergenerational building

## What it is

A coral reef is a biogenic structure and ecosystem built largely from calcium-carbonate skeletons, coralline algae, and sediment, inhabited by diverse organisms and microbes. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** reef patch to structures thousands of kilometres long.
- **Characteristic time:** decades to millennia.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Coral Colony](033-coral-colony.md).
- **Larger container:** A useful containing or consequence-level bridge is [Ocean Current](053-ocean-current.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Reefs accrete, erode, cement, recover, and reorganize through recruitment, growth, grazing, storms, bleaching, disease, chemistry, and sea-level change. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A commons can be both living process and inherited structure; maintenance must exceed loss.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Accumulated Commons.** Coral Reef deserves its own card because it makes **builder and whole** legible through **construction and succession** at the community and ecosystem scale. It differs from [Symbiosis](037-symbiosis.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Biodiversity.** A commons can be both living process and inherited structure; maintenance must exceed loss.
- **Coastal Protection.** This capacity becomes available when coastal protection fits the timing, limits, and needs of the larger system.
- **Intergenerational Building.** This capacity becomes available when intergenerational building fits the timing, limits, and needs of the larger system.

## Wounds

- **Bleaching.** The pattern distorts when bleaching replaces responsive relationship.
- **Erosion Exceeding Growth.** Erosion Exceeding Growth appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Fragile Dependence.** Fragile Dependence appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **biodiversity** becomes **bleaching** when scale, timing, boundary, or reciprocity is ignored. Coral Reef asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

biodiversity remains connected to coastal protection while limits are respected; bleaching is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **bleaching, erosion exceeding growth, fragile dependence**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **biodiversity, coastal protection, intergenerational building** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Coral Colony](033-coral-colony.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to construction and succession as they actually operate in Coral Reef; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Ocean Current](053-ocean-current.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Coral Reef.
- **Deep time:** Consider decades to millennia. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with accumulated commons: examine both biodiversity and bleaching. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support coastal protection or produce erosion exceeding growth. |
| Creativity | Work with the card's actual process—construction and succession—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **biodiversity** already present, even in a small or quiet form?
2. Where might **bleaching** be shaping the situation?
3. Where do you observe **construction**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Accumulated Commons** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Coral Reef**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A commons can be both living process and inherited structure; maintenance must exceed loss.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **biodiversity** while reducing **bleaching**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Future reef persistence depends on interacting heat, acidification, local stress, adaptation, species turnover, and restoration, with wide regional uncertainty.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Coral Reef. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Accumulated Commons** as the original synthesis for Coral Reef: A commons can be both living process and inherited structure; maintenance must exceed loss. This meaning arises from the sourced description of construction and succession, then becomes a reflective lens through the gift of **biodiversity** and the wound of **bleaching**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Ecological Succession](040-ecological-succession.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Ecological Succession](040-ecological-succession.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Coral Colony](033-coral-colony.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Ocean Current](053-ocean-current.md) helps identify containing systems and downstream effects.
- **Shared process:** [Coral Colony](033-coral-colony.md) also expresses construction, but with different constraints.
- **Shared wound:** [Coral Colony](033-coral-colony.md) also carries the wound **bleaching**.
- **Natural cycle:** [Proton](003-proton.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Symbiosis](037-symbiosis.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Coral Reef at its characteristic scale, with the central visual emphasis on **construction and succession** and **builder and whole**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NOAA Coral Reef Conservation Program.** [Coral Reef Information](https://coralreef.noaa.gov/). Accessed 2026-08-23.
- **S02 — NOAA National Ocean Service.** [What is an estuary?](https://oceanservice.noaa.gov/education/tutorial_estuaries/est01_whatis.html). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Future reef persistence depends on interacting heat, acidification, local stress, adaptation, species turnover, and restoration, with wide regional uncertainty.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Coral Reef is retained because **Accumulated Commons** is not duplicated by Symbiosis, even where their processes overlap.
