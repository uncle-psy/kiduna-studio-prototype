---
card_number: 12
name: "Oxygen"
slug: "oxygen"
scale_band: "2. Atomic and molecular"
scientific_domains: ["chemistry","biogeochemistry"]
natural_processes: ["oxidation","exchange"]
system_functions: ["catalyst","transformer"]
spatial_scale: "atomic to planetary atmosphere"
time_scale: "rapid reactions to geologic oxygenation"
core_archetype: "Intensifier"
primary_gifts: ["metabolic power","combustion","transformation"]
primary_wounds: ["oxidative damage","runaway reaction","dependency"]
related_cards: ["mitochondrion", "electron", "cell-membrane", "chemical-bond", "catalysis", "gluon", "archaeon", "pollinator"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Oxygen

## Essence

What enables life can also accelerate change and damage.

## Keywords

oxidation · exchange · catalyst · transformer · metabolic power · combustion · transformation

## What it is

Oxygen is element 8. Molecular oxygen is a reactive gas used in aerobic respiration, while oxygen atoms also occur in water, minerals, carbon dioxide, and many organic compounds. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** atomic to planetary atmosphere.
- **Characteristic time:** rapid reactions to geologic oxygenation.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Electron](002-electron.md).
- **Larger container:** A useful containing or consequence-level bridge is [Mitochondrion](021-mitochondrion.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Oxygen participates in electron-transfer reactions that release or store energy. Photosynthetic organisms transformed Earth's atmosphere over geologic time, enabling new metabolisms while creating oxidative pressures. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

An enabling resource may also intensify every reaction around it.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Intensifier.** Oxygen deserves its own card because it makes **catalyst and transformer** legible through **oxidation and exchange** at the atomic and molecular scale. It differs from [Hydrogen](010-hydrogen.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Metabolic Power.** An enabling resource may also intensify every reaction around it.
- **Combustion.** This capacity becomes available when combustion fits the timing, limits, and needs of the larger system.
- **Transformation.** This capacity becomes available when transformation fits the timing, limits, and needs of the larger system.

## Wounds

- **Oxidative Damage.** The pattern distorts when oxidative damage replaces responsive relationship.
- **Runaway Reaction.** Runaway Reaction appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Dependency.** Dependency appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **metabolic power** becomes **oxidative damage** when scale, timing, boundary, or reciprocity is ignored. Oxygen asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

metabolic power remains connected to combustion while limits are respected; oxidative damage is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **oxidative damage, runaway reaction, dependency**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **metabolic power, combustion, transformation** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Electron](002-electron.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to oxidation and exchange as they actually operate in Oxygen; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Mitochondrion](021-mitochondrion.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Oxygen.
- **Deep time:** Consider rapid reactions to geologic oxygenation. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with intensifier: examine both metabolic power and oxidative damage. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support combustion or produce runaway reaction. |
| Creativity | Work with the card's actual process—oxidation and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **metabolic power** already present, even in a small or quiet form?
2. Where might **oxidative damage** be shaping the situation?
3. Where do you observe **oxidation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Intensifier** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Oxygen**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **An enabling resource may also intensify every reaction around it.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **metabolic power** while reducing **oxidative damage**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Oxygenation history is reconstructed indirectly from rocks and isotopes; timing and ecological consequences of major transitions retain uncertainty.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Oxygen. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Intensifier** as the original synthesis for Oxygen: An enabling resource may also intensify every reaction around it. This meaning arises from the sourced description of oxidation and exchange, then becomes a reflective lens through the gift of **metabolic power** and the wound of **oxidative damage**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Chemical Bond](014-chemical-bond.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Cell Membrane](019-cell-membrane.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Electron](002-electron.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Mitochondrion](021-mitochondrion.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** [Catalysis](018-catalysis.md) also carries the wound **dependency**.
- **Natural cycle:** [Mitochondrion](021-mitochondrion.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Hydrogen](010-hydrogen.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Oxygen at its characteristic scale, with the central visual emphasis on **oxidation and exchange** and **catalyst and transformer**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — National Institute of Standards and Technology.** [Periodic Table of the Elements](https://www.nist.gov/pml/periodic-table-elements). Accessed 2026-08-23.
- **S02 — NASA Science.** [Earth System Science Research](https://science.nasa.gov/earth-science/research/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Oxygenation history is reconstructed indirectly from rocks and isotopes; timing and ecological consequences of major transitions retain uncertainty.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Oxygen is retained because **Intensifier** is not duplicated by Hydrogen, even where their processes overlap.
