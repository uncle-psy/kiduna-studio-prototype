---
card_number: 44
name: "Kelp Forest"
slug: "kelp-forest"
scale_band: "5. Community and ecosystem"
scientific_domains: ["marine ecology","oceanography"]
natural_processes: ["production","feedback"]
system_functions: ["builder","network"]
spatial_scale: "coastal reef patch to regional habitat belt"
time_scale: "seasonal cycles to decadal regime shifts"
core_archetype: "Flexible Habitat"
primary_gifts: ["habitat creation","productivity","wave buffering"]
primary_wounds: ["urchin barren","regime shift","climate sensitivity"]
related_cards: ["kelp", "keystone-species", "watershed", "coral-colony", "microbiome", "carbon", "root", "plankton"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Kelp Forest

## Essence

A habitat is built through repeated growth and maintained by a web of restraint.

## Keywords

production · feedback · builder · network · habitat creation · productivity · wave buffering

## What it is

A kelp forest is a coastal ecosystem structured by dense large brown algae in cool, nutrient-rich, illuminated waters. Canopy, midwater, and seafloor layers support different communities. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** coastal reef patch to regional habitat belt.
- **Characteristic time:** seasonal cycles to decadal regime shifts.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Kelp](032-kelp.md).
- **Larger container:** A useful containing or consequence-level bridge is [Ocean Current](053-ocean-current.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Kelp grows, sheds, dampens currents, exports detritus, and provides refuge. Predators, grazers, nutrients, heatwaves, storms, and water quality can shift forests into alternate states. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Structure persists when builders, consumers, and conditions regulate one another.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Flexible Habitat.** Kelp Forest deserves its own card because it makes **builder and network** legible through **production and feedback** at the community and ecosystem scale. It differs from [Symbiosis](037-symbiosis.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Habitat Creation.** Structure persists when builders, consumers, and conditions regulate one another.
- **Productivity.** This capacity becomes available when productivity fits the timing, limits, and needs of the larger system.
- **Wave Buffering.** This capacity becomes available when wave buffering fits the timing, limits, and needs of the larger system.

## Wounds

- **Urchin Barren.** The pattern distorts when urchin barren replaces responsive relationship.
- **Regime Shift.** Regime Shift appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Climate Sensitivity.** Climate Sensitivity appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **habitat creation** becomes **urchin barren** when scale, timing, boundary, or reciprocity is ignored. Kelp Forest asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

habitat creation remains connected to productivity while limits are respected; urchin barren is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **urchin barren, regime shift, climate sensitivity**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **habitat creation, productivity, wave buffering** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Kelp](032-kelp.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to production and feedback as they actually operate in Kelp Forest; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Ocean Current](053-ocean-current.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Kelp Forest.
- **Deep time:** Consider seasonal cycles to decadal regime shifts. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with flexible habitat: examine both habitat creation and urchin barren. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support productivity or produce regime shift. |
| Creativity | Work with the card's actual process—production and feedback—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **habitat creation** already present, even in a small or quiet form?
2. Where might **urchin barren** be shaping the situation?
3. Where do you observe **production**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Flexible Habitat** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Kelp Forest**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Structure persists when builders, consumers, and conditions regulate one another.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **habitat creation** while reducing **urchin barren**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

The reversibility of kelp loss, local adaptation, restoration outcomes, and compound climate effects differ sharply among regions.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Kelp Forest. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Flexible Habitat** as the original synthesis for Kelp Forest: Structure persists when builders, consumers, and conditions regulate one another. This meaning arises from the sourced description of production and feedback, then becomes a reflective lens through the gift of **habitat creation** and the wound of **urchin barren**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Kelp](032-kelp.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Kelp](032-kelp.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Kelp](032-kelp.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Ocean Current](053-ocean-current.md) helps identify containing systems and downstream effects.
- **Shared process:** [Plankton](026-plankton.md) also expresses production, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Watershed](046-watershed.md) offers a nearby systems comparison.
- **Natural cycle:** [Proton](003-proton.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Symbiosis](037-symbiosis.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Kelp Forest at its characteristic scale, with the central visual emphasis on **production and feedback** and **builder and network**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NOAA National Ocean Service.** [What is a kelp forest?](https://oceanservice.noaa.gov/facts/kelp.html). Accessed 2026-08-23.
- **S02 — NOAA National Ocean Service.** [What is a current?](https://oceanservice.noaa.gov/facts/current.html). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** The reversibility of kelp loss, local adaptation, restoration outcomes, and compound climate effects differ sharply among regions.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Kelp Forest is retained because **Flexible Habitat** is not duplicated by Symbiosis, even where their processes overlap.
