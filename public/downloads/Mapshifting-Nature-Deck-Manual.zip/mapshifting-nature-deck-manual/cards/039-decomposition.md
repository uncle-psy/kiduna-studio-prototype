---
card_number: 39
name: "Decomposition"
slug: "decomposition"
scale_band: "5. Community and ecosystem"
scientific_domains: ["ecology","biogeochemistry"]
natural_processes: ["decomposition","recycling"]
system_functions: ["dissolver","recycler"]
spatial_scale: "molecules to landscapes"
time_scale: "hours to millennia depending on material and conditions"
core_archetype: "Return"
primary_gifts: ["release","recycling","completion"]
primary_wounds: ["stagnation","toxic release","refusal of endings"]
related_cards: ["soil-community", "seed", "watershed", "subduction-zone", "bacterium", "lichen", "fungal-fruiting-body", "pollinator"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "process"
status: complete
---

# Decomposition

## Essence

Ending becomes availability through many slow transformations.

## Keywords

decomposition · recycling · dissolver · recycler · release · completion

## What it is

Decomposition is the physical and biochemical breakdown of dead organisms and wastes by detritivores, fungi, bacteria, oxidation, water, and other processes. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** molecules to landscapes.
- **Characteristic time:** hours to millennia depending on material and conditions.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Bacterium](022-bacterium.md).
- **Larger container:** A useful containing or consequence-level bridge is [Watershed](046-watershed.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Complex tissues fragment and molecules are metabolized or transformed. Temperature, moisture, oxygen, chemistry, and decomposer communities control whether materials cycle quickly or accumulate. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Release requires a community capable of receiving and transforming what has ended.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Return.** Decomposition deserves its own card because it makes **dissolver and recycler** legible through **decomposition and recycling** at the community and ecosystem scale. It differs from [Ecological Succession](040-ecological-succession.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Release.** Release requires a community capable of receiving and transforming what has ended.
- **Recycling.** This capacity becomes available when recycling fits the timing, limits, and needs of the larger system.
- **Completion.** This capacity becomes available when completion fits the timing, limits, and needs of the larger system.

## Wounds

- **Stagnation.** The pattern distorts when stagnation replaces responsive relationship.
- **Toxic Release.** Toxic Release appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Refusal Of Endings.** Refusal Of Endings appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **release** becomes **stagnation** when scale, timing, boundary, or reciprocity is ignored. Decomposition asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

release remains connected to recycling while limits are respected; stagnation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **stagnation, toxic release, refusal of endings**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **release, recycling, completion** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Bacterium](022-bacterium.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to decomposition and recycling as they actually operate in Decomposition; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Watershed](046-watershed.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Decomposition.
- **Deep time:** Consider hours to millennia depending on material and conditions. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with return: examine both release and stagnation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support recycling or produce toxic release. |
| Creativity | Work with the card's actual process—decomposition and recycling—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **release** already present, even in a small or quiet form?
2. Where might **stagnation** be shaping the situation?
3. Where do you observe **decomposition**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Return** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Decomposition**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Release requires a community capable of receiving and transforming what has ended.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **release** while reducing **stagnation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Soil-carbon persistence, microbial controls, and decomposition feedbacks under changing climates remain major uncertainties.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Decomposition. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Return** as the original synthesis for Decomposition: Release requires a community capable of receiving and transforming what has ended. This meaning arises from the sourced description of decomposition and recycling, then becomes a reflective lens through the gift of **release** and the wound of **stagnation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Soil Community](043-soil-community.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Soil Community](043-soil-community.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Bacterium](022-bacterium.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Watershed](046-watershed.md) helps identify containing systems and downstream effects.
- **Shared process:** [Soil Community](043-soil-community.md) also expresses decomposition, but with different constraints.
- **Shared wound:** [Ocean Current](053-ocean-current.md) also carries the wound **stagnation**.
- **Natural cycle:** [Bacterium](022-bacterium.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Ecological Succession](040-ecological-succession.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Decomposition at its characteristic scale, with the central visual emphasis on **decomposition and recycling** and **dissolver and recycler**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Environmental Protection Agency.** [How do Wetlands Function and Why are they Valuable?](https://www.epa.gov/wetlands/how-do-wetlands-function-and-why-are-they-valuable). Accessed 2026-08-23.
- **S02 — NCBI Bookshelf.** [The Diversity of Genomes and the Tree of Life](https://www.ncbi.nlm.nih.gov/books/NBK26866/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Soil-carbon persistence, microbial controls, and decomposition feedbacks under changing climates remain major uncertainties.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Decomposition is retained because **Return** is not duplicated by Ecological Succession, even where their processes overlap.
