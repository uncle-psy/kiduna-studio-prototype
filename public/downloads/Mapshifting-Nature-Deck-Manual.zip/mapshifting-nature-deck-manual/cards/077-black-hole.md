---
card_number: 77
name: "Black Hole"
slug: "black-hole"
scale_band: "9. Stellar and cosmic"
scientific_domains: ["astrophysics","gravitation"]
natural_processes: ["collapse","accretion"]
system_functions: ["threshold","void"]
spatial_scale: "stellar horizons to supermassive scales"
time_scale: "formation seconds to cosmic lifetimes"
core_archetype: "Event Horizon"
primary_gifts: ["concentration","transformative threshold","clarity about limits"]
primary_wounds: ["consumption","secrecy","confusing unknown with nothing"]
related_cards: ["stellar-nursery", "planet", "supernova", "neutron-star", "eclipse", "orbit", "mass-extinction", "delta"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Black Hole

## Essence

A threshold marks the limit of return and the limit of an observer's access.

## Keywords

collapse · accretion · threshold · void · concentration · transformative threshold · clarity about limits

## What it is

A black hole is a region where spacetime curvature creates an event horizon from which signals cannot reach distant observers. Black holes are characterized externally mainly by mass, spin, and charge. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** stellar horizons to supermassive scales.
- **Characteristic time:** formation seconds to cosmic lifetimes.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Gravity](009-gravity.md).
- **Larger container:** A useful containing or consequence-level bridge is [Galaxy](078-galaxy.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

They form through collapse or mergers, grow by accretion and merger, bend light, disturb stars and gas, launch jets through surrounding magnetized disks, and merge with gravitational-wave emission. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Some boundaries are limits on relationship and knowledge, not evidence that nothing exists beyond them.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Event Horizon.** Black Hole deserves its own card because it makes **threshold and void** legible through **collapse and accretion** at the stellar and cosmic scale. It differs from [Star](073-star.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Concentration.** Some boundaries are limits on relationship and knowledge, not evidence that nothing exists beyond them.
- **Transformative Threshold.** This capacity becomes available when transformative threshold fits the timing, limits, and needs of the larger system.
- **Clarity About Limits.** This capacity becomes available when clarity about limits fits the timing, limits, and needs of the larger system.

## Wounds

- **Consumption.** The pattern distorts when consumption replaces responsive relationship.
- **Secrecy.** Secrecy appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Confusing Unknown With Nothing.** Confusing Unknown With Nothing appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **concentration** becomes **consumption** when scale, timing, boundary, or reciprocity is ignored. Black Hole asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

concentration remains connected to transformative threshold while limits are respected; consumption is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **consumption, secrecy, confusing unknown with nothing**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **concentration, transformative threshold, clarity about limits** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Gravity](009-gravity.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to collapse and accretion as they actually operate in Black Hole; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Galaxy](078-galaxy.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Black Hole.
- **Deep time:** Consider formation seconds to cosmic lifetimes. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with event horizon: examine both concentration and consumption. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support transformative threshold or produce secrecy. |
| Creativity | Work with the card's actual process—collapse and accretion—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **concentration** already present, even in a small or quiet form?
2. Where might **consumption** be shaping the situation?
3. Where do you observe **collapse**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Event Horizon** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Black Hole**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Some boundaries are limits on relationship and knowledge, not evidence that nothing exists beyond them.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **concentration** while reducing **consumption**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Black-hole interiors, information, singularities, quantum effects, jet launching, and supermassive origins remain open research areas.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Black Hole. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Event Horizon** as the original synthesis for Black Hole: Some boundaries are limits on relationship and knowledge, not evidence that nothing exists beyond them. This meaning arises from the sourced description of collapse and accretion, then becomes a reflective lens through the gift of **concentration** and the wound of **consumption**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Stellar Nursery](074-stellar-nursery.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Stellar Nursery](074-stellar-nursery.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Gravity](009-gravity.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Galaxy](078-galaxy.md) helps identify containing systems and downstream effects.
- **Shared process:** [Planet](064-planet.md) also expresses accretion, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Supernova](075-supernova.md) offers a nearby systems comparison.
- **Natural cycle:** [Phase Transition](017-phase-transition.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Star](073-star.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Black Hole at its characteristic scale, with the central visual emphasis on **collapse and accretion** and **threshold and void**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Black Holes](https://science.nasa.gov/universe/black-holes/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Universe Glossary](https://science.nasa.gov/universe/glossary/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Black-hole interiors, information, singularities, quantum effects, jet launching, and supermassive origins remain open research areas.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Black Hole is retained because **Event Horizon** is not duplicated by Star, even where their processes overlap.
