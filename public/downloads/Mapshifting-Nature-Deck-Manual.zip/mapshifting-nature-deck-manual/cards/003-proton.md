---
card_number: 3
name: "Proton"
slug: "proton"
scale_band: "1. Fundamental"
scientific_domains: ["particle physics","nuclear physics"]
natural_processes: ["binding","stability"]
system_functions: ["center","builder"]
spatial_scale: "about 0.84 femtometres in charge radius"
time_scale: "stable beyond current measured limits"
core_archetype: "Anchor"
primary_gifts: ["coherence","identity","anchoring"]
primary_wounds: ["overattachment","centralization","resistance to reconfiguration"]
related_cards: ["chemical-bond", "hydrogen", "carbon", "neutron", "quark", "gluon", "water-molecule", "crystal-lattice"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description; open questions noted"
card_type: "entity"
status: complete
---

# Proton

## Essence

Identity can arise from a stable count within a changing system.

## Keywords

binding · stability · center · builder · coherence · identity · anchoring

## What it is

A proton is a positively charged hadron composed mainly of two up quarks and one down quark, bound by the strong interaction. Proton number defines a chemical element. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** about 0.84 femtometres in charge radius.
- **Characteristic time:** stable beyond current measured limits.
- **Smaller structures:** This is the deck's lowest scale band. Its quantum fields and interactions are not represented by a still smaller card.
- **Larger container:** A useful containing or consequence-level bridge is [Hydrogen](010-hydrogen.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Protons bind with neutrons in nuclei and attract electrons electromagnetically. Most of a proton's mass arises from strong-interaction energy rather than simply adding constituent-quark masses. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A reliable center can organize identity without remaining simple inside.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Anchor.** Proton deserves its own card because it makes **center and builder** legible through **binding and stability** at the fundamental scale. It differs from [Photon](001-photon.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Coherence.** A reliable center can organize identity without remaining simple inside.
- **Identity.** This capacity becomes available when identity fits the timing, limits, and needs of the larger system.
- **Anchoring.** This capacity becomes available when anchoring fits the timing, limits, and needs of the larger system.

## Wounds

- **Overattachment.** The pattern distorts when overattachment replaces responsive relationship.
- **Centralization.** Centralization appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Resistance To Reconfiguration.** Resistance To Reconfiguration appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **coherence** becomes **overattachment** when scale, timing, boundary, or reciprocity is ignored. Proton asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

coherence remains connected to identity while limits are respected; overattachment is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **overattachment, centralization, resistance to reconfiguration**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **coherence, identity, anchoring** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** At the lower boundary of the deck, shift from object language to fields, interactions, measurement conditions, and quantum states rather than inventing a smaller card.
- **Its own scale:** Attend to binding and stability as they actually operate in Proton; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Hydrogen](010-hydrogen.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Proton.
- **Deep time:** Consider stable beyond current measured limits. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with anchor: examine both coherence and overattachment. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support identity or produce centralization. |
| Creativity | Work with the card's actual process—binding and stability—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **coherence** already present, even in a small or quiet form?
2. Where might **overattachment** be shaping the situation?
3. Where do you observe **binding**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Anchor** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Proton**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A reliable center can organize identity without remaining simple inside.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **coherence** while reducing **overattachment**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Whether an isolated proton ultimately decays is unknown; experiments have only established very long lower limits on its lifetime.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Proton. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Anchor** as the original synthesis for Proton: A reliable center can organize identity without remaining simple inside. This meaning arises from the sourced description of binding and stability, then becomes a reflective lens through the gift of **coherence** and the wound of **overattachment**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Chemical Bond](014-chemical-bond.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Chemical Bond](014-chemical-bond.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** No smaller core card is asserted; use the explicit lower-boundary guidance above.
- **Larger scale:** [Hydrogen](010-hydrogen.md) helps identify containing systems and downstream effects.
- **Shared process:** [Neutron](004-neutron.md) also expresses binding, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Carbon](011-carbon.md) offers a nearby systems comparison.
- **Natural cycle:** [Carbon](011-carbon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Photon](001-photon.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Proton at its characteristic scale, with the central visual emphasis on **binding and stability** and **center and builder**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Department of Energy Office of Science.** [DOE Explains: The Standard Model of Particle Physics](https://www.energy.gov/science/doe-explainsthe-standard-model-particle-physics). Accessed 2026-08-23.
- **S02 — CERN.** [The Standard Model](https://home.cern/science/physics/standard-model). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Whether an isolated proton ultimately decays is unknown; experiments have only established very long lower limits on its lifetime.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Proton is retained because **Anchor** is not duplicated by Photon, even where their processes overlap.
