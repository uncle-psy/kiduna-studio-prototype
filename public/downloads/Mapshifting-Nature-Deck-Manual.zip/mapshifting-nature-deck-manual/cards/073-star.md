---
card_number: 73
name: "Star"
slug: "star"
scale_band: "9. Stellar and cosmic"
scientific_domains: ["astrophysics","nuclear physics"]
natural_processes: ["fusion","radiation"]
system_functions: ["source","transformer"]
spatial_scale: "hundreds of thousands to billions of kilometres"
time_scale: "millions to trillions of years by mass"
core_archetype: "Sustained Fire"
primary_gifts: ["radiance","creation of elements","sustained purpose"]
primary_wounds: ["fuel exhaustion","instability","burning beyond balance"]
related_cards: ["hydrogen", "planet", "neutron-star", "subduction-zone", "phase-transition", "photon", "stellar-nursery", "supernova"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Star

## Essence

A source endures by balancing inward gravity with outward energy transport.

## Keywords

fusion · radiation · source · transformer · radiance · creation of elements · sustained purpose

## What it is

A star is a self-gravitating sphere of plasma sustained for much of its life by nuclear fusion. Mass governs core conditions, luminosity, lifetime, and eventual fate. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** hundreds of thousands to billions of kilometres.
- **Characteristic time:** millions to trillions of years by mass.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Plasma](016-plasma.md).
- **Larger container:** A useful containing or consequence-level bridge is [Galaxy](078-galaxy.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Stars form from collapsing gas, reach long-lived balance, transform elements, lose mass, expand, pulse, and end as white dwarfs, neutron stars, black holes, or disrupted remnants depending on mass and history. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Sustained expression is a balance of contraction, transformation, and release—not limitless output.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Sustained Fire.** Star deserves its own card because it makes **source and transformer** legible through **fusion and radiation** at the stellar and cosmic scale. It differs from [Neutron Star](076-neutron-star.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Radiance.** Sustained expression is a balance of contraction, transformation, and release—not limitless output.
- **Creation Of Elements.** This capacity becomes available when creation of elements fits the timing, limits, and needs of the larger system.
- **Sustained Purpose.** This capacity becomes available when sustained purpose fits the timing, limits, and needs of the larger system.

## Wounds

- **Fuel Exhaustion.** The pattern distorts when fuel exhaustion replaces responsive relationship.
- **Instability.** Instability appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Burning Beyond Balance.** Burning Beyond Balance appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **radiance** becomes **fuel exhaustion** when scale, timing, boundary, or reciprocity is ignored. Star asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

radiance remains connected to creation of elements while limits are respected; fuel exhaustion is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **fuel exhaustion, instability, burning beyond balance**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **radiance, creation of elements, sustained purpose** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Plasma](016-plasma.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to fusion and radiation as they actually operate in Star; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Galaxy](078-galaxy.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Star.
- **Deep time:** Consider millions to trillions of years by mass. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with sustained fire: examine both radiance and fuel exhaustion. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support creation of elements or produce instability. |
| Creativity | Work with the card's actual process—fusion and radiation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **radiance** already present, even in a small or quiet form?
2. Where might **fuel exhaustion** be shaping the situation?
3. Where do you observe **fusion**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Sustained Fire** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Star**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Sustained expression is a balance of contraction, transformation, and release—not limitless output.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **radiance** while reducing **fuel exhaustion**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Stellar models are mature, yet convection, magnetic dynamos, mass loss, mixing, and rare endpoints retain important uncertainties.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Star. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Sustained Fire** as the original synthesis for Star: Sustained expression is a balance of contraction, transformation, and release—not limitless output. This meaning arises from the sourced description of fusion and radiation, then becomes a reflective lens through the gift of **radiance** and the wound of **fuel exhaustion**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Hydrogen](010-hydrogen.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Subduction Zone](058-subduction-zone.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Plasma](016-plasma.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Galaxy](078-galaxy.md) helps identify containing systems and downstream effects.
- **Shared process:** [Photon](001-photon.md) also expresses radiation, but with different constraints.
- **Shared wound:** [Plasma](016-plasma.md) also carries the wound **instability**.
- **Natural cycle:** [Hydrogen](010-hydrogen.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Neutron Star](076-neutron-star.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Star at its characteristic scale, with the central visual emphasis on **fusion and radiation** and **source and transformer**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Stars](https://science.nasa.gov/universe/stars/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Universe Glossary](https://science.nasa.gov/universe/glossary/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Stellar models are mature, yet convection, magnetic dynamos, mass loss, mixing, and rare endpoints retain important uncertainties.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Star is retained because **Sustained Fire** is not duplicated by Neutron Star, even where their processes overlap.
