---
card_number: 81
name: "Expanding Universe"
slug: "expanding-universe"
scale_band: "9. Stellar and cosmic"
scientific_domains: ["cosmology","gravitation"]
natural_processes: ["expansion","acceleration"]
system_functions: ["whole","clock"]
spatial_scale: "observable-universe scale"
time_scale: "13.8 billion years and ongoing"
core_archetype: "Changing Metric"
primary_gifts: ["possibility","unfolding","radical scale shift"]
primary_wounds: ["separation","loss of common horizon","certainty projected beyond evidence"]
related_cards: ["orbit", "planet", "gravity", "galaxy", "tide", "tectonic-plate", "coral-reef", "black-hole"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description; open questions noted"
card_type: "process"
status: complete
---

# Expanding Universe

## Essence

The container itself can change, altering every distance without a central edge.

## Keywords

expansion · acceleration · whole · clock · possibility · unfolding · radical scale shift

## What it is

Cosmic expansion is the increase of distances between sufficiently unbound regions as described by an evolving spacetime metric. It is not an explosion from a center into preexisting empty space. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** observable-universe scale.
- **Characteristic time:** 13.8 billion years and ongoing.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Cosmic Web](080-cosmic-web.md).
- **Larger container:** This is the deck's largest containing scale. No larger core card is asserted beyond the observable-universe frame.

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Early expansion, structure formation, and later accelerated expansion shape observable distances and horizons. Gravitationally bound systems do not simply expand in proportion with the universe. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Sometimes the map changes because the containing geometry changes, not because every part chose to move.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Changing Metric.** Expanding Universe deserves its own card because it makes **whole and clock** legible through **expansion and acceleration** at the stellar and cosmic scale. It differs from [Supernova](075-supernova.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Possibility.** Sometimes the map changes because the containing geometry changes, not because every part chose to move.
- **Unfolding.** This capacity becomes available when unfolding fits the timing, limits, and needs of the larger system.
- **Radical Scale Shift.** This capacity becomes available when radical scale shift fits the timing, limits, and needs of the larger system.

## Wounds

- **Separation.** The pattern distorts when separation replaces responsive relationship.
- **Loss Of Common Horizon.** Loss Of Common Horizon appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Certainty Projected Beyond Evidence.** Certainty Projected Beyond Evidence appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **possibility** becomes **separation** when scale, timing, boundary, or reciprocity is ignored. Expanding Universe asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

possibility remains connected to unfolding while limits are respected; separation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **separation, loss of common horizon, certainty projected beyond evidence**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **possibility, unfolding, radical scale shift** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Cosmic Web](080-cosmic-web.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to expansion and acceleration as they actually operate in Expanding Universe; do not substitute a larger story for present conditions.
- **Larger system:** At the upper boundary of the deck, change time horizon, observational frame, or cosmological model rather than claiming a known larger physical container.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Expanding Universe.
- **Deep time:** Consider 13.8 billion years and ongoing. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with changing metric: examine both possibility and separation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support unfolding or produce loss of common horizon. |
| Creativity | Work with the card's actual process—expansion and acceleration—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **possibility** already present, even in a small or quiet form?
2. Where might **separation** be shaping the situation?
3. Where do you observe **expansion**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Changing Metric** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Expanding Universe**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Sometimes the map changes because the containing geometry changes, not because every part chose to move.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **possibility** while reducing **separation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

The nature of dark energy, the early inflationary phase, cosmic tensions in measured expansion, and the ultimate future remain unresolved.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Expanding Universe. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Changing Metric** as the original synthesis for Expanding Universe: Sometimes the map changes because the containing geometry changes, not because every part chose to move. This meaning arises from the sourced description of expansion and acceleration, then becomes a reflective lens through the gift of **possibility** and the wound of **separation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Orbit](066-orbit.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Orbit](066-orbit.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Cosmic Web](080-cosmic-web.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** No larger core card is asserted; use the explicit upper-boundary guidance above.
- **Shared process:** No other core card uses the exact process labels **expansion / acceleration**; [Orbit](066-orbit.md) is retained as a contrast, not an equivalence.
- **Shared wound:** No other core card repeats this exact primary wound set; [Gravity](009-gravity.md) offers a nearby systems comparison.
- **Natural cycle:** [Gravity](009-gravity.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Supernova](075-supernova.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Expanding Universe at its characteristic scale, with the central visual emphasis on **expansion and acceleration** and **whole and clock**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Universe Overview](https://science.nasa.gov/universe/overview/). Accessed 2026-08-23.
- **S02 — NASA Science.** [What Is the Universe?](https://science.nasa.gov/exoplanets/what-is-the-universe/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** The nature of dark energy, the early inflationary phase, cosmic tensions in measured expansion, and the ultimate future remain unresolved.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Expanding Universe is retained because **Changing Metric** is not duplicated by Supernova, even where their processes overlap.
