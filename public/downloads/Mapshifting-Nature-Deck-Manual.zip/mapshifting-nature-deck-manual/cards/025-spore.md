---
card_number: 25
name: "Spore"
slug: "spore"
scale_band: "3. Microscopic and cellular"
scientific_domains: ["mycology","botany","microbiology"]
natural_processes: ["dispersion","dormancy"]
system_functions: ["seed","carrier"]
spatial_scale: "micrometres to visible propagules"
time_scale: "hours to years or longer"
core_archetype: "Dormant Possibility"
primary_gifts: ["patience","dispersal","resilience"]
primary_wounds: ["indefinite suspension","premature emergence","unrooted possibility"]
related_cards: ["seed", "hydrogen", "fungal-fruiting-body", "water-molecule", "plasma", "lichen", "kelp", "supernova"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Spore

## Essence

Waiting is active when a form preserves the capacity to respond.

## Keywords

dispersion · dormancy · seed · carrier · patience · dispersal · resilience

## What it is

A spore is a reproductive or survival unit produced by fungi, plants, algae, and some microbes; these structures are not all homologous. Many spores are adapted for dispersal, dormancy, or resistance. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** micrometres to visible propagules.
- **Characteristic time:** hours to years or longer.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Carbon](011-carbon.md).
- **Larger container:** A useful containing or consequence-level bridge is [Fungal Fruiting Body](034-fungal-fruiting-body.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Spores form under species-specific conditions, travel by air, water, animals, or local release, and germinate when cues and resources permit. Some are short-lived; others persist. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Potential can travel farther when it temporarily reduces its demands.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Dormant Possibility.** Spore deserves its own card because it makes **seed and carrier** legible through **dispersion and dormancy** at the microscopic and cellular scale. It differs from [DNA](020-dna.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Patience.** Potential can travel farther when it temporarily reduces its demands.
- **Dispersal.** This capacity becomes available when dispersal fits the timing, limits, and needs of the larger system.
- **Resilience.** This capacity becomes available when resilience fits the timing, limits, and needs of the larger system.

## Wounds

- **Indefinite Suspension.** The pattern distorts when indefinite suspension replaces responsive relationship.
- **Premature Emergence.** Premature Emergence appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Unrooted Possibility.** Unrooted Possibility appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **patience** becomes **indefinite suspension** when scale, timing, boundary, or reciprocity is ignored. Spore asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

patience remains connected to dispersal while limits are respected; indefinite suspension is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **indefinite suspension, premature emergence, unrooted possibility**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **patience, dispersal, resilience** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Carbon](011-carbon.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to dispersion and dormancy as they actually operate in Spore; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Fungal Fruiting Body](034-fungal-fruiting-body.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Spore.
- **Deep time:** Consider hours to years or longer. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with dormant possibility: examine both patience and indefinite suspension. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support dispersal or produce premature emergence. |
| Creativity | Work with the card's actual process—dispersion and dormancy—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **patience** already present, even in a small or quiet form?
2. Where might **indefinite suspension** be shaping the situation?
3. Where do you observe **dispersion**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Dormant Possibility** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Spore**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Potential can travel farther when it temporarily reduces its demands.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **patience** while reducing **indefinite suspension**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Environmental sensing, long-term viability, aerial dispersal, and the vast diversity of fungal spores are incompletely characterized.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Spore. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Dormant Possibility** as the original synthesis for Spore: Potential can travel farther when it temporarily reduces its demands. This meaning arises from the sourced description of dispersion and dormancy, then becomes a reflective lens through the gift of **patience** and the wound of **indefinite suspension**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Supernova](075-supernova.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Lichen](031-lichen.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Carbon](011-carbon.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Fungal Fruiting Body](034-fungal-fruiting-body.md) helps identify containing systems and downstream effects.
- **Shared process:** [Seed](028-seed.md) also expresses dormancy, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Fungal Fruiting Body](034-fungal-fruiting-body.md) offers a nearby systems comparison.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [DNA](020-dna.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Spore at its characteristic scale, with the central visual emphasis on **dispersion and dormancy** and **seed and carrier**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — USDA Forest Service.** [Plant of the Week and Plant Biology Resources](https://www.fs.usda.gov/wildflowers/plant-of-the-week/). Accessed 2026-08-23.
- **S02 — NCBI Bookshelf.** [Molecular Biology of the Cell](https://www.ncbi.nlm.nih.gov/books/NBK21054/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Environmental sensing, long-term viability, aerial dispersal, and the vast diversity of fungal spores are incompletely characterized.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Spore is retained because **Dormant Possibility** is not duplicated by DNA, even where their processes overlap.
