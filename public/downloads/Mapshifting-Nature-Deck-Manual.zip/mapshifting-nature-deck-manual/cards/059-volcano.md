---
card_number: 59
name: "Volcano"
slug: "volcano"
scale_band: "7. Geologic and continental"
scientific_domains: ["volcanology","geochemistry"]
natural_processes: ["eruption","construction"]
system_functions: ["threshold","builder"]
spatial_scale: "vent to volcanic province"
time_scale: "seconds of eruption to millions of years of construction"
core_archetype: "Pressure Outlet"
primary_gifts: ["creative transformation","fertile renewal","pressure release"]
primary_wounds: ["uncontained eruption","hazard denial","pressure without pathway"]
related_cards: ["coral-reef", "watershed", "planet", "coral-colony", "delta", "estuary", "eclipse", "aquifer"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Volcano

## Essence

Release can destroy, build, and change atmosphere at once.

## Keywords

eruption · construction · threshold · builder · creative transformation · fertile renewal · pressure release

## What it is

A volcano is a vent and landform through which magma, gases, and fragments reach or approach the surface. Volcanoes vary by magma chemistry, supply, tectonic setting, and eruption style. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** vent to volcanic province.
- **Characteristic time:** seconds of eruption to millions of years of construction.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Crystal Lattice](015-crystal-lattice.md).
- **Larger container:** A useful containing or consequence-level bridge is [Planet](064-planet.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Magma rises, stalls, crystallizes, mixes, degasses, intrudes, or erupts. Lava and ash build land while flows, gases, collapse, and secondary hazards can cause severe harm. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A release pathway changes both what was contained and the landscape receiving it.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Pressure Outlet.** Volcano deserves its own card because it makes **threshold and builder** legible through **eruption and construction** at the geologic and continental scale. It differs from [Fault](055-fault.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Creative Transformation.** A release pathway changes both what was contained and the landscape receiving it.
- **Fertile Renewal.** This capacity becomes available when fertile renewal fits the timing, limits, and needs of the larger system.
- **Pressure Release.** This capacity becomes available when pressure release fits the timing, limits, and needs of the larger system.

## Wounds

- **Uncontained Eruption.** The pattern distorts when uncontained eruption replaces responsive relationship.
- **Hazard Denial.** Hazard Denial appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Pressure Without Pathway.** Pressure Without Pathway appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **creative transformation** becomes **uncontained eruption** when scale, timing, boundary, or reciprocity is ignored. Volcano asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

creative transformation remains connected to fertile renewal while limits are respected; uncontained eruption is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **uncontained eruption, hazard denial, pressure without pathway**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **creative transformation, fertile renewal, pressure release** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Crystal Lattice](015-crystal-lattice.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to eruption and construction as they actually operate in Volcano; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Planet](064-planet.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Volcano.
- **Deep time:** Consider seconds of eruption to millions of years of construction. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with pressure outlet: examine both creative transformation and uncontained eruption. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support fertile renewal or produce hazard denial. |
| Creativity | Work with the card's actual process—eruption and construction—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **creative transformation** already present, even in a small or quiet form?
2. Where might **uncontained eruption** be shaping the situation?
3. Where do you observe **eruption**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Pressure Outlet** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Volcano**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A release pathway changes both what was contained and the landscape receiving it.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **creative transformation** while reducing **uncontained eruption**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Eruption timing, magma pathways, transitions in style, and cascading hazards cannot be forecast with certainty even with careful monitoring.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Volcano. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Pressure Outlet** as the original synthesis for Volcano: A release pathway changes both what was contained and the landscape receiving it. This meaning arises from the sourced description of eruption and construction, then becomes a reflective lens through the gift of **creative transformation** and the wound of **uncontained eruption**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Coral Colony](033-coral-colony.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Coral Reef](045-coral-reef.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Crystal Lattice](015-crystal-lattice.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Planet](064-planet.md) helps identify containing systems and downstream effects.
- **Shared process:** [Coral Colony](033-coral-colony.md) also expresses construction, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Planet](064-planet.md) offers a nearby systems comparison.
- **Natural cycle:** [Proton](003-proton.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Fault](055-fault.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Volcano at its characteristic scale, with the central visual emphasis on **eruption and construction** and **threshold and builder**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [Volcanoes: Principal Types and Processes](https://pubs.usgs.gov/gip/volc/text.html). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Plate Tectonics in a Nutshell](https://volcanoes.usgs.gov/about/edu/dynamicplanet/nutshell.php). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Eruption timing, magma pathways, transitions in style, and cascading hazards cannot be forecast with certainty even with careful monitoring.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Volcano is retained because **Pressure Outlet** is not duplicated by Fault, even where their processes overlap.
