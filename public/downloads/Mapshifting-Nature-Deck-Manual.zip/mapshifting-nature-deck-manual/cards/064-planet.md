---
card_number: 64
name: "Planet"
slug: "planet"
scale_band: "8. Planetary and orbital"
scientific_domains: ["planetary science","astronomy"]
natural_processes: ["accretion","differentiation"]
system_functions: ["container","whole"]
spatial_scale: "thousands to hundreds of thousands of kilometres"
time_scale: "millions to billions of years"
core_archetype: "World"
primary_gifts: ["integration","habitat possibility","self-consistent world"]
primary_wounds: ["closed-world thinking","planetary imbalance","scale blindness"]
related_cards: ["atmosphere", "fault", "black-hole", "stellar-nursery", "galaxy", "galaxy-cluster", "expanding-universe", "tectonic-plate"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Planet

## Essence

A whole is a long negotiation among interior, surface, atmosphere, orbit, and history.

## Keywords

accretion · differentiation · container · whole · integration · habitat possibility · self-consistent world

## What it is

A planet is a large body orbiting a star or stellar remnant; formal definitions vary by context. Planets differ in composition, atmosphere, interior, magnetic field, moons, climate, and formation history. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** thousands to hundreds of thousands of kilometres.
- **Characteristic time:** millions to billions of years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Tectonic Plate](057-tectonic-plate.md).
- **Larger container:** A useful containing or consequence-level bridge is [Star](073-star.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Planets accrete, differentiate, cool, outgas, lose or gain atmospheres, experience impacts, and interact with stars and neighboring bodies. Some remain geologically active. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A world is not one surface but a coupled history of layers, flows, and external relationships.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**World.** Planet deserves its own card because it makes **container and whole** legible through **accretion and differentiation** at the planetary and orbital scale. It differs from [Moon](065-moon.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Integration.** A world is not one surface but a coupled history of layers, flows, and external relationships.
- **Habitat Possibility.** This capacity becomes available when habitat possibility fits the timing, limits, and needs of the larger system.
- **Self-Consistent World.** This capacity becomes available when self-consistent world fits the timing, limits, and needs of the larger system.

## Wounds

- **Closed-World Thinking.** The pattern distorts when closed-world thinking replaces responsive relationship.
- **Planetary Imbalance.** Planetary Imbalance appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Scale Blindness.** Scale Blindness appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **integration** becomes **closed-world thinking** when scale, timing, boundary, or reciprocity is ignored. Planet asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

integration remains connected to habitat possibility while limits are respected; closed-world thinking is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **closed-world thinking, planetary imbalance, scale blindness**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **integration, habitat possibility, self-consistent world** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Tectonic Plate](057-tectonic-plate.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to accretion and differentiation as they actually operate in Planet; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Star](073-star.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Planet.
- **Deep time:** Consider millions to billions of years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with world: examine both integration and closed-world thinking. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support habitat possibility or produce planetary imbalance. |
| Creativity | Work with the card's actual process—accretion and differentiation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **integration** already present, even in a small or quiet form?
2. Where might **closed-world thinking** be shaping the situation?
3. Where do you observe **accretion**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **World** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Planet**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A world is not one surface but a coupled history of layers, flows, and external relationships.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **integration** while reducing **closed-world thinking**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Planet formation diversity, interior structure, atmospheric evolution, habitability, and the best general definition of planet remain active research.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Planet. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **World** as the original synthesis for Planet: A world is not one surface but a coupled history of layers, flows, and external relationships. This meaning arises from the sourced description of accretion and differentiation, then becomes a reflective lens through the gift of **integration** and the wound of **closed-world thinking**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Atmosphere](071-atmosphere.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Atmosphere](071-atmosphere.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Tectonic Plate](057-tectonic-plate.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Star](073-star.md) helps identify containing systems and downstream effects.
- **Shared process:** [Black Hole](077-black-hole.md) also expresses accretion, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Black Hole](077-black-hole.md) offers a nearby systems comparison.
- **Natural cycle:** [Gravity](009-gravity.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Moon](065-moon.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Planet at its characteristic scale, with the central visual emphasis on **accretion and differentiation** and **container and whole**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [About the Planets](https://science.nasa.gov/solar-system/planets/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Solar System Exploration](https://science.nasa.gov/solar-system/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Planet formation diversity, interior structure, atmospheric evolution, habitability, and the best general definition of planet remain active research.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Planet is retained because **World** is not duplicated by Moon, even where their processes overlap.
