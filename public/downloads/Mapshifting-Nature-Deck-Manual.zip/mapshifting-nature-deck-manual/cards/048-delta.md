---
card_number: 48
name: "Delta"
slug: "delta"
scale_band: "6. Landscape and regional system"
scientific_domains: ["sedimentology","coastal science"]
natural_processes: ["deposition","distribution"]
system_functions: ["distributor","threshold"]
spatial_scale: "river-mouth lobes to vast coastal plains"
time_scale: "storms and floods to millennial lobe switching"
core_archetype: "Distributive Edge"
primary_gifts: ["distribution","land building","fertile branching"]
primary_wounds: ["subsidence","fragmentation","starved sediment"]
related_cards: ["volcano", "symbiosis", "fault", "mass-extinction", "wetland", "fungal-fruiting-body", "eclipse", "black-hole"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Delta

## Essence

Accumulation at an ending can create many beginnings.

## Keywords

deposition · distribution · distributor · threshold · land building · fertile branching

## What it is

A delta forms where a sediment-carrying flow enters a standing body of water and deposition builds land or subaqueous deposits faster than removal. River, wave, tide, and basin processes shape its form. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** river-mouth lobes to vast coastal plains.
- **Characteristic time:** storms and floods to millennial lobe switching.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Wetland](041-wetland.md).
- **Larger container:** A useful containing or consequence-level bridge is [Fossil](062-fossil.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Channels divide, migrate, avulse, flood, and abandon lobes; sediment compacts while sea level, storms, vegetation, and human engineering alter elevation and routing. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

At a threshold, one concentrated route can become a branching field of consequence.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Distributive Edge.** Delta deserves its own card because it makes **distributor and threshold** legible through **deposition and distribution** at the landscape and regional system scale. It differs from [Watershed](046-watershed.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Distribution.** At a threshold, one concentrated route can become a branching field of consequence.
- **Land Building.** This capacity becomes available when land building fits the timing, limits, and needs of the larger system.
- **Fertile Branching.** This capacity becomes available when fertile branching fits the timing, limits, and needs of the larger system.

## Wounds

- **Subsidence.** The pattern distorts when subsidence replaces responsive relationship.
- **Fragmentation.** Fragmentation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Starved Sediment.** Starved Sediment appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **distribution** becomes **subsidence** when scale, timing, boundary, or reciprocity is ignored. Delta asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

distribution remains connected to land building while limits are respected; subsidence is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **subsidence, fragmentation, starved sediment**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **distribution, land building, fertile branching** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Wetland](041-wetland.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to deposition and distribution as they actually operate in Delta; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Fossil](062-fossil.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Delta.
- **Deep time:** Consider storms and floods to millennial lobe switching. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with distributive edge: examine both distribution and subsidence. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support land building or produce fragmentation. |
| Creativity | Work with the card's actual process—deposition and distribution—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **distribution** already present, even in a small or quiet form?
2. Where might **subsidence** be shaping the situation?
3. Where do you observe **deposition**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Distributive Edge** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Delta**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **At a threshold, one concentrated route can become a branching field of consequence.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **distribution** while reducing **subsidence**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Delta futures depend on uncertain sediment supply, subsidence, sea-level rise, storms, ecosystem feedbacks, and management choices.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Delta. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Distributive Edge** as the original synthesis for Delta: At a threshold, one concentrated route can become a branching field of consequence. This meaning arises from the sourced description of deposition and distribution, then becomes a reflective lens through the gift of **distribution** and the wound of **subsidence**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Volcano](059-volcano.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Volcano](059-volcano.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Wetland](041-wetland.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Fossil](062-fossil.md) helps identify containing systems and downstream effects.
- **Shared process:** No other core card uses the exact process labels **deposition / distribution**; [Volcano](059-volcano.md) is retained as a contrast, not an equivalence.
- **Shared wound:** [Quark](006-quark.md) also carries the wound **fragmentation**.
- **Natural cycle:** [Phase Transition](017-phase-transition.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Watershed](046-watershed.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Delta at its characteristic scale, with the central visual emphasis on **deposition and distribution** and **distributor and threshold**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [Water Science School](https://www.usgs.gov/special-topics/water-science-school). Accessed 2026-08-23.
- **S02 — NOAA National Ocean Service.** [What is an estuary?](https://oceanservice.noaa.gov/education/tutorial_estuaries/est01_whatis.html). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Delta futures depend on uncertain sediment supply, subsidence, sea-level rise, storms, ecosystem feedbacks, and management choices.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Delta is retained because **Distributive Edge** is not duplicated by Watershed, even where their processes overlap.
