---
card_number: 24
name: "Virus"
slug: "virus"
scale_band: "3. Microscopic and cellular"
scientific_domains: ["virology","evolution"]
natural_processes: ["replication","transmission"]
system_functions: ["carrier","disruptor"]
spatial_scale: "tens to hundreds of nanometres for many virions"
time_scale: "minutes to long evolutionary persistence"
core_archetype: "Borrowed Replicator"
primary_gifts: ["economy","rapid evolution","information transfer"]
primary_wounds: ["exploitation","dependency","runaway propagation"]
related_cards: ["earthquake", "hydrogen", "seed", "photon", "water-molecule", "plasma", "kelp", "pollinator"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Virus

## Essence

A pattern can propagate by using machinery it does not contain.

## Keywords

replication · transmission · carrier · disruptor · economy · rapid evolution · information transfer

## What it is

A virus is a genetic replicator packaged in protein and sometimes lipid that depends on host cells for reproduction. Viruses are not cellular organisms and vary greatly in genome type, structure, and host range. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** tens to hundreds of nanometres for many virions.
- **Characteristic time:** minutes to long evolutionary persistence.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Chemical Bond](014-chemical-bond.md).
- **Larger container:** A useful containing or consequence-level bridge is [Food Web](038-food-web.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Viruses attach, enter, redirect host processes, assemble progeny, and spread. They also shape evolution, population dynamics, gene movement, and marine nutrient cycling. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Propagation without self-sufficiency reveals both the power and danger of borrowed capacity.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Borrowed Replicator.** Virus deserves its own card because it makes **carrier and disruptor** legible through **replication and transmission** at the microscopic and cellular scale. It differs from [DNA](020-dna.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Economy.** Propagation without self-sufficiency reveals both the power and danger of borrowed capacity.
- **Rapid Evolution.** This capacity becomes available when rapid evolution fits the timing, limits, and needs of the larger system.
- **Information Transfer.** This capacity becomes available when information transfer fits the timing, limits, and needs of the larger system.

## Wounds

- **Exploitation.** The pattern distorts when exploitation replaces responsive relationship.
- **Dependency.** Dependency appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Runaway Propagation.** Runaway Propagation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **economy** becomes **exploitation** when scale, timing, boundary, or reciprocity is ignored. Virus asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

economy remains connected to rapid evolution while limits are respected; exploitation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **exploitation, dependency, runaway propagation**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **economy, rapid evolution, information transfer** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Chemical Bond](014-chemical-bond.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to replication and transmission as they actually operate in Virus; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Food Web](038-food-web.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Virus.
- **Deep time:** Consider minutes to long evolutionary persistence. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with borrowed replicator: examine both economy and exploitation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support rapid evolution or produce dependency. |
| Creativity | Work with the card's actual process—replication and transmission—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **economy** already present, even in a small or quiet form?
2. Where might **exploitation** be shaping the situation?
3. Where do you observe **replication**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Borrowed Replicator** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Virus**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Propagation without self-sufficiency reveals both the power and danger of borrowed capacity.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **economy** while reducing **exploitation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Virus origins, global diversity, host-range evolution, and the boundary between viruses and other mobile genetic elements remain open.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Virus. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Borrowed Replicator** as the original synthesis for Virus: Propagation without self-sufficiency reveals both the power and danger of borrowed capacity. This meaning arises from the sourced description of replication and transmission, then becomes a reflective lens through the gift of **economy** and the wound of **exploitation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Earthquake](056-earthquake.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Earthquake](056-earthquake.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Chemical Bond](014-chemical-bond.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Food Web](038-food-web.md) helps identify containing systems and downstream effects.
- **Shared process:** [Photon](001-photon.md) also expresses transmission, but with different constraints.
- **Shared wound:** [Oxygen](012-oxygen.md) also carries the wound **dependency**.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [DNA](020-dna.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Virus at its characteristic scale, with the central visual emphasis on **replication and transmission** and **carrier and disruptor**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NCBI Bookshelf.** [What does it mean to be a virus?](https://www.ncbi.nlm.nih.gov/books/NBK562891/box/box001/?report=objectonly). Accessed 2026-08-23.
- **S02 — NCBI Bookshelf.** [Molecular Biology of the Cell](https://www.ncbi.nlm.nih.gov/books/NBK21054/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Virus origins, global diversity, host-range evolution, and the boundary between viruses and other mobile genetic elements remain open.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Virus is retained because **Borrowed Replicator** is not duplicated by DNA, even where their processes overlap.
