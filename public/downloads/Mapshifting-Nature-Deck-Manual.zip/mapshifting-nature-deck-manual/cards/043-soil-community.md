---
card_number: 43
name: "Soil Community"
slug: "soil-community"
scale_band: "5. Community and ecosystem"
scientific_domains: ["soil ecology","microbiology"]
natural_processes: ["decomposition","exchange"]
system_functions: ["network","recycler"]
spatial_scale: "micropores to landscape soil profiles"
time_scale: "seconds of metabolism to centuries of formation"
core_archetype: "Hidden Commons"
primary_gifts: ["fertility","recycling","distributed labor"]
primary_wounds: ["depletion","compaction","invisible collapse"]
related_cards: ["root", "estuary", "decomposition", "symbiosis", "food-web", "pollinator", "bacterium", "coral-colony"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Soil Community

## Essence

Fertility is produced by a community of exchanges beneath visible growth.

## Keywords

decomposition · exchange · network · recycler · fertility · recycling · distributed labor

## What it is

A soil community includes microbes, fungi, protists, plants, animals, and their interactions with minerals, water, air, and organic matter. It is not merely a list of organisms. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** micropores to landscape soil profiles.
- **Characteristic time:** seconds of metabolism to centuries of formation.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Root](029-root.md).
- **Larger container:** A useful containing or consequence-level bridge is [Watershed](046-watershed.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Soil organisms decompose residues, form aggregates, cycle nutrients, graze one another, build pores, and connect roots with distant resources. Disturbance changes both membership and physical habitat. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Support is an active commons maintained by many often-unseen contributors.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Hidden Commons.** Soil Community deserves its own card because it makes **network and recycler** legible through **decomposition and exchange** at the community and ecosystem scale. It differs from [Symbiosis](037-symbiosis.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Fertility.** Support is an active commons maintained by many often-unseen contributors.
- **Recycling.** This capacity becomes available when recycling fits the timing, limits, and needs of the larger system.
- **Distributed Labor.** This capacity becomes available when distributed labor fits the timing, limits, and needs of the larger system.

## Wounds

- **Depletion.** The pattern distorts when depletion replaces responsive relationship.
- **Compaction.** Compaction appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Invisible Collapse.** Invisible Collapse appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **fertility** becomes **depletion** when scale, timing, boundary, or reciprocity is ignored. Soil Community asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

fertility remains connected to recycling while limits are respected; depletion is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **depletion, compaction, invisible collapse**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **fertility, recycling, distributed labor** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Root](029-root.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to decomposition and exchange as they actually operate in Soil Community; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Watershed](046-watershed.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Soil Community.
- **Deep time:** Consider seconds of metabolism to centuries of formation. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with hidden commons: examine both fertility and depletion. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support recycling or produce compaction. |
| Creativity | Work with the card's actual process—decomposition and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **fertility** already present, even in a small or quiet form?
2. Where might **depletion** be shaping the situation?
3. Where do you observe **decomposition**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Hidden Commons** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Soil Community**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Support is an active commons maintained by many often-unseen contributors.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **fertility** while reducing **depletion**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Most soil species and interactions remain undescribed, and linking community composition to specific functions is challenging.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Soil Community. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Hidden Commons** as the original synthesis for Soil Community: Support is an active commons maintained by many often-unseen contributors. This meaning arises from the sourced description of decomposition and exchange, then becomes a reflective lens through the gift of **fertility** and the wound of **depletion**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Electron](002-electron.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Root](029-root.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Root](029-root.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Watershed](046-watershed.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** [Aquifer](050-aquifer.md) also carries the wound **depletion**.
- **Natural cycle:** [Carbon](011-carbon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Symbiosis](037-symbiosis.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Soil Community at its characteristic scale, with the central visual emphasis on **decomposition and exchange** and **network and recycler**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NCBI Bookshelf.** [The Diversity of Genomes and the Tree of Life](https://www.ncbi.nlm.nih.gov/books/NBK26866/). Accessed 2026-08-23.
- **S02 — U.S. Environmental Protection Agency.** [How do Wetlands Function and Why are they Valuable?](https://www.epa.gov/wetlands/how-do-wetlands-function-and-why-are-they-valuable). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Most soil species and interactions remain undescribed, and linking community composition to specific functions is challenging.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Soil Community is retained because **Hidden Commons** is not duplicated by Symbiosis, even where their processes overlap.
