---
card_number: 46
name: "Watershed"
slug: "watershed"
scale_band: "6. Landscape and regional system"
scientific_domains: ["hydrology","landscape ecology"]
natural_processes: ["routing","accumulation"]
system_functions: ["container","network"]
spatial_scale: "headwater catchment to continental drainage basin"
time_scale: "storm minutes to geologic reorganization"
core_archetype: "Nested Container"
primary_gifts: ["integration","context","accountability"]
primary_wounds: ["accumulated contamination","boundary blindness","downstream burden"]
related_cards: ["glacier", "symbiosis", "fault", "food-web", "soil-community", "kelp-forest", "canyon", "ancient-tree"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Watershed

## Essence

What happens upstream joins a larger shared route.

## Keywords

routing · accumulation · container · network · integration · context · accountability

## What it is

A watershed is the land area from which surface water drains to a common outlet. Watersheds are nested: small catchments join larger basins, while groundwater boundaries may differ from surface divides. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** headwater catchment to continental drainage basin.
- **Characteristic time:** storm minutes to geologic reorganization.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Wetland](041-wetland.md).
- **Larger container:** A useful containing or consequence-level bridge is [Planet](064-planet.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Precipitation infiltrates, evaporates, is stored, or travels downslope through channels and soils, carrying sediment, nutrients, organisms, heat, and contaminants. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Change scale until the full contributing area and downstream consequence become visible.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Nested Container.** Watershed deserves its own card because it makes **container and network** legible through **routing and accumulation** at the landscape and regional system scale. It differs from [Delta](048-delta.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Integration.** Change scale until the full contributing area and downstream consequence become visible.
- **Context.** This capacity becomes available when context fits the timing, limits, and needs of the larger system.
- **Accountability.** This capacity becomes available when accountability fits the timing, limits, and needs of the larger system.

## Wounds

- **Accumulated Contamination.** The pattern distorts when accumulated contamination replaces responsive relationship.
- **Boundary Blindness.** Boundary Blindness appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Downstream Burden.** Downstream Burden appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **integration** becomes **accumulated contamination** when scale, timing, boundary, or reciprocity is ignored. Watershed asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

integration remains connected to context while limits are respected; accumulated contamination is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **accumulated contamination, boundary blindness, downstream burden**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **integration, context, accountability** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Wetland](041-wetland.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to routing and accumulation as they actually operate in Watershed; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Planet](064-planet.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Watershed.
- **Deep time:** Consider storm minutes to geologic reorganization. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with nested container: examine both integration and accumulated contamination. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support context or produce boundary blindness. |
| Creativity | Work with the card's actual process—routing and accumulation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **integration** already present, even in a small or quiet form?
2. Where might **accumulated contamination** be shaping the situation?
3. Where do you observe **routing**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Nested Container** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Watershed**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Change scale until the full contributing area and downstream consequence become visible.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **integration** while reducing **accumulated contamination**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Groundwater connections, temporary streams, changing land cover, and extreme events complicate watershed boundaries and flow predictions.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Watershed. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Nested Container** as the original synthesis for Watershed: Change scale until the full contributing area and downstream consequence become visible. This meaning arises from the sourced description of routing and accumulation, then becomes a reflective lens through the gift of **integration** and the wound of **accumulated contamination**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Ancient Tree](030-ancient-tree.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Glacier](052-glacier.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Wetland](041-wetland.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Planet](064-planet.md) helps identify containing systems and downstream effects.
- **Shared process:** [Ancient Tree](030-ancient-tree.md) also expresses accumulation, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Fault](055-fault.md) offers a nearby systems comparison.
- **Natural cycle:** [Carbon](011-carbon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Delta](048-delta.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Watershed at its characteristic scale, with the central visual emphasis on **routing and accumulation** and **container and network**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [Watersheds and Drainage Basins](https://www.usgs.gov/water-science-school/science/watersheds-and-drainage-basins). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Water Science School](https://www.usgs.gov/special-topics/water-science-school). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Groundwater connections, temporary streams, changing land cover, and extreme events complicate watershed boundaries and flow predictions.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Watershed is retained because **Nested Container** is not duplicated by Delta, even where their processes overlap.
