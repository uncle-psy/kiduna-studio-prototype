---
card_number: 2
name: "Electron"
slug: "electron"
scale_band: "1. Fundamental"
scientific_domains: ["particle physics","atomic physics"]
natural_processes: ["attraction","exchange"]
system_functions: ["carrier","boundary"]
spatial_scale: "smaller than current experimental resolution"
time_scale: "quantum interactions to stable atomic histories"
core_archetype: "Participant"
primary_gifts: ["responsiveness","participation","conductivity"]
primary_wounds: ["reactivity","restlessness","uncontained charge"]
related_cards: ["cell-membrane", "oxygen", "food-web", "tide", "chemical-bond", "gluon", "photon", "gravity"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Electron

## Essence

Relationship changes position, energy, and possibility.

## Keywords

attraction · exchange · carrier · boundary · responsiveness · participation · conductivity

## What it is

The electron is an elementary lepton with negative electric charge. Electrons occupy quantum states around atomic nuclei and are central to chemistry, electricity, and material behavior. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** smaller than current experimental resolution.
- **Characteristic time:** quantum interactions to stable atomic histories.
- **Smaller structures:** This is the deck's lowest scale band. Its quantum fields and interactions are not represented by a still smaller card.
- **Larger container:** A useful containing or consequence-level bridge is [Chemical Bond](014-chemical-bond.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Electrons move between allowed energy states, participate in bonds, and carry current in conductors. They are not tiny planets orbiting a nucleus; orbital language describes probability distributions. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Participation is not passivity: a small mobile part can reorganize the whole field of relation.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Participant.** Electron deserves its own card because it makes **carrier and boundary** legible through **attraction and exchange** at the fundamental scale. It differs from [Photon](001-photon.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Responsiveness.** Participation is not passivity: a small mobile part can reorganize the whole field of relation.
- **Participation.** This capacity becomes available when participation fits the timing, limits, and needs of the larger system.
- **Conductivity.** This capacity becomes available when conductivity fits the timing, limits, and needs of the larger system.

## Wounds

- **Reactivity.** The pattern distorts when reactivity replaces responsive relationship.
- **Restlessness.** Restlessness appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Uncontained Charge.** Uncontained Charge appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **responsiveness** becomes **reactivity** when scale, timing, boundary, or reciprocity is ignored. Electron asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

responsiveness remains connected to participation while limits are respected; reactivity is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **reactivity, restlessness, uncontained charge**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **responsiveness, participation, conductivity** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** At the lower boundary of the deck, shift from object language to fields, interactions, measurement conditions, and quantum states rather than inventing a smaller card.
- **Its own scale:** Attend to attraction and exchange as they actually operate in Electron; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Chemical Bond](014-chemical-bond.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Electron.
- **Deep time:** Consider quantum interactions to stable atomic histories. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with participant: examine both responsiveness and reactivity. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support participation or produce restlessness. |
| Creativity | Work with the card's actual process—attraction and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **responsiveness** already present, even in a small or quiet form?
2. Where might **reactivity** be shaping the situation?
3. Where do you observe **attraction**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Participant** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Electron**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Participation is not passivity: a small mobile part can reorganize the whole field of relation.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **responsiveness** while reducing **reactivity**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Quantum electrodynamics predicts electron behavior with extraordinary precision, while the origin of particle masses and the union of quantum theory with gravity remain open.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Electron. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Participant** as the original synthesis for Electron: Participation is not passivity: a small mobile part can reorganize the whole field of relation. This meaning arises from the sourced description of attraction and exchange, then becomes a reflective lens through the gift of **responsiveness** and the wound of **reactivity**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Gravity](009-gravity.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Cell Membrane](019-cell-membrane.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** No smaller core card is asserted; use the explicit lower-boundary guidance above.
- **Larger scale:** [Chemical Bond](014-chemical-bond.md) helps identify containing systems and downstream effects.
- **Shared process:** [Gluon](007-gluon.md) also expresses exchange, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Food Web](038-food-web.md) offers a nearby systems comparison.
- **Natural cycle:** [Water Molecule](013-water-molecule.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Photon](001-photon.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Electron at its characteristic scale, with the central visual emphasis on **attraction and exchange** and **carrier and boundary**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Department of Energy Office of Science.** [DOE Explains: The Standard Model of Particle Physics](https://www.energy.gov/science/doe-explainsthe-standard-model-particle-physics). Accessed 2026-08-23.
- **S02 — CERN.** [The Standard Model](https://home.cern/science/physics/standard-model). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Quantum electrodynamics predicts electron behavior with extraordinary precision, while the origin of particle masses and the union of quantum theory with gravity remain open.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Electron is retained because **Participant** is not duplicated by Photon, even where their processes overlap.
