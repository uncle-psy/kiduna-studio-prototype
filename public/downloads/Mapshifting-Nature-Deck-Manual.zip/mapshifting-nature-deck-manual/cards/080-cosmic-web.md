---
card_number: 80
name: "Cosmic Web"
slug: "cosmic-web"
scale_band: "9. Stellar and cosmic"
scientific_domains: ["cosmology","large-scale structure"]
natural_processes: ["emergence","flow"]
system_functions: ["network","pattern"]
spatial_scale: "hundreds of millions to billions of light-years"
time_scale: "cosmic history"
core_archetype: "Largest Network"
primary_gifts: ["connection","emergent structure","scale perspective"]
primary_wounds: ["void isolation","filament overload","mistaking map for total reality"]
related_cards: ["galaxy", "planet", "planetary-ring", "river", "glacier", "kelp", "fungal-fruiting-body", "plasma"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Cosmic Web

## Essence

Sparse beginnings can become a vast pattern through persistent attraction and flow.

## Keywords

emergence · flow · network · pattern · connection · emergent structure · scale perspective

## What it is

The cosmic web is the large-scale arrangement of matter into filaments, sheets, nodes, and voids. It emerged as gravity amplified small early density variations, with dark matter providing much of the structure. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** hundreds of millions to billions of light-years.
- **Characteristic time:** cosmic history.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Galaxy](078-galaxy.md).
- **Larger container:** A useful containing or consequence-level bridge is [Expanding Universe](081-expanding-universe.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Matter flows along filaments toward groups and clusters while cosmic expansion stretches space. Galaxies and gas trace the web imperfectly and evolve within it. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Pattern can emerge without a planner when local motion repeatedly responds to a shared field.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Largest Network.** Cosmic Web deserves its own card because it makes **network and pattern** legible through **emergence and flow** at the stellar and cosmic scale. It differs from [Stellar Nursery](074-stellar-nursery.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Connection.** Pattern can emerge without a planner when local motion repeatedly responds to a shared field.
- **Emergent Structure.** This capacity becomes available when emergent structure fits the timing, limits, and needs of the larger system.
- **Scale Perspective.** This capacity becomes available when scale perspective fits the timing, limits, and needs of the larger system.

## Wounds

- **Void Isolation.** The pattern distorts when void isolation replaces responsive relationship.
- **Filament Overload.** Filament Overload appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Mistaking Map For Total Reality.** Mistaking Map For Total Reality appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **connection** becomes **void isolation** when scale, timing, boundary, or reciprocity is ignored. Cosmic Web asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

connection remains connected to emergent structure while limits are respected; void isolation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **void isolation, filament overload, mistaking map for total reality**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **connection, emergent structure, scale perspective** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Galaxy](078-galaxy.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to emergence and flow as they actually operate in Cosmic Web; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Expanding Universe](081-expanding-universe.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Cosmic Web.
- **Deep time:** Consider cosmic history. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with largest network: examine both connection and void isolation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support emergent structure or produce filament overload. |
| Creativity | Work with the card's actual process—emergence and flow—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **connection** already present, even in a small or quiet form?
2. Where might **void isolation** be shaping the situation?
3. Where do you observe **emergence**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Largest Network** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Cosmic Web**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Pattern can emerge without a planner when local motion repeatedly responds to a shared field.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **connection** while reducing **void isolation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Diffuse gas mapping, void physics, galaxy–web coupling, dark-matter nature, and precision growth history remain active research.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Cosmic Web. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Largest Network** as the original synthesis for Cosmic Web: Pattern can emerge without a planner when local motion repeatedly responds to a shared field. This meaning arises from the sourced description of emergence and flow, then becomes a reflective lens through the gift of **connection** and the wound of **void isolation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Plasma](016-plasma.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Planet](064-planet.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Galaxy](078-galaxy.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Expanding Universe](081-expanding-universe.md) helps identify containing systems and downstream effects.
- **Shared process:** [Higgs Field](008-higgs-field.md) also expresses emergence, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Planetary Ring](069-planetary-ring.md) offers a nearby systems comparison.
- **Natural cycle:** [Carbon](011-carbon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Stellar Nursery](074-stellar-nursery.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Cosmic Web at its characteristic scale, with the central visual emphasis on **emergence and flow** and **network and pattern**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Galaxies](https://science.nasa.gov/universe/galaxies/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Universe Overview](https://science.nasa.gov/universe/overview/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Diffuse gas mapping, void physics, galaxy–web coupling, dark-matter nature, and precision growth history remain active research.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Cosmic Web is retained because **Largest Network** is not duplicated by Stellar Nursery, even where their processes overlap.
