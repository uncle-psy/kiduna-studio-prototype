---
card_number: 54
name: "Mountain Range"
slug: "mountain-range"
scale_band: "6. Landscape and regional system"
scientific_domains: ["geomorphology","tectonics"]
natural_processes: ["uplift","erosion"]
system_functions: ["boundary","source"]
spatial_scale: "hundreds to thousands of kilometres"
time_scale: "millions to hundreds of millions of years"
core_archetype: "Raised Boundary"
primary_gifts: ["perspective","water source","climatic differentiation"]
primary_wounds: ["barrier","isolation","unstable slope"]
related_cards: ["canyon", "symbiosis", "forest-canopy", "fault", "river", "planetary-ring", "magnetosphere", "cell-membrane"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Mountain Range

## Essence

Elevation redirects flow while exposing structure to erosion.

## Keywords

uplift · erosion · boundary · source · perspective · water source · climatic differentiation

## What it is

A mountain range is a connected belt of elevated terrain formed through tectonic collision, subduction, extension, volcanism, or combinations, then sculpted by erosion and climate. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** hundreds to thousands of kilometres.
- **Characteristic time:** millions to hundreds of millions of years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Forest Canopy](042-forest-canopy.md).
- **Larger container:** A useful containing or consequence-level bridge is [Tectonic Plate](057-tectonic-plate.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Ranges rise, flex crust, redirect winds and rivers, generate rain shadows, store snow and ice, shed sediment, and evolve as uplift competes with erosion. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

What rises becomes both vantage and barrier, altering every flow that crosses it.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Raised Boundary.** Mountain Range deserves its own card because it makes **boundary and source** legible through **uplift and erosion** at the landscape and regional system scale. It differs from [River](047-river.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Perspective.** What rises becomes both vantage and barrier, altering every flow that crosses it.
- **Water Source.** This capacity becomes available when water source fits the timing, limits, and needs of the larger system.
- **Climatic Differentiation.** This capacity becomes available when climatic differentiation fits the timing, limits, and needs of the larger system.

## Wounds

- **Barrier.** The pattern distorts when barrier replaces responsive relationship.
- **Isolation.** Isolation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Unstable Slope.** Unstable Slope appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **perspective** becomes **barrier** when scale, timing, boundary, or reciprocity is ignored. Mountain Range asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

perspective remains connected to water source while limits are respected; barrier is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **barrier, isolation, unstable slope**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **perspective, water source, climatic differentiation** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Forest Canopy](042-forest-canopy.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to uplift and erosion as they actually operate in Mountain Range; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Tectonic Plate](057-tectonic-plate.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Mountain Range.
- **Deep time:** Consider millions to hundreds of millions of years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with raised boundary: examine both perspective and barrier. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support water source or produce isolation. |
| Creativity | Work with the card's actual process—uplift and erosion—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **perspective** already present, even in a small or quiet form?
2. Where might **barrier** be shaping the situation?
3. Where do you observe **uplift**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Raised Boundary** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Mountain Range**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **What rises becomes both vantage and barrier, altering every flow that crosses it.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **perspective** while reducing **barrier**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Rates and histories of uplift, deep crustal structure, erosion feedbacks, and links between climate and tectonics remain debated for many ranges.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Mountain Range. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Raised Boundary** as the original synthesis for Mountain Range: What rises becomes both vantage and barrier, altering every flow that crosses it. This meaning arises from the sourced description of uplift and erosion, then becomes a reflective lens through the gift of **perspective** and the wound of **barrier**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Canyon](061-canyon.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Symbiosis](037-symbiosis.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Forest Canopy](042-forest-canopy.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Tectonic Plate](057-tectonic-plate.md) helps identify containing systems and downstream effects.
- **Shared process:** [River](047-river.md) also expresses erosion, but with different constraints.
- **Shared wound:** [Cell Membrane](019-cell-membrane.md) also carries the wound **isolation**.
- **Natural cycle:** [Electron](002-electron.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [River](047-river.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Mountain Range at its characteristic scale, with the central visual emphasis on **uplift and erosion** and **boundary and source**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [Plate Tectonics in a Nutshell](https://volcanoes.usgs.gov/about/edu/dynamicplanet/nutshell.php). Accessed 2026-08-23.
- **S02 — NASA Science.** [Earth System Science Research](https://science.nasa.gov/earth-science/research/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Rates and histories of uplift, deep crustal structure, erosion feedbacks, and links between climate and tectonics remain debated for many ranges.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Mountain Range is retained because **Raised Boundary** is not duplicated by River, even where their processes overlap.
