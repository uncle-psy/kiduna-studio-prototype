---
card_number: 9
name: "Gravity"
slug: "gravity"
scale_band: "1. Fundamental"
scientific_domains: ["gravitation","cosmology"]
natural_processes: ["attraction","orbit"]
system_functions: ["field","whole"]
spatial_scale: "from laboratory scales to the observable universe"
time_scale: "continuous; shapes cosmic history"
core_archetype: "Curvature"
primary_gifts: ["orientation","coherence","belonging to a whole"]
primary_wounds: ["collapse","overcentralization","inescapable pull"]
related_cards: ["expanding-universe", "hydrogen", "plasma", "orbit", "electron", "moon", "comet", "galaxy"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Gravity

## Essence

Every path is altered by the larger geometry it inhabits.

## Keywords

attraction · orbit · field · whole · orientation · coherence · belonging to a whole

## What it is

Gravity is the universal interaction associated in general relativity with the curvature of spacetime produced by energy and momentum. It governs falling, orbits, stars, galaxies, and cosmic structure. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** from laboratory scales to the observable universe.
- **Characteristic time:** continuous; shapes cosmic history.
- **Smaller structures:** This is the deck's lowest scale band. Its quantum fields and interactions are not represented by a still smaller card.
- **Larger container:** A useful containing or consequence-level bridge is [Phase Transition](017-phase-transition.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Gravity is weak between elementary particles but accumulates because it is long-range and effectively always attractive for ordinary matter. It bends light and changes the rate at which clocks run. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

The larger field can guide local motion without touching it like a hand.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Curvature.** Gravity deserves its own card because it makes **field and whole** legible through **attraction and orbit** at the fundamental scale. It differs from [Higgs Field](008-higgs-field.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Orientation.** The larger field can guide local motion without touching it like a hand.
- **Coherence.** This capacity becomes available when coherence fits the timing, limits, and needs of the larger system.
- **Belonging To A Whole.** This capacity becomes available when belonging to a whole fits the timing, limits, and needs of the larger system.

## Wounds

- **Collapse.** The pattern distorts when collapse replaces responsive relationship.
- **Overcentralization.** Overcentralization appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Inescapable Pull.** Inescapable Pull appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **orientation** becomes **collapse** when scale, timing, boundary, or reciprocity is ignored. Gravity asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

orientation remains connected to coherence while limits are respected; collapse is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **collapse, overcentralization, inescapable pull**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **orientation, coherence, belonging to a whole** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** At the lower boundary of the deck, shift from object language to fields, interactions, measurement conditions, and quantum states rather than inventing a smaller card.
- **Its own scale:** Attend to attraction and orbit as they actually operate in Gravity; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Phase Transition](017-phase-transition.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Gravity.
- **Deep time:** Consider continuous; shapes cosmic history. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with curvature: examine both orientation and collapse. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support coherence or produce overcentralization. |
| Creativity | Work with the card's actual process—attraction and orbit—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **orientation** already present, even in a small or quiet form?
2. Where might **collapse** be shaping the situation?
3. Where do you observe **attraction**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Curvature** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Gravity**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **The larger field can guide local motion without touching it like a hand.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **orientation** while reducing **collapse**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

A quantum description of gravity is not established, and the nature of dark matter and dark energy complicates the full gravitational account of the cosmos.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Gravity. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Curvature** as the original synthesis for Gravity: The larger field can guide local motion without touching it like a hand. This meaning arises from the sourced description of attraction and orbit, then becomes a reflective lens through the gift of **orientation** and the wound of **collapse**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Electron](002-electron.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Expanding Universe](081-expanding-universe.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** No smaller core card is asserted; use the explicit lower-boundary guidance above.
- **Larger scale:** [Phase Transition](017-phase-transition.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses attraction, but with different constraints.
- **Shared wound:** [Keystone Species](036-keystone-species.md) also carries the wound **overcentralization**.
- **Natural cycle:** [Plasma](016-plasma.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Higgs Field](008-higgs-field.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Gravity at its characteristic scale, with the central visual emphasis on **attraction and orbit** and **field and whole**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Space Place.** [What Is Gravity?](https://spaceplace.nasa.gov/what-is-gravity/en/). Accessed 2026-08-23.
- **S02 — NASA Science.** [What Is the Universe?](https://science.nasa.gov/exoplanets/what-is-the-universe/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** A quantum description of gravity is not established, and the nature of dark matter and dark energy complicates the full gravitational account of the cosmos.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Gravity is retained because **Curvature** is not duplicated by Higgs Field, even where their processes overlap.
