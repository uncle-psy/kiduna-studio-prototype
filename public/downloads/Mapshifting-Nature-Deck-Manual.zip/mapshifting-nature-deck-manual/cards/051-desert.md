---
card_number: 51
name: "Desert"
slug: "desert"
scale_band: "6. Landscape and regional system"
scientific_domains: ["climatology","ecology"]
natural_processes: ["scarcity","adaptation"]
system_functions: ["filter","teacher"]
spatial_scale: "local rain shadow to continental arid zone"
time_scale: "flash events to multimillion-year aridity"
core_archetype: "Sparse Abundance"
primary_gifts: ["efficiency","patience","precision"]
primary_wounds: ["depletion","exposure","romanticizing hardship"]
related_cards: ["forest-canopy", "symbiosis", "fault", "decomposition", "ecological-succession", "wetland", "archaeon", "earthquake"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Desert

## Essence

Scarcity reorganizes timing, storage, and attention.

## Keywords

scarcity · adaptation · filter · teacher · efficiency · patience · precision

## What it is

A desert is a region defined by persistent water limitation rather than temperature; hot and cold deserts arise through atmospheric circulation, rain shadows, continental position, and ocean influence. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** local rain shadow to continental arid zone.
- **Characteristic time:** flash events to multimillion-year aridity.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Soil Community](043-soil-community.md).
- **Larger container:** A useful containing or consequence-level bridge is [Fossil](062-fossil.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Rain may arrive episodically, organisms conserve or rapidly exploit water, winds move sediment, salts accumulate, and biological crusts stabilize surfaces. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

When supply is intermittent, survival depends on timing, storage, and respect for limits.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Sparse Abundance.** Desert deserves its own card because it makes **filter and teacher** legible through **scarcity and adaptation** at the landscape and regional system scale. It differs from [Watershed](046-watershed.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Efficiency.** When supply is intermittent, survival depends on timing, storage, and respect for limits.
- **Patience.** This capacity becomes available when patience fits the timing, limits, and needs of the larger system.
- **Precision.** This capacity becomes available when precision fits the timing, limits, and needs of the larger system.

## Wounds

- **Depletion.** The pattern distorts when depletion replaces responsive relationship.
- **Exposure.** Exposure appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Romanticizing Hardship.** Romanticizing Hardship appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **efficiency** becomes **depletion** when scale, timing, boundary, or reciprocity is ignored. Desert asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

efficiency remains connected to patience while limits are respected; depletion is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **depletion, exposure, romanticizing hardship**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **efficiency, patience, precision** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Soil Community](043-soil-community.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to scarcity and adaptation as they actually operate in Desert; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Fossil](062-fossil.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Desert.
- **Deep time:** Consider flash events to multimillion-year aridity. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with sparse abundance: examine both efficiency and depletion. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support patience or produce exposure. |
| Creativity | Work with the card's actual process—scarcity and adaptation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **efficiency** already present, even in a small or quiet form?
2. Where might **depletion** be shaping the situation?
3. Where do you observe **scarcity**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Sparse Abundance** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Desert**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **When supply is intermittent, survival depends on timing, storage, and respect for limits.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **efficiency** while reducing **depletion**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Desert boundaries and ecosystem responses to warming, precipitation variability, grazing, and biological-crust disturbance are uncertain and region-specific.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Desert. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Sparse Abundance** as the original synthesis for Desert: When supply is intermittent, survival depends on timing, storage, and respect for limits. This meaning arises from the sourced description of scarcity and adaptation, then becomes a reflective lens through the gift of **efficiency** and the wound of **depletion**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Archaeon](023-archaeon.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Fault](055-fault.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Soil Community](043-soil-community.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Fossil](062-fossil.md) helps identify containing systems and downstream effects.
- **Shared process:** [Archaeon](023-archaeon.md) also expresses adaptation, but with different constraints.
- **Shared wound:** [Photon](001-photon.md) also carries the wound **exposure**.
- **Natural cycle:** [Cell Membrane](019-cell-membrane.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Watershed](046-watershed.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Desert at its characteristic scale, with the central visual emphasis on **scarcity and adaptation** and **filter and teacher**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Earth System Science Research](https://science.nasa.gov/earth-science/research/). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Water Science School](https://www.usgs.gov/special-topics/water-science-school). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Desert boundaries and ecosystem responses to warming, precipitation variability, grazing, and biological-crust disturbance are uncertain and region-specific.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Desert is retained because **Sparse Abundance** is not duplicated by Watershed, even where their processes overlap.
