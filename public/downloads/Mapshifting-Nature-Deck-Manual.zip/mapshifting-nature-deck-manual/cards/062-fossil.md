---
card_number: 62
name: "Fossil"
slug: "fossil"
scale_band: "7. Geologic and continental"
scientific_domains: ["paleontology","geology"]
natural_processes: ["preservation","interpretation"]
system_functions: ["memory","ancestor"]
spatial_scale: "microscopic trace to giant skeleton"
time_scale: "thousands to billions of years"
core_archetype: "Partial Witness"
primary_gifts: ["memory","evidence","ancestral perspective"]
primary_wounds: ["selection bias","frozen narrative","absence mistaken for nonexistence"]
related_cards: ["aquifer", "watershed", "planet", "ancient-tree", "glacier", "comet", "fault", "canyon"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Fossil

## Essence

The surviving record is evidence shaped by what could be preserved.

## Keywords

preservation · interpretation · memory · ancestor · evidence · ancestral perspective

## What it is

A fossil is preserved evidence of past life, including body parts, impressions, tracks, burrows, chemical signatures, and microscopic remains. Fossilization is rare and strongly selective. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** microscopic trace to giant skeleton.
- **Characteristic time:** thousands to billions of years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [DNA](020-dna.md).
- **Larger container:** A useful containing or consequence-level bridge is [Planet](064-planet.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Burial, mineral replacement, compression, freezing, drying, amber, and other pathways preserve different information. Erosion and discovery later expose a partial record. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Evidence speaks through both what survives and the filters that determined survival.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Partial Witness.** Fossil deserves its own card because it makes **memory and ancestor** legible through **preservation and interpretation** at the geologic and continental scale. It differs from [Fault](055-fault.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Memory.** Evidence speaks through both what survives and the filters that determined survival.
- **Evidence.** This capacity becomes available when evidence fits the timing, limits, and needs of the larger system.
- **Ancestral Perspective.** This capacity becomes available when ancestral perspective fits the timing, limits, and needs of the larger system.

## Wounds

- **Selection Bias.** The pattern distorts when selection bias replaces responsive relationship.
- **Frozen Narrative.** Frozen Narrative appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Absence Mistaken For Nonexistence.** Absence Mistaken For Nonexistence appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **memory** becomes **selection bias** when scale, timing, boundary, or reciprocity is ignored. Fossil asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

memory remains connected to evidence while limits are respected; selection bias is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **selection bias, frozen narrative, absence mistaken for nonexistence**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **memory, evidence, ancestral perspective** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [DNA](020-dna.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to preservation and interpretation as they actually operate in Fossil; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Planet](064-planet.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Fossil.
- **Deep time:** Consider thousands to billions of years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with partial witness: examine both memory and selection bias. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support evidence or produce frozen narrative. |
| Creativity | Work with the card's actual process—preservation and interpretation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **memory** already present, even in a small or quiet form?
2. Where might **selection bias** be shaping the situation?
3. Where do you observe **preservation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Partial Witness** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Fossil**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Evidence speaks through both what survives and the filters that determined survival.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **memory** while reducing **selection bias**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Most organisms never fossilize; dating, classification, behavior, soft tissues, and evolutionary relationships may remain uncertain or be revised.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Fossil. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Partial Witness** as the original synthesis for Fossil: Evidence speaks through both what survives and the filters that determined survival. This meaning arises from the sourced description of preservation and interpretation, then becomes a reflective lens through the gift of **memory** and the wound of **selection bias**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Aquifer](050-aquifer.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Aquifer](050-aquifer.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [DNA](020-dna.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Planet](064-planet.md) helps identify containing systems and downstream effects.
- **Shared process:** No other core card uses the exact process labels **preservation / interpretation**; [Aquifer](050-aquifer.md) is retained as a contrast, not an equivalence.
- **Shared wound:** No other core card repeats this exact primary wound set; [Planet](064-planet.md) offers a nearby systems comparison.
- **Natural cycle:** [DNA](020-dna.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Fault](055-fault.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Fossil at its characteristic scale, with the central visual emphasis on **preservation and interpretation** and **memory and ancestor**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [Fossils, Rocks, and Time: Introduction](https://pubs.usgs.gov/gip/fossils/intro.html). Accessed 2026-08-23.
- **S02 — Smithsonian National Museum of Natural History.** [Extinction Over Time](https://naturalhistory.si.edu/education/teaching-resources/paleontology/extinction-over-time). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Most organisms never fossilize; dating, classification, behavior, soft tissues, and evolutionary relationships may remain uncertain or be revised.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Fossil is retained because **Partial Witness** is not duplicated by Fault, even where their processes overlap.
