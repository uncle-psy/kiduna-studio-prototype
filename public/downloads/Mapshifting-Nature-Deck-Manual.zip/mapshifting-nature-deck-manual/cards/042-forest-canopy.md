---
card_number: 42
name: "Forest Canopy"
slug: "forest-canopy"
scale_band: "5. Community and ecosystem"
scientific_domains: ["forest ecology","climatology"]
natural_processes: ["capture","regulation"]
system_functions: ["boundary","filter"]
spatial_scale: "tree crowns to continental forest belts"
time_scale: "daily exchange to centuries of development"
core_archetype: "Living Roof"
primary_gifts: ["capture","shelter","layered habitat"]
primary_wounds: ["closure","light exclusion","windthrow exposure"]
related_cards: ["cell-membrane", "keystone-species", "watershed", "desert", "mountain-range", "ancient-tree", "fault", "electron"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Forest Canopy

## Essence

The upper boundary receives force first and distributes what enters below.

## Keywords

capture · regulation · boundary · filter · shelter · layered habitat

## What it is

A forest canopy is the three-dimensional layer formed by tree crowns and associated organisms. Its gaps, strata, leaf area, and species composition regulate light, heat, water, gas exchange, and habitat. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** tree crowns to continental forest belts.
- **Characteristic time:** daily exchange to centuries of development.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Ancient Tree](030-ancient-tree.md).
- **Larger container:** A useful containing or consequence-level bridge is [Mountain Range](054-mountain-range.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Leaves intercept radiation and rain, exchange carbon dioxide and water, and respond to wind and drought. Disturbance opens gaps that alter conditions throughout the forest. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Protection and productivity depend on a permeable upper layer with openings, depth, and renewal.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Living Roof.** Forest Canopy deserves its own card because it makes **boundary and filter** legible through **capture and regulation** at the community and ecosystem scale. It differs from [Symbiosis](037-symbiosis.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Capture.** Protection and productivity depend on a permeable upper layer with openings, depth, and renewal.
- **Shelter.** This capacity becomes available when shelter fits the timing, limits, and needs of the larger system.
- **Layered Habitat.** This capacity becomes available when layered habitat fits the timing, limits, and needs of the larger system.

## Wounds

- **Closure.** The pattern distorts when closure replaces responsive relationship.
- **Light Exclusion.** Light Exclusion appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Windthrow Exposure.** Windthrow Exposure appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **capture** becomes **closure** when scale, timing, boundary, or reciprocity is ignored. Forest Canopy asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

capture remains connected to shelter while limits are respected; closure is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **closure, light exclusion, windthrow exposure**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **capture, shelter, layered habitat** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Ancient Tree](030-ancient-tree.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to capture and regulation as they actually operate in Forest Canopy; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Mountain Range](054-mountain-range.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Forest Canopy.
- **Deep time:** Consider daily exchange to centuries of development. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with living roof: examine both capture and closure. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support shelter or produce light exclusion. |
| Creativity | Work with the card's actual process—capture and regulation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **capture** already present, even in a small or quiet form?
2. Where might **closure** be shaping the situation?
3. Where do you observe **capture**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Living Roof** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Forest Canopy**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Protection and productivity depend on a permeable upper layer with openings, depth, and renewal.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **capture** while reducing **closure**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Canopies are hard to measure; global responses to drought, elevated carbon dioxide, fire, insects, and compound disturbances remain uncertain.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Forest Canopy. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Living Roof** as the original synthesis for Forest Canopy: Protection and productivity depend on a permeable upper layer with openings, depth, and renewal. This meaning arises from the sourced description of capture and regulation, then becomes a reflective lens through the gift of **capture** and the wound of **closure**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Cell Membrane](019-cell-membrane.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Mountain Range](054-mountain-range.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Ancient Tree](030-ancient-tree.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Mountain Range](054-mountain-range.md) helps identify containing systems and downstream effects.
- **Shared process:** [Cell Membrane](019-cell-membrane.md) also expresses regulation, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Watershed](046-watershed.md) offers a nearby systems comparison.
- **Natural cycle:** [Electron](002-electron.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Symbiosis](037-symbiosis.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Forest Canopy at its characteristic scale, with the central visual emphasis on **capture and regulation** and **boundary and filter**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — USDA Forest Service Research.** [Advances in understanding canopy development in forest trees](https://research.fs.usda.gov/treesearch/59369). Accessed 2026-08-23.
- **S02 — USDA Forest Service Research.** [New findings about old-growth forests](https://research.fs.usda.gov/treesearch/7320). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Canopies are hard to measure; global responses to drought, elevated carbon dioxide, fire, insects, and compound disturbances remain uncertain.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Forest Canopy is retained because **Living Roof** is not duplicated by Symbiosis, even where their processes overlap.
