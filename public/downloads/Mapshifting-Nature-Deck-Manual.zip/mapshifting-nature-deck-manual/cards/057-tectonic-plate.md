---
card_number: 57
name: "Tectonic Plate"
slug: "tectonic-plate"
scale_band: "7. Geologic and continental"
scientific_domains: ["plate tectonics","geodynamics"]
natural_processes: ["drift","interaction"]
system_functions: ["carrier","whole"]
spatial_scale: "thousands of kilometres across"
time_scale: "millions to hundreds of millions of years"
core_archetype: "Moving Foundation"
primary_gifts: ["coherent movement","renewal","large-scale context"]
primary_wounds: ["collision","boundary stress","illusion of fixed ground"]
related_cards: ["plankton", "watershed", "planet", "mantle-convection", "ocean-current", "tide", "river", "glacier"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Tectonic Plate

## Essence

A foundation can be coherent and still be in motion.

## Keywords

drift · interaction · carrier · whole · coherent movement · renewal · large-scale context

## What it is

A tectonic plate is a coherent segment of Earth's rigid lithosphere moving relative to other plates over the more deformable asthenosphere. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** thousands of kilometres across.
- **Characteristic time:** millions to hundreds of millions of years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Mountain Range](054-mountain-range.md).
- **Larger container:** A useful containing or consequence-level bridge is [Planet](064-planet.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Plates diverge, converge, slide past one another, bend, fragment, and carry continents and seafloor. New oceanic lithosphere forms while older lithosphere is recycled at subduction zones. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Stability may mean moving together, not remaining fixed in absolute space.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Moving Foundation.** Tectonic Plate deserves its own card because it makes **carrier and whole** legible through **drift and interaction** at the geologic and continental scale. It differs from [Fault](055-fault.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Coherent Movement.** Stability may mean moving together, not remaining fixed in absolute space.
- **Renewal.** This capacity becomes available when renewal fits the timing, limits, and needs of the larger system.
- **Large-Scale Context.** This capacity becomes available when large-scale context fits the timing, limits, and needs of the larger system.

## Wounds

- **Collision.** The pattern distorts when collision replaces responsive relationship.
- **Boundary Stress.** Boundary Stress appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Illusion Of Fixed Ground.** Illusion Of Fixed Ground appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **coherent movement** becomes **collision** when scale, timing, boundary, or reciprocity is ignored. Tectonic Plate asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

coherent movement remains connected to renewal while limits are respected; collision is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **collision, boundary stress, illusion of fixed ground**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **coherent movement, renewal, large-scale context** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Mountain Range](054-mountain-range.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to drift and interaction as they actually operate in Tectonic Plate; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Planet](064-planet.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Tectonic Plate.
- **Deep time:** Consider millions to hundreds of millions of years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with moving foundation: examine both coherent movement and collision. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support renewal or produce boundary stress. |
| Creativity | Work with the card's actual process—drift and interaction—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **coherent movement** already present, even in a small or quiet form?
2. Where might **collision** be shaping the situation?
3. Where do you observe **drift**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Moving Foundation** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Tectonic Plate**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Stability may mean moving together, not remaining fixed in absolute space.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **coherent movement** while reducing **collision**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

The relative importance of slab pull, mantle flow, ridge forces, plate-edge processes, and deep coupling remains actively studied.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Tectonic Plate. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Moving Foundation** as the original synthesis for Tectonic Plate: Stability may mean moving together, not remaining fixed in absolute space. This meaning arises from the sourced description of drift and interaction, then becomes a reflective lens through the gift of **coherent movement** and the wound of **collision**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Higgs Field](008-higgs-field.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Plankton](026-plankton.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Mountain Range](054-mountain-range.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Planet](064-planet.md) helps identify containing systems and downstream effects.
- **Shared process:** [Higgs Field](008-higgs-field.md) also expresses interaction, but with different constraints.
- **Shared wound:** [Planetary Ring](069-planetary-ring.md) also carries the wound **collision**.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Fault](055-fault.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Tectonic Plate at its characteristic scale, with the central visual emphasis on **drift and interaction** and **carrier and whole**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [Plate Tectonics in a Nutshell](https://volcanoes.usgs.gov/about/edu/dynamicplanet/nutshell.php). Accessed 2026-08-23.
- **S02 — NASA Science.** [Earth System Science Research](https://science.nasa.gov/earth-science/research/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** The relative importance of slab pull, mantle flow, ridge forces, plate-edge processes, and deep coupling remains actively studied.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Tectonic Plate is retained because **Moving Foundation** is not duplicated by Fault, even where their processes overlap.
