# Card Files


This directory contains the 81 canonical core cards. Each file has YAML front matter for later structured-data conversion and a full human-readable entry. Card numbers and slugs are stable for this edition.

## Card construction rule

Every card includes scientific description, observed behavior, scale, transferable pattern, archetype, gifts and wounds, balanced/over/underexpression, scale and time shifts, reading applications, questions, safe practice, uncertainty, cultural-integrity note, original synthesis, relationships, a future visual brief, sources, and research notes.

See the [complete card index](../indexes/CARD-INDEX.md), [template](../templates/CARD-TEMPLATE.md), and [audit](../research/AUDIT-REPORT.md).
