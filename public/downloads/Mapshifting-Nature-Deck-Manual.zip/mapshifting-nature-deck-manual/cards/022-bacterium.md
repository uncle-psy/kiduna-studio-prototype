---
card_number: 22
name: "Bacterium"
slug: "bacterium"
scale_band: "3. Microscopic and cellular"
scientific_domains: ["microbiology","ecology"]
natural_processes: ["metabolism","replication"]
system_functions: ["builder","recycler"]
spatial_scale: "typically micrometres"
time_scale: "minutes to dormancy lasting far longer"
core_archetype: "Metabolic Inventor"
primary_gifts: ["adaptability","metabolic invention","collective impact"]
primary_wounds: ["unchecked growth","pathogenic imbalance","resource exhaustion"]
related_cards: ["archaeon", "hydrogen", "seed", "chemical-bond", "crystal-lattice", "coral-colony", "decomposition", "ecological-succession"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description; open questions noted"
card_type: "entity"
status: complete
---

# Bacterium

## Essence

Small lives can transform planetary chemistry through repeated local acts.

## Keywords

metabolism · replication · builder · recycler · adaptability · metabolic invention · collective impact

## What it is

Bacteria are one of the three domains of cellular life. They lack a membrane-bound nucleus yet possess diverse cell structures, metabolisms, genomes, and ecological roles. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** typically micrometres.
- **Characteristic time:** minutes to dormancy lasting far longer.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Hydrogen](010-hydrogen.md).
- **Larger container:** A useful containing or consequence-level bridge is [Microbiome](027-microbiome.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Bacteria divide, exchange genes, form biofilms, enter dormancy, and metabolize an enormous range of compounds. Some cause disease; many more sustain nutrient cycles, hosts, soils, waters, and industry. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Scale can convert repetition into planetary consequence.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Metabolic Inventor.** Bacterium deserves its own card because it makes **builder and recycler** legible through **metabolism and replication** at the microscopic and cellular scale. It differs from [DNA](020-dna.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Adaptability.** Scale can convert repetition into planetary consequence.
- **Metabolic Invention.** This capacity becomes available when metabolic invention fits the timing, limits, and needs of the larger system.
- **Collective Impact.** This capacity becomes available when collective impact fits the timing, limits, and needs of the larger system.

## Wounds

- **Unchecked Growth.** The pattern distorts when unchecked growth replaces responsive relationship.
- **Pathogenic Imbalance.** Pathogenic Imbalance appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Resource Exhaustion.** Resource Exhaustion appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **adaptability** becomes **unchecked growth** when scale, timing, boundary, or reciprocity is ignored. Bacterium asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

adaptability remains connected to metabolic invention while limits are respected; unchecked growth is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **unchecked growth, pathogenic imbalance, resource exhaustion**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **adaptability, metabolic invention, collective impact** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Hydrogen](010-hydrogen.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to metabolism and replication as they actually operate in Bacterium; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Microbiome](027-microbiome.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Bacterium.
- **Deep time:** Consider minutes to dormancy lasting far longer. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with metabolic inventor: examine both adaptability and unchecked growth. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support metabolic invention or produce pathogenic imbalance. |
| Creativity | Work with the card's actual process—metabolism and replication—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **adaptability** already present, even in a small or quiet form?
2. Where might **unchecked growth** be shaping the situation?
3. Where do you observe **metabolism**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Metabolic Inventor** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Bacterium**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Scale can convert repetition into planetary consequence.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **adaptability** while reducing **unchecked growth**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Most bacterial diversity has not been cultured, and the functions and ecological interactions of many lineages remain unknown.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Bacterium. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Metabolic Inventor** as the original synthesis for Bacterium: Scale can convert repetition into planetary consequence. This meaning arises from the sourced description of metabolism and replication, then becomes a reflective lens through the gift of **adaptability** and the wound of **unchecked growth**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Archaeon](023-archaeon.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Chemical Bond](014-chemical-bond.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Hydrogen](010-hydrogen.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Microbiome](027-microbiome.md) helps identify containing systems and downstream effects.
- **Shared process:** [DNA](020-dna.md) also expresses replication, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Seed](028-seed.md) offers a nearby systems comparison.
- **Natural cycle:** [Proton](003-proton.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [DNA](020-dna.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Bacterium at its characteristic scale, with the central visual emphasis on **metabolism and replication** and **builder and recycler**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NCBI Bookshelf.** [The Diversity of Genomes and the Tree of Life](https://www.ncbi.nlm.nih.gov/books/NBK26866/). Accessed 2026-08-23.
- **S02 — NCBI Bookshelf.** [Molecular Biology of the Cell](https://www.ncbi.nlm.nih.gov/books/NBK21054/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Most bacterial diversity has not been cultured, and the functions and ecological interactions of many lineages remain unknown.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Bacterium is retained because **Metabolic Inventor** is not duplicated by DNA, even where their processes overlap.
