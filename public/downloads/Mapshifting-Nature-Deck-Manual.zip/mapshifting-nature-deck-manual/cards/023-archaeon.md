---
card_number: 23
name: "Archaeon"
slug: "archaeon"
scale_band: "3. Microscopic and cellular"
scientific_domains: ["microbiology","evolution"]
natural_processes: ["adaptation","metabolism"]
system_functions: ["ancestor","transformer"]
spatial_scale: "typically micrometres"
time_scale: "minutes to evolutionary deep time"
core_archetype: "Deep-Lineage Adapter"
primary_gifts: ["persistence","unusual metabolism","evolutionary perspective"]
primary_wounds: ["misclassification","overspecialization","invisibility"]
related_cards: ["mitochondrion", "hydrogen", "seed", "bacterium", "phase-transition", "oxygen", "ancient-tree", "pollinator"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Archaeon

## Essence

A life can resemble its neighbors while carrying a profoundly different history.

## Keywords

adaptation · metabolism · ancestor · transformer · persistence · unusual metabolism · evolutionary perspective

## What it is

Archaea form a domain of cellular life distinct from Bacteria and Eukarya. Many have unique membrane lipids and molecular systems; archaeal information-processing machinery often resembles eukaryotic machinery. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** typically micrometres.
- **Characteristic time:** minutes to evolutionary deep time.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Hydrogen](010-hydrogen.md).
- **Larger container:** A useful containing or consequence-level bridge is [Microbiome](027-microbiome.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Archaea inhabit oceans, soils, sediments, hosts, and extreme environments. Their metabolisms include methane production, ammonia oxidation, and many still-unclear ecological functions. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Similarity of outward form does not erase difference in lineage, mechanism, or role.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Deep-Lineage Adapter.** Archaeon deserves its own card because it makes **ancestor and transformer** legible through **adaptation and metabolism** at the microscopic and cellular scale. It differs from [DNA](020-dna.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Persistence.** Similarity of outward form does not erase difference in lineage, mechanism, or role.
- **Unusual Metabolism.** This capacity becomes available when unusual metabolism fits the timing, limits, and needs of the larger system.
- **Evolutionary Perspective.** This capacity becomes available when evolutionary perspective fits the timing, limits, and needs of the larger system.

## Wounds

- **Misclassification.** The pattern distorts when misclassification replaces responsive relationship.
- **Overspecialization.** Overspecialization appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Invisibility.** Invisibility appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **persistence** becomes **misclassification** when scale, timing, boundary, or reciprocity is ignored. Archaeon asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

persistence remains connected to unusual metabolism while limits are respected; misclassification is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **misclassification, overspecialization, invisibility**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **persistence, unusual metabolism, evolutionary perspective** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Hydrogen](010-hydrogen.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to adaptation and metabolism as they actually operate in Archaeon; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Microbiome](027-microbiome.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Archaeon.
- **Deep time:** Consider minutes to evolutionary deep time. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with deep-lineage adapter: examine both persistence and misclassification. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support unusual metabolism or produce overspecialization. |
| Creativity | Work with the card's actual process—adaptation and metabolism—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **persistence** already present, even in a small or quiet form?
2. Where might **misclassification** be shaping the situation?
3. Where do you observe **adaptation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Deep-Lineage Adapter** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Archaeon**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Similarity of outward form does not erase difference in lineage, mechanism, or role.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **persistence** while reducing **misclassification**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Archaeal diversity, nomenclature, evolutionary relationships, and ecosystem functions are rapidly changing as uncultivated genomes are discovered.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Archaeon. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Deep-Lineage Adapter** as the original synthesis for Archaeon: Similarity of outward form does not erase difference in lineage, mechanism, or role. This meaning arises from the sourced description of adaptation and metabolism, then becomes a reflective lens through the gift of **persistence** and the wound of **misclassification**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Desert](051-desert.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Phase Transition](017-phase-transition.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Hydrogen](010-hydrogen.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Microbiome](027-microbiome.md) helps identify containing systems and downstream effects.
- **Shared process:** [Mitochondrion](021-mitochondrion.md) also expresses metabolism, but with different constraints.
- **Shared wound:** [Neutron](004-neutron.md) also carries the wound **invisibility**.
- **Natural cycle:** [Oxygen](012-oxygen.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [DNA](020-dna.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Archaeon at its characteristic scale, with the central visual emphasis on **adaptation and metabolism** and **ancestor and transformer**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NCBI Taxonomy.** [Taxonomy Browser: Archaea](https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id=2157&mode=Info). Accessed 2026-08-23.
- **S02 — NCBI Bookshelf.** [The Diversity of Genomes and the Tree of Life](https://www.ncbi.nlm.nih.gov/books/NBK26866/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Archaeal diversity, nomenclature, evolutionary relationships, and ecosystem functions are rapidly changing as uncultivated genomes are discovered.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Archaeon is retained because **Deep-Lineage Adapter** is not duplicated by DNA, even where their processes overlap.
