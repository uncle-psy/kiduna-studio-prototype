---
card_number: 40
name: "Ecological Succession"
slug: "ecological-succession"
scale_band: "5. Community and ecosystem"
scientific_domains: ["ecology","restoration science"]
natural_processes: ["succession","regeneration"]
system_functions: ["clock","builder"]
spatial_scale: "patch to landscape"
time_scale: "years to centuries"
core_archetype: "Changing Assembly"
primary_gifts: ["regeneration","development","facilitation"]
primary_wounds: ["stalled transition","erased history","myth of one climax"]
related_cards: ["coral-reef", "ancient-tree", "watershed", "kelp", "coral-colony", "bacterium", "seed", "lichen"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "process"
status: complete
---

# Ecological Succession

## Essence

Recovery is a sequence of changing conditions, not a return along one guaranteed path.

## Keywords

succession · regeneration · clock · builder · development · facilitation

## What it is

Ecological succession is change in community composition and structure following new substrate, disturbance, or shifting conditions. Multiple pathways, feedbacks, and legacies replace the older idea of one inevitable climax. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** patch to landscape.
- **Characteristic time:** years to centuries.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Lichen](031-lichen.md).
- **Larger container:** A useful containing or consequence-level bridge is [Watershed](046-watershed.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Colonists alter soil, shade, nutrients, and habitat; later arrivals may be facilitated, inhibited, or unaffected. Disturbance can redirect or reset parts of the sequence. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Each stage changes the conditions of possibility for what can follow.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Changing Assembly.** Ecological Succession deserves its own card because it makes **clock and builder** legible through **succession and regeneration** at the community and ecosystem scale. It differs from [Decomposition](039-decomposition.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Regeneration.** Each stage changes the conditions of possibility for what can follow.
- **Development.** This capacity becomes available when development fits the timing, limits, and needs of the larger system.
- **Facilitation.** This capacity becomes available when facilitation fits the timing, limits, and needs of the larger system.

## Wounds

- **Stalled Transition.** The pattern distorts when stalled transition replaces responsive relationship.
- **Erased History.** Erased History appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Myth Of One Climax.** Myth Of One Climax appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **regeneration** becomes **stalled transition** when scale, timing, boundary, or reciprocity is ignored. Ecological Succession asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

regeneration remains connected to development while limits are respected; stalled transition is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **stalled transition, erased history, myth of one climax**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **regeneration, development, facilitation** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Lichen](031-lichen.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to succession and regeneration as they actually operate in Ecological Succession; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Watershed](046-watershed.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Ecological Succession.
- **Deep time:** Consider years to centuries. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with changing assembly: examine both regeneration and stalled transition. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support development or produce erased history. |
| Creativity | Work with the card's actual process—succession and regeneration—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **regeneration** already present, even in a small or quiet form?
2. Where might **stalled transition** be shaping the situation?
3. Where do you observe **succession**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Changing Assembly** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Ecological Succession**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Each stage changes the conditions of possibility for what can follow.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **regeneration** while reducing **stalled transition**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Forecasting succession is difficult because dispersal, climate, disturbance, species interactions, and historical contingencies differ across sites.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Ecological Succession. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Changing Assembly** as the original synthesis for Ecological Succession: Each stage changes the conditions of possibility for what can follow. This meaning arises from the sourced description of succession and regeneration, then becomes a reflective lens through the gift of **regeneration** and the wound of **stalled transition**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Ancient Tree](030-ancient-tree.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Coral Reef](045-coral-reef.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Lichen](031-lichen.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Watershed](046-watershed.md) helps identify containing systems and downstream effects.
- **Shared process:** [Ancient Tree](030-ancient-tree.md) also expresses regeneration, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Watershed](046-watershed.md) offers a nearby systems comparison.
- **Natural cycle:** [Proton](003-proton.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Decomposition](039-decomposition.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Ecological Succession at its characteristic scale, with the central visual emphasis on **succession and regeneration** and **clock and builder**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. National Park Service.** [Plant Succession at Kenai Fjords](https://www.nps.gov/kefj/learn/nature/plant-succession.htm). Accessed 2026-08-23.
- **S02 — USDA Forest Service Research.** [New findings about old-growth forests](https://research.fs.usda.gov/treesearch/7320). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Forecasting succession is difficult because dispersal, climate, disturbance, species interactions, and historical contingencies differ across sites.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Ecological Succession is retained because **Changing Assembly** is not duplicated by Decomposition, even where their processes overlap.
