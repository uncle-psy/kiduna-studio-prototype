---
card_number: 70
name: "Magnetosphere"
slug: "magnetosphere"
scale_band: "8. Planetary and orbital"
scientific_domains: ["space physics","plasma physics"]
natural_processes: ["deflection","reconnection"]
system_functions: ["protector","boundary"]
spatial_scale: "planetary radius to millions of kilometres downstream"
time_scale: "seconds to billion-year field evolution"
core_archetype: "Responsive Shield"
primary_gifts: ["deflection","buffering","dynamic protection"]
primary_wounds: ["overexposure","trapped radiation","shield mistaken for seal"]
related_cards: ["fault", "star", "mountain-range", "electron", "planetary-ring", "earthquake", "tectonic-plate", "subduction-zone"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Magnetosphere

## Essence

Protection is an active negotiation with the incoming flow.

## Keywords

deflection · reconnection · protector · boundary · buffering · dynamic protection

## What it is

A magnetosphere is the region where a body's magnetic field strongly organizes charged-particle motion, shaped by interaction with stellar wind, plasma, and internal field sources. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** planetary radius to millions of kilometres downstream.
- **Characteristic time:** seconds to billion-year field evolution.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Plasma](016-plasma.md).
- **Larger container:** A useful containing or consequence-level bridge is [Star](073-star.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

It compresses on the starward side, forms a tail, stores and releases energy through reconnection, and can trap radiation or channel particles into auroras and atmospheres. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A shield remains protective by flexing, redirecting, and sometimes releasing what it receives.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Responsive Shield.** Magnetosphere deserves its own card because it makes **protector and boundary** legible through **deflection and reconnection** at the planetary and orbital scale. It differs from [Orbit](066-orbit.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Deflection.** A shield remains protective by flexing, redirecting, and sometimes releasing what it receives.
- **Buffering.** This capacity becomes available when buffering fits the timing, limits, and needs of the larger system.
- **Dynamic Protection.** This capacity becomes available when dynamic protection fits the timing, limits, and needs of the larger system.

## Wounds

- **Overexposure.** The pattern distorts when overexposure replaces responsive relationship.
- **Trapped Radiation.** Trapped Radiation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Shield Mistaken For Seal.** Shield Mistaken For Seal appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **deflection** becomes **overexposure** when scale, timing, boundary, or reciprocity is ignored. Magnetosphere asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

deflection remains connected to buffering while limits are respected; overexposure is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **overexposure, trapped radiation, shield mistaken for seal**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **deflection, buffering, dynamic protection** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Plasma](016-plasma.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to deflection and reconnection as they actually operate in Magnetosphere; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Star](073-star.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Magnetosphere.
- **Deep time:** Consider seconds to billion-year field evolution. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with responsive shield: examine both deflection and overexposure. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support buffering or produce trapped radiation. |
| Creativity | Work with the card's actual process—deflection and reconnection—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **deflection** already present, even in a small or quiet form?
2. Where might **overexposure** be shaping the situation?
3. Where do you observe **deflection**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Responsive Shield** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Magnetosphere**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A shield remains protective by flexing, redirecting, and sometimes releasing what it receives.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **deflection** while reducing **overexposure**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Magnetic reconnection, particle acceleration, space-weather coupling, and long-term planetary-field evolution remain active research.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Magnetosphere. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Responsive Shield** as the original synthesis for Magnetosphere: A shield remains protective by flexing, redirecting, and sometimes releasing what it receives. This meaning arises from the sourced description of deflection and reconnection, then becomes a reflective lens through the gift of **deflection** and the wound of **overexposure**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Fault](055-fault.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Fault](055-fault.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Plasma](016-plasma.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Star](073-star.md) helps identify containing systems and downstream effects.
- **Shared process:** No other core card uses the exact process labels **deflection / reconnection**; [Fault](055-fault.md) is retained as a contrast, not an equivalence.
- **Shared wound:** No other core card repeats this exact primary wound set; [Mountain Range](054-mountain-range.md) offers a nearby systems comparison.
- **Natural cycle:** [Electron](002-electron.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Orbit](066-orbit.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Magnetosphere at its characteristic scale, with the central visual emphasis on **deflection and reconnection** and **protector and boundary**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NASA Science.** [Earth's Magnetosphere](https://science.nasa.gov/heliophysics/focus-areas/magnetosphere-ionosphere/). Accessed 2026-08-23.
- **S02 — NASA Science.** [Solar System Exploration](https://science.nasa.gov/solar-system/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Magnetic reconnection, particle acceleration, space-weather coupling, and long-term planetary-field evolution remain active research.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Magnetosphere is retained because **Responsive Shield** is not duplicated by Orbit, even where their processes overlap.
