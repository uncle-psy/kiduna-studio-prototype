---
card_number: 53
name: "Ocean Current"
slug: "ocean-current"
scale_band: "6. Landscape and regional system"
scientific_domains: ["oceanography","climate science"]
natural_processes: ["circulation","transport"]
system_functions: ["carrier","regulator"]
spatial_scale: "coastal channel to global overturning circulation"
time_scale: "seconds to millennia"
core_archetype: "Planetary Circulation"
primary_gifts: ["distribution","climate regulation","connection"]
primary_wounds: ["stagnation","misrouting","hidden dependency"]
related_cards: ["mantle-convection", "symbiosis", "food-web", "tectonic-plate", "plankton", "kelp-forest", "atmosphere", "tide"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "process"
status: complete
---

# Ocean Current

## Essence

A system redistributes difference rather than eliminating it.

## Keywords

circulation · transport · carrier · regulator · distribution · climate regulation · connection

## What it is

An ocean current is sustained seawater motion driven by wind, density differences, tides, pressure gradients, Earth's rotation, and basin geometry. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** coastal channel to global overturning circulation.
- **Characteristic time:** seconds to millennia.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Kelp Forest](044-kelp-forest.md).
- **Larger container:** A useful containing or consequence-level bridge is [Atmosphere](071-atmosphere.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Currents transport heat, salt, nutrients, oxygen, organisms, sediment, and pollutants; they interact across surface, deep, coastal, and eddy scales. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Circulation links distant conditions and converts local imbalance into system-wide movement.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Planetary Circulation.** Ocean Current deserves its own card because it makes **carrier and regulator** legible through **circulation and transport** at the landscape and regional system scale. It differs from [Plankton](026-plankton.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Distribution.** Circulation links distant conditions and converts local imbalance into system-wide movement.
- **Climate Regulation.** This capacity becomes available when climate regulation fits the timing, limits, and needs of the larger system.
- **Connection.** This capacity becomes available when connection fits the timing, limits, and needs of the larger system.

## Wounds

- **Stagnation.** The pattern distorts when stagnation replaces responsive relationship.
- **Misrouting.** Misrouting appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Hidden Dependency.** Hidden Dependency appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **distribution** becomes **stagnation** when scale, timing, boundary, or reciprocity is ignored. Ocean Current asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

distribution remains connected to climate regulation while limits are respected; stagnation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **stagnation, misrouting, hidden dependency**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **distribution, climate regulation, connection** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Kelp Forest](044-kelp-forest.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to circulation and transport as they actually operate in Ocean Current; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Atmosphere](071-atmosphere.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Ocean Current.
- **Deep time:** Consider seconds to millennia. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with planetary circulation: examine both distribution and stagnation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support climate regulation or produce misrouting. |
| Creativity | Work with the card's actual process—circulation and transport—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **distribution** already present, even in a small or quiet form?
2. Where might **stagnation** be shaping the situation?
3. Where do you observe **circulation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Planetary Circulation** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Ocean Current**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Circulation links distant conditions and converts local imbalance into system-wide movement.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **distribution** while reducing **stagnation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Future changes in major currents, eddy effects, mixing rates, and interactions with atmosphere and ice remain active research.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Ocean Current. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Planetary Circulation** as the original synthesis for Ocean Current: Circulation links distant conditions and converts local imbalance into system-wide movement. This meaning arises from the sourced description of circulation and transport, then becomes a reflective lens through the gift of **distribution** and the wound of **stagnation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Atmosphere](071-atmosphere.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Symbiosis](037-symbiosis.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Kelp Forest](044-kelp-forest.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Atmosphere](071-atmosphere.md) helps identify containing systems and downstream effects.
- **Shared process:** [Mantle Convection](060-mantle-convection.md) also expresses circulation, but with different constraints.
- **Shared wound:** [Microbiome](027-microbiome.md) also carries the wound **hidden dependency**.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Plankton](026-plankton.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Ocean Current at its characteristic scale, with the central visual emphasis on **circulation and transport** and **carrier and regulator**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NOAA National Ocean Service.** [What is a current?](https://oceanservice.noaa.gov/facts/current.html). Accessed 2026-08-23.
- **S02 — NASA Science.** [Earth System Science Research](https://science.nasa.gov/earth-science/research/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Future changes in major currents, eddy effects, mixing rates, and interactions with atmosphere and ice remain active research.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Ocean Current is retained because **Planetary Circulation** is not duplicated by Plankton, even where their processes overlap.
