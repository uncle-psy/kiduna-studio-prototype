---
card_number: 61
name: "Canyon"
slug: "canyon"
scale_band: "7. Geologic and continental"
scientific_domains: ["geomorphology","hydrology"]
natural_processes: ["erosion","incision"]
system_functions: ["memory","revelation"]
spatial_scale: "local gorge to hundreds of kilometres"
time_scale: "flood events to millions of years"
core_archetype: "Exposed Record"
primary_gifts: ["discernment","depth","revealed history"]
primary_wounds: ["entrenchment","isolation","erosion without renewal"]
related_cards: ["river", "planet", "mountain-range", "glacier", "aquifer", "eclipse", "watershed", "comet"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Canyon

## Essence

Removal can reveal sequence and create a path through resistance.

## Keywords

erosion · incision · memory · revelation · discernment · depth · revealed history

## What it is

A canyon is a steep-sided valley cut by rivers, floods, mass movement, weathering, tectonic uplift, or combinations. Its walls can expose layered geologic records. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** local gorge to hundreds of kilometres.
- **Characteristic time:** flood events to millions of years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [River](047-river.md).
- **Larger container:** A useful containing or consequence-level bridge is [Planet](064-planet.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Water and sediment abrade and pluck rock, slopes fail, tributaries join, and uplift changes gradients. Incision alternates with deposition and widening. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Depth comes from persistent removal, but the resulting path can also confine movement.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Exposed Record.** Canyon deserves its own card because it makes **memory and revelation** legible through **erosion and incision** at the geologic and continental scale. It differs from [Fault](055-fault.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Discernment.** Depth comes from persistent removal, but the resulting path can also confine movement.
- **Depth.** This capacity becomes available when depth fits the timing, limits, and needs of the larger system.
- **Revealed History.** This capacity becomes available when revealed history fits the timing, limits, and needs of the larger system.

## Wounds

- **Entrenchment.** The pattern distorts when entrenchment replaces responsive relationship.
- **Isolation.** Isolation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Erosion Without Renewal.** Erosion Without Renewal appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **discernment** becomes **entrenchment** when scale, timing, boundary, or reciprocity is ignored. Canyon asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

discernment remains connected to depth while limits are respected; entrenchment is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **entrenchment, isolation, erosion without renewal**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **discernment, depth, revealed history** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [River](047-river.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to erosion and incision as they actually operate in Canyon; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Planet](064-planet.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Canyon.
- **Deep time:** Consider flood events to millions of years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with exposed record: examine both discernment and entrenchment. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support depth or produce isolation. |
| Creativity | Work with the card's actual process—erosion and incision—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **discernment** already present, even in a small or quiet form?
2. Where might **entrenchment** be shaping the situation?
3. Where do you observe **erosion**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Exposed Record** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Canyon**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Depth comes from persistent removal, but the resulting path can also confine movement.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **discernment** while reducing **entrenchment**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Canyon histories depend on uncertain past flow, uplift, rock strength, drainage capture, and episodic extreme events.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Canyon. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Exposed Record** as the original synthesis for Canyon: Depth comes from persistent removal, but the resulting path can also confine movement. This meaning arises from the sourced description of erosion and incision, then becomes a reflective lens through the gift of **discernment** and the wound of **entrenchment**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [River](047-river.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Aquifer](050-aquifer.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [River](047-river.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Planet](064-planet.md) helps identify containing systems and downstream effects.
- **Shared process:** [River](047-river.md) also expresses erosion, but with different constraints.
- **Shared wound:** [Cell Membrane](019-cell-membrane.md) also carries the wound **isolation**.
- **Natural cycle:** [DNA](020-dna.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Fault](055-fault.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Canyon at its characteristic scale, with the central visual emphasis on **erosion and incision** and **memory and revelation**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [Water Science School](https://www.usgs.gov/special-topics/water-science-school). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Fossils, Rocks, and Time: Introduction](https://pubs.usgs.gov/gip/fossils/intro.html). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Canyon histories depend on uncertain past flow, uplift, rock strength, drainage capture, and episodic extreme events.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Canyon is retained because **Exposed Record** is not duplicated by Fault, even where their processes overlap.
