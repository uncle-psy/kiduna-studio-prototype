---
card_number: 29
name: "Root"
slug: "root"
scale_band: "4. Organism"
scientific_domains: ["botany","soil ecology"]
natural_processes: ["absorption","exchange"]
system_functions: ["anchor","network"]
spatial_scale: "root hairs to landscape-spanning systems"
time_scale: "days of growth to organismal lifetimes"
core_archetype: "Hidden Negotiator"
primary_gifts: ["anchoring","resource sensing","reciprocity"]
primary_wounds: ["entrenchment","resource capture","hidden depletion"]
related_cards: ["soil-community", "cell-membrane", "symbiosis", "food-web", "mitochondrion", "microbiome", "kelp-forest", "pollinator"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Root

## Essence

Grounding is an exchange with what supports you.

## Keywords

absorption · exchange · anchor · network · anchoring · resource sensing · reciprocity

## What it is

Roots anchor many vascular plants, absorb and transport water and nutrients, store compounds, sense conditions, and interact with fungi, microbes, neighboring roots, and soil structure. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** root hairs to landscape-spanning systems.
- **Characteristic time:** days of growth to organismal lifetimes.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Cell Membrane](019-cell-membrane.md).
- **Larger container:** A useful containing or consequence-level bridge is [Soil Community](043-soil-community.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Root tips grow through heterogeneous soil, branch in response to resources and obstacles, exude compounds, and continually lose and replace fine roots. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Grounding is not static attachment but exploratory, reciprocal contact with a medium.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Hidden Negotiator.** Root deserves its own card because it makes **anchor and network** legible through **absorption and exchange** at the organism scale. It differs from [Seed](028-seed.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Anchoring.** Grounding is not static attachment but exploratory, reciprocal contact with a medium.
- **Resource Sensing.** This capacity becomes available when resource sensing fits the timing, limits, and needs of the larger system.
- **Reciprocity.** This capacity becomes available when reciprocity fits the timing, limits, and needs of the larger system.

## Wounds

- **Entrenchment.** The pattern distorts when entrenchment replaces responsive relationship.
- **Resource Capture.** Resource Capture appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Hidden Depletion.** Hidden Depletion appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **anchoring** becomes **entrenchment** when scale, timing, boundary, or reciprocity is ignored. Root asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

anchoring remains connected to resource sensing while limits are respected; entrenchment is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **entrenchment, resource capture, hidden depletion**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **anchoring, resource sensing, reciprocity** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Cell Membrane](019-cell-membrane.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to absorption and exchange as they actually operate in Root; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Soil Community](043-soil-community.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Root.
- **Deep time:** Consider days of growth to organismal lifetimes. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with hidden negotiator: examine both anchoring and entrenchment. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support resource sensing or produce resource capture. |
| Creativity | Work with the card's actual process—absorption and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **anchoring** already present, even in a small or quiet form?
2. Where might **entrenchment** be shaping the situation?
3. Where do you observe **absorption**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Hidden Negotiator** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Root**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Grounding is not static attachment but exploratory, reciprocal contact with a medium.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **anchoring** while reducing **entrenchment**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Root architecture and belowground signaling are difficult to observe; species, soils, microbes, and climate produce highly contextual outcomes.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Root. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Hidden Negotiator** as the original synthesis for Root: Grounding is not static attachment but exploratory, reciprocal contact with a medium. This meaning arises from the sourced description of absorption and exchange, then becomes a reflective lens through the gift of **anchoring** and the wound of **entrenchment**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Chemical Bond](014-chemical-bond.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Soil Community](043-soil-community.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Cell Membrane](019-cell-membrane.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Soil Community](043-soil-community.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** [Canyon](061-canyon.md) also carries the wound **entrenchment**.
- **Natural cycle:** [Carbon](011-carbon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Seed](028-seed.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Root at its characteristic scale, with the central visual emphasis on **absorption and exchange** and **anchor and network**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — USDA Forest Service.** [Plant of the Week and Plant Biology Resources](https://www.fs.usda.gov/wildflowers/plant-of-the-week/). Accessed 2026-08-23.
- **S02 — U.S. Environmental Protection Agency.** [How do Wetlands Function and Why are they Valuable?](https://www.epa.gov/wetlands/how-do-wetlands-function-and-why-are-they-valuable). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Root architecture and belowground signaling are difficult to observe; species, soils, microbes, and climate produce highly contextual outcomes.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Root is retained because **Hidden Negotiator** is not duplicated by Seed, even where their processes overlap.
