---
card_number: 21
name: "Mitochondrion"
slug: "mitochondrion"
scale_band: "3. Microscopic and cellular"
scientific_domains: ["cell biology","evolution"]
natural_processes: ["metabolism","exchange"]
system_functions: ["transformer","powerhouse"]
spatial_scale: "roughly 0.5–10 micrometres"
time_scale: "seconds for energy turnover to organismal inheritance"
core_archetype: "Inner Transformer"
primary_gifts: ["energy conversion","integration","metabolic flexibility"]
primary_wounds: ["burnout","damaged inheritance","power detached from need"]
related_cards: ["archaeon", "oxygen", "root", "pollinator", "cell-membrane", "chemical-bond", "symbiosis", "phase-transition"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Mitochondrion

## Essence

Capacity grows when an old partnership becomes integrated without becoming inert.

## Keywords

metabolism · exchange · transformer · powerhouse · energy conversion · integration · metabolic flexibility

## What it is

Mitochondria are membrane-bound organelles in most eukaryotic cells. They generate much cellular ATP through respiration and also participate in metabolism, signaling, calcium regulation, and programmed cell death. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** roughly 0.5–10 micrometres.
- **Characteristic time:** seconds for energy turnover to organismal inheritance.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Oxygen](012-oxygen.md).
- **Larger container:** A useful containing or consequence-level bridge is [Ancient Tree](030-ancient-tree.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Mitochondria maintain their own genomes, divide, fuse, move, and are removed when damaged. Their bacterial ancestry reflects an ancient endosymbiotic integration. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A deeply integrated partnership can become infrastructure while retaining its own history.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Inner Transformer.** Mitochondrion deserves its own card because it makes **transformer and powerhouse** legible through **metabolism and exchange** at the microscopic and cellular scale. It differs from [DNA](020-dna.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Energy Conversion.** A deeply integrated partnership can become infrastructure while retaining its own history.
- **Integration.** This capacity becomes available when integration fits the timing, limits, and needs of the larger system.
- **Metabolic Flexibility.** This capacity becomes available when metabolic flexibility fits the timing, limits, and needs of the larger system.

## Wounds

- **Burnout.** The pattern distorts when burnout replaces responsive relationship.
- **Damaged Inheritance.** Damaged Inheritance appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Power Detached From Need.** Power Detached From Need appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **energy conversion** becomes **burnout** when scale, timing, boundary, or reciprocity is ignored. Mitochondrion asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

energy conversion remains connected to integration while limits are respected; burnout is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **burnout, damaged inheritance, power detached from need**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **energy conversion, integration, metabolic flexibility** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Oxygen](012-oxygen.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to metabolism and exchange as they actually operate in Mitochondrion; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Ancient Tree](030-ancient-tree.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Mitochondrion.
- **Deep time:** Consider seconds for energy turnover to organismal inheritance. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with inner transformer: examine both energy conversion and burnout. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support integration or produce damaged inheritance. |
| Creativity | Work with the card's actual process—metabolism and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **energy conversion** already present, even in a small or quiet form?
2. Where might **burnout** be shaping the situation?
3. Where do you observe **metabolism**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Inner Transformer** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Mitochondrion**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A deeply integrated partnership can become infrastructure while retaining its own history.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **energy conversion** while reducing **burnout**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

The sequence and diversity of early endosymbiotic events, mitochondrial signaling networks, and causes of many mitochondrial disorders remain active research.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Mitochondrion. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Inner Transformer** as the original synthesis for Mitochondrion: A deeply integrated partnership can become infrastructure while retaining its own history. This meaning arises from the sourced description of metabolism and exchange, then becomes a reflective lens through the gift of **energy conversion** and the wound of **burnout**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Chemical Bond](014-chemical-bond.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Pollinator](035-pollinator.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Oxygen](012-oxygen.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Ancient Tree](030-ancient-tree.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Root](029-root.md) offers a nearby systems comparison.
- **Natural cycle:** [Oxygen](012-oxygen.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [DNA](020-dna.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Mitochondrion at its characteristic scale, with the central visual emphasis on **metabolism and exchange** and **transformer and powerhouse**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NCBI Bookshelf.** [Molecular Biology of the Cell](https://www.ncbi.nlm.nih.gov/books/NBK21054/). Accessed 2026-08-23.
- **S02 — National Human Genome Research Institute.** [Deoxyribonucleic Acid (DNA) Fact Sheet](https://www.genome.gov/about-genomics/fact-sheets/Deoxyribonucleic-Acid-Fact-Sheet). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** The sequence and diversity of early endosymbiotic events, mitochondrial signaling networks, and causes of many mitochondrial disorders remain active research.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Mitochondrion is retained because **Inner Transformer** is not duplicated by DNA, even where their processes overlap.
