---
card_number: 52
name: "Glacier"
slug: "glacier"
scale_band: "6. Landscape and regional system"
scientific_domains: ["glaciology","hydrology"]
natural_processes: ["accumulation","flow"]
system_functions: ["memory","carrier"]
spatial_scale: "mountain glacier to continental ice sheet"
time_scale: "seasonal mass balance to hundred-thousand-year cycles"
core_archetype: "Slow River"
primary_gifts: ["storage","deep memory","patient force"]
primary_wounds: ["locked capacity","delayed consequence","rapid loss after slow formation"]
related_cards: ["river", "symbiosis", "fault", "watershed", "canyon", "ancient-tree", "kelp", "plasma"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Glacier

## Essence

What appears still may be moving, recording, and reshaping the world.

## Keywords

accumulation · flow · memory · carrier · storage · deep memory · patient force

## What it is

A glacier is persistent land ice formed where accumulated snow compacts and recrystallizes faster than it is lost over many years. Gravity drives deformation and basal motion. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** mountain glacier to continental ice sheet.
- **Characteristic time:** seasonal mass balance to hundred-thousand-year cycles.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Ecological Succession](040-ecological-succession.md).
- **Larger container:** A useful containing or consequence-level bridge is [Canyon](061-canyon.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Glaciers flow, fracture, erode, transport rock, store freshwater, advance or retreat as mass balance changes, and leave landforms and sediment records. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Slow accumulation can create immense force, while slow systems may cross into rapid loss.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Slow River.** Glacier deserves its own card because it makes **memory and carrier** legible through **accumulation and flow** at the landscape and regional system scale. It differs from [River](047-river.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Storage.** Slow accumulation can create immense force, while slow systems may cross into rapid loss.
- **Deep Memory.** This capacity becomes available when deep memory fits the timing, limits, and needs of the larger system.
- **Patient Force.** This capacity becomes available when patient force fits the timing, limits, and needs of the larger system.

## Wounds

- **Locked Capacity.** The pattern distorts when locked capacity replaces responsive relationship.
- **Delayed Consequence.** Delayed Consequence appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Rapid Loss After Slow Formation.** Rapid Loss After Slow Formation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **storage** becomes **locked capacity** when scale, timing, boundary, or reciprocity is ignored. Glacier asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

storage remains connected to deep memory while limits are respected; locked capacity is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **locked capacity, delayed consequence, rapid loss after slow formation**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **storage, deep memory, patient force** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Ecological Succession](040-ecological-succession.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to accumulation and flow as they actually operate in Glacier; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Canyon](061-canyon.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Glacier.
- **Deep time:** Consider seasonal mass balance to hundred-thousand-year cycles. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with slow river: examine both storage and locked capacity. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support deep memory or produce delayed consequence. |
| Creativity | Work with the card's actual process—accumulation and flow—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **storage** already present, even in a small or quiet form?
2. Where might **locked capacity** be shaping the situation?
3. Where do you observe **accumulation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Slow River** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Glacier**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Slow accumulation can create immense force, while slow systems may cross into rapid loss.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **storage** while reducing **locked capacity**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Ice dynamics, basal conditions, regional precipitation, feedbacks, and future mass loss contain important uncertainties despite clear global trends.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Glacier. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Slow River** as the original synthesis for Glacier: Slow accumulation can create immense force, while slow systems may cross into rapid loss. This meaning arises from the sourced description of accumulation and flow, then becomes a reflective lens through the gift of **storage** and the wound of **locked capacity**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Watershed](046-watershed.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Symbiosis](037-symbiosis.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Ecological Succession](040-ecological-succession.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Canyon](061-canyon.md) helps identify containing systems and downstream effects.
- **Shared process:** [Plasma](016-plasma.md) also expresses flow, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Fault](055-fault.md) offers a nearby systems comparison.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [River](047-river.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Glacier at its characteristic scale, with the central visual emphasis on **accumulation and flow** and **memory and carrier**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [Glaciers and Icecaps](https://www.usgs.gov/water-science-school/science/glaciers-and-icecaps). Accessed 2026-08-23.
- **S02 — NASA Science.** [Earth System Science Research](https://science.nasa.gov/earth-science/research/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Ice dynamics, basal conditions, regional precipitation, feedbacks, and future mass loss contain important uncertainties despite clear global trends.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Glacier is retained because **Slow River** is not duplicated by River, even where their processes overlap.
