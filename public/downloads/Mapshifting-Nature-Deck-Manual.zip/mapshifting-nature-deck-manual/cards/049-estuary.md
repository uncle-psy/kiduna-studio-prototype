---
card_number: 49
name: "Estuary"
slug: "estuary"
scale_band: "6. Landscape and regional system"
scientific_domains: ["estuarine science","oceanography"]
natural_processes: ["mixing","exchange"]
system_functions: ["threshold","nursery"]
spatial_scale: "river mouth or coastal basin"
time_scale: "tidal hours to centuries of geomorphic change"
core_archetype: "Mixing Threshold"
primary_gifts: ["mixing","nursery habitat","translation between systems"]
primary_wounds: ["salinity stress","pollutant concentration","loss of gradient"]
related_cards: ["tide", "symbiosis", "fault", "food-web", "soil-community", "volcano", "mass-extinction", "wetland"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Estuary

## Essence

A boundary can be a productive gradient rather than a clean dividing line.

## Keywords

mixing · exchange · threshold · nursery · nursery habitat · translation between systems

## What it is

An estuary is a partly enclosed water body where waters of different sources and chemistry—commonly river freshwater and seawater—meet and mix. Geology and circulation create many estuary types. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** river mouth or coastal basin.
- **Characteristic time:** tidal hours to centuries of geomorphic change.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Wetland](041-wetland.md).
- **Larger container:** A useful containing or consequence-level bridge is [Watershed](046-watershed.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Tides, river flow, wind, density, sediment, nutrients, and organisms create shifting salinity and oxygen gradients. Estuaries exchange materials with watersheds and coasts. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Productive translation occurs in gradients that neither erase difference nor stop exchange.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Mixing Threshold.** Estuary deserves its own card because it makes **threshold and nursery** legible through **mixing and exchange** at the landscape and regional system scale. It differs from [Watershed](046-watershed.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Mixing.** Productive translation occurs in gradients that neither erase difference nor stop exchange.
- **Nursery Habitat.** This capacity becomes available when nursery habitat fits the timing, limits, and needs of the larger system.
- **Translation Between Systems.** This capacity becomes available when translation between systems fits the timing, limits, and needs of the larger system.

## Wounds

- **Salinity Stress.** The pattern distorts when salinity stress replaces responsive relationship.
- **Pollutant Concentration.** Pollutant Concentration appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Loss Of Gradient.** Loss Of Gradient appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **mixing** becomes **salinity stress** when scale, timing, boundary, or reciprocity is ignored. Estuary asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

mixing remains connected to nursery habitat while limits are respected; salinity stress is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **salinity stress, pollutant concentration, loss of gradient**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **mixing, nursery habitat, translation between systems** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Wetland](041-wetland.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to mixing and exchange as they actually operate in Estuary; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Watershed](046-watershed.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Estuary.
- **Deep time:** Consider tidal hours to centuries of geomorphic change. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with mixing threshold: examine both mixing and salinity stress. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support nursery habitat or produce pollutant concentration. |
| Creativity | Work with the card's actual process—mixing and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **mixing** already present, even in a small or quiet form?
2. Where might **salinity stress** be shaping the situation?
3. Where do you observe **mixing**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Mixing Threshold** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Estuary**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Productive translation occurs in gradients that neither erase difference nor stop exchange.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **mixing** while reducing **salinity stress**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Local circulation, hypoxia, sediment response, species shifts, and sea-level adaptation can be highly uncertain and site-specific.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Estuary. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Mixing Threshold** as the original synthesis for Estuary: Productive translation occurs in gradients that neither erase difference nor stop exchange. This meaning arises from the sourced description of mixing and exchange, then becomes a reflective lens through the gift of **mixing** and the wound of **salinity stress**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Electron](002-electron.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Tide](072-tide.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Wetland](041-wetland.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Watershed](046-watershed.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Fault](055-fault.md) offers a nearby systems comparison.
- **Natural cycle:** [Phase Transition](017-phase-transition.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Watershed](046-watershed.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Estuary at its characteristic scale, with the central visual emphasis on **mixing and exchange** and **threshold and nursery**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NOAA National Ocean Service.** [What is an estuary?](https://oceanservice.noaa.gov/education/tutorial_estuaries/est01_whatis.html). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Watersheds and Drainage Basins](https://www.usgs.gov/water-science-school/science/watersheds-and-drainage-basins). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Local circulation, hypoxia, sediment response, species shifts, and sea-level adaptation can be highly uncertain and site-specific.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Estuary is retained because **Mixing Threshold** is not duplicated by Watershed, even where their processes overlap.
