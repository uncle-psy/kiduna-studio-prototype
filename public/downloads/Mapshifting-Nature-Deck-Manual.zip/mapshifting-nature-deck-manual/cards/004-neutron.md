---
card_number: 4
name: "Neutron"
slug: "neutron"
scale_band: "1. Fundamental"
scientific_domains: ["particle physics","nuclear physics"]
natural_processes: ["binding","decay"]
system_functions: ["regulator","stabilizer"]
spatial_scale: "about 0.8 femtometres"
time_scale: "minutes when free; often stable in nuclei"
core_archetype: "Quiet Binder"
primary_gifts: ["stabilization","moderation","hidden contribution"]
primary_wounds: ["invisibility","decay outside belonging","muted agency"]
related_cards: ["proton", "hydrogen", "chemical-bond", "quark", "gluon", "carbon", "water-molecule", "microbiome"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Neutron

## Essence

What seems neutral may be carrying the conditions for stability.

## Keywords

binding · decay · regulator · stabilizer · stabilization · moderation · hidden contribution

## What it is

A neutron is an electrically neutral hadron composed mainly of one up quark and two down quarks. In most atomic nuclei, neutrons help strong-force binding overcome proton–proton electrical repulsion. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** about 0.8 femtometres.
- **Characteristic time:** minutes when free; often stable in nuclei.
- **Smaller structures:** This is the deck's lowest scale band. Its quantum fields and interactions are not represented by a still smaller card.
- **Larger container:** A useful containing or consequence-level bridge is [Hydrogen](010-hydrogen.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

A free neutron undergoes beta decay, but a neutron bound in a stable nucleus may persist. Different neutron counts create isotopes with distinct stability and nuclear properties. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Neutrality can be an active contribution whose value depends on the container.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Quiet Binder.** Neutron deserves its own card because it makes **regulator and stabilizer** legible through **binding and decay** at the fundamental scale. It differs from [Photon](001-photon.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Stabilization.** Neutrality can be an active contribution whose value depends on the container.
- **Moderation.** This capacity becomes available when moderation fits the timing, limits, and needs of the larger system.
- **Hidden Contribution.** This capacity becomes available when hidden contribution fits the timing, limits, and needs of the larger system.

## Wounds

- **Invisibility.** The pattern distorts when invisibility replaces responsive relationship.
- **Decay Outside Belonging.** Decay Outside Belonging appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Muted Agency.** Muted Agency appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **stabilization** becomes **invisibility** when scale, timing, boundary, or reciprocity is ignored. Neutron asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

stabilization remains connected to moderation while limits are respected; invisibility is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **invisibility, decay outside belonging, muted agency**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **stabilization, moderation, hidden contribution** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** At the lower boundary of the deck, shift from object language to fields, interactions, measurement conditions, and quantum states rather than inventing a smaller card.
- **Its own scale:** Attend to binding and decay as they actually operate in Neutron; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Hydrogen](010-hydrogen.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Neutron.
- **Deep time:** Consider minutes when free; often stable in nuclei. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with quiet binder: examine both stabilization and invisibility. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support moderation or produce decay outside belonging. |
| Creativity | Work with the card's actual process—binding and decay—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **stabilization** already present, even in a small or quiet form?
2. Where might **invisibility** be shaping the situation?
3. Where do you observe **binding**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Quiet Binder** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Neutron**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Neutrality can be an active contribution whose value depends on the container.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **stabilization** while reducing **invisibility**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Precise neutron-lifetime measurements disagree slightly by method, and neutron-rich matter remains a major research subject.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Neutron. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Quiet Binder** as the original synthesis for Neutron: Neutrality can be an active contribution whose value depends on the container. This meaning arises from the sourced description of binding and decay, then becomes a reflective lens through the gift of **stabilization** and the wound of **invisibility**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Chemical Bond](014-chemical-bond.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Chemical Bond](014-chemical-bond.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** No smaller core card is asserted; use the explicit lower-boundary guidance above.
- **Larger scale:** [Hydrogen](010-hydrogen.md) helps identify containing systems and downstream effects.
- **Shared process:** [Proton](003-proton.md) also expresses binding, but with different constraints.
- **Shared wound:** [Archaeon](023-archaeon.md) also carries the wound **invisibility**.
- **Natural cycle:** [Microbiome](027-microbiome.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Photon](001-photon.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Neutron at its characteristic scale, with the central visual emphasis on **binding and decay** and **regulator and stabilizer**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Department of Energy Office of Science.** [DOE Explains: The Standard Model of Particle Physics](https://www.energy.gov/science/doe-explainsthe-standard-model-particle-physics). Accessed 2026-08-23.
- **S02 — CERN.** [The Standard Model](https://home.cern/science/physics/standard-model). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Precise neutron-lifetime measurements disagree slightly by method, and neutron-rich matter remains a major research subject.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Neutron is retained because **Quiet Binder** is not duplicated by Photon, even where their processes overlap.
