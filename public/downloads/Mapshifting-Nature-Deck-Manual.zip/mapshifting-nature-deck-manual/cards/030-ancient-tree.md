---
card_number: 30
name: "Ancient Tree"
slug: "ancient-tree"
scale_band: "4. Organism"
scientific_domains: ["forest ecology","dendrology"]
natural_processes: ["accumulation","regeneration"]
system_functions: ["memory","ancestor"]
spatial_scale: "individual organism with landscape influence"
time_scale: "centuries to millennia"
core_archetype: "Living Archive"
primary_gifts: ["continuity","witness","structural habitat"]
primary_wounds: ["inflexibility","accumulated damage","mistaking age for invulnerability"]
related_cards: ["ecological-succession", "cell-membrane", "glacier", "fossil", "dna", "archaeon", "forest-canopy", "watershed"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Ancient Tree

## Essence

Longevity is a history of repair, disturbance, and continued exchange.

## Keywords

accumulation · regeneration · memory · ancestor · continuity · witness · structural habitat

## What it is

An ancient tree is an individual that has survived for an exceptional span relative to its species. Age is not identical with size; slow growth, disturbance history, and site conditions matter. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** individual organism with landscape influence.
- **Characteristic time:** centuries to millennia.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Mitochondrion](021-mitochondrion.md).
- **Larger container:** A useful containing or consequence-level bridge is [Forest Canopy](042-forest-canopy.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Old trees compartmentalize damage, add new tissues, shed limbs, host many organisms, store carbon, and alter local light, water, and soil. They remain living and vulnerable, not timeless monuments. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Endurance is repeated adjustment that leaves a layered record.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Living Archive.** Ancient Tree deserves its own card because it makes **memory and ancestor** legible through **accumulation and regeneration** at the organism scale. It differs from [Seed](028-seed.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Continuity.** Endurance is repeated adjustment that leaves a layered record.
- **Witness.** This capacity becomes available when witness fits the timing, limits, and needs of the larger system.
- **Structural Habitat.** This capacity becomes available when structural habitat fits the timing, limits, and needs of the larger system.

## Wounds

- **Inflexibility.** The pattern distorts when inflexibility replaces responsive relationship.
- **Accumulated Damage.** Accumulated Damage appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Mistaking Age For Invulnerability.** Mistaking Age For Invulnerability appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **continuity** becomes **inflexibility** when scale, timing, boundary, or reciprocity is ignored. Ancient Tree asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

continuity remains connected to witness while limits are respected; inflexibility is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **inflexibility, accumulated damage, mistaking age for invulnerability**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **continuity, witness, structural habitat** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Mitochondrion](021-mitochondrion.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to accumulation and regeneration as they actually operate in Ancient Tree; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Forest Canopy](042-forest-canopy.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Ancient Tree.
- **Deep time:** Consider centuries to millennia. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with living archive: examine both continuity and inflexibility. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support witness or produce accumulated damage. |
| Creativity | Work with the card's actual process—accumulation and regeneration—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **continuity** already present, even in a small or quiet form?
2. Where might **inflexibility** be shaping the situation?
3. Where do you observe **accumulation**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Living Archive** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Ancient Tree**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Endurance is repeated adjustment that leaves a layered record.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **continuity** while reducing **inflexibility**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Exact age can be uncertain without complete rings, and definitions of ancient or old-growth differ by species, region, and purpose.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Ancient Tree. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Living Archive** as the original synthesis for Ancient Tree: Endurance is repeated adjustment that leaves a layered record. This meaning arises from the sourced description of accumulation and regeneration, then becomes a reflective lens through the gift of **continuity** and the wound of **inflexibility**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Ecological Succession](040-ecological-succession.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Ecological Succession](040-ecological-succession.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Mitochondrion](021-mitochondrion.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Forest Canopy](042-forest-canopy.md) helps identify containing systems and downstream effects.
- **Shared process:** [Ecological Succession](040-ecological-succession.md) also expresses regeneration, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Glacier](052-glacier.md) offers a nearby systems comparison.
- **Natural cycle:** [DNA](020-dna.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Seed](028-seed.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Ancient Tree at its characteristic scale, with the central visual emphasis on **accumulation and regeneration** and **memory and ancestor**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — USDA Forest Service Research.** [New findings about old-growth forests](https://research.fs.usda.gov/treesearch/7320). Accessed 2026-08-23.
- **S02 — USDA Forest Service Research.** [Advances in understanding canopy development in forest trees](https://research.fs.usda.gov/treesearch/59369). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Exact age can be uncertain without complete rings, and definitions of ancient or old-growth differ by species, region, and purpose.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Ancient Tree is retained because **Living Archive** is not duplicated by Seed, even where their processes overlap.
