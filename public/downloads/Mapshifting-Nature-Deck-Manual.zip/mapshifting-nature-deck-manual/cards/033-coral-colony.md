---
card_number: 33
name: "Coral Colony"
slug: "coral-colony"
scale_band: "4. Organism"
scientific_domains: ["marine biology","symbiosis"]
natural_processes: ["construction","symbiosis"]
system_functions: ["builder","network"]
spatial_scale: "millimetre polyps to metre-scale colonies"
time_scale: "years to centuries"
core_archetype: "Collective Builder"
primary_gifts: ["collective construction","continuity","habitat creation"]
primary_wounds: ["bleaching","fragmentation","growth beyond resilience"]
related_cards: ["microbiome", "symbiosis", "coral-reef", "kelp-forest", "volcano", "carbon", "bacterium", "ecological-succession"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Coral Colony

## Essence

Many small bodies can deposit a structure larger than any one lifetime.

## Keywords

construction · symbiosis · builder · network · collective construction · continuity · habitat creation

## What it is

A coral colony consists of genetically related or associated polyps connected by living tissue in many species. Reef-building corals secrete calcium carbonate and commonly host photosynthetic dinoflagellate symbionts. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** millimetre polyps to metre-scale colonies.
- **Characteristic time:** years to centuries.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Microbiome](027-microbiome.md).
- **Larger container:** A useful containing or consequence-level bridge is [Coral Reef](045-coral-reef.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Polyps feed, exchange resources, reproduce sexually or asexually, deposit skeleton, compete for space, and respond to heat, light, disease, acidity, and water quality. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Shared construction carries past labor forward while exposing the whole to common stress.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Collective Builder.** Coral Colony deserves its own card because it makes **builder and network** legible through **construction and symbiosis** at the organism scale. It differs from [Lichen](031-lichen.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Collective Construction.** Shared construction carries past labor forward while exposing the whole to common stress.
- **Continuity.** This capacity becomes available when continuity fits the timing, limits, and needs of the larger system.
- **Habitat Creation.** This capacity becomes available when habitat creation fits the timing, limits, and needs of the larger system.

## Wounds

- **Bleaching.** The pattern distorts when bleaching replaces responsive relationship.
- **Fragmentation.** Fragmentation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Growth Beyond Resilience.** Growth Beyond Resilience appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **collective construction** becomes **bleaching** when scale, timing, boundary, or reciprocity is ignored. Coral Colony asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

collective construction remains connected to continuity while limits are respected; bleaching is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **bleaching, fragmentation, growth beyond resilience**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **collective construction, continuity, habitat creation** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Microbiome](027-microbiome.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to construction and symbiosis as they actually operate in Coral Colony; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Coral Reef](045-coral-reef.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Coral Colony.
- **Deep time:** Consider years to centuries. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with collective builder: examine both collective construction and bleaching. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support continuity or produce fragmentation. |
| Creativity | Work with the card's actual process—construction and symbiosis—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **collective construction** already present, even in a small or quiet form?
2. Where might **bleaching** be shaping the situation?
3. Where do you observe **construction**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Collective Builder** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Coral Colony**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Shared construction carries past labor forward while exposing the whole to common stress.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **collective construction** while reducing **bleaching**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Coral–microbe partnerships, acclimatization, adaptation rates, disease dynamics, and future resilience under multiple stressors remain uncertain.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Coral Colony. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Collective Builder** as the original synthesis for Coral Colony: Shared construction carries past labor forward while exposing the whole to common stress. This meaning arises from the sourced description of construction and symbiosis, then becomes a reflective lens through the gift of **collective construction** and the wound of **bleaching**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Volcano](059-volcano.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Volcano](059-volcano.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Microbiome](027-microbiome.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Coral Reef](045-coral-reef.md) helps identify containing systems and downstream effects.
- **Shared process:** [Microbiome](027-microbiome.md) also expresses symbiosis, but with different constraints.
- **Shared wound:** [Quark](006-quark.md) also carries the wound **fragmentation**.
- **Natural cycle:** [Proton](003-proton.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Lichen](031-lichen.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Coral Colony at its characteristic scale, with the central visual emphasis on **construction and symbiosis** and **builder and network**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NOAA Coral Reef Conservation Program.** [Coral Reef Information](https://coralreef.noaa.gov/). Accessed 2026-08-23.
- **S02 — Smithsonian National Museum of Natural History.** [What Is Biodiversity?](https://naturalhistory.si.edu/education/teaching-resources/life-science/what-biodiversity). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Coral–microbe partnerships, acclimatization, adaptation rates, disease dynamics, and future resilience under multiple stressors remain uncertain.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Coral Colony is retained because **Collective Builder** is not duplicated by Lichen, even where their processes overlap.
