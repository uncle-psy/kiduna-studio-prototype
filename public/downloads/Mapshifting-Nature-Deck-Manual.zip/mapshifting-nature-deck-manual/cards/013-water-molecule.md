---
card_number: 13
name: "Water Molecule"
slug: "water-molecule"
scale_band: "2. Atomic and molecular"
scientific_domains: ["chemistry","hydrology"]
natural_processes: ["binding","phase transition"]
system_functions: ["carrier","solvent"]
spatial_scale: "about 0.3 nanometres per molecule"
time_scale: "picosecond rearrangements to planetary cycling"
core_archetype: "Relational Solvent"
primary_gifts: ["solvency","cohesion","transport"]
primary_wounds: ["dilution","flooding","carrying contamination"]
related_cards: ["chemical-bond", "proton", "cell-membrane", "hydrogen", "carbon", "neutron", "quark", "gluon"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Water Molecule

## Essence

The capacity to receive and carry depends on molecular shape and bond.

## Keywords

binding · phase transition · carrier · solvent · solvency · cohesion · transport

## What it is

Water is H2O: a bent polar molecule whose charge distribution permits hydrogen bonding. These transient bonds underpin cohesion, surface tension, solvent behavior, and unusual phase properties. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** about 0.3 nanometres per molecule.
- **Characteristic time:** picosecond rearrangements to planetary cycling.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Photon](001-photon.md).
- **Larger container:** A useful containing or consequence-level bridge is [Cell Membrane](019-cell-membrane.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Water molecules constantly rearrange hydrogen-bond networks, dissolve many ions and polar substances, and move among solid, liquid, and vapor phases through the water cycle. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A carrier is never neutral: what it can hold follows from its own structure.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Relational Solvent.** Water Molecule deserves its own card because it makes **carrier and solvent** legible through **binding and phase transition** at the atomic and molecular scale. It differs from [Hydrogen](010-hydrogen.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Solvency.** A carrier is never neutral: what it can hold follows from its own structure.
- **Cohesion.** This capacity becomes available when cohesion fits the timing, limits, and needs of the larger system.
- **Transport.** This capacity becomes available when transport fits the timing, limits, and needs of the larger system.

## Wounds

- **Dilution.** The pattern distorts when dilution replaces responsive relationship.
- **Flooding.** Flooding appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Carrying Contamination.** Carrying Contamination appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **solvency** becomes **dilution** when scale, timing, boundary, or reciprocity is ignored. Water Molecule asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

solvency remains connected to cohesion while limits are respected; dilution is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **dilution, flooding, carrying contamination**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **solvency, cohesion, transport** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Photon](001-photon.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to binding and phase transition as they actually operate in Water Molecule; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Cell Membrane](019-cell-membrane.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Water Molecule.
- **Deep time:** Consider picosecond rearrangements to planetary cycling. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with relational solvent: examine both solvency and dilution. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support cohesion or produce flooding. |
| Creativity | Work with the card's actual process—binding and phase transition—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **solvency** already present, even in a small or quiet form?
2. Where might **dilution** be shaping the situation?
3. Where do you observe **binding**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Relational Solvent** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Water Molecule**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A carrier is never neutral: what it can hold follows from its own structure.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **solvency** while reducing **dilution**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

The collective behavior of liquid water remains computationally challenging, especially at interfaces, under confinement, and in supercooled states.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Water Molecule. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Relational Solvent** as the original synthesis for Water Molecule: A carrier is never neutral: what it can hold follows from its own structure. This meaning arises from the sourced description of binding and phase transition, then becomes a reflective lens through the gift of **solvency** and the wound of **dilution**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Chemical Bond](014-chemical-bond.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Chemical Bond](014-chemical-bond.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Photon](001-photon.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Cell Membrane](019-cell-membrane.md) helps identify containing systems and downstream effects.
- **Shared process:** [Proton](003-proton.md) also expresses binding, but with different constraints.
- **Shared wound:** [River](047-river.md) also carries the wound **flooding**.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Hydrogen](010-hydrogen.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Water Molecule at its characteristic scale, with the central visual emphasis on **binding and phase transition** and **carrier and solvent**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — National Institute of Standards and Technology.** [NIST Chemistry WebBook](https://webbook.nist.gov/chemistry/). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Water Science School](https://www.usgs.gov/special-topics/water-science-school). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** The collective behavior of liquid water remains computationally challenging, especially at interfaces, under confinement, and in supercooled states.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Water Molecule is retained because **Relational Solvent** is not duplicated by Hydrogen, even where their processes overlap.
