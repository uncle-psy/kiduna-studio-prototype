---
card_number: 31
name: "Lichen"
slug: "lichen"
scale_band: "4. Organism"
scientific_domains: ["mycology","ecology"]
natural_processes: ["symbiosis","weathering"]
system_functions: ["bridge","pioneer"]
spatial_scale: "millimetres to metre-scale colonies"
time_scale: "years to centuries"
core_archetype: "Composite Pioneer"
primary_gifts: ["cooperation","pioneering","sensitivity"]
primary_wounds: ["dependency","slow recovery","partnership under strain"]
related_cards: ["symbiosis", "microbiome", "fungal-fruiting-body", "pollinator", "bacterium", "spore", "decomposition", "ecological-succession"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Lichen

## Essence

A new form can emerge from partners without erasing their difference.

## Keywords

symbiosis · weathering · bridge · pioneer · cooperation · pioneering · sensitivity

## What it is

A lichen is a stable association centered on a fungus with one or more photosynthetic partners, often algae or cyanobacteria, plus a wider microbial community. It is an ecological consortium, not a single lineage. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** millimetres to metre-scale colonies.
- **Characteristic time:** years to centuries.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Microbiome](027-microbiome.md).
- **Larger container:** A useful containing or consequence-level bridge is [Ecological Succession](040-ecological-succession.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Lichens colonize surfaces, cycle between hydration and dormancy, contribute to weathering and nutrient pathways, and respond sensitively to air quality and microclimate. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Partnership can create a body and capability none of the participants has alone.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Composite Pioneer.** Lichen deserves its own card because it makes **bridge and pioneer** legible through **symbiosis and weathering** at the organism scale. It differs from [Coral Colony](033-coral-colony.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Cooperation.** Partnership can create a body and capability none of the participants has alone.
- **Pioneering.** This capacity becomes available when pioneering fits the timing, limits, and needs of the larger system.
- **Sensitivity.** This capacity becomes available when sensitivity fits the timing, limits, and needs of the larger system.

## Wounds

- **Dependency.** The pattern distorts when dependency replaces responsive relationship.
- **Slow Recovery.** Slow Recovery appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Partnership Under Strain.** Partnership Under Strain appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **cooperation** becomes **dependency** when scale, timing, boundary, or reciprocity is ignored. Lichen asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

cooperation remains connected to pioneering while limits are respected; dependency is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **dependency, slow recovery, partnership under strain**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **cooperation, pioneering, sensitivity** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Microbiome](027-microbiome.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to symbiosis and weathering as they actually operate in Lichen; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Ecological Succession](040-ecological-succession.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Lichen.
- **Deep time:** Consider years to centuries. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with composite pioneer: examine both cooperation and dependency. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support pioneering or produce slow recovery. |
| Creativity | Work with the card's actual process—symbiosis and weathering—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **cooperation** already present, even in a small or quiet form?
2. Where might **dependency** be shaping the situation?
3. Where do you observe **symbiosis**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Composite Pioneer** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Lichen**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Partnership can create a body and capability none of the participants has alone.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **cooperation** while reducing **dependency**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

The roles of additional microbes, specificity among partners, and boundaries of lichen individuality remain active research.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Lichen. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Composite Pioneer** as the original synthesis for Lichen: Partnership can create a body and capability none of the participants has alone. This meaning arises from the sourced description of symbiosis and weathering, then becomes a reflective lens through the gift of **cooperation** and the wound of **dependency**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Symbiosis](037-symbiosis.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Fungal Fruiting Body](034-fungal-fruiting-body.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Microbiome](027-microbiome.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Ecological Succession](040-ecological-succession.md) helps identify containing systems and downstream effects.
- **Shared process:** [Microbiome](027-microbiome.md) also expresses symbiosis, but with different constraints.
- **Shared wound:** [Oxygen](012-oxygen.md) also carries the wound **dependency**.
- **Natural cycle:** [Gluon](007-gluon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Coral Colony](033-coral-colony.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Lichen at its characteristic scale, with the central visual emphasis on **symbiosis and weathering** and **bridge and pioneer**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — USDA Forest Service.** [National Atlas of Epiphytic Lichens in Forested Habitats of the United States](https://www.fs.usda.gov/sites/default/files/fs_media/fs_document/Lichen-Atlas.pdf). Accessed 2026-08-23.
- **S02 — Smithsonian National Museum of Natural History.** [What Is Biodiversity?](https://naturalhistory.si.edu/education/teaching-resources/life-science/what-biodiversity). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** The roles of additional microbes, specificity among partners, and boundaries of lichen individuality remain active research.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Lichen is retained because **Composite Pioneer** is not duplicated by Coral Colony, even where their processes overlap.
