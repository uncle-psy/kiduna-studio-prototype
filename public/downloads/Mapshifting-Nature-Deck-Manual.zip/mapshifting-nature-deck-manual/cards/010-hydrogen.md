---
card_number: 10
name: "Hydrogen"
slug: "hydrogen"
scale_band: "2. Atomic and molecular"
scientific_domains: ["chemistry","astrophysics"]
natural_processes: ["fusion","binding"]
system_functions: ["source","seed"]
spatial_scale: "atomic to cosmic abundance"
time_scale: "femtosecond reactions to stellar lifetimes"
core_archetype: "First Element"
primary_gifts: ["beginnings","availability","fusion potential"]
primary_wounds: ["underdevelopment","volatility","simplicity mistaken for insufficiency"]
related_cards: ["quark", "proton", "cell-membrane", "star", "chemical-bond", "carbon", "water-molecule", "neutron"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Hydrogen

## Essence

Simplicity can become the feedstock of immense complexity.

## Keywords

fusion · binding · source · seed · beginnings · availability · fusion potential

## What it is

Hydrogen is the lightest element, defined by one proton. Neutral protium has one electron and no neutron; other isotopes include deuterium and radioactive tritium. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** atomic to cosmic abundance.
- **Characteristic time:** femtosecond reactions to stellar lifetimes.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Proton](003-proton.md).
- **Larger container:** A useful containing or consequence-level bridge is [Mitochondrion](021-mitochondrion.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Hydrogen forms covalent and ionic compounds, participates in acid–base chemistry, and fuels stellar fusion. It is the most abundant element in the universe by ordinary matter. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A minimal structure can be generative when conditions allow binding and transformation.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**First Element.** Hydrogen deserves its own card because it makes **source and seed** legible through **fusion and binding** at the atomic and molecular scale. It differs from [Carbon](011-carbon.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Beginnings.** A minimal structure can be generative when conditions allow binding and transformation.
- **Availability.** This capacity becomes available when availability fits the timing, limits, and needs of the larger system.
- **Fusion Potential.** This capacity becomes available when fusion potential fits the timing, limits, and needs of the larger system.

## Wounds

- **Underdevelopment.** The pattern distorts when underdevelopment replaces responsive relationship.
- **Volatility.** Volatility appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Simplicity Mistaken For Insufficiency.** Simplicity Mistaken For Insufficiency appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **beginnings** becomes **underdevelopment** when scale, timing, boundary, or reciprocity is ignored. Hydrogen asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

beginnings remains connected to availability while limits are respected; underdevelopment is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **underdevelopment, volatility, simplicity mistaken for insufficiency**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **beginnings, availability, fusion potential** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Proton](003-proton.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to fusion and binding as they actually operate in Hydrogen; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Mitochondrion](021-mitochondrion.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Hydrogen.
- **Deep time:** Consider femtosecond reactions to stellar lifetimes. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with first element: examine both beginnings and underdevelopment. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support availability or produce volatility. |
| Creativity | Work with the card's actual process—fusion and binding—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **beginnings** already present, even in a small or quiet form?
2. Where might **underdevelopment** be shaping the situation?
3. Where do you observe **fusion**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **First Element** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Hydrogen**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A minimal structure can be generative when conditions allow binding and transformation.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **beginnings** while reducing **underdevelopment**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Primordial-abundance measurements and stellar physics are precise, but the earliest star formation and some interstellar hydrogen processes remain active research.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Hydrogen. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **First Element** as the original synthesis for Hydrogen: A minimal structure can be generative when conditions allow binding and transformation. This meaning arises from the sourced description of fusion and binding, then becomes a reflective lens through the gift of **beginnings** and the wound of **underdevelopment**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Chemical Bond](014-chemical-bond.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Cell Membrane](019-cell-membrane.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Proton](003-proton.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Mitochondrion](021-mitochondrion.md) helps identify containing systems and downstream effects.
- **Shared process:** [Proton](003-proton.md) also expresses binding, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Cell Membrane](019-cell-membrane.md) offers a nearby systems comparison.
- **Natural cycle:** [Quark](006-quark.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Carbon](011-carbon.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Hydrogen at its characteristic scale, with the central visual emphasis on **fusion and binding** and **source and seed**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — National Institute of Standards and Technology.** [Periodic Table of the Elements](https://www.nist.gov/pml/periodic-table-elements). Accessed 2026-08-23.
- **S02 — NASA Science.** [Stars](https://science.nasa.gov/universe/stars/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Primordial-abundance measurements and stellar physics are precise, but the earliest star formation and some interstellar hydrogen processes remain active research.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Hydrogen is retained because **First Element** is not duplicated by Carbon, even where their processes overlap.
