---
card_number: 35
name: "Pollinator"
slug: "pollinator"
scale_band: "4. Organism"
scientific_domains: ["ecology","evolution"]
natural_processes: ["pollination","exchange"]
system_functions: ["messenger","bridge"]
spatial_scale: "individual movement among flowers and landscapes"
time_scale: "seconds per visit to coevolutionary time"
core_archetype: "Crossing Messenger"
primary_gifts: ["connection","fertility","cross-boundary service"]
primary_wounds: ["overdependence","network loss","service extracted without habitat"]
related_cards: ["symbiosis", "cell-membrane", "mitochondrion", "gluon", "chemical-bond", "fungal-fruiting-body", "food-web", "soil-community"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Pollinator

## Essence

Movement between separate lives can create a future for both.

## Keywords

pollination · exchange · messenger · bridge · connection · fertility · cross-boundary service

## What it is

A pollinator is an animal or other vector that moves pollen between reproductive structures, enabling fertilization in many flowering plants. Insects, birds, bats, and other animals serve this role. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** individual movement among flowers and landscapes.
- **Characteristic time:** seconds per visit to coevolutionary time.
- **Smaller structures:** A useful composing or mechanism-level bridge is [DNA](020-dna.md).
- **Larger container:** A useful containing or consequence-level bridge is [Food Web](038-food-web.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Pollinators forage, learn cues, move through landscapes, and interact with many plant species. Pollination networks range from specialized partnerships to redundant generalist systems. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A bridge survives only when both destinations also support the bridge-builder.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Crossing Messenger.** Pollinator deserves its own card because it makes **messenger and bridge** legible through **pollination and exchange** at the organism scale. It differs from [Lichen](031-lichen.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Connection.** A bridge survives only when both destinations also support the bridge-builder.
- **Fertility.** This capacity becomes available when fertility fits the timing, limits, and needs of the larger system.
- **Cross-Boundary Service.** This capacity becomes available when cross-boundary service fits the timing, limits, and needs of the larger system.

## Wounds

- **Overdependence.** The pattern distorts when overdependence replaces responsive relationship.
- **Network Loss.** Network Loss appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Service Extracted Without Habitat.** Service Extracted Without Habitat appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **connection** becomes **overdependence** when scale, timing, boundary, or reciprocity is ignored. Pollinator asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

connection remains connected to fertility while limits are respected; overdependence is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **overdependence, network loss, service extracted without habitat**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **connection, fertility, cross-boundary service** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [DNA](020-dna.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to pollination and exchange as they actually operate in Pollinator; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Food Web](038-food-web.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Pollinator.
- **Deep time:** Consider seconds per visit to coevolutionary time. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with crossing messenger: examine both connection and overdependence. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support fertility or produce network loss. |
| Creativity | Work with the card's actual process—pollination and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **connection** already present, even in a small or quiet form?
2. Where might **overdependence** be shaping the situation?
3. Where do you observe **pollination**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Crossing Messenger** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Pollinator**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A bridge survives only when both destinations also support the bridge-builder.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **connection** while reducing **overdependence**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Pollinator trends, network resilience, combined pesticide and climate effects, and many non-bee pollination systems remain incompletely measured.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Pollinator. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Crossing Messenger** as the original synthesis for Pollinator: A bridge survives only when both destinations also support the bridge-builder. This meaning arises from the sourced description of pollination and exchange, then becomes a reflective lens through the gift of **connection** and the wound of **overdependence**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Electron](002-electron.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Mitochondrion](021-mitochondrion.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [DNA](020-dna.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Food Web](038-food-web.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Mitochondrion](021-mitochondrion.md) offers a nearby systems comparison.
- **Natural cycle:** [Neutrino](005-neutrino.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Lichen](031-lichen.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Pollinator at its characteristic scale, with the central visual emphasis on **pollination and exchange** and **messenger and bridge**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — USDA Forest Service.** [Pollinators](https://www.fs.usda.gov/wildflowers/pollinators/). Accessed 2026-08-23.
- **S02 — Smithsonian National Museum of Natural History.** [What Is Biodiversity?](https://naturalhistory.si.edu/education/teaching-resources/life-science/what-biodiversity). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Pollinator trends, network resilience, combined pesticide and climate effects, and many non-bee pollination systems remain incompletely measured.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Pollinator is retained because **Crossing Messenger** is not duplicated by Lichen, even where their processes overlap.
