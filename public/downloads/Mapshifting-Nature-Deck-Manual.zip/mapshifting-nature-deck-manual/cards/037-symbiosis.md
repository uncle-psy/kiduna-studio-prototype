---
card_number: 37
name: "Symbiosis"
slug: "symbiosis"
scale_band: "5. Community and ecosystem"
scientific_domains: ["ecology","evolution"]
natural_processes: ["symbiosis","exchange"]
system_functions: ["bridge","network"]
spatial_scale: "cellular partners to ecosystem-spanning associations"
time_scale: "hours to coevolutionary time"
core_archetype: "Close Association"
primary_gifts: ["mutual support","integration","shared capability"]
primary_wounds: ["exploitation","enmeshment","loss of autonomy"]
related_cards: ["pollinator", "root", "estuary", "lichen", "coral-colony", "gluon", "food-web", "soil-community"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Symbiosis

## Essence

Intimacy is a condition; its value depends on what passes between partners.

## Keywords

symbiosis · exchange · bridge · network · mutual support · integration · shared capability

## What it is

Symbiosis is a close, persistent interaction between organisms of different species. It includes mutualism, commensalism, parasitism, and relationships whose effects change with context. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** cellular partners to ecosystem-spanning associations.
- **Characteristic time:** hours to coevolutionary time.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Bacterium](022-bacterium.md).
- **Larger container:** A useful containing or consequence-level bridge is [Food Web](038-food-web.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Partners exchange nutrients, protection, transport, signals, or harm; associations can become obligatory, dissolve, or shift along a continuum as environments change. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Closeness does not guarantee reciprocity; examine flows, costs, alternatives, and scale.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Close Association.** Symbiosis deserves its own card because it makes **bridge and network** legible through **symbiosis and exchange** at the community and ecosystem scale. It differs from [Food Web](038-food-web.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Mutual Support.** Closeness does not guarantee reciprocity; examine flows, costs, alternatives, and scale.
- **Integration.** This capacity becomes available when integration fits the timing, limits, and needs of the larger system.
- **Shared Capability.** This capacity becomes available when shared capability fits the timing, limits, and needs of the larger system.

## Wounds

- **Exploitation.** The pattern distorts when exploitation replaces responsive relationship.
- **Enmeshment.** Enmeshment appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Loss Of Autonomy.** Loss Of Autonomy appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **mutual support** becomes **exploitation** when scale, timing, boundary, or reciprocity is ignored. Symbiosis asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

mutual support remains connected to integration while limits are respected; exploitation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **exploitation, enmeshment, loss of autonomy**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **mutual support, integration, shared capability** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Bacterium](022-bacterium.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to symbiosis and exchange as they actually operate in Symbiosis; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Food Web](038-food-web.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Symbiosis.
- **Deep time:** Consider hours to coevolutionary time. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with close association: examine both mutual support and exploitation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support integration or produce enmeshment. |
| Creativity | Work with the card's actual process—symbiosis and exchange—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **mutual support** already present, even in a small or quiet form?
2. Where might **exploitation** be shaping the situation?
3. Where do you observe **symbiosis**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Close Association** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Symbiosis**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Closeness does not guarantee reciprocity; examine flows, costs, alternatives, and scale.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **mutual support** while reducing **exploitation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Many symbioses involve multiple partners and context-dependent outcomes that are difficult to reduce to a single category.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Symbiosis. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Close Association** as the original synthesis for Symbiosis: Closeness does not guarantee reciprocity; examine flows, costs, alternatives, and scale. This meaning arises from the sourced description of symbiosis and exchange, then becomes a reflective lens through the gift of **mutual support** and the wound of **exploitation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Electron](002-electron.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Root](029-root.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Bacterium](022-bacterium.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Food Web](038-food-web.md) helps identify containing systems and downstream effects.
- **Shared process:** [Electron](002-electron.md) also expresses exchange, but with different constraints.
- **Shared wound:** [Virus](024-virus.md) also carries the wound **exploitation**.
- **Natural cycle:** [Gluon](007-gluon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Food Web](038-food-web.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Symbiosis at its characteristic scale, with the central visual emphasis on **symbiosis and exchange** and **bridge and network**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — Smithsonian National Museum of Natural History.** [What Is Biodiversity?](https://naturalhistory.si.edu/education/teaching-resources/life-science/what-biodiversity). Accessed 2026-08-23.
- **S02 — NCBI Bookshelf.** [The Diversity of Genomes and the Tree of Life](https://www.ncbi.nlm.nih.gov/books/NBK26866/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Many symbioses involve multiple partners and context-dependent outcomes that are difficult to reduce to a single category.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Symbiosis is retained because **Close Association** is not duplicated by Food Web, even where their processes overlap.
