---
card_number: 41
name: "Wetland"
slug: "wetland"
scale_band: "5. Community and ecosystem"
scientific_domains: ["wetland ecology","hydrology"]
natural_processes: ["filtration","storage"]
system_functions: ["filter","threshold"]
spatial_scale: "small seasonal basin to vast deltaic complex"
time_scale: "seasonal pulses to millennial peat accumulation"
core_archetype: "Living Sponge"
primary_gifts: ["buffering","filtration","nursery habitat"]
primary_wounds: ["saturation","contaminant accumulation","drainage and loss"]
related_cards: ["fungal-fruiting-body", "seed", "aquifer", "river", "delta", "estuary", "desert", "glacier"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Wetland

## Essence

Capacity comes from holding, slowing, and transforming flows at an edge.

## Keywords

filtration · storage · filter · threshold · buffering · nursery habitat

## What it is

A wetland is a place where water saturation shapes soils, chemistry, and biological communities. Marshes, swamps, bogs, fens, and seasonal wetlands differ greatly. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** small seasonal basin to vast deltaic complex.
- **Characteristic time:** seasonal pulses to millennial peat accumulation.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Microbiome](027-microbiome.md).
- **Larger container:** A useful containing or consequence-level bridge is [Watershed](046-watershed.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Wetlands store and release water, trap or transform materials, support food webs, accumulate organic matter, and connect terrestrial and aquatic systems. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A threshold zone can reduce force and improve quality by giving flow time and complexity.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Living Sponge.** Wetland deserves its own card because it makes **filter and threshold** legible through **filtration and storage** at the community and ecosystem scale. It differs from [Symbiosis](037-symbiosis.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Buffering.** A threshold zone can reduce force and improve quality by giving flow time and complexity.
- **Filtration.** This capacity becomes available when filtration fits the timing, limits, and needs of the larger system.
- **Nursery Habitat.** This capacity becomes available when nursery habitat fits the timing, limits, and needs of the larger system.

## Wounds

- **Saturation.** The pattern distorts when saturation replaces responsive relationship.
- **Contaminant Accumulation.** Contaminant Accumulation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Drainage And Loss.** Drainage And Loss appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **buffering** becomes **saturation** when scale, timing, boundary, or reciprocity is ignored. Wetland asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

buffering remains connected to filtration while limits are respected; saturation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **saturation, contaminant accumulation, drainage and loss**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **buffering, filtration, nursery habitat** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Microbiome](027-microbiome.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to filtration and storage as they actually operate in Wetland; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Watershed](046-watershed.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Wetland.
- **Deep time:** Consider seasonal pulses to millennial peat accumulation. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with living sponge: examine both buffering and saturation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support filtration or produce contaminant accumulation. |
| Creativity | Work with the card's actual process—filtration and storage—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **buffering** already present, even in a small or quiet form?
2. Where might **saturation** be shaping the situation?
3. Where do you observe **filtration**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Living Sponge** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Wetland**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A threshold zone can reduce force and improve quality by giving flow time and complexity.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **buffering** while reducing **saturation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Wetland boundaries, condition, greenhouse-gas balance, and responses to altered hydrology vary by type and are difficult to generalize.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Wetland. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Living Sponge** as the original synthesis for Wetland: A threshold zone can reduce force and improve quality by giving flow time and complexity. This meaning arises from the sourced description of filtration and storage, then becomes a reflective lens through the gift of **buffering** and the wound of **saturation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Fungal Fruiting Body](034-fungal-fruiting-body.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Fungal Fruiting Body](034-fungal-fruiting-body.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Microbiome](027-microbiome.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Watershed](046-watershed.md) helps identify containing systems and downstream effects.
- **Shared process:** [Aquifer](050-aquifer.md) also expresses storage, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Aquifer](050-aquifer.md) offers a nearby systems comparison.
- **Natural cycle:** [Phase Transition](017-phase-transition.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Symbiosis](037-symbiosis.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Wetland at its characteristic scale, with the central visual emphasis on **filtration and storage** and **filter and threshold**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Environmental Protection Agency.** [How do Wetlands Function and Why are they Valuable?](https://www.epa.gov/wetlands/how-do-wetlands-function-and-why-are-they-valuable). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Watersheds and Drainage Basins](https://www.usgs.gov/water-science-school/science/watersheds-and-drainage-basins). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Wetland boundaries, condition, greenhouse-gas balance, and responses to altered hydrology vary by type and are difficult to generalize.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Wetland is retained because **Living Sponge** is not duplicated by Symbiosis, even where their processes overlap.
