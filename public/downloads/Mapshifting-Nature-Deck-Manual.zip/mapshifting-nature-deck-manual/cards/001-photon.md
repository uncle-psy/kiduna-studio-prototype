---
card_number: 1
name: "Photon"
slug: "photon"
scale_band: "1. Fundamental"
scientific_domains: ["particle physics","electromagnetism"]
natural_processes: ["transmission","radiation"]
system_functions: ["signal","carrier"]
spatial_scale: "quantum; wavelength-dependent"
time_scale: "interaction instants to cosmic travel"
core_archetype: "Messenger"
primary_gifts: ["transmission","illumination","reach"]
primary_wounds: ["exposure","scattering","signal overload"]
related_cards: ["earthquake", "hydrogen", "virus", "neutrino", "electron", "water-molecule", "plasma", "plankton"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Photon

## Essence

Energy becomes knowable by what carries it.

## Keywords

transmission · radiation · signal · carrier · illumination · reach

## What it is

A photon is the quantum of the electromagnetic field. It has no electric charge or rest mass and carries electromagnetic energy and momentum. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** quantum; wavelength-dependent.
- **Characteristic time:** interaction instants to cosmic travel.
- **Smaller structures:** This is the deck's lowest scale band. Its quantum fields and interactions are not represented by a still smaller card.
- **Larger container:** A useful containing or consequence-level bridge is [Hydrogen](010-hydrogen.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Photons are emitted and absorbed in discrete interactions. Their energy depends on frequency; they propagate through vacuum at light speed while matter can absorb, scatter, refract, or redirect them. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

A message is shaped both by what leaves the source and by every medium it crosses.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Messenger.** Photon deserves its own card because it makes **signal and carrier** legible through **transmission and radiation** at the fundamental scale. It differs from [Electron](002-electron.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Transmission.** A message is shaped both by what leaves the source and by every medium it crosses.
- **Illumination.** This capacity becomes available when illumination fits the timing, limits, and needs of the larger system.
- **Reach.** This capacity becomes available when reach fits the timing, limits, and needs of the larger system.

## Wounds

- **Exposure.** The pattern distorts when exposure replaces responsive relationship.
- **Scattering.** Scattering appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Signal Overload.** Signal Overload appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **transmission** becomes **exposure** when scale, timing, boundary, or reciprocity is ignored. Photon asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

transmission remains connected to illumination while limits are respected; exposure is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **exposure, scattering, signal overload**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **transmission, illumination, reach** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** At the lower boundary of the deck, shift from object language to fields, interactions, measurement conditions, and quantum states rather than inventing a smaller card.
- **Its own scale:** Attend to transmission and radiation as they actually operate in Photon; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Hydrogen](010-hydrogen.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Photon.
- **Deep time:** Consider interaction instants to cosmic travel. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with messenger: examine both transmission and exposure. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support illumination or produce scattering. |
| Creativity | Work with the card's actual process—transmission and radiation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **transmission** already present, even in a small or quiet form?
2. Where might **exposure** be shaping the situation?
3. Where do you observe **transmission**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Messenger** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Photon**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **A message is shaped both by what leaves the source and by every medium it crosses.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **transmission** while reducing **exposure**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

How measurement, quantum state, and gravity jointly shape photon behavior remains an active frontier; the deck makes no claim that photons transmit intention or consciousness.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Photon. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Messenger** as the original synthesis for Photon: A message is shaped both by what leaves the source and by every medium it crosses. This meaning arises from the sourced description of transmission and radiation, then becomes a reflective lens through the gift of **transmission** and the wound of **exposure**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Earthquake](056-earthquake.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Earthquake](056-earthquake.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** No smaller core card is asserted; use the explicit lower-boundary guidance above.
- **Larger scale:** [Hydrogen](010-hydrogen.md) helps identify containing systems and downstream effects.
- **Shared process:** [Neutrino](005-neutrino.md) also expresses transmission, but with different constraints.
- **Shared wound:** [Desert](051-desert.md) also carries the wound **exposure**.
- **Natural cycle:** [Water Molecule](013-water-molecule.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Electron](002-electron.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Photon at its characteristic scale, with the central visual emphasis on **transmission and radiation** and **signal and carrier**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Department of Energy Office of Science.** [DOE Explains: The Standard Model of Particle Physics](https://www.energy.gov/science/doe-explainsthe-standard-model-particle-physics). Accessed 2026-08-23.
- **S02 — CERN.** [The Standard Model](https://home.cern/science/physics/standard-model). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** How measurement, quantum state, and gravity jointly shape photon behavior remains an active frontier; the deck makes no claim that photons transmit intention or consciousness.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Photon is retained because **Messenger** is not duplicated by Electron, even where their processes overlap.
