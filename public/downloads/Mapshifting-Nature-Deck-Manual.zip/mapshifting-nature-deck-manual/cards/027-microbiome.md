---
card_number: 27
name: "Microbiome"
slug: "microbiome"
scale_band: "3. Microscopic and cellular"
scientific_domains: ["microbial ecology","systems biology"]
natural_processes: ["symbiosis","feedback"]
system_functions: ["network","regulator"]
spatial_scale: "host microhabitat to ecosystem"
time_scale: "hours to coevolutionary time"
core_archetype: "Invisible Community"
primary_gifts: ["distributed function","resilience","co-metabolism"]
primary_wounds: ["dysbiosis","hidden dependency","loss of diversity"]
related_cards: ["coral-colony", "hydrogen", "lichen", "keystone-species", "symbiosis", "kelp-forest", "carbon", "root"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "system_relationship"
status: complete
---

# Microbiome

## Essence

A visible life is partly governed by communities it cannot see.

## Keywords

symbiosis · feedback · network · regulator · distributed function · resilience · co-metabolism

## What it is

A microbiome is a microbial community considered with its genes, activities, and environmental context. Microbiomes occur in hosts, soils, oceans, buildings, and other habitats. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** host microhabitat to ecosystem.
- **Characteristic time:** hours to coevolutionary time.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Bacterium](022-bacterium.md).
- **Larger container:** A useful containing or consequence-level bridge is [Lichen](031-lichen.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Members compete, cooperate, exchange metabolites and genes, respond to disturbance, and alter their environment. Composition varies across place, time, method, and individual hosts. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Identity and capacity may be distributed across a changing consortium rather than located in one body.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Invisible Community.** Microbiome deserves its own card because it makes **network and regulator** legible through **symbiosis and feedback** at the microscopic and cellular scale. It differs from [Cell Membrane](019-cell-membrane.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Distributed Function.** Identity and capacity may be distributed across a changing consortium rather than located in one body.
- **Resilience.** This capacity becomes available when resilience fits the timing, limits, and needs of the larger system.
- **Co-Metabolism.** This capacity becomes available when co-metabolism fits the timing, limits, and needs of the larger system.

## Wounds

- **Dysbiosis.** The pattern distorts when dysbiosis replaces responsive relationship.
- **Hidden Dependency.** Hidden Dependency appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Loss Of Diversity.** Loss Of Diversity appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **distributed function** becomes **dysbiosis** when scale, timing, boundary, or reciprocity is ignored. Microbiome asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

distributed function remains connected to resilience while limits are respected; dysbiosis is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **dysbiosis, hidden dependency, loss of diversity**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **distributed function, resilience, co-metabolism** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Bacterium](022-bacterium.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to symbiosis and feedback as they actually operate in Microbiome; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Lichen](031-lichen.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Microbiome.
- **Deep time:** Consider hours to coevolutionary time. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with invisible community: examine both distributed function and dysbiosis. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support resilience or produce hidden dependency. |
| Creativity | Work with the card's actual process—symbiosis and feedback—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **distributed function** already present, even in a small or quiet form?
2. Where might **dysbiosis** be shaping the situation?
3. Where do you observe **symbiosis**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Invisible Community** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Microbiome**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Identity and capacity may be distributed across a changing consortium rather than located in one body.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **distributed function** while reducing **dysbiosis**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Causal links between community composition and function are often difficult to establish; measurement methods capture only parts of a dynamic system.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Microbiome. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Invisible Community** as the original synthesis for Microbiome: Identity and capacity may be distributed across a changing consortium rather than located in one body. This meaning arises from the sourced description of symbiosis and feedback, then becomes a reflective lens through the gift of **distributed function** and the wound of **dysbiosis**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Coral Colony](033-coral-colony.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Hydrogen](010-hydrogen.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Bacterium](022-bacterium.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Lichen](031-lichen.md) helps identify containing systems and downstream effects.
- **Shared process:** [Lichen](031-lichen.md) also expresses symbiosis, but with different constraints.
- **Shared wound:** [Ocean Current](053-ocean-current.md) also carries the wound **hidden dependency**.
- **Natural cycle:** [Neutron](004-neutron.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Cell Membrane](019-cell-membrane.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Microbiome at its characteristic scale, with the central visual emphasis on **symbiosis and feedback** and **network and regulator**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — National Institutes of Health.** [Human Microbiome Project](https://commonfund.nih.gov/hmp). Accessed 2026-08-23.
- **S02 — NCBI Bookshelf.** [The Diversity of Genomes and the Tree of Life](https://www.ncbi.nlm.nih.gov/books/NBK26866/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Causal links between community composition and function are often difficult to establish; measurement methods capture only parts of a dynamic system.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Microbiome is retained because **Invisible Community** is not duplicated by Cell Membrane, even where their processes overlap.
