---
card_number: 6
name: "Quark"
slug: "quark"
scale_band: "1. Fundamental"
scientific_domains: ["particle physics"]
natural_processes: ["binding","transformation"]
system_functions: ["seed","component"]
spatial_scale: "elementary-particle scale"
time_scale: "interaction instants; confined in hadrons"
core_archetype: "Constituent"
primary_gifts: ["contribution","differentiation","compositional power"]
primary_wounds: ["fragmentation","forced independence","identity reduced to parts"]
related_cards: ["hydrogen", "chemical-bond", "phase-transition", "catalysis", "proton", "neutron", "gluon", "carbon"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Quark

## Essence

A part may be real even when it cannot stand alone.

## Keywords

binding · transformation · seed · component · contribution · differentiation · compositional power

## What it is

Quarks are elementary fermions in six flavors. Up and down quarks compose ordinary protons and neutrons; quarks carry fractional electric charge and color charge. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** elementary-particle scale.
- **Characteristic time:** interaction instants; confined in hadrons.
- **Smaller structures:** This is the deck's lowest scale band. Its quantum fields and interactions are not represented by a still smaller card.
- **Larger container:** A useful containing or consequence-level bridge is [Hydrogen](010-hydrogen.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Quarks interact by exchanging gluons and are confined within hadrons under ordinary conditions. Flavor can change through weak interactions. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Composition does not imply separability; some parts exist only through binding relationships.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Constituent.** Quark deserves its own card because it makes **seed and component** legible through **binding and transformation** at the fundamental scale. It differs from [Photon](001-photon.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Contribution.** Composition does not imply separability; some parts exist only through binding relationships.
- **Differentiation.** This capacity becomes available when differentiation fits the timing, limits, and needs of the larger system.
- **Compositional Power.** This capacity becomes available when compositional power fits the timing, limits, and needs of the larger system.

## Wounds

- **Fragmentation.** The pattern distorts when fragmentation replaces responsive relationship.
- **Forced Independence.** Forced Independence appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Identity Reduced To Parts.** Identity Reduced To Parts appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **contribution** becomes **fragmentation** when scale, timing, boundary, or reciprocity is ignored. Quark asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

contribution remains connected to differentiation while limits are respected; fragmentation is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **fragmentation, forced independence, identity reduced to parts**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **contribution, differentiation, compositional power** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** At the lower boundary of the deck, shift from object language to fields, interactions, measurement conditions, and quantum states rather than inventing a smaller card.
- **Its own scale:** Attend to binding and transformation as they actually operate in Quark; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Hydrogen](010-hydrogen.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Quark.
- **Deep time:** Consider interaction instants; confined in hadrons. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with constituent: examine both contribution and fragmentation. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support differentiation or produce forced independence. |
| Creativity | Work with the card's actual process—binding and transformation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **contribution** already present, even in a small or quiet form?
2. Where might **fragmentation** be shaping the situation?
3. Where do you observe **binding**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Constituent** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Quark**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Composition does not imply separability; some parts exist only through binding relationships.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **contribution** while reducing **fragmentation**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Why quarks occur in three generations and why their masses span such a wide range are unexplained features of the Standard Model.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Quark. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Constituent** as the original synthesis for Quark: Composition does not imply separability; some parts exist only through binding relationships. This meaning arises from the sourced description of binding and transformation, then becomes a reflective lens through the gift of **contribution** and the wound of **fragmentation**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Chemical Bond](014-chemical-bond.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Chemical Bond](014-chemical-bond.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** No smaller core card is asserted; use the explicit lower-boundary guidance above.
- **Larger scale:** [Hydrogen](010-hydrogen.md) helps identify containing systems and downstream effects.
- **Shared process:** [Proton](003-proton.md) also expresses binding, but with different constraints.
- **Shared wound:** [Coral Colony](033-coral-colony.md) also carries the wound **fragmentation**.
- **Natural cycle:** [Hydrogen](010-hydrogen.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Photon](001-photon.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Quark at its characteristic scale, with the central visual emphasis on **binding and transformation** and **seed and component**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Department of Energy Office of Science.** [DOE Explains: The Standard Model of Particle Physics](https://www.energy.gov/science/doe-explainsthe-standard-model-particle-physics). Accessed 2026-08-23.
- **S02 — CERN.** [The Standard Model](https://home.cern/science/physics/standard-model). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Why quarks occur in three generations and why their masses span such a wide range are unexplained features of the Standard Model.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Quark is retained because **Constituent** is not duplicated by Photon, even where their processes overlap.
