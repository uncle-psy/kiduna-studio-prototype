---
card_number: 32
name: "Kelp"
slug: "kelp"
scale_band: "4. Organism"
scientific_domains: ["phycology","marine ecology"]
natural_processes: ["growth","flow"]
system_functions: ["builder","carrier"]
spatial_scale: "metres to tens of metres"
time_scale: "days of rapid growth to multi-year life cycles"
core_archetype: "Flexible Builder"
primary_gifts: ["flexibility","rapid growth","habitat creation"]
primary_wounds: ["uprooting","overextension","dependence on narrow conditions"]
related_cards: ["kelp-forest", "cell-membrane", "symbiosis", "coral-reef", "plasma", "river", "glacier", "plankton"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "entity"
status: complete
---

# Kelp

## Essence

Structure can be strong because it yields to motion.

## Keywords

growth · flow · builder · carrier · flexibility · rapid growth · habitat creation

## What it is

Kelp are large brown algae rather than plants. Holdfasts attach them to substrate, while flexible stipes and blades reach light; some species use gas-filled structures for buoyancy. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** metres to tens of metres.
- **Characteristic time:** days of rapid growth to multi-year life cycles.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Cell Membrane](019-cell-membrane.md).
- **Larger container:** A useful containing or consequence-level bridge is [Kelp Forest](044-kelp-forest.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Kelp photosynthesize, grow quickly under favorable cold nutrient-rich conditions, flex with waves, shed tissue, reproduce by spores, and create three-dimensional habitat. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

Resilience can come from moving with force while maintaining attachment and direction.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Flexible Builder.** Kelp deserves its own card because it makes **builder and carrier** legible through **growth and flow** at the organism scale. It differs from [Seed](028-seed.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Flexibility.** Resilience can come from moving with force while maintaining attachment and direction.
- **Rapid Growth.** This capacity becomes available when rapid growth fits the timing, limits, and needs of the larger system.
- **Habitat Creation.** This capacity becomes available when habitat creation fits the timing, limits, and needs of the larger system.

## Wounds

- **Uprooting.** The pattern distorts when uprooting replaces responsive relationship.
- **Overextension.** Overextension appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Dependence On Narrow Conditions.** Dependence On Narrow Conditions appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **flexibility** becomes **uprooting** when scale, timing, boundary, or reciprocity is ignored. Kelp asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

flexibility remains connected to rapid growth while limits are respected; uprooting is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **uprooting, overextension, dependence on narrow conditions**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **flexibility, rapid growth, habitat creation** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Cell Membrane](019-cell-membrane.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to growth and flow as they actually operate in Kelp; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Kelp Forest](044-kelp-forest.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Kelp.
- **Deep time:** Consider days of rapid growth to multi-year life cycles. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with flexible builder: examine both flexibility and uprooting. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support rapid growth or produce overextension. |
| Creativity | Work with the card's actual process—growth and flow—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **flexibility** already present, even in a small or quiet form?
2. Where might **uprooting** be shaping the situation?
3. Where do you observe **growth**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Flexible Builder** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Kelp**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **Resilience can come from moving with force while maintaining attachment and direction.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **flexibility** while reducing **uprooting**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Responses to marine heatwaves, nutrient change, grazers, storms, and interacting stressors vary among species and regions.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Kelp. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Flexible Builder** as the original synthesis for Kelp: Resilience can come from moving with force while maintaining attachment and direction. This meaning arises from the sourced description of growth and flow, then becomes a reflective lens through the gift of **flexibility** and the wound of **uprooting**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Cosmic Web](080-cosmic-web.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Kelp Forest](044-kelp-forest.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Cell Membrane](019-cell-membrane.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Kelp Forest](044-kelp-forest.md) helps identify containing systems and downstream effects.
- **Shared process:** [Plasma](016-plasma.md) also expresses flow, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Symbiosis](037-symbiosis.md) offers a nearby systems comparison.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Seed](028-seed.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Kelp at its characteristic scale, with the central visual emphasis on **growth and flow** and **builder and carrier**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — NOAA National Ocean Service.** [What is a kelp forest?](https://oceanservice.noaa.gov/facts/kelp.html). Accessed 2026-08-23.
- **S02 — NOAA National Ocean Service.** [What is a current?](https://oceanservice.noaa.gov/facts/current.html). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Responses to marine heatwaves, nutrient change, grazers, storms, and interacting stressors vary among species and regions.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Kelp is retained because **Flexible Builder** is not duplicated by Seed, even where their processes overlap.
