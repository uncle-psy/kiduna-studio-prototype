---
card_number: 18
name: "Catalysis"
slug: "catalysis"
scale_band: "2. Atomic and molecular"
scientific_domains: ["chemistry","biochemistry"]
natural_processes: ["catalysis","transformation"]
system_functions: ["catalyst","bridge"]
spatial_scale: "molecular active sites to industrial reactors"
time_scale: "femtoseconds to repeated cycles"
core_archetype: "Alternate Path"
primary_gifts: ["enablement","efficiency","lowered barrier"]
primary_wounds: ["dependency","misdirected acceleration","unaccounted side reaction"]
related_cards: ["quark", "cell-membrane", "oxygen", "chemical-bond", "gluon", "phase-transition", "lichen", "pollinator"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "process"
status: complete
---

# Catalysis

## Essence

Change may become possible when the path changes, not the goal.

## Keywords

catalysis · transformation · catalyst · bridge · enablement · efficiency · lowered barrier

## What it is

Catalysis changes the rate of a reaction by providing a different reaction pathway with a lower activation barrier. A catalyst participates in intermediate steps and is regenerated overall, though it can degrade or be poisoned. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** molecular active sites to industrial reactors.
- **Characteristic time:** femtoseconds to repeated cycles.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Electron](002-electron.md).
- **Larger container:** A useful containing or consequence-level bridge is [Mitochondrion](021-mitochondrion.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Catalysts orient reactants, stabilize transition states, or shuttle charge and atoms. They do not change the thermodynamic equilibrium; they change how quickly a system approaches it. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

The right intervention changes the route and timing without pretending to change underlying limits.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Alternate Path.** Catalysis deserves its own card because it makes **catalyst and bridge** legible through **catalysis and transformation** at the atomic and molecular scale. It differs from [Phase Transition](017-phase-transition.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Enablement.** The right intervention changes the route and timing without pretending to change underlying limits.
- **Efficiency.** This capacity becomes available when efficiency fits the timing, limits, and needs of the larger system.
- **Lowered Barrier.** This capacity becomes available when lowered barrier fits the timing, limits, and needs of the larger system.

## Wounds

- **Dependency.** The pattern distorts when dependency replaces responsive relationship.
- **Misdirected Acceleration.** Misdirected Acceleration appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Unaccounted Side Reaction.** Unaccounted Side Reaction appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **enablement** becomes **dependency** when scale, timing, boundary, or reciprocity is ignored. Catalysis asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

enablement remains connected to efficiency while limits are respected; dependency is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **dependency, misdirected acceleration, unaccounted side reaction**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **enablement, efficiency, lowered barrier** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Electron](002-electron.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to catalysis and transformation as they actually operate in Catalysis; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Mitochondrion](021-mitochondrion.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Catalysis.
- **Deep time:** Consider femtoseconds to repeated cycles. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with alternate path: examine both enablement and dependency. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support efficiency or produce misdirected acceleration. |
| Creativity | Work with the card's actual process—catalysis and transformation—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **enablement** already present, even in a small or quiet form?
2. Where might **dependency** be shaping the situation?
3. Where do you observe **catalysis**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Alternate Path** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Catalysis**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **The right intervention changes the route and timing without pretending to change underlying limits.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **enablement** while reducing **dependency**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Real catalytic mechanisms, selectivity, active-site evolution, and behavior under operating conditions can remain uncertain even for widely used catalysts.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Catalysis. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Alternate Path** as the original synthesis for Catalysis: The right intervention changes the route and timing without pretending to change underlying limits. This meaning arises from the sourced description of catalysis and transformation, then becomes a reflective lens through the gift of **enablement** and the wound of **dependency**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Quark](006-quark.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Quark](006-quark.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Electron](002-electron.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Mitochondrion](021-mitochondrion.md) helps identify containing systems and downstream effects.
- **Shared process:** [Quark](006-quark.md) also expresses transformation, but with different constraints.
- **Shared wound:** [Oxygen](012-oxygen.md) also carries the wound **dependency**.
- **Natural cycle:** [Gluon](007-gluon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Phase Transition](017-phase-transition.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Catalysis at its characteristic scale, with the central visual emphasis on **catalysis and transformation** and **catalyst and bridge**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — International Union of Pure and Applied Chemistry.** [Compendium of Chemical Terminology (Gold Book)](https://goldbook.iupac.org/). Accessed 2026-08-23.
- **S02 — National Institute of Standards and Technology.** [NIST Chemistry WebBook](https://webbook.nist.gov/chemistry/). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Real catalytic mechanisms, selectivity, active-site evolution, and behavior under operating conditions can remain uncertain even for widely used catalysts.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Catalysis is retained because **Alternate Path** is not duplicated by Phase Transition, even where their processes overlap.
