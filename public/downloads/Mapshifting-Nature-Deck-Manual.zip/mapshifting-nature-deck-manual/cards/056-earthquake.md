---
card_number: 56
name: "Earthquake"
slug: "earthquake"
scale_band: "7. Geologic and continental"
scientific_domains: ["seismology","hazard science"]
natural_processes: ["rupture","transmission"]
system_functions: ["disruptor","signal"]
spatial_scale: "fault patch to global wave propagation"
time_scale: "seconds to aftershock sequences lasting years"
core_archetype: "Sudden Release"
primary_gifts: ["release","revealed structure","reset"]
primary_wounds: ["destruction","shock propagation","romanticized hazard"]
related_cards: ["virus", "watershed", "planet", "photon", "fault", "neutrino", "neutron-star", "mass-extinction"]
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence: "high for core description"
card_type: "process"
status: complete
---

# Earthquake

## Essence

A rapid event may be the visible moment of long accumulation.

## Keywords

rupture · transmission · disruptor · signal · release · revealed structure · reset

## What it is

An earthquake is ground shaking and energy release caused mainly by sudden fault slip, though volcanic and other processes can also generate seismic events. Seismic waves reveal both the rupture and Earth's interior. [S01] [S02]

**Provenance:** scientific description. The final sentence of the Essence and all reflective interpretations below are deck synthesis, not scientific findings.

## Scale

- **Physical scale:** fault patch to global wave propagation.
- **Characteristic time:** seconds to aftershock sequences lasting years.
- **Smaller structures:** A useful composing or mechanism-level bridge is [Fault](055-fault.md).
- **Larger container:** A useful containing or consequence-level bridge is [Planet](064-planet.md).

Scale is part of the meaning: a process that is negligible in one interaction can become decisive after repetition, accumulation, or network propagation.

## How it behaves

Rupture initiates, propagates, and stops across a fault while waves travel outward. Aftershocks and deformation continue as the crust readjusts. [S01] [S02]

Behavior should not be moralized. The same process may maintain one system while disrupting another, and its effect changes with rate, location, duration, and relationship.

## Natural pattern

The event is not the whole process: accumulation, rupture, propagation, and recovery occur on different clocks.

This is the transferable pattern used by the deck. It is an analogy grounded in observed behavior, not a claim that the phenomenon intends, judges, predicts, or causes human events.

## Core archetype

**Sudden Release.** Earthquake deserves its own card because it makes **disruptor and signal** legible through **rupture and transmission** at the geologic and continental scale. It differs from [Subduction Zone](058-subduction-zone.md): the two may share a scale or outward resemblance, but they organize matter, energy, information, or relationship differently.

## Gifts

- **Release.** The event is not the whole process: accumulation, rupture, propagation, and recovery occur on different clocks.
- **Revealed Structure.** This capacity becomes available when revealed structure fits the timing, limits, and needs of the larger system.
- **Reset.** This capacity becomes available when reset fits the timing, limits, and needs of the larger system.

## Wounds

- **Destruction.** The pattern distorts when destruction replaces responsive relationship.
- **Shock Propagation.** Shock Propagation appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.
- **Romanticized Hazard.** Romanticized Hazard appears when the card's underlying force is blocked, depleted, isolated, or allowed to exceed the system's capacity.

These are prompts for reflection, not diagnoses. No wound means that the natural phenomenon is bad, and no gift makes it morally good.

## Gift–wound relationship

The gift and wound arise from the same capacity. **release** becomes **destruction** when scale, timing, boundary, or reciprocity is ignored. Earthquake asks not “Is this force good?” but “What does this force do here, at this intensity, for this duration, in relation to what?”

## Balanced expression

release remains connected to revealed structure while limits are respected; destruction is noticed early rather than denied. The participant can use the pattern without pretending to control every outcome or confusing metaphor with mechanism.

## Overexpression

Overexpression resembles **destruction, shock propagation, romanticized hazard**: the pattern becomes too intense, too centralized, too fast, too persistent, or insufficiently responsive to feedback. What originally served connection or transformation begins to narrow the system's options.

## Underexpression

Underexpression appears when **release, revealed structure, reset** cannot develop. The relevant movement, boundary, exchange, or signal is absent, depleted, denied, or unable to reach the scale where it matters.

## Change of scale

- **Smaller scale:** Ask what constituents or shorter interactions compose this pattern. [Fault](055-fault.md) offers one scientifically grounded bridge.
- **Its own scale:** Attend to rupture and transmission as they actually operate in Earthquake; do not substitute a larger story for present conditions.
- **Larger system:** Follow what the card carries, alters, stores, or releases into [Planet](064-planet.md) and beyond. A local gift may create a downstream wound, or a local wound may be a symptom of a containing system.

## Change over time

- **Immediate moment:** Notice the current state, active force, and nearest feedback. What is moving or being held now?
- **Developmental cycle:** Track how initiation, maintenance, transition, and ending change the role of Earthquake.
- **Deep time:** Consider seconds to aftershock sequences lasting years. Ask which effects accumulate, which records survive, and which apparent constants are only slow changes.

## Appearing in a reading

These are possibilities, not predictions.

| Domain | Possible reading |
|---|---|
| Identity | You may be identifying with sudden release: examine both release and destruction. |
| Relationships | Trace what is exchanged, withheld, amplified, or carried between people. |
| Community | Look for how the local pattern contributes to a network and who bears downstream effects. |
| Work | Ask whether structure, timing, and feedback support revealed structure or produce shock propagation. |
| Creativity | Work with the card's actual process—rupture and transmission—rather than forcing an abstract idea. |
| Conflict | Change scale: the visible clash may be a boundary event, accumulated pressure, or system-level routing problem. |
| Healing and restoration | Identify conditions that would restore exchange, diversity, pacing, or containment; this is reflective guidance, not medical treatment. |
| Decision-making | Compare the immediate benefit with effects on the next larger system and the next longer time scale. |
| Leadership | Steward the conditions and feedbacks; do not claim command over the whole living system. |
| Change | Determine whether the system needs release, stabilization, a new path, or time for development. |
| Uncertainty and long-term direction | Separate established observation, model-based expectation, open question, and deck metaphor before acting. |

## Questions for reflection

1. Where is **release** already present, even in a small or quiet form?
2. Where might **destruction** be shaping the situation?
3. Where do you observe **rupture**, and what evidence supports that reading?
4. If you moved one scale smaller, which parts or brief interactions would become visible?
5. If you moved one scale larger, who or what receives the downstream consequence?
6. What boundary, carrier, feedback, or time delay is easy to overlook here?
7. What would a balanced expression of **Sudden Release** look like this week?
8. What one observable, reversible action could test that possibility without pretending to guarantee an outcome?

## Practice

Create a three-layer map titled **Earthquake**. In the first layer, write only observations from the present situation. In the second, label the card's pattern: **The event is not the whole process: accumulation, rupture, propagation, and recovery occur on different clocks.** In the third, draw one smaller composing process and one larger containing system. Circle a single reversible action that supports **release** while reducing **destruction**. After acting, record what changed and what did not. Do not approach hazards, handle organisms, alter habitat, or use this practice as medical advice.

## Scientific uncertainty

Exact initiation, rupture evolution, ground motion at a site, and the timing of future earthquakes remain uncertain; probabilities are not predictions.

**Confidence boundary:** the core description and observed behavior are supported by the sources below. The reflective meanings are original deck synthesis and have no status as scientific evidence.

## Cultural and historical interpretations

This core edition adopts no culturally specific symbolic teaching for Earthquake. That is an intentional cultural-integrity decision: absence of a responsibly sourced, community-appropriate account is not permission to generalize, extract, or invent one.

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|
| Mapshifting editorial policy | No culturally specific symbolism adopted; scientific history is kept separate from deck synthesis. | Core edition, 2026-08-23 | [Cultural-attribution ledger](../research/CULTURAL-ATTRIBUTION.md) | High |

## Mapshifting synthesis

The deck adopts **Sudden Release** as the original synthesis for Earthquake: The event is not the whole process: accumulation, rupture, propagation, and recovery occur on different clocks. This meaning arises from the sourced description of rupture and transmission, then becomes a reflective lens through the gift of **release** and the wound of **destruction**. It does not imply consciousness, intention, destiny, supernatural causation, or prediction in the natural phenomenon.

## Card relationships

- **Complementary:** [Photon](001-photon.md) expresses a related process through a different kind of natural form.
- **Balancing:** [Virus](024-virus.md) helps test whether the present pattern needs counterweight, pacing, or a wider context.
- **Smaller scale:** [Fault](055-fault.md) helps identify composing mechanisms or a grounded lower-scale bridge.
- **Larger scale:** [Planet](064-planet.md) helps identify containing systems and downstream effects.
- **Shared process:** [Photon](001-photon.md) also expresses transmission, but with different constraints.
- **Shared wound:** No other core card repeats this exact primary wound set; [Planet](064-planet.md) offers a nearby systems comparison.
- **Natural cycle:** [Photon](001-photon.md) can be paired with this card to trace movement, storage, transformation, or return.
- **Easily confused:** [Subduction Zone](058-subduction-zone.md) is distinct because its primary archetype and system function are different.

## Future visual brief

Create a scientifically informed, non-anthropomorphic depiction of Earthquake at its characteristic scale, with the central visual emphasis on **rupture and transmission** and **disruptor and signal**. Include one accurate smaller-scale inset and one faint larger-system context. Avoid mystical energy effects, human faces, sacred cultural motifs, false color presented as natural color, and any suggestion that the phenomenon possesses intention. No image is generated in this edition.

## Sources

- **S01 — U.S. Geological Survey.** [The Science of Earthquakes](https://www.usgs.gov/programs/earthquake-hazards/science-earthquakes). Accessed 2026-08-23.
- **S02 — U.S. Geological Survey.** [Plate Tectonics in a Nutshell](https://volcanoes.usgs.gov/about/edu/dynamicplanet/nutshell.php). Accessed 2026-08-23.

## Research notes

- **Expert review focus:** Exact initiation, rupture evolution, ground motion at a site, and the timing of future earthquakes remain uncertain; probabilities are not predictions.
- **Cultural review:** no specific cultural claim is included; any future addition requires a community-appropriate primary source, permissions review, and clear separation from science.
- **Editorial distinction:** Earthquake is retained because **Sudden Release** is not duplicated by Subduction Zone, even where their processes overlap.
