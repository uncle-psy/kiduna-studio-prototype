# Changelog


## 1.0.0 — 2026-08-23

- Established the 81-card core roster with nine cards per scale band.
- Completed all card files with YAML, scientific/source boundaries, gift–wound analysis, scale and time shifts, readings, practices, relationships, uncertainty, and future visual briefs.
- Added the full manual, required spreads, eleven indexes, research ledgers, scientific and cultural audits, glossary, annotated bibliography, template, completeness report, and manifest.
- Confirmed that no card images were generated.
