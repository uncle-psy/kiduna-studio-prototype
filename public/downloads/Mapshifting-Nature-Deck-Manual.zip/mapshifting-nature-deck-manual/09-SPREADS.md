# Spreads


All spreads are reflective maps, not fixed predictions. Read the scientific description before the deck synthesis, name the scale of each position, and end with an observable choice or an explicit decision to gather more information.

## Single Phenomenon

**One card:** the most relevant natural pattern. Ask what fits, what does not, and which evidence would distinguish the two.

## Gift and Wound

1. **Gift:** a capacity available in the situation.
2. **Wound:** the same or a related force under excess, depletion, displacement, or delay.

Do not assign one card as “good” and the other as “bad.” Read the relationship.

## Part and Whole

1. **Smaller composing process**
2. **Present system**
3. **Larger containing system**

After reading, redraw the question at each boundary. Note what becomes action-relevant and what disappears.

## Flow

1. **Source**
2. **Carrier**
3. **Obstruction**
4. **Transformation**
5. **Destination**

Identify whether the flow is matter, energy, information, attention, authority, money, time, or something else. Do not use “energy” when a more precise word exists.

## Threshold

1. **Existing state**
2. **Accumulating pressure**
3. **Threshold**
4. **Phase change**
5. **Emerging condition**

Test whether the presumed threshold is observed, model-based, feared, or metaphorical. Not every increase leads to abrupt change.

## Ecosystem

1. **Subject**
2. **Environment**
3. **Resource**
4. **Competitor or constraint**
5. **Ally or symbiosis**
6. **Disturbance**
7. **Systemic outcome**

This spread resists hero-centered readings by placing the subject within resources, limits, allies, disturbance, and indirect effects.

## Deep Time

1. **Origin**
2. **Formation**
3. **Early condition**
4. **Present condition**
5. **Active pressure**
6. **Transformation**
7. **Long-term possibility**

Separate evidence about the past from narrative convenience. “Long-term possibility” is a scenario, not destiny.

## Nine Scales

Draw nine cards, one for each scale band in order:

1. Fundamental
2. Atomic and molecular
3. Microscopic and cellular
4. Organism
5. Community and ecosystem
6. Landscape and regional system
7. Geologic and continental
8. Planetary and orbital
9. Stellar and cosmic

If the random draw does not match the position's band, either draw from nine pre-sorted scale piles or treat the mismatch explicitly as a limitation. Do not pretend a card belongs to a scientific scale it does not.

## Closing every spread

End with four statements: **what I observed; what I inferred; what remains unknown; what I can responsibly do next.** Schedule a review date if an action is taken.
