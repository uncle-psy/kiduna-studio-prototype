# Goal and Scope


## Purpose of the Nature Deck

The Nature Deck helps a participant recognize structures, flows, thresholds, relationships, and time scales that may be active in a situation. It draws from science because science offers disciplined descriptions of how natural phenomena form, interact, change, and remain uncertain. It draws from symbolic practice because analogy can help a participant notice patterns, generate questions, compare perspectives, and choose a grounded action.

The deck does not declare a fixed future. A card does not mean that the named phenomenon has selected the participant, caused an event, or delivered a supernatural message. Drawing a card is a constrained prompt: it supplies a well-defined natural pattern, a set of gifts and wounds, and a requirement to examine evidence at more than one scale.

## Primary questions

- What pattern is active, and what evidence supports that reading?
- At what scale is it visible, and at what scale is it produced?
- What larger system contains it?
- What matter, energy, information, or influence is flowing?
- Which boundary filters, concentrates, blocks, or redirects that flow?
- What is stable, what is changing, and on which clock?
- Where is a threshold near, crossed, or merely imagined?
- What gift is available, what wound is unresolved, and what action remains possible?

## Boundaries of use

This manual supports reflection, facilitated inquiry, journaling, observation, and systems thinking. It is not medical, mental-health, legal, financial, emergency, ecological-management, or hazard-safety advice. Scientific passages are written for an intelligent general reader and point to authoritative sources, but they do not replace specialist literature or site-specific assessment.

Hazard cards—including Earthquake, Volcano, Fault, Mass Extinction, and Black Hole—are not invitations to romanticize danger. Human suffering during disasters is not evidence of personal imbalance. Participants should follow qualified authorities and emergency guidance in real situations.

## Final scope decision

The core contains **81 cards**: nine in each of nine scale bands. Eighty-one is justified here not by numerology but by coverage. It allows every band to include a meaningful mixture of entity, process, and relationship cards; keeps the deck practical; and leaves distinct but nonessential subjects in the [expansion index](indexes/EXPANSION-CANDIDATES.md).

The roster deliberately avoids being a catalog of attractive objects. [Photon](cards/001-photon.md), [Chemical Bond](cards/014-chemical-bond.md), [Cell Membrane](cards/019-cell-membrane.md), [Watershed](cards/046-watershed.md), [Subduction Zone](cards/058-subduction-zone.md), [Orbit](cards/066-orbit.md), and [Cosmic Web](cards/080-cosmic-web.md) make relationship, process, and nested context central.

## What belongs elsewhere

Strong candidates omitted to prevent duplication or overload include Dark Matter, Dark Energy, Quantum Vacuum, Salt, RNA, Gene Regulation, Mycelial Network, Fire, Storm, Dune Field, Cave, Mineral Vein, Asteroid, Solar Wind, Tidal Locking, Galactic Collision, and Cosmic Void. Their rationale appears in the [expansion-candidates index](indexes/EXPANSION-CANDIDATES.md).
