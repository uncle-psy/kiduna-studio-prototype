# Ethics and Cultural Integrity


## Ethical stance

The deck supports agency by widening a map, not by claiming authority over a participant. Readings are invitations. Consent can be withdrawn. A participant may decline a card, reject an analogy, or end the process without explanation.

Do not use the deck to predict death, diagnose illness, advise stopping treatment, determine guilt, direct financial risk, justify surveillance, or replace emergency and hazard guidance. A reflective practice should become more modest as stakes rise.

## Nature is not a moral court

Earthquakes, storms, fires, extinctions, disease, and other hazards do not occur because a person or community is spiritually unbalanced. Describing a volcano as “pressure release” is a deck synthesis based on geologic behavior; it is not an explanation for why a disaster affected particular people.

## Cultural-integrity rules

1. Attribute a teaching to a specific people, community, author, text, or living tradition.
2. Prefer sources created, published, or approved by the community.
3. Use living cultures in the present tense where appropriate.
4. Do not treat Indigenous knowledge as one universal category.
5. Do not extract closed, sacred, ceremonial, initiatory, or restricted material.
6. Do not decorate scientific content with sacred cosmology.
7. Do not claim equivalence because two accounts share a surface resemblance.
8. Record permissions, preferred names, source context, and limits on reuse.
9. Place uncertain claims in research records, not finished cards.
10. Compensate and credit specialist or community review when cultural knowledge materially shapes an edition.

## Core-edition decision

No culturally specific symbolism has been adopted in the 81 core card files. This is not a claim that no such knowledge exists. It is a boundary chosen because broad internet research cannot establish permission, community standing, or whether knowledge is appropriate for an oracle-style commercial or public artifact.

The [Cultural Attribution Ledger](research/CULTURAL-ATTRIBUTION.md) records this decision and the workflow for later proposals. Any proposed addition must remain visibly separate from the deck's original synthesis and scientific account.

## Scientific traditions and history

Scientific concepts also have histories, institutions, disputes, and uneven power. Where historical material is added, it should identify the source and context rather than tell a lone-genius myth. Terminology inherited from Greek, Latin, or other languages should not be mistaken for a timeless universal worldview.

## Privacy and facilitation

Do not record another person's reading without permission. Avoid collecting sensitive disclosures unnecessary to the practice. When journaling in groups, state who can see the material, how long it will be kept, and how it can be removed.

## Review triggers

Pause publication and seek specialist review when a card includes a living community's teaching, a disputed attribution, a sacred site or being, a language translation, colonial-era ethnography, or material with unclear permissions. Silence is preferable to confident extraction.
