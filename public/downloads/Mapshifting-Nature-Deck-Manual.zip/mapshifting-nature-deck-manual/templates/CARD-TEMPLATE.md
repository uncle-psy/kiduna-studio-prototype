---
card_number:
name:
slug:
scale_band:
scientific_domains: []
natural_processes: []
system_functions: []
spatial_scale:
time_scale:
core_archetype:
primary_gifts: []
primary_wounds: []
related_cards: []
provenance_labels: ["scientific description", "observed behavior", "deck metaphor"]
scientific_confidence:
card_type:
status: draft
---

# Card name

## Essence

## Keywords

## What it is

## Scale

## How it behaves

## Natural pattern

## Core archetype

## Gifts

## Wounds

## Gift–wound relationship

## Balanced expression

## Overexpression

## Underexpression

## Change of scale

## Change over time

## Appearing in a reading

## Questions for reflection

## Practice

## Scientific uncertainty

## Cultural and historical interpretations

| Culture, text, or source | Interpretation | Period and context | Source | Confidence |
|---|---|---|---|---|

## Mapshifting synthesis

## Card relationships

## Future visual brief

## Sources

## Research notes
