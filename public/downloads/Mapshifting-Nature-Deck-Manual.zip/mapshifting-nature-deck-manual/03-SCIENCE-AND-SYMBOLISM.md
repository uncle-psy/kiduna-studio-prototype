# Scientific and Symbolic Interpretation


## Five separate layers

Every card uses five layers that must not be collapsed:

1. **Scientific description:** what the phenomenon is under current evidence and models.
2. **Observed behavior:** what it forms, does, exchanges, or becomes.
3. **Historical or cultural interpretation:** only when specific, sourced, appropriate, and nonrestricted.
4. **Mapshifting synthesis:** the deck's original reflective meaning.
5. **Open question:** what remains uncertain, unobserved, debated, or model-dependent.

The words “field,” “energy,” “information,” “resonance,” “quantum,” and “frequency” have technical meanings. The deck may also use ordinary-language meanings, but it must label the shift. Quantum physics is not evidence that thought alone manifests external events, that consciousness collapses reality in a personally directive way, or that healing occurs through unspecified vibrations.

## How analogy earns its place

A sound deck analogy begins with a documented pattern, names the shared structure, and names the break in equivalence. [Catalysis](cards/018-catalysis.md) supports the question “Could a different path lower the barrier?” because catalysts provide alternate reaction pathways. It does not imply that every life obstacle is chemical, that a facilitator remains unchanged, or that the desired outcome is thermodynamically possible.

[Fault](cards/055-fault.md) supports inquiry into accumulated strain because locked faults can store elastic deformation. It does not mean psychological stress causes earthquakes or that releasing emotion prevents geologic hazards.

## Scientific models

A model is not “just a guess.” It is a selective representation used to explain, calculate, test, and predict within a domain. Models have assumptions and ranges. Orbital approximations, plate tectonics, food webs, climate models, and the Standard Model of particle physics differ in form and scope. Their limitations should guide better use, not invite unsupported replacement.

## Scientific uncertainty

Uncertainty is information about the limits of evidence, measurement, variability, and model structure. It does not make all claims equally plausible. Each card states a core confidence boundary and an open question. Readers should distinguish uncertainty about a detail from uncertainty about the phenomenon's existence.

## Cultural and historical material

This core edition takes a conservative approach: it adopts no culturally specific symbolic teaching inside individual cards. This avoids decorative extraction, false universals, and accidental exposure of restricted knowledge. Future editions may add material only through the process in [Ethics and Cultural Integrity](08-ETHICS-AND-CULTURAL-INTEGRITY.md) and the [cultural-attribution ledger](research/CULTURAL-ATTRIBUTION.md).

## Reading protocol

Before using a card interpretation, say which layer you are using. A simple script is: “Scientifically, the card describes ____. The transferable pattern is ____. In this situation, that metaphor makes me ask ____. The evidence I have is ____. The uncertainty is ____.” This preserves poetry without counterfeit authority.
