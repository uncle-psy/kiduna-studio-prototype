# Deck Architecture


## Three intersecting dimensions

Every card is positioned by **scale**, **natural process**, and **system function**. A fourth editorial label—entity, process, or system relationship—helps balance the roster but does not replace those dimensions.

### Scale

Each of nine bands contains exactly nine cards. This equal count prevents the familiar and visible scales from overwhelming the fundamental, microscopic, geologic, or cosmic. Equal count does not claim equal natural importance.

### Natural process

Processes include binding, exchange, transmission, flow, accumulation, phase transition, metabolism, replication, symbiosis, decomposition, succession, circulation, rupture, erosion, orbit, collapse, emergence, extinction, and regeneration. The [Process Index](indexes/PROCESS-INDEX.md) shows where each appears.

### System function

Functions describe what the phenomenon does in a system: signal, carrier, boundary, filter, bridge, network, memory, catalyst, builder, dissolver, regulator, protector, disruptor, threshold, clock, field, and whole. These are deck-facing roles grounded in science, not universal archetypal laws.

## Why 81

The candidate inventory was first widened beyond 140 subjects. Candidates were mapped to scale, process, and function, then screened for distinct mechanism, interpretive usefulness, source quality, overlap, balance, and practical deck size. Eighty-one is the smallest reviewed roster that preserved nine meaningful entries per band after removing the strongest duplications.

The roster includes 37 entities, 13 processes, and 31 system relationships. It is intentionally relationship-heavy: the governing principle says nature is nested exchange, not isolated inventory.

## Distinction tests

- **Proton / Photon:** proton anchors elemental identity within nuclei; photon carries electromagnetic energy and information.
- **River / Watershed:** river foregrounds channel flow; watershed foregrounds the full contributing and routing area.
- **Fault / Earthquake:** fault is a structure with displacement and stored strain; earthquake is an episode of rupture and wave transmission.
- **Planet / Orbit:** planet is a differentiated world; orbit is a gravitational relationship and trajectory.
- **Galaxy / Cosmic Web:** galaxy is a bound evolving system; cosmic web is the largest-scale distribution and flow pattern of matter.

## Canonical registry

The [Card Index](indexes/CARD-INDEX.md) is the human-readable registry. YAML front matter in each card is the structured canonical record. Card number and slug are stable identifiers for this edition. Renaming or replacing a card requires a changelog entry, repaired links, regenerated indexes, and a new audit.

## Expansion policy

An expansion card must add a mechanism, scale relation, or system function not already served well. Beauty, popularity, or symbolic familiarity alone is insufficient. See [Expansion Candidates](indexes/EXPANSION-CANDIDATES.md).
