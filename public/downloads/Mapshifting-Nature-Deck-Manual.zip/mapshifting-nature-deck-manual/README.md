# Mapshifting Nature Deck Manual


This directory is the complete core manual for an 81-card Mapshifting deck grounded in natural structures, processes, and relationships from elementary particles to the expanding universe. **Mapshifting is always one word.** The deck is a reflective and self-inquiry tool. It is not a predictive device, a substitute for expertise, or evidence of supernatural causation.

## Completion snapshot

- **Final deck:** 81 cards, with exactly nine cards in each of nine scale bands.
- **Card balance:** 37 entities, 13 processes, and 31 system relationships.
- **Scientific sources:** 51 authoritative source records in the core ledger.
- **Images:** none generated. Every card contains only a future visual brief.
- **Status:** complete core edition; bounded scientific questions and future specialist-review needs are recorded rather than concealed.

## Start here

1. [Goal and scope](00-GOAL-AND-SCOPE.md)
2. [Nature as nested systems](01-NATURE-AS-NESTED-SYSTEMS.md)
3. [Scale and Mapshifting](02-SCALE-AND-MAPSHIFTING.md)
4. [Science and symbolism](03-SCIENCE-AND-SYMBOLISM.md)
5. [Gifts and wounds](04-GIFTS-AND-WOUNDS.md)
6. [Deck architecture](05-DECK-ARCHITECTURE.md)
7. [How to use the deck](06-HOW-TO-USE-THE-DECK.md)
8. [Reading across scales](07-READING-ACROSS-SCALES.md)
9. [Ethics and cultural integrity](08-ETHICS-AND-CULTURAL-INTEGRITY.md)
10. [Spreads](09-SPREADS.md)

## Catalog, indexes, and research

- [Complete card catalog](indexes/CARD-INDEX.md)
- [Scale index](indexes/SCALE-INDEX.md)
- [Process index](indexes/PROCESS-INDEX.md)
- [System-function index](indexes/SYSTEM-FUNCTION-INDEX.md)
- [Natural cycles](indexes/NATURAL-CYCLES.md)
- [Expansion candidates](indexes/EXPANSION-CANDIDATES.md)
- [Glossary](GLOSSARY.md)
- [Annotated bibliography](BIBLIOGRAPHY.md)
- [Source ledger](research/SOURCE-LEDGER.md)
- [Scientific and cultural audit](research/AUDIT-REPORT.md)
- [Completeness report](research/COMPLETENESS-REPORT.md)
- [Manifest](MANIFEST.md)

## Provenance rule

Each card separates: **scientific description**, **observed behavior**, **cultural or historical interpretation when responsibly sourced**, **original Mapshifting synthesis**, and **open scientific question**. A metaphor is never presented as a mechanism. A scientific model is never used as proof of manifestation, destiny, healing, consciousness, or spiritual causation.
