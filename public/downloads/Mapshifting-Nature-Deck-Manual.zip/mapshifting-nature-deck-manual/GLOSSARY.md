# Glossary

## Acceleration

Change in velocity; in cosmology, “accelerated expansion” means the expansion rate evolves in a way attributed to dark energy or equivalent physics, not that galaxies fire engines outward.

## Accretion

Growth through gravitational or physical accumulation of material.

## Adaptation

A heritable trait shaped by natural selection, or contextually a process of adjustment; the two meanings should not be silently mixed.

## Archetype

In this deck, a concise original organizing pattern; not a claim of a universal inherited symbol.

## Boundary

A physical, functional, analytical, or causal limit that separates while often regulating exchange.

## Catalyst

A participant that changes reaction rate by an alternate pathway and is regenerated overall.

## Confidence

A bounded statement about how strongly evidence supports a claim, distinct from personal conviction.

## Deep time

Time spans sufficient for geologic, evolutionary, planetary, or cosmic change to become visible.

## Dissipation

Spreading of organized energy into less available forms, commonly as heat.

## Emergence

A system-level property or pattern arising from interactions among parts.

## Energy

A conserved physical quantity associated with capacity for change; not a synonym for mood, moral quality, or unspecified spiritual force.

## Entity

An editorial card type emphasizing a natural structure or body while acknowledging that every entity is relational.

## Feedback

A process whose consequence modifies its own future operation.

## Field

A physical quantity defined across space and time; metaphorical uses must be labeled.

## Gift

A constructive or available expression of a card's underlying pattern.

## Information

A physically instantiated difference that can affect system behavior; not proof of a cosmic personalized message.

## Mapshifting

Changing scale, boundary, time horizon, or relationship map to reveal evidence and choices hidden by the prior frame.

## Mechanism

A supported account of how parts and interactions produce an outcome.

## Metaphor

A comparison used to generate insight; it does not establish causal identity.

## Model

A selective, testable representation used to explain or predict within a stated domain.

## Natural process

A card dimension describing transformation, motion, exchange, accumulation, or change.

## Network

A set of nodes and connections whose paths, strengths, and indirect effects matter.

## Observation

Information obtained through measurement, instrument, or documented experience under stated conditions.

## Open question

A matter unresolved, debated, unobserved, or limited by current evidence.

## Phase transition

A collective change of state or organization as control conditions cross a relevant region or threshold.

## Process card

An editorial type emphasizing change through time rather than a persisting structure.

## Provenance

The source and status of a claim: scientific description, observed behavior, cultural account, deck synthesis, or uncertainty.

## Scale

The spatial, temporal, organizational, or relational level at which a description is made.

## Self-organization

Order produced through local interactions and constraints without a central planner; it does not imply consciousness.

## System

A bounded set of interacting parts chosen for a question; boundaries are analytic and may overlap.

## System function

The role a card foregrounds—such as carrier, boundary, filter, regulator, builder, or threshold.

## System relationship card

An editorial type emphasizing interaction, boundary, network, field, container, or collective organization.

## Threshold

A condition near which system behavior changes substantially; not every increase produces a sharp threshold.

## Uncertainty

A characterized limit arising from measurement, variability, model structure, incomplete observation, or unresolved theory.

## Wound

A reflective name for excess, depletion, displacement, delay, vulnerability, or system failure; not a diagnosis.
