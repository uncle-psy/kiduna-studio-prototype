# Gifts and Wounds


## Definitions

A **gift** is a capacity, relationship, intelligence, or possibility made visible by the natural pattern. A **wound** is an unresolved hurt, defensive response, imbalance, system failure, depletion, or distorted expression associated with the same underlying force. Wounds are reflective language, never clinical diagnosis.

Nature is not morally good or evil. Oxygen enables respiration and oxidative damage. A boundary protects and isolates. Flow connects and floods. Crystal order clarifies and becomes brittle. The card does not choose a side; context, scale, timing, intensity, feedback, and relationship determine expression.

## Four common transformations

- **Gift through excess:** flexibility becomes lack of anchoring; protection becomes exclusion.
- **Gift through deprivation:** useful regulation disappears; connection cannot form.
- **Gift through displacement:** a process useful at one scale harms another, as local disposal becomes downstream contamination.
- **Gift through delay:** feedback arrives too late, allowing overshoot or accumulated strain.

## Balanced expression

Balance is not a permanent midpoint. It is responsive fit. A balanced membrane changes transport in response to conditions. A balanced watershed metaphor considers both upstream action and downstream capacity. A balanced orbit is dynamic motion under constraints, not frozen symmetry.

## Avoiding repetitive wounds

The deck deliberately includes quiet wounds: scattering, muted agency, false abundance, surface fixation, indefinite suspension, loss of gradient, contaminant persistence, selection bias, and viewpoint mistaken for disappearance. Not every wound is catastrophe, collapse, or fear. The [Wound Index](indexes/WOUND-INDEX.md) exposes repetition so future editing can preserve distinctness.

## Working with a wound

Do not ask “What is wrong with me?” Ask:

1. What capacity is trying to operate?
2. What condition, boundary, or feedback is missing?
3. Is the problem excess, depletion, timing, routing, or scale mismatch?
4. Who receives the consequence?
5. What small, observable, reversible action could test a more balanced expression?

## No forced silver lining

Loss can be irreversible. Disaster can be devastating. Extinction is not redeemed by later diversification, and an earthquake is not “necessary” for a person's growth. The deck may examine renewal without declaring that harm was intended, deserved, or spiritually assigned.
