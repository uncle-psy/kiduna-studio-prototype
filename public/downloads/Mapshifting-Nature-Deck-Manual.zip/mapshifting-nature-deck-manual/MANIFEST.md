# Manifest


Generated 2026-08-23. Paths are relative to this manual directory. SHA-256 values cover every Markdown file except this self-referential manifest.

## Complete Markdown file tree

```text
00-GOAL-AND-SCOPE.md
01-NATURE-AS-NESTED-SYSTEMS.md
02-SCALE-AND-MAPSHIFTING.md
03-SCIENCE-AND-SYMBOLISM.md
04-GIFTS-AND-WOUNDS.md
05-DECK-ARCHITECTURE.md
06-HOW-TO-USE-THE-DECK.md
07-READING-ACROSS-SCALES.md
08-ETHICS-AND-CULTURAL-INTEGRITY.md
09-SPREADS.md
BIBLIOGRAPHY.md
CHANGELOG.md
GLOSSARY.md
README.md
cards/001-photon.md
cards/002-electron.md
cards/003-proton.md
cards/004-neutron.md
cards/005-neutrino.md
cards/006-quark.md
cards/007-gluon.md
cards/008-higgs-field.md
cards/009-gravity.md
cards/010-hydrogen.md
cards/011-carbon.md
cards/012-oxygen.md
cards/013-water-molecule.md
cards/014-chemical-bond.md
cards/015-crystal-lattice.md
cards/016-plasma.md
cards/017-phase-transition.md
cards/018-catalysis.md
cards/019-cell-membrane.md
cards/020-dna.md
cards/021-mitochondrion.md
cards/022-bacterium.md
cards/023-archaeon.md
cards/024-virus.md
cards/025-spore.md
cards/026-plankton.md
cards/027-microbiome.md
cards/028-seed.md
cards/029-root.md
cards/030-ancient-tree.md
cards/031-lichen.md
cards/032-kelp.md
cards/033-coral-colony.md
cards/034-fungal-fruiting-body.md
cards/035-pollinator.md
cards/036-keystone-species.md
cards/037-symbiosis.md
cards/038-food-web.md
cards/039-decomposition.md
cards/040-ecological-succession.md
cards/041-wetland.md
cards/042-forest-canopy.md
cards/043-soil-community.md
cards/044-kelp-forest.md
cards/045-coral-reef.md
cards/046-watershed.md
cards/047-river.md
cards/048-delta.md
cards/049-estuary.md
cards/050-aquifer.md
cards/051-desert.md
cards/052-glacier.md
cards/053-ocean-current.md
cards/054-mountain-range.md
cards/055-fault.md
cards/056-earthquake.md
cards/057-tectonic-plate.md
cards/058-subduction-zone.md
cards/059-volcano.md
cards/060-mantle-convection.md
cards/061-canyon.md
cards/062-fossil.md
cards/063-mass-extinction.md
cards/064-planet.md
cards/065-moon.md
cards/066-orbit.md
cards/067-eclipse.md
cards/068-comet.md
cards/069-planetary-ring.md
cards/070-magnetosphere.md
cards/071-atmosphere.md
cards/072-tide.md
cards/073-star.md
cards/074-stellar-nursery.md
cards/075-supernova.md
cards/076-neutron-star.md
cards/077-black-hole.md
cards/078-galaxy.md
cards/079-galaxy-cluster.md
cards/080-cosmic-web.md
cards/081-expanding-universe.md
cards/README.md
indexes/CARD-INDEX.md
indexes/EXPANSION-CANDIDATES.md
indexes/GIFT-INDEX.md
indexes/NATURAL-CYCLES.md
indexes/PROCESS-INDEX.md
indexes/RELATIONSHIP-INDEX.md
indexes/SCALE-INDEX.md
indexes/SCIENTIFIC-DOMAIN-INDEX.md
indexes/SYSTEM-FUNCTION-INDEX.md
indexes/TIME-SCALE-INDEX.md
indexes/WOUND-INDEX.md
research/AUDIT-REPORT.md
research/CANDIDATE-INVENTORY.md
research/COMPLETENESS-REPORT.md
research/CONTRADICTIONS.md
research/COVERAGE-MATRIX.md
research/CULTURAL-ATTRIBUTION.md
research/OPEN-QUESTIONS.md
research/SCIENTIFIC-CLAIMS.md
research/SOURCE-LEDGER.md
templates/CARD-TEMPLATE.md
MANIFEST.md
```

## File integrity

| File | Bytes | SHA-256 |
|---|---:|---|
| 00-GOAL-AND-SCOPE.md | 3257 | 43c2071358752d162131f26b869200d0db94345fd12e308d68d36e3e24d6f23b |
| 01-NATURE-AS-NESTED-SYSTEMS.md | 5401 | e59d942ecf77998268408b3540ff7f34bf379426ed6e788363657dc5fb3795f3 |
| 02-SCALE-AND-MAPSHIFTING.md | 3439 | f46e0bd5aa852eccbcb2fa80eebc1372904f0933b39235be1b4bf5d5009fe61e |
| 03-SCIENCE-AND-SYMBOLISM.md | 3234 | 9d7d91f3c2f0ab10619eb5bd6bcf42426e4844fe95bb3a6aadf47ca3d0e19185 |
| 04-GIFTS-AND-WOUNDS.md | 2499 | 941f5b658ac4da1c5ed2927f8ca5ca2f9ba72fea3003faa70deafe64147062af |
| 05-DECK-ARCHITECTURE.md | 2994 | fc8fa424bdf9c735bcf98133505dfa04365710f68cbc37162d89f0ecd6b7f67e |
| 06-HOW-TO-USE-THE-DECK.md | 3243 | 81054ea01f02163e28a1ce3b7293f5022b600d7383a826560337b1c0d334e88c |
| 07-READING-ACROSS-SCALES.md | 3244 | 6fbedcd81f63fc12944c1fa2edec5a52618ee3c97b7bb856af8d9e0c17444f77 |
| 08-ETHICS-AND-CULTURAL-INTEGRITY.md | 3183 | 4464cac5212057723eeb50df4c996f84ce0e01791023ca729bd35a7aaa7e5700 |
| 09-SPREADS.md | 2667 | c8409db1bfd49d4c86392fe0677917e5edcc8a539f63a84b1f4fe43ca8159adc |
| BIBLIOGRAPHY.md | 12941 | ab8db90d1d61b1085d88d2151b8c0b6cd9d4a5cb141b01d361ade086fe9eb674 |
| CHANGELOG.md | 534 | 55bb0a5658aa9ad8aa212c728f72a1922d1d57fa3fe6306c35525e62580c696a |
| GLOSSARY.md | 4068 | 9ac9362d4373e4e7852278d9de42387a6c28545e99506e67dd657815bd7bd2da |
| README.md | 2401 | b86623ad7f5f60b6e07061a8d55d7ac27aaebba25466021251c833ae61ffee20 |
| cards/001-photon.md | 12379 | 5dce2a3de2e386f06d0d75cc5b8dd054e8cecfb7e232ebc6d3fb8d5c161d6dd4 |
| cards/002-electron.md | 12751 | d4a15718930b65c774c41f5f973080b7c4645727387adb0d632b586a7775f9d0 |
| cards/003-proton.md | 12428 | 1a417ded7843e27b805d459470ef00389ca978433e1ece40ea5855bb81ce02c1 |
| cards/004-neutron.md | 12470 | bce60df8c6f2cd2af5e2bcf6ae44719081055f41ea7f15fabc1f65b4bdc8201e |
| cards/005-neutrino.md | 12720 | 7ca0be9c75dce195abe120b92dbabc62a0e4c9e617966db7296728ebbd4dd5e8 |
| cards/006-quark.md | 12524 | 76fd300085f98b2e21a5d7d24d475e5016b6d798737814c4e7e9bcef872b7ea5 |
| cards/007-gluon.md | 12517 | 65492ab30df4dc7ed3113f47820ba43a67c82a1c988b2f7caaca2e1e6cbd6883 |
| cards/008-higgs-field.md | 12886 | a268d13ff40b187d644cd0f934411baa58d4d957f2bcff015ba25a5a32d21b24 |
| cards/009-gravity.md | 12468 | ab7588c17c21361074ad9a86b10721addad005ed5b1ce73eac69fab41c0bf5f7 |
| cards/010-hydrogen.md | 12547 | 8e1761bed86c9166820aa24afe4dd7d1d5dab2a73c09d6f6fbfb4f0c7fa3b7fe |
| cards/011-carbon.md | 12577 | 6f71e6a9182ad4dfcac08d5d35c880f8bb1f94932e6f92943553c827110c693e |
| cards/012-oxygen.md | 12487 | 0487258c0f76a8deaa49c85a9302efb4222d1a3ca0e8e55227e5ddb66981df45 |
| cards/013-water-molecule.md | 12445 | 517bcc61e0e80a1e6a814cc5749aa741048631222b1f44dadce32fdb3b42e2ed |
| cards/014-chemical-bond.md | 12602 | b2392afac3e64a7aa35abda68203fd9e567d5cc165d269698300a72740c222ae |
| cards/015-crystal-lattice.md | 12719 | eb13e9ff85d4eb1ee6be047a134579f648a3a7ea9b117966640744e77785b37e |
| cards/016-plasma.md | 12254 | 70b6a2b1b4b0259884201655b9d4c16f2d2456d55a0b3043baaac104a90afbd3 |
| cards/017-phase-transition.md | 12825 | 338121688bc7caedf337e9ed6c4b7c53faf65919d3415355593f52bdafe492ee |
| cards/018-catalysis.md | 12727 | c0f222e2e3fdac2c10eff8132cfbe894270db136c8a3f6398c0ffb896a8c296a |
| cards/019-cell-membrane.md | 12509 | 86e789aac4136bbe3ca3bca6e41463e53ab7f6cb43b670fc76bce993d79996af |
| cards/020-dna.md | 12667 | 62ab94c2a93233466ec65296de7839c59825d4d977ceede62c4fa8e13eb556c4 |
| cards/021-mitochondrion.md | 12850 | 5d6c8339f845b1f6acf654659ea89e21f476a8ac4b27c3e420e7cd8379562b39 |
| cards/022-bacterium.md | 12563 | 18d3cb0a1d92dae5980464330d9ab003a11d497f4bd65b200e29a9e66f394c32 |
| cards/023-archaeon.md | 12691 | 4357b517ba8564b456b474293557dae8fec9d8edca2be6d9c78e814f21b015b8 |
| cards/024-virus.md | 12536 | 798a323f8830d27d232a6feda4b56a57058e3b5b22b4ffe6575a36f7fb2bdfa6 |
| cards/025-spore.md | 12480 | b93cef3bae18587b7f754763714574e4a9237b6ec5191c4aaaa9728d4b090efb |
| cards/026-plankton.md | 12805 | f4f35cd8e1cd9b695b27703bac521778930a5b2d58775a61fc09c3c48cff4d49 |
| cards/027-microbiome.md | 12638 | dd1b3017d800351aeffb42b06395736ec7f14974f665418f47bb4cec928a4de8 |
| cards/028-seed.md | 12543 | 62289744b4d66eb91abb056583fc1414bf1c5f513d550230cc14a1dc0ed80037 |
| cards/029-root.md | 12504 | ac16e2f3cd89e77e728c9ccf4ebf2a14146552cca24ff08d4191f69db074f162 |
| cards/030-ancient-tree.md | 12678 | 658f1c4cf71819fca06412b034a85d63f8a7e611121901db922d1ce7c6c6ab36 |
| cards/031-lichen.md | 12585 | 04e5e0694094ca5dd17ed06a849154594bc20c009a259a72c733041b64c57277 |
| cards/032-kelp.md | 12356 | cc75204a721ca38167790124ea24724e9f44deabc2b7d25390eff891c4d0d5c0 |
| cards/033-coral-colony.md | 12696 | ccd5b6c0243a8566837c44b6c0ac5f86a81da6657026b24bb2c2474378c96692 |
| cards/034-fungal-fruiting-body.md | 12749 | 1c4b761c289e9d790f9aad00b065b77acfa7507e26467e182ba2d5a0346f2b66 |
| cards/035-pollinator.md | 12679 | 96d6c81d92547253718241dbbbf8d597a0738f5fe23072a7dd88972f908759f5 |
| cards/036-keystone-species.md | 12835 | 0821b95c27b4957d4a432421da9ebb25510596b0c848c9b72fc50dda304ce2fb |
| cards/037-symbiosis.md | 12498 | 54e40e8c8d08598317a83e215235bc03b24146b6c134d0408993674be4fa45b0 |
| cards/038-food-web.md | 12559 | 5c241c427a845ae5d55a82050104cbd1bf175ae360bf68dbb0c1d7b64a20fd9f |
| cards/039-decomposition.md | 12562 | e0860275c9e763d77cc8d1fa6b5c84a970f2bfb0a46984a848dfed52c7cea0fa |
| cards/040-ecological-succession.md | 12703 | b9715777204b730228a223ff31cf4042e723a86785ed31f7f114c29c0b176d2a |
| cards/041-wetland.md | 12654 | 59112fc403f4d7414f01b0809e5e28d47502fa879e65e3a441c2043398e38466 |
| cards/042-forest-canopy.md | 12662 | 2024dddf4a9be528aa1c503597d695c4ddd472cea590a25f07309b5537113656 |
| cards/043-soil-community.md | 12504 | caad4dbce259d2177234b961800c8bcb25cc004a74d1ff93bc5d1eb1a8435bf2 |
| cards/044-kelp-forest.md | 12604 | 16f12cd97314f96bfccc668c6200132b852ccec158180205da77bcce84324c65 |
| cards/045-coral-reef.md | 12829 | b6211f833f33a1e9fdd8ce39cc3d64f4047bdf8c8d3ed2bded2f3a6d6c58040d |
| cards/046-watershed.md | 12705 | 1124ab47d3606384145eec459d214948b6576a1037ef418d1d5c8257e78d2535 |
| cards/047-river.md | 12224 | 07306143ad4a4f78b9246c286b680f0733360ebdd386e91ce2d0df744c599a00 |
| cards/048-delta.md | 12583 | c088f9f1843f9660cc1a8d3c050a4a11a873ede14c7f3c391cb2c53520e8b03b |
| cards/049-estuary.md | 12683 | 49b6360bf467f0144308912901f8387b244da002ff29d52124fb98d190d9889d |
| cards/050-aquifer.md | 12650 | ce857615260a8ee3e529a291a30b32d096e647452c4e959211438e08c8b89095 |
| cards/051-desert.md | 12422 | ee2400246b09578a854d222fc572082a0a06acf949cb5b1ad3bd26eb0b6ea82f |
| cards/052-glacier.md | 12587 | 3d068b0e27f1051edf15f8168b0be2f43a49cf09b6970eeea5b7ebb08c22c8b1 |
| cards/053-ocean-current.md | 12531 | 2fdccb7fe82f8082d2fa7d215bc0e126590275bf689fc0badb0239c06f3706e3 |
| cards/054-mountain-range.md | 12482 | 62e6b76613c7c8cce8878753dca39263241a6477637b069185bae29e6f2e6768 |
| cards/055-fault.md | 12729 | dc9f248129f385476e310c004e3588d2db5c4ac8e8668705cc7b41b35fa4cda9 |
| cards/056-earthquake.md | 12657 | 2938db7e6c55f155b9452a8fae78e4a8feae78be9c49abb1b8a90c25182d7c35 |
| cards/057-tectonic-plate.md | 12477 | b98a80ba68665f8550ada60dace21a0d3f16556fe2816fd827ca0f1b2dd0cda5 |
| cards/058-subduction-zone.md | 12699 | 7bee9720c28e250394e134a9756e35ad3cf043eaf9bee097968d3cf141449fc1 |
| cards/059-volcano.md | 12807 | f61b5d5704d4d2dda2ab919944d96b99b0621acb282adaec595f8fe65cc53910 |
| cards/060-mantle-convection.md | 12795 | 29d150737a9428880337dd0f6d6769815cb8e6fce3d8f8decf0643d3baf03fbe |
| cards/061-canyon.md | 12189 | 0f141d926042dcc05ae9fcce05aae148c65c41c929454ca0f4fc76e379dad42e |
| cards/062-fossil.md | 12598 | e8d6654f3b006137ec75f088e036f25c76e5b239c2a627ad170aabd83e2e569c |
| cards/063-mass-extinction.md | 13109 | bf9ed68c3fef15f81aafd3032536f4930e2ed6e7cfc4c0b7b9d7ba7ae50d481c |
| cards/064-planet.md | 12712 | 4c521f21be2b7ec5182a6d2a4c3a9cf26a1944c6e707ab2e86977b490d3ecaa2 |
| cards/065-moon.md | 12293 | fa64bf3abe1b4e5e75358cd21751368bab86f07cb8c5ddb750f0e31c313c8f4b |
| cards/066-orbit.md | 12314 | b446bf86b1378e80d2a5ce7126a73473cb33084a8eafc7cf52525b86d00c8730 |
| cards/067-eclipse.md | 12605 | 80d5543e22ea59997768c129dbb97f30ef252c1d3483a6af370f61399c2cf1f4 |
| cards/068-comet.md | 12509 | 07c958bb209a44921300617991a77cef4407142bbcb620269d32e70127a5db5e |
| cards/069-planetary-ring.md | 12416 | db15b89df3e3538b8231c780dad4fa65055099fdc2c3ad873f734d23a0b44b01 |
| cards/070-magnetosphere.md | 12694 | 971f059bb9c5efdc58d9ce7d3e7741059aaaaf5f5896f7b200435b6ed0edb600 |
| cards/071-atmosphere.md | 12699 | 7c535a8ba5ab6a30c852a1dbeaf36548fcaea88ed749f1284469a12bb10c6344 |
| cards/072-tide.md | 12328 | 7f7443cc4235200691e58e53dc03f231e76d44b654ff14f990eab4b7f4e364eb |
| cards/073-star.md | 12487 | 1eb5e1aab352e3de200cc8d8fac3824ae43e87ecbcdbad80124dd8f26d3958ec |
| cards/074-stellar-nursery.md | 12502 | 5e3780093db1161d3f1b446b0937d99dcf48f821335ddbb3a8a72abf778d2f75 |
| cards/075-supernova.md | 12727 | 036b41d2b4a0a8e774692de9a8d7e156e20edd58f645c2498af36ab70ae0d03d |
| cards/076-neutron-star.md | 12459 | 8e631d119cd05b17bda0395341b54676ba1d603c4bc193370d90e6d057cfb711 |
| cards/077-black-hole.md | 12689 | af5a51fcec04c92f0f4bf1f0ce89de777c522150f143f97221daff8fd6b9fc61 |
| cards/078-galaxy.md | 12588 | 5ec50ee2bfc7c815b3176d5eb49b3ba81171a68dcf7da4c4913287b280c2ff39 |
| cards/079-galaxy-cluster.md | 12467 | 2d3373c4fef778dbd76d84eef3e8c6a82dbb08b97e833a3c4aeec014ee0f3791 |
| cards/080-cosmic-web.md | 12647 | f194b71cd761a30bd9019d1c31af624864de8b08743542735c213ee70ba53e9f |
| cards/081-expanding-universe.md | 12795 | bdb653ce702ab521a26569715b325b58187f8349c53d27f0e59c9e04e84ebd09 |
| cards/README.md | 741 | 3bc951f30c2bf7ab072da15411169622e2932ed399b856f73977bbdf0350cc8f |
| indexes/CARD-INDEX.md | 8726 | a21882e5516c8d488ab767c4a3064e227b4568f71851f5f1f591dad9f51958a9 |
| indexes/EXPANSION-CANDIDATES.md | 6641 | 6d4ca91f9bb3a4b1106fe9946689257069d9206220db3146bdfd15386a796c1d |
| indexes/GIFT-INDEX.md | 14671 | 0ae5a89737767851b4893a02f5fb7951b19d2a3615cf573f63097de830376d4d |
| indexes/NATURAL-CYCLES.md | 4988 | c4ed669909fc8e78104bf070cf18b6eff0f90efb4358fd1ccb83b79f4f955ba6 |
| indexes/PROCESS-INDEX.md | 8358 | 2e2c208aba99ea35d5981e24c28150a41362e13b6891218d42cc4e6790c09af1 |
| indexes/RELATIONSHIP-INDEX.md | 29899 | 2a8a2d4e057141af908cd8244d41f015217342c1de478c821317630d014b4941 |
| indexes/SCALE-INDEX.md | 11251 | 58b3a7d18eb921315a85b6f987f6fbd309159cf4f14fb5d44887c1bf8f71a461 |
| indexes/SCIENTIFIC-DOMAIN-INDEX.md | 8437 | fbf436e144f01025869e77c91eb815e03a1223c7b383a460607b07ff8517d339 |
| indexes/SYSTEM-FUNCTION-INDEX.md | 7526 | 8403669f006859f9c7fa4924bb4dbf7b8887d53adecc65a47d51f0472d516d8f |
| indexes/TIME-SCALE-INDEX.md | 9134 | 1d67460c891222a293da2113f41400aa4490345b737c7238ed64ef5722eb6490 |
| indexes/WOUND-INDEX.md | 15837 | c897a971e379a5311161df85760e01df8f742756f8aea58e2e27ffbb3962874b |
| research/AUDIT-REPORT.md | 3713 | 0ab6aeb73e88c00aed9b45fc1be672a7fb6069de948447227be62a5e17a9fe92 |
| research/CANDIDATE-INVENTORY.md | 13298 | 482d2f3d8718c4794360bd58c4d89d9f433d9ec1e0a47b1bd8afc4dc1b070f19 |
| research/COMPLETENESS-REPORT.md | 1597 | 1e984369372506e499ab7a4b1eefa2b4f3ef7b293824517089dfc1721d86a605 |
| research/CONTRADICTIONS.md | 1256 | 84c52988a99b477cdbdbdcbeae48530906916f56beb654baf3f9d6ee252d82f6 |
| research/COVERAGE-MATRIX.md | 5666 | ad323c0f9ee0952c4258ff29db39f3d00f75b1d47c4761c33fb1b15714824fc0 |
| research/CULTURAL-ATTRIBUTION.md | 1902 | 15afb5948ca6877ac5f8c4db6666bdf4197dba9fb0f610f0d074534125be95be |
| research/OPEN-QUESTIONS.md | 13596 | d2dcbb813699596538b4648bb1cdc12093827e6dd5790ddee3e4abd16e28e2c9 |
| research/SCIENTIFIC-CLAIMS.md | 47899 | 75e3f27b6abe17b0c4d31565e3087da8faf5bd4e466ed1b9cbe1c88d3b94a834 |
| research/SOURCE-LEDGER.md | 10794 | 71d955f1ef9c647e8ef63b7e0fd9c6385a1691aafe1abc99e6bf59e71913b804 |
| templates/CARD-TEMPLATE.md | 973 | 6534bcf43c884f9e35e29b454c993d7b643016d9fd90b20a534f965ce82c1155 |

## Counts

- Markdown files including manifest: 118
- Card files excluding cards/README.md: 81
- Core source records: 51
- Images: 0
