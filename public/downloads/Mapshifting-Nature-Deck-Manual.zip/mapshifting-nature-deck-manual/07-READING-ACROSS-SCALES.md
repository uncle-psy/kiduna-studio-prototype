# Reading Across Scales


## Part and whole

Every card is both a whole for some questions and a part for others. [Cell Membrane](cards/019-cell-membrane.md) is a molecular assembly, a cellular boundary, and a participant in an organism. [Wetland](cards/041-wetland.md) is an ecosystem, a watershed component, a carbon store, and a migration node. Readings become more useful when “the system” is named rather than assumed.

## The scale ladder

For any question, make a nine-row ladder. At each band, write only what can responsibly be said. A workplace conflict may have no meaningful quark-level explanation; the fundamental row can remain “not relevant.” Mapshifting is not an obligation to force every scale into every question.

Useful cross-scale chains include:

- [Photon](cards/001-photon.md) → [Chemical Bond](cards/014-chemical-bond.md) → [DNA](cards/020-dna.md) → [Seed](cards/028-seed.md) → [Pollinator](cards/035-pollinator.md) → [Food Web](cards/038-food-web.md) → [Watershed](cards/046-watershed.md) → [Atmosphere](cards/071-atmosphere.md) → [Star](cards/073-star.md).
- [Water Molecule](cards/013-water-molecule.md) → [Cell Membrane](cards/019-cell-membrane.md) → [Root](cards/029-root.md) → [Wetland](cards/041-wetland.md) → [River](cards/047-river.md) → [Glacier](cards/052-glacier.md) → [Tide](cards/072-tide.md) → [Moon](cards/065-moon.md).

These chains are pedagogical routes, not causal equivalences.

## Upward and downward causation

Small-scale interactions compose larger patterns, while larger structures constrain local possibilities. A molecule's behavior helps produce membrane properties; membrane organization shapes which molecules can cross. A river transports sediment; basin geometry and climate shape river behavior. Use “bottom-up” and “top-down” as complementary descriptions, not competing dogmas.

## Time-scale mismatch

Many conflicts are clock problems. Extraction may be fast and aquifer recharge slow. Pressure can accumulate over decades and rupture in seconds. A supernova is brief relative to stellar evolution but its remnant influences later generations. Ask which process is fast, which feedback is slow, and whether the decision horizon matches the consequence horizon.

## Local gift, systemic wound

A gift at one scale may externalize a wound. Fast drainage protects one parcel and increases downstream peak flow. A strong boundary protects one cell but isolation harms the organism. Efficient catalysis accelerates a desired reaction but may create unwanted by-products. Trace at least one outward step before naming a gift balanced.

## Systemic gift, local cost

Conversely, a process stabilizing a larger system may burden a local part. Ecological predation, immune response, erosion, and competitive exclusion cannot be reduced to individual moral narratives. The deck asks what scale is being served and who bears the cost, without declaring the cost unreal.

## The stop rule

Stop shifting scale when the new map adds no decision-relevant evidence, exceeds available competence, or turns analogy into speculation. Return to the smallest scale where an accountable action is possible while retaining awareness of the larger system.
