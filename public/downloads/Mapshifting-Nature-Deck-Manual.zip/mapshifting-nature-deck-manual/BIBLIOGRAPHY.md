# Annotated Bibliography


The bibliography mirrors the [Source Ledger](research/SOURCE-LEDGER.md) but is organized for reading. Accessed 2026-08-23.

## U.S. Department of Energy Office of Science: DOE Explains: The Standard Model of Particle Physics

[DOE Explains: The Standard Model of Particle Physics](https://www.energy.gov/science/doe-explainsthe-standard-model-particle-physics) — Overview of particles, force carriers, the Higgs mechanism, and known limits of the Standard Model. **Ledger ID:** DOE_STANDARD_MODEL.

## CERN: The Standard Model

[The Standard Model](https://home.cern/science/physics/standard-model) — Primary overview of elementary particles and three Standard Model interactions. **Ledger ID:** CERN_STANDARD_MODEL.

## CERN: The Higgs boson

[The Higgs boson](https://home.cern/science/physics/higgs-boson) — Primary overview of the Higgs field, boson, and experimental confirmation. **Ledger ID:** CERN_HIGGS.

## Fermilab: All Things Neutrino

[All Things Neutrino](https://neutrinos.fnal.gov/) — Research-laboratory overview of neutrino properties, oscillation, and open questions. **Ledger ID:** FERMILAB_NEUTRINO.

## NASA Space Place: What Is Gravity?

[What Is Gravity?](https://spaceplace.nasa.gov/what-is-gravity/en/) — Accessible account of gravitational attraction and orbital motion. **Ledger ID:** NASA_GRAVITY.

## National Institute of Standards and Technology: Periodic Table of the Elements

[Periodic Table of the Elements](https://www.nist.gov/pml/periodic-table-elements) — Authoritative atomic-property reference for the chemical elements. **Ledger ID:** NIST_PERIODIC.

## National Institute of Standards and Technology: NIST Chemistry WebBook

[NIST Chemistry WebBook](https://webbook.nist.gov/chemistry/) — Evaluated thermochemical, spectroscopic, and molecular data. **Ledger ID:** NIST_WEBBOOK.

## International Union of Pure and Applied Chemistry: Compendium of Chemical Terminology (Gold Book)

[Compendium of Chemical Terminology (Gold Book)](https://goldbook.iupac.org/) — Authoritative definitions for chemical bonds, phases, transitions, and catalysis. **Ledger ID:** IUPAC_GOLD.

## NASA Science: What Is the Universe?

[What Is the Universe?](https://science.nasa.gov/exoplanets/what-is-the-universe/) — Scale-setting overview from atoms through galaxies and the observable universe. **Ledger ID:** NASA_UNIVERSE.

## National Human Genome Research Institute: Deoxyribonucleic Acid (DNA) Fact Sheet

[Deoxyribonucleic Acid (DNA) Fact Sheet](https://www.genome.gov/about-genomics/fact-sheets/Deoxyribonucleic-Acid-Fact-Sheet) — DNA structure, replication, information, and cellular location. **Ledger ID:** GENOME_DNA.

## NCBI Bookshelf: Molecular Biology of the Cell

[Molecular Biology of the Cell](https://www.ncbi.nlm.nih.gov/books/NBK21054/) — Reference text for membranes, organelles, cellular energetics, microbes, viruses, and spores. **Ledger ID:** NCBI_CELL.

## NCBI Bookshelf: The Diversity of Genomes and the Tree of Life

[The Diversity of Genomes and the Tree of Life](https://www.ncbi.nlm.nih.gov/books/NBK26866/) — Three-domain framework and molecular distinctions among Bacteria, Archaea, and Eukarya. **Ledger ID:** NCBI_TREE.

## NCBI Taxonomy: Taxonomy Browser: Archaea

[Taxonomy Browser: Archaea](https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id=2157&mode=Info) — Current taxonomic record for the domain Archaea. **Ledger ID:** NCBI_ARCHAEA.

## National Institutes of Health: Human Microbiome Project

[Human Microbiome Project](https://commonfund.nih.gov/hmp) — Authoritative program overview of microbial communities and host-associated microbiomes. **Ledger ID:** NIH_MICROBIOME.

## NCBI Bookshelf: What does it mean to be a virus?

[What does it mean to be a virus?](https://www.ncbi.nlm.nih.gov/books/NBK562891/box/box001/?report=objectonly) — Virus structure, genetic material, and dependence on host-cell machinery. **Ledger ID:** NCBI_VIRUS.

## NOAA National Ocean Service: What are plankton?

[What are plankton?](https://oceanservice.noaa.gov/facts/plankton.html) — Ecological definition, diversity, and roles of drifting organisms. **Ledger ID:** NOAA_PLANKTON.

## Smithsonian National Museum of Natural History: What Is Biodiversity?

[What Is Biodiversity?](https://naturalhistory.si.edu/education/teaching-resources/life-science/what-biodiversity) — Genetic, species, and ecosystem diversity and their relationships. **Ledger ID:** SMITHSONIAN_BIODIVERSITY.

## USDA Forest Service: Plant of the Week and Plant Biology Resources

[Plant of the Week and Plant Biology Resources](https://www.fs.usda.gov/wildflowers/plant-of-the-week/) — Botanical reference context for seeds, roots, trees, fungi, lichens, and plant life cycles. **Ledger ID:** USDA_PLANTS.

## USDA Forest Service: Pollinators

[Pollinators](https://www.fs.usda.gov/wildflowers/pollinators/) — Pollination ecology and plant–pollinator relationships. **Ledger ID:** USDA_POLLINATORS.

## USDA Forest Service Research: Advances in understanding canopy development in forest trees

[Advances in understanding canopy development in forest trees](https://research.fs.usda.gov/treesearch/59369) — Canopy development, photosynthesis, competition, and environmental response. **Ledger ID:** USDA_CANOPY.

## USDA Forest Service Research: New findings about old-growth forests

[New findings about old-growth forests](https://research.fs.usda.gov/treesearch/7320) — Structural complexity, disturbance history, and multiple old-growth pathways. **Ledger ID:** USDA_OLD_GROWTH.

## USDA Forest Service: National Atlas of Epiphytic Lichens in Forested Habitats of the United States

[National Atlas of Epiphytic Lichens in Forested Habitats of the United States](https://www.fs.usda.gov/sites/default/files/fs_media/fs_document/Lichen-Atlas.pdf) — Lichen partnerships, forms, diversity, and ecological roles. **Ledger ID:** USDA_LICHEN.

## USDA Forest Service Research: Field guide to common macrofungi in eastern forests and their ecosystem functions

[Field guide to common macrofungi in eastern forests and their ecosystem functions](https://research.fs.usda.gov/treesearch/38089) — Spore-bearing fruiting bodies, fungal diversity, decomposition, and symbiosis. **Ledger ID:** USDA_FUNGI.

## U.S. National Park Service: Plant Succession at Kenai Fjords

[Plant Succession at Kenai Fjords](https://www.nps.gov/kefj/learn/nature/plant-succession.htm) — Observed primary succession following glacier retreat. **Ledger ID:** NPS_SUCCESSION.

## U.S. Environmental Protection Agency: How do Wetlands Function and Why are they Valuable?

[How do Wetlands Function and Why are they Valuable?](https://www.epa.gov/wetlands/how-do-wetlands-function-and-why-are-they-valuable) — Wetland hydrology, food webs, material cycling, and landscape functions. **Ledger ID:** EPA_WETLANDS.

## NOAA National Ocean Service: What is a kelp forest?

[What is a kelp forest?](https://oceanservice.noaa.gov/facts/kelp.html) — Kelp biology, environmental requirements, and forest-forming role. **Ledger ID:** NOAA_KELP.

## NOAA Coral Reef Conservation Program: Coral Reef Information

[Coral Reef Information](https://coralreef.noaa.gov/) — Coral organisms, reef ecosystems, stressors, and conservation science. **Ledger ID:** NOAA_CORAL.

## U.S. Geological Survey: Watersheds and Drainage Basins

[Watersheds and Drainage Basins](https://www.usgs.gov/water-science-school/science/watersheds-and-drainage-basins) — Nested drainage areas, routing, and watershed boundaries. **Ledger ID:** USGS_WATERSHED.

## U.S. Geological Survey: Water Science School

[Water Science School](https://www.usgs.gov/special-topics/water-science-school) — Rivers, groundwater, aquifers, water-cycle storage, and flow. **Ledger ID:** USGS_WATER.

## NOAA National Ocean Service: What is an estuary?

[What is an estuary?](https://oceanservice.noaa.gov/education/tutorial_estuaries/est01_whatis.html) — Mixing, tides, geology, and ecological variability in estuaries. **Ledger ID:** NOAA_ESTUARY.

## NOAA National Ocean Service: What is a current?

[What is a current?](https://oceanservice.noaa.gov/facts/current.html) — Wind-driven and density-driven ocean circulation. **Ledger ID:** NOAA_CURRENT.

## U.S. Geological Survey: Glaciers and Icecaps

[Glaciers and Icecaps](https://www.usgs.gov/water-science-school/science/glaciers-and-icecaps) — Glacier formation, flow, erosion, and freshwater storage. **Ledger ID:** USGS_GLACIER.

## U.S. Geological Survey: Plate Tectonics in a Nutshell

[Plate Tectonics in a Nutshell](https://volcanoes.usgs.gov/about/edu/dynamicplanet/nutshell.php) — Lithospheric plates, boundaries, motion rates, and associated activity. **Ledger ID:** USGS_PLATES.

## U.S. Geological Survey: The Science of Earthquakes

[The Science of Earthquakes](https://www.usgs.gov/programs/earthquake-hazards/science-earthquakes) — Fault slip, seismic waves, measurement, and uncertainty. **Ledger ID:** USGS_EARTHQUAKE.

## U.S. Geological Survey: Volcanoes: Principal Types and Processes

[Volcanoes: Principal Types and Processes](https://pubs.usgs.gov/gip/volc/text.html) — Magma, eruption, volcanic landforms, and hazards. **Ledger ID:** USGS_VOLCANO.

## U.S. Geological Survey: Fossils, Rocks, and Time: Introduction

[Fossils, Rocks, and Time: Introduction](https://pubs.usgs.gov/gip/fossils/intro.html) — Deep-time framework, stratigraphy, and fossils as evidence. **Ledger ID:** USGS_TIME.

## Smithsonian National Museum of Natural History: Extinction Over Time

[Extinction Over Time](https://naturalhistory.si.edu/education/teaching-resources/paleontology/extinction-over-time) — Extinction background rates and mass-extinction evidence. **Ledger ID:** SMITHSONIAN_EXTINCTION.

## NASA Science: Solar System Exploration

[Solar System Exploration](https://science.nasa.gov/solar-system/) — Planets, moons, small bodies, rings, and orbital context. **Ledger ID:** NASA_SOLAR_SYSTEM.

## NASA Science: About the Planets

[About the Planets](https://science.nasa.gov/solar-system/planets/) — Planet definitions, diversity, and solar-system roster. **Ledger ID:** NASA_PLANETS.

## NASA Science: Earth's Moon

[Earth's Moon](https://science.nasa.gov/moon/) — Formation evidence, orbit, geology, phases, and exploration. **Ledger ID:** NASA_MOON.

## NASA Science: Comets

[Comets](https://science.nasa.gov/solar-system/comets/) — Comet nuclei, volatile activity, tails, and orbital populations. **Ledger ID:** NASA_COMET.

## NASA Science: Eclipses

[Eclipses](https://science.nasa.gov/eclipses/) — Solar and lunar eclipse geometry and observation. **Ledger ID:** NASA_ECLIPSE.

## NASA Science: Earth's Magnetosphere

[Earth's Magnetosphere](https://science.nasa.gov/heliophysics/focus-areas/magnetosphere-ionosphere/) — Interaction of planetary magnetic fields with charged particles and solar wind. **Ledger ID:** NASA_MAGNETOSPHERE.

## NOAA National Ocean Service: What are tides?

[What are tides?](https://oceanservice.noaa.gov/facts/tides.html) — Gravitational and orbital basis of tides and local modulation. **Ledger ID:** NOAA_TIDES.

## NASA Science: Stars

[Stars](https://science.nasa.gov/universe/stars/) — Star formation, fusion, stellar evolution, and element production. **Ledger ID:** NASA_STARS.

## NASA Science: Hubble's Nebulae

[Hubble's Nebulae](https://science.nasa.gov/mission/hubble/science/universe-uncovered/hubble-nebulae/) — Gas-and-dust clouds associated with star birth and death. **Ledger ID:** NASA_NEBULAE.

## NASA Science: Black Holes

[Black Holes](https://science.nasa.gov/universe/black-holes/) — Black-hole formation, event horizons, accretion, and observation. **Ledger ID:** NASA_BLACK_HOLES.

## NASA Science: Galaxies

[Galaxies](https://science.nasa.gov/universe/galaxies/) — Galaxies, groups, clusters, large-scale structure, and cosmic web. **Ledger ID:** NASA_GALAXIES.

## NASA Science: Universe Overview

[Universe Overview](https://science.nasa.gov/universe/overview/) — Cosmic history, expansion, reionization, and accelerating expansion. **Ledger ID:** NASA_OVERVIEW.

## NASA Science: Universe Glossary

[Universe Glossary](https://science.nasa.gov/universe/glossary/) — Definitions for supernovae, neutron stars, black holes, and cosmological terms. **Ledger ID:** NASA_GLOSSARY.

## NASA Science: Earth System Science Research

[Earth System Science Research](https://science.nasa.gov/earth-science/research/) — Interacting atmosphere, biosphere, cryosphere, geosphere, and hydrosphere. **Ledger ID:** NASA_EARTH_SYSTEM.

## Editorial note

These authoritative public sources support a scientifically responsible general-reader manual. A future academic edition should add peer-reviewed specialist literature at finer claim granularity and commission domain review rather than treating this bibliography as exhaustive.
