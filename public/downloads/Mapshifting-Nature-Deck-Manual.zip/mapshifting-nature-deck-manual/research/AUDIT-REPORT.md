# Scientific and Cultural-Integrity Audit


## Audit scope

The audit covers all 81 card files, 51 source-ledger records, nine scale bands, required manual topics, YAML completeness, scientific/symbolic separation, cultural attribution, gifts and wounds, relationships, indexes, links, and image status.

## Scientific audit

- Every card has a source-labeled **What it is** paragraph and a source-labeled **How it behaves** paragraph.
- Every source label resolves in that card's Sources section and in the central [Source Ledger](SOURCE-LEDGER.md).
- Each card has a bounded uncertainty statement; uncertainty is not used to undermine well-established core descriptions.
- Quantum, field, energy, information, resonance, and frequency language is not used as evidence for supernatural causation, healing, manifestation, destiny, or personalized cosmic messaging.
- Hazard cards distinguish reflective synthesis from physical causation and reject disaster moralization.
- Broad general-reader descriptions are auditable here; a technical or instructional-science edition should add claim-level specialist citations and domain peer review.

## Cultural-integrity audit

- Culturally specific symbolic claims in finished cards: **0**.
- Unattributed Indigenous or universalized “ancient” claims: **0**.
- Restricted or ceremonial teachings: **0**.
- Each card states the scope decision and links to the [Cultural Attribution Ledger](CULTURAL-ATTRIBUTION.md).
- Any future cultural addition is blocked pending named community context, access-status review, permission, credit, and appropriate compensation.

## Gifts and wounds audit

All cards have three named gifts and three named wounds. The indexes make exact repetition visible. Quiet wounds—such as scattering, false stillness, surface fixation, selection bias, starved sediment, false abundance, and viewpoint mistaken for disappearance—prevent catastrophe from becoming the default interpretation.

No wound is phrased as clinical diagnosis. Every card explains how gift and wound arise from the same capacity under different scale, timing, intensity, boundary, and relationship conditions.

## Balance audit

| Test | Result |
|---|---|
| Scale coverage | 9 cards in each of 9 bands; pass. |
| Entities / processes / system relationships | 37 / 13 / 31; relationship-rich by design. |
| Living / nonliving | Cellular, organismal, and ecosystem life are integrated with chemistry, Earth systems, planetary science, and cosmology; pass. |
| Visible / invisible | Both represented, with evidence pathways distinguished from symbolism; pass. |
| Fast / slow | Interaction instants, daily cycles, developmental time, geologic time, and cosmic time represented; pass. |
| Stability / transformation | Binding, storage, regulation, and orbit balanced with rupture, succession, eruption, extinction, and expansion; pass. |
| Creation / dissolution | Formation, construction, emergence, decomposition, recycling, collapse, and dispersal represented; pass. |

## Remaining specialist review

- Domain specialists could refine individual quantitative details for a classroom or scientific-reference edition.
- Cultural specialists are not being asked to validate absent content; any later cultural proposal must begin with community partnership rather than retrospective review.
- Facilitated user testing should assess whether card relationships and practices support agency without encouraging overinterpretation.

## Audit conclusion

The core manual meets its declared general-reader scientific and cultural-integrity standard. Open questions are explicitly recorded in [Open Questions](OPEN-QUESTIONS.md) and do not function as incomplete placeholders.
