# Completeness Report


## Required completion metrics

1. **Final deck size:** 81 cards, justified in [Deck Architecture](../05-DECK-ARCHITECTURE.md).
2. **Cards per scale band:** 9 in every band.
3. **Card types:** 37 entities, 13 processes, 31 system relationships.
4. **Scientific sources consulted:** 51 authoritative source records.
5. **Unresolved scientific questions:** one bounded entry per card in [Open Questions](OPEN-QUESTIONS.md); none invalidates the core phenomenon.
6. **Cultural material requiring specialist review:** none included in the core; all future additions require the workflow in [Cultural Attribution](CULTURAL-ATTRIBUTION.md).
7. **Expansion candidates:** 62, listed in [Expansion Candidates](../indexes/EXPANSION-CANDIDATES.md).
8. **Complete Markdown file tree:** recorded in [Manifest](../MANIFEST.md).
9. **Manifest location:** [MANIFEST.md](../MANIFEST.md).
10. **Card images:** none generated.

## Content checks

- Every selected card has a finished Markdown file with YAML front matter.
- Every required card section is present.
- Every required manual topic is covered in chapters 00–09.
- Every required spread is present and explicitly nonpredictive.
- Every card has distinct gifts, wounds, scale changes, time changes, reading domains, questions, safe practice, uncertainty, relationships, visual brief, sources, and research notes.
- Every required index and research record is populated.
- Internal relative links are validated by the build script.
- Empty files, TODO markers, TBD markers, and lorem-ipsum placeholders are rejected by validation.
