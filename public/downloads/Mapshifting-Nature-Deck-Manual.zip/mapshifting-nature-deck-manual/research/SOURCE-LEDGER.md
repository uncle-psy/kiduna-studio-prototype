# Source Ledger


Access date for all web records: **2026-08-23**. Source IDs are stable within this edition.

| ID | Organization | Source | Use in manual |
|---|---|---|---|
| DOE_STANDARD_MODEL | U.S. Department of Energy Office of Science | [DOE Explains: The Standard Model of Particle Physics](https://www.energy.gov/science/doe-explainsthe-standard-model-particle-physics) | Overview of particles, force carriers, the Higgs mechanism, and known limits of the Standard Model. |
| CERN_STANDARD_MODEL | CERN | [The Standard Model](https://home.cern/science/physics/standard-model) | Primary overview of elementary particles and three Standard Model interactions. |
| CERN_HIGGS | CERN | [The Higgs boson](https://home.cern/science/physics/higgs-boson) | Primary overview of the Higgs field, boson, and experimental confirmation. |
| FERMILAB_NEUTRINO | Fermilab | [All Things Neutrino](https://neutrinos.fnal.gov/) | Research-laboratory overview of neutrino properties, oscillation, and open questions. |
| NASA_GRAVITY | NASA Space Place | [What Is Gravity?](https://spaceplace.nasa.gov/what-is-gravity/en/) | Accessible account of gravitational attraction and orbital motion. |
| NIST_PERIODIC | National Institute of Standards and Technology | [Periodic Table of the Elements](https://www.nist.gov/pml/periodic-table-elements) | Authoritative atomic-property reference for the chemical elements. |
| NIST_WEBBOOK | National Institute of Standards and Technology | [NIST Chemistry WebBook](https://webbook.nist.gov/chemistry/) | Evaluated thermochemical, spectroscopic, and molecular data. |
| IUPAC_GOLD | International Union of Pure and Applied Chemistry | [Compendium of Chemical Terminology (Gold Book)](https://goldbook.iupac.org/) | Authoritative definitions for chemical bonds, phases, transitions, and catalysis. |
| NASA_UNIVERSE | NASA Science | [What Is the Universe?](https://science.nasa.gov/exoplanets/what-is-the-universe/) | Scale-setting overview from atoms through galaxies and the observable universe. |
| GENOME_DNA | National Human Genome Research Institute | [Deoxyribonucleic Acid (DNA) Fact Sheet](https://www.genome.gov/about-genomics/fact-sheets/Deoxyribonucleic-Acid-Fact-Sheet) | DNA structure, replication, information, and cellular location. |
| NCBI_CELL | NCBI Bookshelf | [Molecular Biology of the Cell](https://www.ncbi.nlm.nih.gov/books/NBK21054/) | Reference text for membranes, organelles, cellular energetics, microbes, viruses, and spores. |
| NCBI_TREE | NCBI Bookshelf | [The Diversity of Genomes and the Tree of Life](https://www.ncbi.nlm.nih.gov/books/NBK26866/) | Three-domain framework and molecular distinctions among Bacteria, Archaea, and Eukarya. |
| NCBI_ARCHAEA | NCBI Taxonomy | [Taxonomy Browser: Archaea](https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id=2157&mode=Info) | Current taxonomic record for the domain Archaea. |
| NIH_MICROBIOME | National Institutes of Health | [Human Microbiome Project](https://commonfund.nih.gov/hmp) | Authoritative program overview of microbial communities and host-associated microbiomes. |
| NCBI_VIRUS | NCBI Bookshelf | [What does it mean to be a virus?](https://www.ncbi.nlm.nih.gov/books/NBK562891/box/box001/?report=objectonly) | Virus structure, genetic material, and dependence on host-cell machinery. |
| NOAA_PLANKTON | NOAA National Ocean Service | [What are plankton?](https://oceanservice.noaa.gov/facts/plankton.html) | Ecological definition, diversity, and roles of drifting organisms. |
| SMITHSONIAN_BIODIVERSITY | Smithsonian National Museum of Natural History | [What Is Biodiversity?](https://naturalhistory.si.edu/education/teaching-resources/life-science/what-biodiversity) | Genetic, species, and ecosystem diversity and their relationships. |
| USDA_PLANTS | USDA Forest Service | [Plant of the Week and Plant Biology Resources](https://www.fs.usda.gov/wildflowers/plant-of-the-week/) | Botanical reference context for seeds, roots, trees, fungi, lichens, and plant life cycles. |
| USDA_POLLINATORS | USDA Forest Service | [Pollinators](https://www.fs.usda.gov/wildflowers/pollinators/) | Pollination ecology and plant–pollinator relationships. |
| USDA_CANOPY | USDA Forest Service Research | [Advances in understanding canopy development in forest trees](https://research.fs.usda.gov/treesearch/59369) | Canopy development, photosynthesis, competition, and environmental response. |
| USDA_OLD_GROWTH | USDA Forest Service Research | [New findings about old-growth forests](https://research.fs.usda.gov/treesearch/7320) | Structural complexity, disturbance history, and multiple old-growth pathways. |
| USDA_LICHEN | USDA Forest Service | [National Atlas of Epiphytic Lichens in Forested Habitats of the United States](https://www.fs.usda.gov/sites/default/files/fs_media/fs_document/Lichen-Atlas.pdf) | Lichen partnerships, forms, diversity, and ecological roles. |
| USDA_FUNGI | USDA Forest Service Research | [Field guide to common macrofungi in eastern forests and their ecosystem functions](https://research.fs.usda.gov/treesearch/38089) | Spore-bearing fruiting bodies, fungal diversity, decomposition, and symbiosis. |
| NPS_SUCCESSION | U.S. National Park Service | [Plant Succession at Kenai Fjords](https://www.nps.gov/kefj/learn/nature/plant-succession.htm) | Observed primary succession following glacier retreat. |
| EPA_WETLANDS | U.S. Environmental Protection Agency | [How do Wetlands Function and Why are they Valuable?](https://www.epa.gov/wetlands/how-do-wetlands-function-and-why-are-they-valuable) | Wetland hydrology, food webs, material cycling, and landscape functions. |
| NOAA_KELP | NOAA National Ocean Service | [What is a kelp forest?](https://oceanservice.noaa.gov/facts/kelp.html) | Kelp biology, environmental requirements, and forest-forming role. |
| NOAA_CORAL | NOAA Coral Reef Conservation Program | [Coral Reef Information](https://coralreef.noaa.gov/) | Coral organisms, reef ecosystems, stressors, and conservation science. |
| USGS_WATERSHED | U.S. Geological Survey | [Watersheds and Drainage Basins](https://www.usgs.gov/water-science-school/science/watersheds-and-drainage-basins) | Nested drainage areas, routing, and watershed boundaries. |
| USGS_WATER | U.S. Geological Survey | [Water Science School](https://www.usgs.gov/special-topics/water-science-school) | Rivers, groundwater, aquifers, water-cycle storage, and flow. |
| NOAA_ESTUARY | NOAA National Ocean Service | [What is an estuary?](https://oceanservice.noaa.gov/education/tutorial_estuaries/est01_whatis.html) | Mixing, tides, geology, and ecological variability in estuaries. |
| NOAA_CURRENT | NOAA National Ocean Service | [What is a current?](https://oceanservice.noaa.gov/facts/current.html) | Wind-driven and density-driven ocean circulation. |
| USGS_GLACIER | U.S. Geological Survey | [Glaciers and Icecaps](https://www.usgs.gov/water-science-school/science/glaciers-and-icecaps) | Glacier formation, flow, erosion, and freshwater storage. |
| USGS_PLATES | U.S. Geological Survey | [Plate Tectonics in a Nutshell](https://volcanoes.usgs.gov/about/edu/dynamicplanet/nutshell.php) | Lithospheric plates, boundaries, motion rates, and associated activity. |
| USGS_EARTHQUAKE | U.S. Geological Survey | [The Science of Earthquakes](https://www.usgs.gov/programs/earthquake-hazards/science-earthquakes) | Fault slip, seismic waves, measurement, and uncertainty. |
| USGS_VOLCANO | U.S. Geological Survey | [Volcanoes: Principal Types and Processes](https://pubs.usgs.gov/gip/volc/text.html) | Magma, eruption, volcanic landforms, and hazards. |
| USGS_TIME | U.S. Geological Survey | [Fossils, Rocks, and Time: Introduction](https://pubs.usgs.gov/gip/fossils/intro.html) | Deep-time framework, stratigraphy, and fossils as evidence. |
| SMITHSONIAN_EXTINCTION | Smithsonian National Museum of Natural History | [Extinction Over Time](https://naturalhistory.si.edu/education/teaching-resources/paleontology/extinction-over-time) | Extinction background rates and mass-extinction evidence. |
| NASA_SOLAR_SYSTEM | NASA Science | [Solar System Exploration](https://science.nasa.gov/solar-system/) | Planets, moons, small bodies, rings, and orbital context. |
| NASA_PLANETS | NASA Science | [About the Planets](https://science.nasa.gov/solar-system/planets/) | Planet definitions, diversity, and solar-system roster. |
| NASA_MOON | NASA Science | [Earth's Moon](https://science.nasa.gov/moon/) | Formation evidence, orbit, geology, phases, and exploration. |
| NASA_COMET | NASA Science | [Comets](https://science.nasa.gov/solar-system/comets/) | Comet nuclei, volatile activity, tails, and orbital populations. |
| NASA_ECLIPSE | NASA Science | [Eclipses](https://science.nasa.gov/eclipses/) | Solar and lunar eclipse geometry and observation. |
| NASA_MAGNETOSPHERE | NASA Science | [Earth's Magnetosphere](https://science.nasa.gov/heliophysics/focus-areas/magnetosphere-ionosphere/) | Interaction of planetary magnetic fields with charged particles and solar wind. |
| NOAA_TIDES | NOAA National Ocean Service | [What are tides?](https://oceanservice.noaa.gov/facts/tides.html) | Gravitational and orbital basis of tides and local modulation. |
| NASA_STARS | NASA Science | [Stars](https://science.nasa.gov/universe/stars/) | Star formation, fusion, stellar evolution, and element production. |
| NASA_NEBULAE | NASA Science | [Hubble's Nebulae](https://science.nasa.gov/mission/hubble/science/universe-uncovered/hubble-nebulae/) | Gas-and-dust clouds associated with star birth and death. |
| NASA_BLACK_HOLES | NASA Science | [Black Holes](https://science.nasa.gov/universe/black-holes/) | Black-hole formation, event horizons, accretion, and observation. |
| NASA_GALAXIES | NASA Science | [Galaxies](https://science.nasa.gov/universe/galaxies/) | Galaxies, groups, clusters, large-scale structure, and cosmic web. |
| NASA_OVERVIEW | NASA Science | [Universe Overview](https://science.nasa.gov/universe/overview/) | Cosmic history, expansion, reionization, and accelerating expansion. |
| NASA_GLOSSARY | NASA Science | [Universe Glossary](https://science.nasa.gov/universe/glossary/) | Definitions for supernovae, neutron stars, black holes, and cosmological terms. |
| NASA_EARTH_SYSTEM | NASA Science | [Earth System Science Research](https://science.nasa.gov/earth-science/research/) | Interacting atmosphere, biosphere, cryosphere, geosphere, and hydrosphere. |

## Source policy

Priority is given to government science agencies, international scientific bodies, national laboratories, research institutions, authoritative databases, and peer-reviewed material hosted by those bodies. General pages establish core claims; card uncertainty sections identify where specialist literature would be required for a technical edition.
