# Cultural Attribution Ledger


## Core-edition result

No culturally specific teaching, sacred cosmology, ceremonial association, Indigenous correspondence, or universalized “ancient wisdom” claim is adopted in the 81 core cards. Each card records that scope decision. Therefore there are **zero culturally specific symbolic claims requiring attribution in the finished catalog**.

## Why absence is recorded

The brief requires responsible use, not compulsory inclusion. A web source alone rarely establishes community authority, permission, intended audience, or whether knowledge may be republished in a divination product. Uncertain material was excluded rather than laundered into generic symbolism.

## Required fields for any future proposal

| Field | Requirement |
|---|---|
| Community / people / text | Specific self-identification; never a continental or “Indigenous” universal. |
| Knowledge holder / author | Named where permission allows. |
| Community-approved source | Primary or explicitly approved publication preferred. |
| Living context | Present-tense context and contemporary community standing. |
| Access status | Public, restricted, ceremonial, closed, initiatory, or uncertain. Restricted/uncertain material is excluded. |
| Permission | Written scope for quotation, paraphrase, commercial use, and imagery where relevant. |
| Interpretation | Exact claim, without equating it to a scientific concept. |
| Compensation and credit | Agreed terms for substantive contribution or review. |
| Review date | Required before each new edition. |

## Specialist-review queue

There is no unresolved cultural claim in the core edition. Future proposals involving sacred beings, origin narratives, celestial interpretation, medicinal plants, animal relations, land-based teaching, or Indigenous ecological knowledge require paid community-appropriate review before drafting.
