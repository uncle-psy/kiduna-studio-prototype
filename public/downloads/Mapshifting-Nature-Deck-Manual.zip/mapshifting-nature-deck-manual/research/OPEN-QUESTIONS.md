# Open Scientific and Editorial Questions


## Scientific questions

- **Photon:** How measurement, quantum state, and gravity jointly shape photon behavior remains an active frontier; the deck makes no claim that photons transmit intention or consciousness.
- **Electron:** Quantum electrodynamics predicts electron behavior with extraordinary precision, while the origin of particle masses and the union of quantum theory with gravity remain open.
- **Proton:** Whether an isolated proton ultimately decays is unknown; experiments have only established very long lower limits on its lifetime.
- **Neutron:** Precise neutron-lifetime measurements disagree slightly by method, and neutron-rich matter remains a major research subject.
- **Neutrino:** The absolute neutrino-mass scale, mass ordering details, possible matter–antimatter differences, and whether neutrinos are their own antiparticles remain open.
- **Quark:** Why quarks occur in three generations and why their masses span such a wide range are unexplained features of the Standard Model.
- **Gluon:** The mathematics of confinement is strongly supported but not fully solved from first principles in every regime; strongly coupled matter remains active research.
- **Higgs Field:** The shape and stability of the Higgs potential, possible additional Higgs particles, and links to physics beyond the Standard Model remain open.
- **Gravity:** A quantum description of gravity is not established, and the nature of dark matter and dark energy complicates the full gravitational account of the cosmos.
- **Hydrogen:** Primordial-abundance measurements and stellar physics are precise, but the earliest star formation and some interstellar hydrogen processes remain active research.
- **Carbon:** The details of the global carbon cycle, feedbacks, and carbon behavior under extreme planetary conditions remain active research.
- **Oxygen:** Oxygenation history is reconstructed indirectly from rocks and isotopes; timing and ecological consequences of major transitions retain uncertainty.
- **Water Molecule:** The collective behavior of liquid water remains computationally challenging, especially at interfaces, under confinement, and in supercooled states.
- **Chemical Bond:** Bond categories are models with fuzzy boundaries, and accurate bonding descriptions in complex materials often require advanced quantum calculation.
- **Crystal Lattice:** Nucleation pathways and defect behavior can be difficult to predict, especially in complex, rapidly formed, or nanoscale materials.
- **Plasma:** Turbulence, magnetic reconnection, and multiscale energy transfer in plasmas remain difficult and active research problems.
- **Phase Transition:** Nucleation, glass transitions, nonequilibrium phases, and critical behavior in complex systems remain major research areas.
- **Catalysis:** Real catalytic mechanisms, selectivity, active-site evolution, and behavior under operating conditions can remain uncertain even for widely used catalysts.
- **Cell Membrane:** Membrane organization is highly heterogeneous and dynamic; many nanoscale domains and protein–lipid interactions remain difficult to observe directly.
- **DNA:** Much remains unknown about gene regulation, genome architecture, noncoding function, and how genetic variation interacts with environments and development.
- **Mitochondrion:** The sequence and diversity of early endosymbiotic events, mitochondrial signaling networks, and causes of many mitochondrial disorders remain active research.
- **Bacterium:** Most bacterial diversity has not been cultured, and the functions and ecological interactions of many lineages remain unknown.
- **Archaeon:** Archaeal diversity, nomenclature, evolutionary relationships, and ecosystem functions are rapidly changing as uncultivated genomes are discovered.
- **Virus:** Virus origins, global diversity, host-range evolution, and the boundary between viruses and other mobile genetic elements remain open.
- **Spore:** Environmental sensing, long-term viability, aerial dispersal, and the vast diversity of fungal spores are incompletely characterized.
- **Plankton:** Plankton diversity, bloom dynamics, microbial interactions, and climate feedbacks are active, observation-limited research areas.
- **Microbiome:** Causal links between community composition and function are often difficult to establish; measurement methods capture only parts of a dynamic system.
- **Seed:** Dormancy mechanisms, longevity in natural seed banks, and germination responses under changing climates vary widely and remain incompletely known.
- **Root:** Root architecture and belowground signaling are difficult to observe; species, soils, microbes, and climate produce highly contextual outcomes.
- **Ancient Tree:** Exact age can be uncertain without complete rings, and definitions of ancient or old-growth differ by species, region, and purpose.
- **Lichen:** The roles of additional microbes, specificity among partners, and boundaries of lichen individuality remain active research.
- **Kelp:** Responses to marine heatwaves, nutrient change, grazers, storms, and interacting stressors vary among species and regions.
- **Coral Colony:** Coral–microbe partnerships, acclimatization, adaptation rates, disease dynamics, and future resilience under multiple stressors remain uncertain.
- **Fungal Fruiting Body:** Fungal diversity is vastly undersampled, and fruiting triggers, underground network extent, and organism boundaries are often uncertain.
- **Pollinator:** Pollinator trends, network resilience, combined pesticide and climate effects, and many non-bee pollination systems remain incompletely measured.
- **Keystone Species:** Keystone effects can shift with climate, invasion, harvest, spatial scale, and community composition; causal attribution is often difficult.
- **Symbiosis:** Many symbioses involve multiple partners and context-dependent outcomes that are difficult to reduce to a single category.
- **Food Web:** Complete food webs are rarely observed, interaction strengths are hard to measure, and climate and behavior continually rewire them.
- **Decomposition:** Soil-carbon persistence, microbial controls, and decomposition feedbacks under changing climates remain major uncertainties.
- **Ecological Succession:** Forecasting succession is difficult because dispersal, climate, disturbance, species interactions, and historical contingencies differ across sites.
- **Wetland:** Wetland boundaries, condition, greenhouse-gas balance, and responses to altered hydrology vary by type and are difficult to generalize.
- **Forest Canopy:** Canopies are hard to measure; global responses to drought, elevated carbon dioxide, fire, insects, and compound disturbances remain uncertain.
- **Soil Community:** Most soil species and interactions remain undescribed, and linking community composition to specific functions is challenging.
- **Kelp Forest:** The reversibility of kelp loss, local adaptation, restoration outcomes, and compound climate effects differ sharply among regions.
- **Coral Reef:** Future reef persistence depends on interacting heat, acidification, local stress, adaptation, species turnover, and restoration, with wide regional uncertainty.
- **Watershed:** Groundwater connections, temporary streams, changing land cover, and extreme events complicate watershed boundaries and flow predictions.
- **River:** River response to changing precipitation, dams, sediment supply, land use, and compound extremes remains difficult to forecast locally.
- **Delta:** Delta futures depend on uncertain sediment supply, subsidence, sea-level rise, storms, ecosystem feedbacks, and management choices.
- **Estuary:** Local circulation, hypoxia, sediment response, species shifts, and sea-level adaptation can be highly uncertain and site-specific.
- **Aquifer:** Subsurface heterogeneity, recharge rates, contaminant transport, and groundwater–surface-water exchange are often incompletely mapped.
- **Desert:** Desert boundaries and ecosystem responses to warming, precipitation variability, grazing, and biological-crust disturbance are uncertain and region-specific.
- **Glacier:** Ice dynamics, basal conditions, regional precipitation, feedbacks, and future mass loss contain important uncertainties despite clear global trends.
- **Ocean Current:** Future changes in major currents, eddy effects, mixing rates, and interactions with atmosphere and ice remain active research.
- **Mountain Range:** Rates and histories of uplift, deep crustal structure, erosion feedbacks, and links between climate and tectonics remain debated for many ranges.
- **Fault:** Earthquake timing on individual faults cannot be predicted precisely; subsurface geometry, friction, fluids, and interaction among faults remain uncertain.
- **Earthquake:** Exact initiation, rupture evolution, ground motion at a site, and the timing of future earthquakes remain uncertain; probabilities are not predictions.
- **Tectonic Plate:** The relative importance of slab pull, mantle flow, ridge forces, plate-edge processes, and deep coupling remains actively studied.
- **Subduction Zone:** Megathrust behavior, slow slip, fluid pathways, earthquake segmentation, and long-term slab–mantle interaction remain uncertain.
- **Volcano:** Eruption timing, magma pathways, transitions in style, and cascading hazards cannot be forecast with certainty even with careful monitoring.
- **Mantle Convection:** The geometry of whole-mantle flow, plume origins, chemical reservoirs, and coupling between plates and mantle are major research questions.
- **Canyon:** Canyon histories depend on uncertain past flow, uplift, rock strength, drainage capture, and episodic extreme events.
- **Fossil:** Most organisms never fossilize; dating, classification, behavior, soft tissues, and evolutionary relationships may remain uncertain or be revised.
- **Mass Extinction:** Rates, selectivity, causal sequences, duration, and the boundaries of some extinction events remain debated; modern comparisons require care.
- **Planet:** Planet formation diversity, interior structure, atmospheric evolution, habitability, and the best general definition of planet remain active research.
- **Moon:** Formation histories, hidden oceans, geologic activity, and long-term orbital evolution remain uncertain for many moons.
- **Orbit:** Long-term stability in many-body systems, chaotic transitions, and the detailed formation of orbital architectures remain active research.
- **Eclipse:** Orbital predictions are extremely precise, while atmospheric and surface conditions affect observed appearance; no supernatural causation is inferred.
- **Comet:** Comet interiors, formation reservoirs, chemical diversity, activity at large distances, and fragmentation remain incompletely understood.
- **Planetary Ring:** Ring ages, origins, recycling, mass, and lifetimes—especially for Saturn's rings—remain debated.
- **Magnetosphere:** Magnetic reconnection, particle acceleration, space-weather coupling, and long-term planetary-field evolution remain active research.
- **Atmosphere:** Cloud feedbacks, circulation extremes, atmospheric escape, exoplanet composition, and coupled climate thresholds remain uncertain.
- **Tide:** Local tide prediction is strong with observations, while long-term coastal extremes combine uncertain sea level, storms, morphology, and changing resonance.
- **Star:** Stellar models are mature, yet convection, magnetic dynamos, mass loss, mixing, and rare endpoints retain important uncertainties.
- **Stellar Nursery:** What initiates collapse, sets stellar masses, regulates efficiency, and determines feedback across scales remains active research.
- **Supernova:** Explosion mechanisms, progenitors for some classes, asymmetry, element yields, and outcomes of failed explosions remain research frontiers.
- **Neutron Star:** The state of matter in neutron-star cores, maximum mass, magnetic-field evolution, and merger outcomes remain major open questions.
- **Black Hole:** Black-hole interiors, information, singularities, quantum effects, jet launching, and supermassive origins remain open research areas.
- **Galaxy:** Early galaxy formation, dark-matter structure, feedback, quenching, and supermassive black-hole coevolution remain active research.
- **Galaxy Cluster:** Cluster mass calibration, plasma microphysics, merger history, dark-matter properties, and feedback remain research areas.
- **Cosmic Web:** Diffuse gas mapping, void physics, galaxy–web coupling, dark-matter nature, and precision growth history remain active research.
- **Expanding Universe:** The nature of dark energy, the early inflationary phase, cosmic tensions in measured expansion, and the ultimate future remain unresolved.

## Editorial questions for a future edition

- Should specialized cards split broad categories such as Plankton, Atmosphere, Desert, and Planet into mechanism-specific subjects?
- Should an expansion introduce dark matter and dark energy before their physical nature is known, or retain them only as research context?
- Should cultural interpretation remain absent unless a co-created edition is developed with named communities and explicit permissions?
- Which card relationships prove most useful in observed practice, and which are merely editorially plausible?
- Can future user testing identify gifts or wounds that are too repetitive, confusing, or prone to deterministic use?

None of these questions makes a core card a placeholder. They define bounded research and revision work.
