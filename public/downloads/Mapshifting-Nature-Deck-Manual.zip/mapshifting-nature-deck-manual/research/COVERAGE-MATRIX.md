# Scale-by-Process Coverage Matrix


## Scale and type coverage

| Scale band | Cards | Entities | Processes | System relationships |
|---|---:|---:|---:|---:|
| 1. Fundamental | 9 | 7 | 0 | 2 |
| 2. Atomic and molecular | 9 | 5 | 2 | 2 |
| 3. Microscopic and cellular | 9 | 6 | 0 | 3 |
| 4. Organism | 9 | 5 | 0 | 4 |
| 5. Community and ecosystem | 9 | 0 | 2 | 7 |
| 6. Landscape and regional system | 9 | 3 | 1 | 5 |
| 7. Geologic and continental | 9 | 5 | 4 | 0 |
| 8. Planetary and orbital | 9 | 3 | 2 | 4 |
| 9. Stellar and cosmic | 9 | 3 | 2 | 4 |
| **Total** | **81** | **37** | **13** | **31** |

## Process coverage by scale

| Process | S1 | S2 | S3 | S4 | S5 | S6 | S7 | S8 | S9 | Total |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Absorption | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 1 |
| Acceleration | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| Accretion | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 2 |
| Accumulation | 0 | 0 | 0 | 1 | 0 | 2 | 0 | 0 | 0 | 3 |
| Adaptation | 0 | 0 | 1 | 0 | 0 | 1 | 0 | 0 | 0 | 2 |
| Aggregation | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| Alignment | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 |
| Assembly | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| Attraction | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 2 |
| Binding | 4 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 8 |
| Capture | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 1 |
| Catalysis | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Circulation | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 4 |
| Collapse | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 4 | 4 |
| Construction | 0 | 0 | 0 | 1 | 1 | 0 | 1 | 0 | 0 | 3 |
| Crystallization | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Cycling | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Decay | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Decomposition | 0 | 0 | 0 | 0 | 2 | 0 | 0 | 0 | 0 | 2 |
| Deflection | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 |
| Deposition | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 1 |
| Descent | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 1 |
| Differentiation | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 |
| Dispersion | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 1 | 3 |
| Distribution | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 1 |
| Dormancy | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 2 |
| Drift | 0 | 0 | 1 | 0 | 0 | 0 | 1 | 0 | 0 | 2 |
| Emergence | 1 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 2 | 4 |
| Erosion | 0 | 0 | 0 | 0 | 0 | 2 | 1 | 0 | 0 | 3 |
| Eruption | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 1 |
| Exchange | 2 | 2 | 2 | 2 | 3 | 1 | 0 | 2 | 0 | 14 |
| Expansion | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| Extinction | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 1 |
| Feedback | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 1 | 0 | 4 |
| Filtration | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 1 |
| Flow | 0 | 1 | 0 | 1 | 0 | 2 | 0 | 0 | 1 | 5 |
| Fragmentation | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 |
| Fusion | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 2 |
| Germination | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 1 |
| Growth | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 1 |
| Heat Transfer | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 1 |
| Incision | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 1 |
| Infiltration | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 1 |
| Interaction | 1 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 | 3 |
| Interpretation | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 1 |
| Ionization | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Metabolism | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 3 |
| Mixing | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 1 |
| Mutation | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Occlusion | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 |
| Orbit | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 4 | 0 | 5 |
| Oscillation | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 2 |
| Oxidation | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Phase Transition | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Pollination | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 1 |
| Predation | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 1 |
| Preservation | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 1 |
| Production | 0 | 0 | 1 | 0 | 1 | 0 | 0 | 0 | 0 | 2 |
| Radiation | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 2 |
| Reconnection | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 |
| Recycling | 0 | 0 | 0 | 0 | 1 | 0 | 1 | 0 | 0 | 2 |
| Regeneration | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 2 |
| Regulation | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 3 |
| Reorganization | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 1 |
| Repetition | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Replication | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 3 |
| Rotation | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| Routing | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 1 |
| Rupture | 0 | 0 | 0 | 0 | 0 | 0 | 2 | 0 | 0 | 2 |
| Scarcity | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 1 |
| Stability | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Storage | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 2 |
| Strain | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 1 |
| Sublimation | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 |
| Succession | 0 | 0 | 0 | 0 | 2 | 0 | 0 | 0 | 0 | 2 |
| Symbiosis | 0 | 0 | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 4 |
| Threshold Crossing | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| Tidal Interaction | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 |
| Transformation | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 |
| Transmission | 2 | 0 | 1 | 0 | 0 | 0 | 1 | 0 | 0 | 4 |
| Transport | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 1 |
| Uplift | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 1 |
| Weathering | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 1 |

## Balance finding

No scale band is empty or token. Dramatic processes do not dominate: rupture, eruption, collapse, predation, and extinction are bounded by cards about binding, filtering, storage, circulation, construction, dormancy, regulation, and regeneration. Living and nonliving subjects are linked through shared processes without claiming equivalence.
