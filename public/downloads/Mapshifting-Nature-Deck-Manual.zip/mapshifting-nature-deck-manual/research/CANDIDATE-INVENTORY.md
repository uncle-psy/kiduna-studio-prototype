# Candidate Inventory


## Method

The inventory began with the user's domain list, widened across the nine scale bands, then tagged for process, function, scientific distinctness, source availability, and overlap with the separate Animal Deck. Selection favored cards that reveal a mechanism or system relationship useful in readings.

## Core selections

### 1. Fundamental

- **Photon** — entity; transmission, radiation; signal, carrier.
- **Electron** — entity; attraction, exchange; carrier, boundary.
- **Proton** — entity; binding, stability; center, builder.
- **Neutron** — entity; binding, decay; regulator, stabilizer.
- **Neutrino** — entity; transmission, oscillation; messenger, witness.
- **Quark** — entity; binding, transformation; seed, component.
- **Gluon** — entity; binding, exchange; bridge, binder.
- **Higgs Field** — system_relationship; interaction, emergence; field, condition.
- **Gravity** — system_relationship; attraction, orbit; field, whole.

### 2. Atomic and molecular

- **Hydrogen** — entity; fusion, binding; source, seed.
- **Carbon** — entity; binding, cycling; builder, network.
- **Oxygen** — entity; oxidation, exchange; catalyst, transformer.
- **Water Molecule** — entity; binding, phase transition; carrier, solvent.
- **Chemical Bond** — system_relationship; binding, exchange; bridge, builder.
- **Crystal Lattice** — system_relationship; crystallization, repetition; pattern, builder.
- **Plasma** — entity; ionization, flow; field, carrier.
- **Phase Transition** — process; threshold crossing, transformation; threshold, transformer.
- **Catalysis** — process; catalysis, transformation; catalyst, bridge.

### 3. Microscopic and cellular

- **Cell Membrane** — system_relationship; exchange, regulation; boundary, filter.
- **DNA** — entity; replication, mutation; memory, pattern.
- **Mitochondrion** — entity; metabolism, exchange; transformer, powerhouse.
- **Bacterium** — entity; metabolism, replication; builder, recycler.
- **Archaeon** — entity; adaptation, metabolism; ancestor, transformer.
- **Virus** — entity; replication, transmission; carrier, disruptor.
- **Spore** — entity; dispersion, dormancy; seed, carrier.
- **Plankton** — system_relationship; drift, production; carrier, foundation.
- **Microbiome** — system_relationship; symbiosis, feedback; network, regulator.

### 4. Organism

- **Seed** — entity; dormancy, germination; seed, memory.
- **Root** — entity; absorption, exchange; anchor, network.
- **Ancient Tree** — entity; accumulation, regeneration; memory, ancestor.
- **Lichen** — system_relationship; symbiosis, weathering; bridge, pioneer.
- **Kelp** — entity; growth, flow; builder, carrier.
- **Coral Colony** — system_relationship; construction, symbiosis; builder, network.
- **Fungal Fruiting Body** — entity; emergence, dispersion; messenger, threshold.
- **Pollinator** — system_relationship; pollination, exchange; messenger, bridge.
- **Keystone Species** — system_relationship; regulation, feedback; regulator, center.

### 5. Community and ecosystem

- **Symbiosis** — system_relationship; symbiosis, exchange; bridge, network.
- **Food Web** — system_relationship; predation, exchange; network, carrier.
- **Decomposition** — process; decomposition, recycling; dissolver, recycler.
- **Ecological Succession** — process; succession, regeneration; clock, builder.
- **Wetland** — system_relationship; filtration, storage; filter, threshold.
- **Forest Canopy** — system_relationship; capture, regulation; boundary, filter.
- **Soil Community** — system_relationship; decomposition, exchange; network, recycler.
- **Kelp Forest** — system_relationship; production, feedback; builder, network.
- **Coral Reef** — system_relationship; construction, succession; builder, whole.

### 6. Landscape and regional system

- **Watershed** — system_relationship; routing, accumulation; container, network.
- **River** — entity; flow, erosion; carrier, path.
- **Delta** — system_relationship; deposition, distribution; distributor, threshold.
- **Estuary** — system_relationship; mixing, exchange; threshold, nursery.
- **Aquifer** — system_relationship; infiltration, storage; container, memory.
- **Desert** — system_relationship; scarcity, adaptation; filter, teacher.
- **Glacier** — entity; accumulation, flow; memory, carrier.
- **Ocean Current** — process; circulation, transport; carrier, regulator.
- **Mountain Range** — entity; uplift, erosion; boundary, source.

### 7. Geologic and continental

- **Fault** — entity; strain, rupture; boundary, memory.
- **Earthquake** — process; rupture, transmission; disruptor, signal.
- **Tectonic Plate** — entity; drift, interaction; carrier, whole.
- **Subduction Zone** — process; descent, recycling; dissolver, transformer.
- **Volcano** — entity; eruption, construction; threshold, builder.
- **Mantle Convection** — process; circulation, heat transfer; carrier, clock.
- **Canyon** — entity; erosion, incision; memory, revelation.
- **Fossil** — entity; preservation, interpretation; memory, ancestor.
- **Mass Extinction** — process; extinction, reorganization; disruptor, threshold.

### 8. Planetary and orbital

- **Planet** — entity; accretion, differentiation; container, whole.
- **Moon** — entity; orbit, tidal interaction; companion, mirror.
- **Orbit** — system_relationship; orbit, feedback; relationship, clock.
- **Eclipse** — process; alignment, occlusion; threshold, revelation.
- **Comet** — entity; orbit, sublimation; messenger, memory.
- **Planetary Ring** — system_relationship; orbit, fragmentation; boundary, pattern.
- **Magnetosphere** — system_relationship; deflection, reconnection; protector, boundary.
- **Atmosphere** — system_relationship; circulation, exchange; container, filter.
- **Tide** — process; oscillation, exchange; clock, carrier.

### 9. Stellar and cosmic

- **Star** — entity; fusion, radiation; source, transformer.
- **Stellar Nursery** — system_relationship; collapse, emergence; container, seed.
- **Supernova** — process; collapse, dispersion; disruptor, recycler.
- **Neutron Star** — entity; collapse, rotation; memory, signal.
- **Black Hole** — entity; collapse, accretion; threshold, void.
- **Galaxy** — system_relationship; assembly, circulation; whole, network.
- **Galaxy Cluster** — system_relationship; aggregation, interaction; container, lens.
- **Cosmic Web** — system_relationship; emergence, flow; network, pattern.
- **Expanding Universe** — process; expansion, acceleration; whole, clock.

## Retained expansion pool

- **Muon** (Fundamental) — A heavier charged lepton adds decay and generational structure.
- **W and Z Bosons** (Fundamental) — Weak-interaction carriers would deepen transformation and radioactive decay.
- **Quantum Vacuum** (Fundamental) — Adds ground-state fields but carries a high pseudoscience risk.
- **Wave–Particle Duality** (Fundamental) — Adds model-dependent complementarity; overlaps Photon and Electron.
- **Antimatter** (Fundamental) — Adds symmetry and annihilation without implying moral opposition.
- **Dark Matter** (Fundamental) — Strong cosmic role, but identity remains unknown; may fit a research expansion.
- **Dark Energy** (Fundamental) — Central to acceleration but currently a name for an unexplained effect.
- **Nitrogen** (Atomic and molecular) — Adds atmospheric and biological cycling.
- **Iron** (Atomic and molecular) — Adds stellar nucleosynthesis, redox, cores, and biological use.
- **Salt** (Atomic and molecular) — Adds ionic dissociation, osmotic boundary, and mineral accumulation.
- **Mineral** (Atomic and molecular) — Adds composition and crystallographic diversity beyond Crystal Lattice.
- **Glass** (Atomic and molecular) — Adds noncrystalline solidity and kinetic arrest.
- **Organic Molecule** (Atomic and molecular) — Too broad for core; could anchor a chemistry expansion.
- **Polymer** (Atomic and molecular) — Adds repeated units, folding, and material memory.
- **RNA** (Microscopic and cellular) — Adds information, catalysis, translation, and origin-of-life questions.
- **Ribosome** (Microscopic and cellular) — Adds molecular translation and ancient shared machinery.
- **Gene Regulation** (Microscopic and cellular) — Adds conditional expression beyond DNA storage.
- **Protist** (Microscopic and cellular) — Adds major eukaryotic diversity hidden by familiar kingdoms.
- **Mycelial Hypha** (Microscopic and cellular) — Adds tip growth and network formation at micro-to-organism scales.
- **Biofilm** (Microscopic and cellular) — Adds collective attachment, matrix building, and gradients.
- **Cell Division** (Microscopic and cellular) — Adds copying, partition, checkpoints, and lineage.
- **Leaf** (Organism) — Adds exchange surface and light capture.
- **Flower** (Organism) — Adds reproductive signaling and coevolution.
- **Fire-Adapted Plant** (Organism) — Adds disturbance-dependent life history without making Fire an organism.
- **Migrating Organism** (Organism) — Adds navigation, seasonal timing, and connectivity; overlaps Animal Deck.
- **Ecosystem Engineer** (Organism) — Adds habitat modification as an organismal strategy.
- **Parasite** (Organism) — Adds intimate dependence and host cost; partly covered by Symbiosis and Virus.
- **Grassland** (Community and ecosystem) — Adds disturbance, root allocation, grazing, and open-canopy dynamics.
- **Tundra** (Community and ecosystem) — Adds cold limits, permafrost, and seasonal pulses.
- **Rainforest** (Community and ecosystem) — Adds vertical complexity, rainfall feedback, and rapid nutrient cycling.
- **Fire Ecology** (Community and ecosystem) — Adds combustion, succession, and regime.
- **Predation** (Community and ecosystem) — Adds consumer control and behavioral landscapes.
- **Competition** (Community and ecosystem) — Adds resource limitation and niche change.
- **Migration Network** (Community and ecosystem) — Adds distributed seasonal habitat dependence.
- **Dune Field** (Landscape and regional system) — Adds wind transport, migration, and patterned instability.
- **Continental Shelf** (Landscape and regional system) — Adds submerged margins, productivity, and sea-level history.
- **Rain Shadow** (Landscape and regional system) — Adds atmospheric routing and leeward scarcity.
- **Floodplain** (Landscape and regional system) — Adds lateral river exchange and disturbance memory.
- **Peatland** (Landscape and regional system) — Adds slow decomposition and long carbon storage.
- **Monsoon** (Landscape and regional system) — Adds seasonal atmospheric reversal and coupled land–ocean heating.
- **Storm** (Landscape and regional system) — Adds organized atmospheric energy and hazard; requires type-specific treatment.
- **Cave** (Geologic and continental) — Adds dissolution, hidden drainage, and long records.
- **Mineral Vein** (Geologic and continental) — Adds fluid transport, concentration, and fracture filling.
- **Supercontinent** (Geologic and continental) — Adds assembly and breakup across plate cycles.
- **Mantle Plume** (Geologic and continental) — Adds focused upwelling; origin and expression remain debated.
- **Erosion** (Geologic and continental) — Adds a standalone process now distributed across River, Canyon, Glacier, and Mountain Range.
- **Deposition** (Geologic and continental) — Adds a standalone process now carried by Delta and rivers.
- **Geodynamo** (Geologic and continental) — Adds planetary magnetic-field generation.
- **Asteroid** (Planetary and orbital) — Adds collision, remnant material, and hazard.
- **Solar Wind** (Planetary and orbital) — Adds stellar plasma flow and space weather.
- **Tidal Locking** (Planetary and orbital) — Adds coupled rotation–orbit evolution.
- **Biosphere** (Planetary and orbital) — Adds the planetary totality of living systems.
- **Impact Crater** (Planetary and orbital) — Adds sudden excavation and persistent record.
- **Planetary Differentiation** (Planetary and orbital) — Adds internal separation by density and heat.
- **Aurora** (Planetary and orbital) — Adds visible magnetosphere–atmosphere interaction.
- **White Dwarf** (Stellar and cosmic) — Completes low/intermediate-mass stellar endings.
- **Galactic Collision** (Stellar and cosmic) — Adds merger-driven transformation without literal stellar collision in most encounters.
- **Cosmic Void** (Stellar and cosmic) — Adds underdensity, spatial possibility, and disconnection.
- **Gravitational Wave** (Stellar and cosmic) — Adds spacetime transmission and new observation channels.
- **Active Galactic Nucleus** (Stellar and cosmic) — Adds black-hole accretion and galaxy-scale feedback.
- **Reionization** (Stellar and cosmic) — Adds a universe-wide phase of radiative transformation.
- **Cosmic Microwave Background** (Stellar and cosmic) — Adds an early-universe observational record.

## Selection result

Total reviewed inventory: **143** named candidates. Core: **81**. Expansion pool: **62**. The inventory is broad enough to expose omissions, while the core remains practical.
