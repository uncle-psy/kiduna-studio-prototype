# Contradictions and Resolutions


| Tension | Resolution in core edition | Status |
|---|---|---|
| Divination language vs. scientific accuracy | Deck framed as reflective prompting, never prediction or supernatural mechanism. | Resolved |
| Equal nine-card bands vs. natural unevenness | Equal count is an editorial coverage device, explicitly not a claim about nature. | Resolved |
| Required cultural section vs. lack of permission-ready material | Each card records that no specific cultural claim is adopted; no content is invented to fill space. | Resolved |
| Symbolic “energy” vs. physical energy | Manual requires precise alternatives and labels metaphor. | Resolved |
| Organism cards vs. separate Animal Deck | Nature roster favors plant, fungal, algal, colonial, and ecological-role cards; animal duplication is minimal. | Resolved |
| Destruction as renewal vs. real harm | Manual rejects forced silver linings and disaster moralization. | Resolved |
| Scientific models vs. certainty | Every card distinguishes strong core knowledge from open research. | Resolved |
| Source breadth vs. claim-level audit | Scientific paragraphs carry local source labels and are mirrored in SCIENTIFIC-CLAIMS.md. | Resolved for general-reader edition |
