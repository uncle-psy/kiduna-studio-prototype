# Expansion Candidates


These 62 candidates survived broad inventory review but were omitted from the 81-card core to control duplication, uncertainty, or size. Inclusion in a later edition requires a fresh coverage and source audit.

| Scale | Candidate | Rationale / boundary |
|---:|---|---|
| 1. Fundamental | Muon | A heavier charged lepton adds decay and generational structure. |
| 1. Fundamental | W and Z Bosons | Weak-interaction carriers would deepen transformation and radioactive decay. |
| 1. Fundamental | Quantum Vacuum | Adds ground-state fields but carries a high pseudoscience risk. |
| 1. Fundamental | Wave–Particle Duality | Adds model-dependent complementarity; overlaps Photon and Electron. |
| 1. Fundamental | Antimatter | Adds symmetry and annihilation without implying moral opposition. |
| 1. Fundamental | Dark Matter | Strong cosmic role, but identity remains unknown; may fit a research expansion. |
| 1. Fundamental | Dark Energy | Central to acceleration but currently a name for an unexplained effect. |
| 2. Atomic and molecular | Nitrogen | Adds atmospheric and biological cycling. |
| 2. Atomic and molecular | Iron | Adds stellar nucleosynthesis, redox, cores, and biological use. |
| 2. Atomic and molecular | Salt | Adds ionic dissociation, osmotic boundary, and mineral accumulation. |
| 2. Atomic and molecular | Mineral | Adds composition and crystallographic diversity beyond Crystal Lattice. |
| 2. Atomic and molecular | Glass | Adds noncrystalline solidity and kinetic arrest. |
| 2. Atomic and molecular | Organic Molecule | Too broad for core; could anchor a chemistry expansion. |
| 2. Atomic and molecular | Polymer | Adds repeated units, folding, and material memory. |
| 3. Microscopic and cellular | RNA | Adds information, catalysis, translation, and origin-of-life questions. |
| 3. Microscopic and cellular | Ribosome | Adds molecular translation and ancient shared machinery. |
| 3. Microscopic and cellular | Gene Regulation | Adds conditional expression beyond DNA storage. |
| 3. Microscopic and cellular | Protist | Adds major eukaryotic diversity hidden by familiar kingdoms. |
| 3. Microscopic and cellular | Mycelial Hypha | Adds tip growth and network formation at micro-to-organism scales. |
| 3. Microscopic and cellular | Biofilm | Adds collective attachment, matrix building, and gradients. |
| 3. Microscopic and cellular | Cell Division | Adds copying, partition, checkpoints, and lineage. |
| 4. Organism | Leaf | Adds exchange surface and light capture. |
| 4. Organism | Flower | Adds reproductive signaling and coevolution. |
| 4. Organism | Fire-Adapted Plant | Adds disturbance-dependent life history without making Fire an organism. |
| 4. Organism | Migrating Organism | Adds navigation, seasonal timing, and connectivity; overlaps Animal Deck. |
| 4. Organism | Ecosystem Engineer | Adds habitat modification as an organismal strategy. |
| 4. Organism | Parasite | Adds intimate dependence and host cost; partly covered by Symbiosis and Virus. |
| 5. Community and ecosystem | Grassland | Adds disturbance, root allocation, grazing, and open-canopy dynamics. |
| 5. Community and ecosystem | Tundra | Adds cold limits, permafrost, and seasonal pulses. |
| 5. Community and ecosystem | Rainforest | Adds vertical complexity, rainfall feedback, and rapid nutrient cycling. |
| 5. Community and ecosystem | Fire Ecology | Adds combustion, succession, and regime. |
| 5. Community and ecosystem | Predation | Adds consumer control and behavioral landscapes. |
| 5. Community and ecosystem | Competition | Adds resource limitation and niche change. |
| 5. Community and ecosystem | Migration Network | Adds distributed seasonal habitat dependence. |
| 6. Landscape and regional system | Dune Field | Adds wind transport, migration, and patterned instability. |
| 6. Landscape and regional system | Continental Shelf | Adds submerged margins, productivity, and sea-level history. |
| 6. Landscape and regional system | Rain Shadow | Adds atmospheric routing and leeward scarcity. |
| 6. Landscape and regional system | Floodplain | Adds lateral river exchange and disturbance memory. |
| 6. Landscape and regional system | Peatland | Adds slow decomposition and long carbon storage. |
| 6. Landscape and regional system | Monsoon | Adds seasonal atmospheric reversal and coupled land–ocean heating. |
| 6. Landscape and regional system | Storm | Adds organized atmospheric energy and hazard; requires type-specific treatment. |
| 7. Geologic and continental | Cave | Adds dissolution, hidden drainage, and long records. |
| 7. Geologic and continental | Mineral Vein | Adds fluid transport, concentration, and fracture filling. |
| 7. Geologic and continental | Supercontinent | Adds assembly and breakup across plate cycles. |
| 7. Geologic and continental | Mantle Plume | Adds focused upwelling; origin and expression remain debated. |
| 7. Geologic and continental | Erosion | Adds a standalone process now distributed across River, Canyon, Glacier, and Mountain Range. |
| 7. Geologic and continental | Deposition | Adds a standalone process now carried by Delta and rivers. |
| 7. Geologic and continental | Geodynamo | Adds planetary magnetic-field generation. |
| 8. Planetary and orbital | Asteroid | Adds collision, remnant material, and hazard. |
| 8. Planetary and orbital | Solar Wind | Adds stellar plasma flow and space weather. |
| 8. Planetary and orbital | Tidal Locking | Adds coupled rotation–orbit evolution. |
| 8. Planetary and orbital | Biosphere | Adds the planetary totality of living systems. |
| 8. Planetary and orbital | Impact Crater | Adds sudden excavation and persistent record. |
| 8. Planetary and orbital | Planetary Differentiation | Adds internal separation by density and heat. |
| 8. Planetary and orbital | Aurora | Adds visible magnetosphere–atmosphere interaction. |
| 9. Stellar and cosmic | White Dwarf | Completes low/intermediate-mass stellar endings. |
| 9. Stellar and cosmic | Galactic Collision | Adds merger-driven transformation without literal stellar collision in most encounters. |
| 9. Stellar and cosmic | Cosmic Void | Adds underdensity, spatial possibility, and disconnection. |
| 9. Stellar and cosmic | Gravitational Wave | Adds spacetime transmission and new observation channels. |
| 9. Stellar and cosmic | Active Galactic Nucleus | Adds black-hole accretion and galaxy-scale feedback. |
| 9. Stellar and cosmic | Reionization | Adds a universe-wide phase of radiative transformation. |
| 9. Stellar and cosmic | Cosmic Microwave Background | Adds an early-universe observational record. |
