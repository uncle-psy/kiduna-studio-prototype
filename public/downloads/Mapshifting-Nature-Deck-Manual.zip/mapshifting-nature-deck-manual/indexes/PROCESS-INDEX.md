# Natural Process Index

Entries are drawn from the canonical YAML registry.

| Process | Cards | Count |
|---|---|---:|
| Absorption | [Root](../cards/029-root.md) | 1 |
| Acceleration | [Expanding Universe](../cards/081-expanding-universe.md) | 1 |
| Accretion | [Planet](../cards/064-planet.md), [Black Hole](../cards/077-black-hole.md) | 2 |
| Accumulation | [Ancient Tree](../cards/030-ancient-tree.md), [Watershed](../cards/046-watershed.md), [Glacier](../cards/052-glacier.md) | 3 |
| Adaptation | [Archaeon](../cards/023-archaeon.md), [Desert](../cards/051-desert.md) | 2 |
| Aggregation | [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 1 |
| Alignment | [Eclipse](../cards/067-eclipse.md) | 1 |
| Assembly | [Galaxy](../cards/078-galaxy.md) | 1 |
| Attraction | [Electron](../cards/002-electron.md), [Gravity](../cards/009-gravity.md) | 2 |
| Binding | [Proton](../cards/003-proton.md), [Neutron](../cards/004-neutron.md), [Quark](../cards/006-quark.md), [Gluon](../cards/007-gluon.md), [Hydrogen](../cards/010-hydrogen.md), [Carbon](../cards/011-carbon.md), [Water Molecule](../cards/013-water-molecule.md), [Chemical Bond](../cards/014-chemical-bond.md) | 8 |
| Capture | [Forest Canopy](../cards/042-forest-canopy.md) | 1 |
| Catalysis | [Catalysis](../cards/018-catalysis.md) | 1 |
| Circulation | [Ocean Current](../cards/053-ocean-current.md), [Mantle Convection](../cards/060-mantle-convection.md), [Atmosphere](../cards/071-atmosphere.md), [Galaxy](../cards/078-galaxy.md) | 4 |
| Collapse | [Stellar Nursery](../cards/074-stellar-nursery.md), [Supernova](../cards/075-supernova.md), [Neutron Star](../cards/076-neutron-star.md), [Black Hole](../cards/077-black-hole.md) | 4 |
| Construction | [Coral Colony](../cards/033-coral-colony.md), [Coral Reef](../cards/045-coral-reef.md), [Volcano](../cards/059-volcano.md) | 3 |
| Crystallization | [Crystal Lattice](../cards/015-crystal-lattice.md) | 1 |
| Cycling | [Carbon](../cards/011-carbon.md) | 1 |
| Decay | [Neutron](../cards/004-neutron.md) | 1 |
| Decomposition | [Decomposition](../cards/039-decomposition.md), [Soil Community](../cards/043-soil-community.md) | 2 |
| Deflection | [Magnetosphere](../cards/070-magnetosphere.md) | 1 |
| Deposition | [Delta](../cards/048-delta.md) | 1 |
| Descent | [Subduction Zone](../cards/058-subduction-zone.md) | 1 |
| Differentiation | [Planet](../cards/064-planet.md) | 1 |
| Dispersion | [Spore](../cards/025-spore.md), [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md), [Supernova](../cards/075-supernova.md) | 3 |
| Distribution | [Delta](../cards/048-delta.md) | 1 |
| Dormancy | [Spore](../cards/025-spore.md), [Seed](../cards/028-seed.md) | 2 |
| Drift | [Plankton](../cards/026-plankton.md), [Tectonic Plate](../cards/057-tectonic-plate.md) | 2 |
| Emergence | [Higgs Field](../cards/008-higgs-field.md), [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md), [Stellar Nursery](../cards/074-stellar-nursery.md), [Cosmic Web](../cards/080-cosmic-web.md) | 4 |
| Erosion | [River](../cards/047-river.md), [Mountain Range](../cards/054-mountain-range.md), [Canyon](../cards/061-canyon.md) | 3 |
| Eruption | [Volcano](../cards/059-volcano.md) | 1 |
| Exchange | [Electron](../cards/002-electron.md), [Gluon](../cards/007-gluon.md), [Oxygen](../cards/012-oxygen.md), [Chemical Bond](../cards/014-chemical-bond.md), [Cell Membrane](../cards/019-cell-membrane.md), [Mitochondrion](../cards/021-mitochondrion.md), [Root](../cards/029-root.md), [Pollinator](../cards/035-pollinator.md), [Symbiosis](../cards/037-symbiosis.md), [Food Web](../cards/038-food-web.md), [Soil Community](../cards/043-soil-community.md), [Estuary](../cards/049-estuary.md), [Atmosphere](../cards/071-atmosphere.md), [Tide](../cards/072-tide.md) | 14 |
| Expansion | [Expanding Universe](../cards/081-expanding-universe.md) | 1 |
| Extinction | [Mass Extinction](../cards/063-mass-extinction.md) | 1 |
| Feedback | [Microbiome](../cards/027-microbiome.md), [Keystone Species](../cards/036-keystone-species.md), [Kelp Forest](../cards/044-kelp-forest.md), [Orbit](../cards/066-orbit.md) | 4 |
| Filtration | [Wetland](../cards/041-wetland.md) | 1 |
| Flow | [Plasma](../cards/016-plasma.md), [Kelp](../cards/032-kelp.md), [River](../cards/047-river.md), [Glacier](../cards/052-glacier.md), [Cosmic Web](../cards/080-cosmic-web.md) | 5 |
| Fragmentation | [Planetary Ring](../cards/069-planetary-ring.md) | 1 |
| Fusion | [Hydrogen](../cards/010-hydrogen.md), [Star](../cards/073-star.md) | 2 |
| Germination | [Seed](../cards/028-seed.md) | 1 |
| Growth | [Kelp](../cards/032-kelp.md) | 1 |
| Heat Transfer | [Mantle Convection](../cards/060-mantle-convection.md) | 1 |
| Incision | [Canyon](../cards/061-canyon.md) | 1 |
| Infiltration | [Aquifer](../cards/050-aquifer.md) | 1 |
| Interaction | [Higgs Field](../cards/008-higgs-field.md), [Tectonic Plate](../cards/057-tectonic-plate.md), [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 3 |
| Interpretation | [Fossil](../cards/062-fossil.md) | 1 |
| Ionization | [Plasma](../cards/016-plasma.md) | 1 |
| Metabolism | [Mitochondrion](../cards/021-mitochondrion.md), [Bacterium](../cards/022-bacterium.md), [Archaeon](../cards/023-archaeon.md) | 3 |
| Mixing | [Estuary](../cards/049-estuary.md) | 1 |
| Mutation | [DNA](../cards/020-dna.md) | 1 |
| Occlusion | [Eclipse](../cards/067-eclipse.md) | 1 |
| Orbit | [Gravity](../cards/009-gravity.md), [Moon](../cards/065-moon.md), [Orbit](../cards/066-orbit.md), [Comet](../cards/068-comet.md), [Planetary Ring](../cards/069-planetary-ring.md) | 5 |
| Oscillation | [Neutrino](../cards/005-neutrino.md), [Tide](../cards/072-tide.md) | 2 |
| Oxidation | [Oxygen](../cards/012-oxygen.md) | 1 |
| Phase Transition | [Water Molecule](../cards/013-water-molecule.md) | 1 |
| Pollination | [Pollinator](../cards/035-pollinator.md) | 1 |
| Predation | [Food Web](../cards/038-food-web.md) | 1 |
| Preservation | [Fossil](../cards/062-fossil.md) | 1 |
| Production | [Plankton](../cards/026-plankton.md), [Kelp Forest](../cards/044-kelp-forest.md) | 2 |
| Radiation | [Photon](../cards/001-photon.md), [Star](../cards/073-star.md) | 2 |
| Reconnection | [Magnetosphere](../cards/070-magnetosphere.md) | 1 |
| Recycling | [Decomposition](../cards/039-decomposition.md), [Subduction Zone](../cards/058-subduction-zone.md) | 2 |
| Regeneration | [Ancient Tree](../cards/030-ancient-tree.md), [Ecological Succession](../cards/040-ecological-succession.md) | 2 |
| Regulation | [Cell Membrane](../cards/019-cell-membrane.md), [Keystone Species](../cards/036-keystone-species.md), [Forest Canopy](../cards/042-forest-canopy.md) | 3 |
| Reorganization | [Mass Extinction](../cards/063-mass-extinction.md) | 1 |
| Repetition | [Crystal Lattice](../cards/015-crystal-lattice.md) | 1 |
| Replication | [DNA](../cards/020-dna.md), [Bacterium](../cards/022-bacterium.md), [Virus](../cards/024-virus.md) | 3 |
| Rotation | [Neutron Star](../cards/076-neutron-star.md) | 1 |
| Routing | [Watershed](../cards/046-watershed.md) | 1 |
| Rupture | [Fault](../cards/055-fault.md), [Earthquake](../cards/056-earthquake.md) | 2 |
| Scarcity | [Desert](../cards/051-desert.md) | 1 |
| Stability | [Proton](../cards/003-proton.md) | 1 |
| Storage | [Wetland](../cards/041-wetland.md), [Aquifer](../cards/050-aquifer.md) | 2 |
| Strain | [Fault](../cards/055-fault.md) | 1 |
| Sublimation | [Comet](../cards/068-comet.md) | 1 |
| Succession | [Ecological Succession](../cards/040-ecological-succession.md), [Coral Reef](../cards/045-coral-reef.md) | 2 |
| Symbiosis | [Microbiome](../cards/027-microbiome.md), [Lichen](../cards/031-lichen.md), [Coral Colony](../cards/033-coral-colony.md), [Symbiosis](../cards/037-symbiosis.md) | 4 |
| Threshold Crossing | [Phase Transition](../cards/017-phase-transition.md) | 1 |
| Tidal Interaction | [Moon](../cards/065-moon.md) | 1 |
| Transformation | [Quark](../cards/006-quark.md), [Phase Transition](../cards/017-phase-transition.md), [Catalysis](../cards/018-catalysis.md) | 3 |
| Transmission | [Photon](../cards/001-photon.md), [Neutrino](../cards/005-neutrino.md), [Virus](../cards/024-virus.md), [Earthquake](../cards/056-earthquake.md) | 4 |
| Transport | [Ocean Current](../cards/053-ocean-current.md) | 1 |
| Uplift | [Mountain Range](../cards/054-mountain-range.md) | 1 |
| Weathering | [Lichen](../cards/031-lichen.md) | 1 |
