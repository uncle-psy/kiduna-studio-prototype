# Natural Cycles and Process Chains


## Electromagnetic transmission

[Photon](../cards/001-photon.md) → [Water Molecule](../cards/013-water-molecule.md) → [Cell Membrane](../cards/019-cell-membrane.md) → [Star](../cards/073-star.md) → [Galaxy](../cards/078-galaxy.md)

Radiation is emitted, carried, absorbed, and interpreted through matter and larger systems. The arrows mark a reading route, not a single irreversible scientific sequence.


## Binding and release

[Quark](../cards/006-quark.md) → [Gluon](../cards/007-gluon.md) → [Chemical Bond](../cards/014-chemical-bond.md) → [Phase Transition](../cards/017-phase-transition.md) → [Fault](../cards/055-fault.md) → [Earthquake](../cards/056-earthquake.md)

Parts bind, energy accumulates, thresholds are crossed, and structure changes. The arrows mark a reading route, not a single irreversible scientific sequence.


## Biological information

[DNA](../cards/020-dna.md) → [Virus](../cards/024-virus.md) → [Spore](../cards/025-spore.md) → [Seed](../cards/028-seed.md) → [Pollinator](../cards/035-pollinator.md) → [Food Web](../cards/038-food-web.md)

Information is stored, copied, carried, filtered by survival, and expressed in networks. The arrows mark a reading route, not a single irreversible scientific sequence.


## Carbon and decomposition

[Carbon](../cards/011-carbon.md) → [Bacterium](../cards/022-bacterium.md) → [Microbiome](../cards/027-microbiome.md) → [Decomposition](../cards/039-decomposition.md) → [Wetland](../cards/041-wetland.md) → [Coral Reef](../cards/045-coral-reef.md)

Carbon is fixed, exchanged, stored, decomposed, and routed through ecosystems. The arrows mark a reading route, not a single irreversible scientific sequence.


## Water from molecule to basin

[Water Molecule](../cards/013-water-molecule.md) → [Cell Membrane](../cards/019-cell-membrane.md) → [Root](../cards/029-root.md) → [Wetland](../cards/041-wetland.md) → [Watershed](../cards/046-watershed.md) → [River](../cards/047-river.md) → [Estuary](../cards/049-estuary.md) → [Aquifer](../cards/050-aquifer.md) → [Glacier](../cards/052-glacier.md)

Water's molecular properties support cellular exchange and landscape storage, routing, mixing, and ice. The arrows mark a reading route, not a single irreversible scientific sequence.


## Ecological construction and succession

[Seed](../cards/028-seed.md) → [Lichen](../cards/031-lichen.md) → [Kelp](../cards/032-kelp.md) → [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) → [Ecological Succession](../cards/040-ecological-succession.md) → [Forest Canopy](../cards/042-forest-canopy.md) → [Kelp Forest](../cards/044-kelp-forest.md) → [Coral Reef](../cards/045-coral-reef.md)

Pioneers, builders, disturbance, and inherited structures change conditions for later life. The arrows mark a reading route, not a single irreversible scientific sequence.


## Rock cycle and relief

[Mountain Range](../cards/054-mountain-range.md) → [Fault](../cards/055-fault.md) → [Tectonic Plate](../cards/057-tectonic-plate.md) → [Subduction Zone](../cards/058-subduction-zone.md) → [Volcano](../cards/059-volcano.md) → [Mantle Convection](../cards/060-mantle-convection.md) → [Canyon](../cards/061-canyon.md) → [Fossil](../cards/062-fossil.md)

Plate motion, descent, melting, uplift, erosion, and preservation continually remake the crust. The arrows mark a reading route, not a single irreversible scientific sequence.


## Orbital relationship

[Gravity](../cards/009-gravity.md) → [Moon](../cards/065-moon.md) → [Orbit](../cards/066-orbit.md) → [Eclipse](../cards/067-eclipse.md) → [Comet](../cards/068-comet.md) → [Planetary Ring](../cards/069-planetary-ring.md) → [Magnetosphere](../cards/070-magnetosphere.md) → [Tide](../cards/072-tide.md)

Gravity and motion produce companionship, alignment, rings, shielding, and tides. The arrows mark a reading route, not a single irreversible scientific sequence.


## Stellar generations

[Hydrogen](../cards/010-hydrogen.md) → [Plasma](../cards/016-plasma.md) → [Star](../cards/073-star.md) → [Stellar Nursery](../cards/074-stellar-nursery.md) → [Supernova](../cards/075-supernova.md) → [Neutron Star](../cards/076-neutron-star.md) → [Black Hole](../cards/077-black-hole.md) → [Galaxy](../cards/078-galaxy.md)

Gas collapses into stars; stars transform matter, disperse it, and leave compact remnants within galaxies. The arrows mark a reading route, not a single irreversible scientific sequence.


## Cosmic structure

[Gravity](../cards/009-gravity.md) → [Galaxy](../cards/078-galaxy.md) → [Galaxy Cluster](../cards/079-galaxy-cluster.md) → [Cosmic Web](../cards/080-cosmic-web.md) → [Expanding Universe](../cards/081-expanding-universe.md)

Gravity amplifies density differences while expansion changes large-scale distances and horizons. The arrows mark a reading route, not a single irreversible scientific sequence.
