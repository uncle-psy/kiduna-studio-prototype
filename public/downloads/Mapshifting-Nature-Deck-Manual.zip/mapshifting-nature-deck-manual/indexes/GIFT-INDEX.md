# Gift Index

Entries are drawn from the canonical YAML registry.

| Gift | Cards | Count |
|---|---|---:|
| Accountability | [Watershed](../cards/046-watershed.md) | 1 |
| Adaptability | [Bacterium](../cards/022-bacterium.md) | 1 |
| Adaptation To Flow | [Plankton](../cards/026-plankton.md) | 1 |
| Adaptive Routing | [River](../cards/047-river.md) | 1 |
| Amplification | [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 1 |
| Ancestral Perspective | [Fossil](../cards/062-fossil.md) | 1 |
| Anchoring | [Proton](../cards/003-proton.md), [Root](../cards/029-root.md) | 2 |
| Availability | [Hydrogen](../cards/010-hydrogen.md) | 1 |
| Beginnings | [Hydrogen](../cards/010-hydrogen.md) | 1 |
| Belonging | [Galaxy](../cards/078-galaxy.md) | 1 |
| Belonging To A Whole | [Gravity](../cards/009-gravity.md) | 1 |
| Biodiversity | [Coral Reef](../cards/045-coral-reef.md) | 1 |
| Buffering | [Wetland](../cards/041-wetland.md), [Magnetosphere](../cards/070-magnetosphere.md) | 2 |
| Capture | [Forest Canopy](../cards/042-forest-canopy.md) | 1 |
| Circulation | [Atmosphere](../cards/071-atmosphere.md) | 1 |
| Clarity | [Crystal Lattice](../cards/015-crystal-lattice.md) | 1 |
| Clarity About Limits | [Black Hole](../cards/077-black-hole.md) | 1 |
| Clarity Of Boundary | [Fault](../cards/055-fault.md) | 1 |
| Climate Regulation | [Ocean Current](../cards/053-ocean-current.md), [Atmosphere](../cards/071-atmosphere.md) | 2 |
| Climatic Differentiation | [Mountain Range](../cards/054-mountain-range.md) | 1 |
| Co-Metabolism | [Microbiome](../cards/027-microbiome.md) | 1 |
| Coastal Protection | [Coral Reef](../cards/045-coral-reef.md) | 1 |
| Coherence | [Proton](../cards/003-proton.md), [Gravity](../cards/009-gravity.md) | 2 |
| Coherent Movement | [Tectonic Plate](../cards/057-tectonic-plate.md) | 1 |
| Cohesion | [Gluon](../cards/007-gluon.md), [Water Molecule](../cards/013-water-molecule.md) | 2 |
| Collective Construction | [Coral Colony](../cards/033-coral-colony.md) | 1 |
| Collective Impact | [Bacterium](../cards/022-bacterium.md) | 1 |
| Collective Order | [Planetary Ring](../cards/069-planetary-ring.md) | 1 |
| Collective Response | [Plasma](../cards/016-plasma.md) | 1 |
| Combustion | [Oxygen](../cards/012-oxygen.md) | 1 |
| Completion | [Decomposition](../cards/039-decomposition.md) | 1 |
| Complexity | [Carbon](../cards/011-carbon.md) | 1 |
| Compositional Power | [Quark](../cards/006-quark.md) | 1 |
| Concentration | [Neutron Star](../cards/076-neutron-star.md), [Black Hole](../cards/077-black-hole.md) | 2 |
| Conductivity | [Electron](../cards/002-electron.md), [Plasma](../cards/016-plasma.md) | 2 |
| Connection | [Chemical Bond](../cards/014-chemical-bond.md), [Pollinator](../cards/035-pollinator.md), [River](../cards/047-river.md), [Ocean Current](../cards/053-ocean-current.md), [Cosmic Web](../cards/080-cosmic-web.md) | 5 |
| Context | [Watershed](../cards/046-watershed.md) | 1 |
| Continuity | [DNA](../cards/020-dna.md), [Seed](../cards/028-seed.md), [Ancient Tree](../cards/030-ancient-tree.md), [Coral Colony](../cards/033-coral-colony.md) | 4 |
| Continuity Through Drought | [Aquifer](../cards/050-aquifer.md) | 1 |
| Contribution | [Quark](../cards/006-quark.md) | 1 |
| Cooperation | [Lichen](../cards/031-lichen.md) | 1 |
| Coordination | [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 1 |
| Creation Of Elements | [Star](../cards/073-star.md) | 1 |
| Creative Transformation | [Volcano](../cards/059-volcano.md) | 1 |
| Cross-Boundary Service | [Pollinator](../cards/035-pollinator.md) | 1 |
| Deep Memory | [Glacier](../cards/052-glacier.md) | 1 |
| Deep Persistence | [Mantle Convection](../cards/060-mantle-convection.md) | 1 |
| Deep Transformation | [Subduction Zone](../cards/058-subduction-zone.md) | 1 |
| Deep-System Memory | [Comet](../cards/068-comet.md) | 1 |
| Deflection | [Magnetosphere](../cards/070-magnetosphere.md) | 1 |
| Depth | [Canyon](../cards/061-canyon.md) | 1 |
| Development | [Ecological Succession](../cards/040-ecological-succession.md) | 1 |
| Differentiation | [Quark](../cards/006-quark.md) | 1 |
| Discernment | [Cell Membrane](../cards/019-cell-membrane.md), [Canyon](../cards/061-canyon.md) | 2 |
| Dispersal | [Spore](../cards/025-spore.md) | 1 |
| Distributed Function | [Microbiome](../cards/027-microbiome.md) | 1 |
| Distributed Labor | [Soil Community](../cards/043-soil-community.md) | 1 |
| Distributed Productivity | [Plankton](../cards/026-plankton.md) | 1 |
| Distribution | [Delta](../cards/048-delta.md), [Ocean Current](../cards/053-ocean-current.md), [Supernova](../cards/075-supernova.md) | 3 |
| Dynamic Balance | [Orbit](../cards/066-orbit.md) | 1 |
| Dynamic Protection | [Magnetosphere](../cards/070-magnetosphere.md) | 1 |
| Dynamic Structure | [Planetary Ring](../cards/069-planetary-ring.md) | 1 |
| Economy | [Virus](../cards/024-virus.md) | 1 |
| Efficiency | [Catalysis](../cards/018-catalysis.md), [Desert](../cards/051-desert.md) | 2 |
| Embodiment | [Higgs Field](../cards/008-higgs-field.md) | 1 |
| Emergent Structure | [Cosmic Web](../cards/080-cosmic-web.md) | 1 |
| Enablement | [Higgs Field](../cards/008-higgs-field.md), [Catalysis](../cards/018-catalysis.md) | 2 |
| Energy Conversion | [Mitochondrion](../cards/021-mitochondrion.md) | 1 |
| Energy Routing | [Food Web](../cards/038-food-web.md) | 1 |
| Evidence | [Fossil](../cards/062-fossil.md) | 1 |
| Evolutionary Opening | [Mass Extinction](../cards/063-mass-extinction.md) | 1 |
| Evolutionary Perspective | [Archaeon](../cards/023-archaeon.md) | 1 |
| Exchange | [Gluon](../cards/007-gluon.md), [Tide](../cards/072-tide.md) | 2 |
| Facilitation | [Ecological Succession](../cards/040-ecological-succession.md) | 1 |
| Fertile Branching | [Delta](../cards/048-delta.md) | 1 |
| Fertile Renewal | [Volcano](../cards/059-volcano.md) | 1 |
| Fertility | [Pollinator](../cards/035-pollinator.md), [Soil Community](../cards/043-soil-community.md) | 2 |
| Filtration | [Wetland](../cards/041-wetland.md) | 1 |
| Flexibility | [Kelp](../cards/032-kelp.md) | 1 |
| Foundation | [Plankton](../cards/026-plankton.md) | 1 |
| Fusion Potential | [Hydrogen](../cards/010-hydrogen.md) | 1 |
| Generational Renewal | [Galaxy](../cards/078-galaxy.md) | 1 |
| Gestation | [Stellar Nursery](../cards/074-stellar-nursery.md) | 1 |
| Habitat Creation | [Kelp](../cards/032-kelp.md), [Coral Colony](../cards/033-coral-colony.md), [Kelp Forest](../cards/044-kelp-forest.md) | 3 |
| Habitat Possibility | [Planet](../cards/064-planet.md) | 1 |
| Heat Transport | [Mantle Convection](../cards/060-mantle-convection.md) | 1 |
| Hidden Contribution | [Neutron](../cards/004-neutron.md) | 1 |
| Identity | [Proton](../cards/003-proton.md) | 1 |
| Illumination | [Photon](../cards/001-photon.md) | 1 |
| Information Transfer | [Virus](../cards/024-virus.md) | 1 |
| Integration | [Mitochondrion](../cards/021-mitochondrion.md), [Symbiosis](../cards/037-symbiosis.md), [Watershed](../cards/046-watershed.md), [Planet](../cards/064-planet.md) | 4 |
| Interdependence | [Food Web](../cards/038-food-web.md) | 1 |
| Intergenerational Building | [Coral Reef](../cards/045-coral-reef.md) | 1 |
| Land Building | [Delta](../cards/048-delta.md) | 1 |
| Large-Scale Context | [Tectonic Plate](../cards/057-tectonic-plate.md) | 1 |
| Large-Scale Pattern | [Galaxy](../cards/078-galaxy.md) | 1 |
| Layered Habitat | [Forest Canopy](../cards/042-forest-canopy.md) | 1 |
| Leverage | [Keystone Species](../cards/036-keystone-species.md) | 1 |
| Load-Bearing Pattern | [Crystal Lattice](../cards/015-crystal-lattice.md) | 1 |
| Long-Range Witness | [Neutrino](../cards/005-neutrino.md) | 1 |
| Lowered Barrier | [Catalysis](../cards/018-catalysis.md) | 1 |
| Memory | [DNA](../cards/020-dna.md), [Fossil](../cards/062-fossil.md) | 2 |
| Metabolic Flexibility | [Mitochondrion](../cards/021-mitochondrion.md) | 1 |
| Metabolic Invention | [Bacterium](../cards/022-bacterium.md) | 1 |
| Metabolic Power | [Oxygen](../cards/012-oxygen.md) | 1 |
| Mixing | [Estuary](../cards/049-estuary.md) | 1 |
| Moderation | [Neutron](../cards/004-neutron.md) | 1 |
| Movement | [River](../cards/047-river.md) | 1 |
| Multiplicity | [Stellar Nursery](../cards/074-stellar-nursery.md) | 1 |
| Mutual Support | [Symbiosis](../cards/037-symbiosis.md) | 1 |
| Necessary Movement | [Fault](../cards/055-fault.md) | 1 |
| New Centers | [Stellar Nursery](../cards/074-stellar-nursery.md) | 1 |
| New Ingredients | [Supernova](../cards/075-supernova.md) | 1 |
| New Organization | [Phase Transition](../cards/017-phase-transition.md) | 1 |
| Nursery Habitat | [Wetland](../cards/041-wetland.md), [Estuary](../cards/049-estuary.md) | 2 |
| Order | [Crystal Lattice](../cards/015-crystal-lattice.md) | 1 |
| Orientation | [Gravity](../cards/009-gravity.md) | 1 |
| Participation | [Electron](../cards/002-electron.md) | 1 |
| Patience | [Spore](../cards/025-spore.md), [Desert](../cards/051-desert.md) | 2 |
| Patient Force | [Glacier](../cards/052-glacier.md) | 1 |
| Penetration | [Neutrino](../cards/005-neutrino.md) | 1 |
| Persistence | [Archaeon](../cards/023-archaeon.md) | 1 |
| Persistent Signal | [Neutron Star](../cards/076-neutron-star.md) | 1 |
| Perspective | [Mountain Range](../cards/054-mountain-range.md), [Eclipse](../cards/067-eclipse.md) | 2 |
| Pioneering | [Lichen](../cards/031-lichen.md) | 1 |
| Possibility | [Expanding Universe](../cards/081-expanding-universe.md) | 1 |
| Potential | [Seed](../cards/028-seed.md) | 1 |
| Precision | [Desert](../cards/051-desert.md), [Eclipse](../cards/067-eclipse.md), [Neutron Star](../cards/076-neutron-star.md) | 3 |
| Preparedness | [Seed](../cards/028-seed.md) | 1 |
| Pressure Release | [Volcano](../cards/059-volcano.md) | 1 |
| Productivity | [Kelp Forest](../cards/044-kelp-forest.md) | 1 |
| Protection | [Cell Membrane](../cards/019-cell-membrane.md), [Atmosphere](../cards/071-atmosphere.md) | 2 |
| Radiance | [Plasma](../cards/016-plasma.md), [Star](../cards/073-star.md) | 2 |
| Radical Scale Shift | [Expanding Universe](../cards/081-expanding-universe.md) | 1 |
| Rapid Evolution | [Virus](../cards/024-virus.md) | 1 |
| Rapid Growth | [Kelp](../cards/032-kelp.md) | 1 |
| Reach | [Photon](../cards/001-photon.md) | 1 |
| Reciprocity | [Root](../cards/029-root.md) | 1 |
| Recognition Of Limits | [Mass Extinction](../cards/063-mass-extinction.md) | 1 |
| Recycling | [Decomposition](../cards/039-decomposition.md), [Soil Community](../cards/043-soil-community.md), [Subduction Zone](../cards/058-subduction-zone.md) | 3 |
| Redundancy | [Food Web](../cards/038-food-web.md) | 1 |
| Reflected Perspective | [Moon](../cards/065-moon.md) | 1 |
| Regeneration | [Ecological Succession](../cards/040-ecological-succession.md) | 1 |
| Regulated Exchange | [Cell Membrane](../cards/019-cell-membrane.md) | 1 |
| Regulation | [Keystone Species](../cards/036-keystone-species.md) | 1 |
| Relational Strength | [Gluon](../cards/007-gluon.md) | 1 |
| Release | [Decomposition](../cards/039-decomposition.md), [Fault](../cards/055-fault.md), [Earthquake](../cards/056-earthquake.md), [Supernova](../cards/075-supernova.md) | 4 |
| Renewal | [Tectonic Plate](../cards/057-tectonic-plate.md), [Subduction Zone](../cards/058-subduction-zone.md), [Mantle Convection](../cards/060-mantle-convection.md), [Comet](../cards/068-comet.md) | 4 |
| Reproduction | [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) | 1 |
| Reserve | [Aquifer](../cards/050-aquifer.md) | 1 |
| Reset | [Earthquake](../cards/056-earthquake.md) | 1 |
| Resilience | [Spore](../cards/025-spore.md), [Microbiome](../cards/027-microbiome.md) | 2 |
| Resource Sensing | [Root](../cards/029-root.md) | 1 |
| Responsiveness | [Electron](../cards/002-electron.md) | 1 |
| Return | [Orbit](../cards/066-orbit.md) | 1 |
| Revealed History | [Canyon](../cards/061-canyon.md) | 1 |
| Revealed Interdependence | [Tide](../cards/072-tide.md) | 1 |
| Revealed Relationship | [Eclipse](../cards/067-eclipse.md) | 1 |
| Revealed Structure | [Earthquake](../cards/056-earthquake.md), [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 2 |
| Revelation | [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) | 1 |
| Rhythm | [Moon](../cards/065-moon.md), [Orbit](../cards/066-orbit.md), [Tide](../cards/072-tide.md) | 3 |
| Scale Perspective | [Cosmic Web](../cards/080-cosmic-web.md) | 1 |
| Self-Consistent World | [Planet](../cards/064-planet.md) | 1 |
| Sensitivity | [Lichen](../cards/031-lichen.md) | 1 |
| Shared Capability | [Symbiosis](../cards/037-symbiosis.md) | 1 |
| Shared Condition | [Higgs Field](../cards/008-higgs-field.md) | 1 |
| Shared Structure | [Chemical Bond](../cards/014-chemical-bond.md) | 1 |
| Shelter | [Forest Canopy](../cards/042-forest-canopy.md) | 1 |
| Slow Release | [Aquifer](../cards/050-aquifer.md) | 1 |
| Solvency | [Water Molecule](../cards/013-water-molecule.md) | 1 |
| Stability | [Chemical Bond](../cards/014-chemical-bond.md) | 1 |
| Stabilization | [Neutron](../cards/004-neutron.md) | 1 |
| Stabilizing Relationship | [Moon](../cards/065-moon.md) | 1 |
| Storage | [Glacier](../cards/052-glacier.md) | 1 |
| Structural Habitat | [Ancient Tree](../cards/030-ancient-tree.md) | 1 |
| Structural Imagination | [Carbon](../cards/011-carbon.md) | 1 |
| Subtle Perception | [Neutrino](../cards/005-neutrino.md) | 1 |
| Support Of Diversity | [Keystone Species](../cards/036-keystone-species.md) | 1 |
| Sustained Purpose | [Star](../cards/073-star.md) | 1 |
| System Reset | [Mass Extinction](../cards/063-mass-extinction.md) | 1 |
| Timely Change | [Phase Transition](../cards/017-phase-transition.md) | 1 |
| Timely Emergence | [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) | 1 |
| Transformation | [Oxygen](../cards/012-oxygen.md), [Phase Transition](../cards/017-phase-transition.md) | 2 |
| Transformative Threshold | [Black Hole](../cards/077-black-hole.md) | 1 |
| Translation Between Systems | [Estuary](../cards/049-estuary.md) | 1 |
| Transmission | [Photon](../cards/001-photon.md) | 1 |
| Transport | [Water Molecule](../cards/013-water-molecule.md) | 1 |
| Unfolding | [Expanding Universe](../cards/081-expanding-universe.md) | 1 |
| Unusual Metabolism | [Archaeon](../cards/023-archaeon.md) | 1 |
| Variation | [DNA](../cards/020-dna.md) | 1 |
| Versatility | [Carbon](../cards/011-carbon.md) | 1 |
| Visible Limit | [Planetary Ring](../cards/069-planetary-ring.md) | 1 |
| Visible Response | [Comet](../cards/068-comet.md) | 1 |
| Water Source | [Mountain Range](../cards/054-mountain-range.md) | 1 |
| Wave Buffering | [Kelp Forest](../cards/044-kelp-forest.md) | 1 |
| Witness | [Ancient Tree](../cards/030-ancient-tree.md) | 1 |
