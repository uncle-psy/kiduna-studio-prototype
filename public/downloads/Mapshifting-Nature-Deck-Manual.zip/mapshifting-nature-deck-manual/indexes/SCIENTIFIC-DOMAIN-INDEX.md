# Scientific Domain Index

Entries are drawn from the canonical YAML registry.

| Domain | Cards | Count |
|---|---|---:|
| Astrochemistry | [Comet](../cards/068-comet.md) | 1 |
| Astronomy | [Planet](../cards/064-planet.md), [Eclipse](../cards/067-eclipse.md) | 2 |
| Astrophysics | [Neutrino](../cards/005-neutrino.md), [Hydrogen](../cards/010-hydrogen.md), [Plasma](../cards/016-plasma.md), [Star](../cards/073-star.md), [Stellar Nursery](../cards/074-stellar-nursery.md), [Supernova](../cards/075-supernova.md), [Neutron Star](../cards/076-neutron-star.md), [Black Hole](../cards/077-black-hole.md), [Galaxy](../cards/078-galaxy.md), [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 10 |
| Atmospheric Science | [Atmosphere](../cards/071-atmosphere.md) | 1 |
| Atomic Physics | [Electron](../cards/002-electron.md) | 1 |
| Biochemistry | [Catalysis](../cards/018-catalysis.md) | 1 |
| Biogeochemistry | [Carbon](../cards/011-carbon.md), [Oxygen](../cards/012-oxygen.md), [Decomposition](../cards/039-decomposition.md), [Coral Reef](../cards/045-coral-reef.md) | 4 |
| Biophysics | [Cell Membrane](../cards/019-cell-membrane.md) | 1 |
| Botany | [Spore](../cards/025-spore.md), [Seed](../cards/028-seed.md), [Root](../cards/029-root.md) | 3 |
| Cell Biology | [Cell Membrane](../cards/019-cell-membrane.md), [Mitochondrion](../cards/021-mitochondrion.md) | 2 |
| Chemistry | [Hydrogen](../cards/010-hydrogen.md), [Carbon](../cards/011-carbon.md), [Oxygen](../cards/012-oxygen.md), [Water Molecule](../cards/013-water-molecule.md), [Chemical Bond](../cards/014-chemical-bond.md), [Catalysis](../cards/018-catalysis.md) | 6 |
| Climate Science | [Ocean Current](../cards/053-ocean-current.md) | 1 |
| Climatology | [Forest Canopy](../cards/042-forest-canopy.md), [Desert](../cards/051-desert.md) | 2 |
| Coastal Science | [Delta](../cards/048-delta.md) | 1 |
| Community Ecology | [Keystone Species](../cards/036-keystone-species.md), [Food Web](../cards/038-food-web.md) | 2 |
| Conservation Biology | [Keystone Species](../cards/036-keystone-species.md) | 1 |
| Cosmology | [Gravity](../cards/009-gravity.md), [Galaxy](../cards/078-galaxy.md), [Galaxy Cluster](../cards/079-galaxy-cluster.md), [Cosmic Web](../cards/080-cosmic-web.md), [Expanding Universe](../cards/081-expanding-universe.md) | 5 |
| Crystallography | [Crystal Lattice](../cards/015-crystal-lattice.md) | 1 |
| Dendrology | [Ancient Tree](../cards/030-ancient-tree.md) | 1 |
| Earth-System Science | [Mass Extinction](../cards/063-mass-extinction.md) | 1 |
| Ecology | [Bacterium](../cards/022-bacterium.md), [Plankton](../cards/026-plankton.md), [Seed](../cards/028-seed.md), [Lichen](../cards/031-lichen.md), [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md), [Pollinator](../cards/035-pollinator.md), [Symbiosis](../cards/037-symbiosis.md), [Decomposition](../cards/039-decomposition.md), [Ecological Succession](../cards/040-ecological-succession.md), [Desert](../cards/051-desert.md) | 10 |
| Electromagnetism | [Photon](../cards/001-photon.md) | 1 |
| Estuarine Science | [Estuary](../cards/049-estuary.md) | 1 |
| Evolution | [Mitochondrion](../cards/021-mitochondrion.md), [Archaeon](../cards/023-archaeon.md), [Virus](../cards/024-virus.md), [Pollinator](../cards/035-pollinator.md), [Symbiosis](../cards/037-symbiosis.md) | 5 |
| Fluvial Geomorphology | [River](../cards/047-river.md) | 1 |
| Forest Ecology | [Ancient Tree](../cards/030-ancient-tree.md), [Forest Canopy](../cards/042-forest-canopy.md) | 2 |
| Genetics | [DNA](../cards/020-dna.md) | 1 |
| Geochemistry | [Aquifer](../cards/050-aquifer.md), [Volcano](../cards/059-volcano.md) | 2 |
| Geodynamics | [Tectonic Plate](../cards/057-tectonic-plate.md), [Subduction Zone](../cards/058-subduction-zone.md), [Mantle Convection](../cards/060-mantle-convection.md) | 3 |
| Geology | [Fossil](../cards/062-fossil.md) | 1 |
| Geomorphology | [Mountain Range](../cards/054-mountain-range.md), [Canyon](../cards/061-canyon.md) | 2 |
| Geophysics | [Mantle Convection](../cards/060-mantle-convection.md) | 1 |
| Glaciology | [Glacier](../cards/052-glacier.md) | 1 |
| Gravitation | [Gravity](../cards/009-gravity.md), [Orbit](../cards/066-orbit.md), [Black Hole](../cards/077-black-hole.md), [Expanding Universe](../cards/081-expanding-universe.md) | 4 |
| Hazard Science | [Earthquake](../cards/056-earthquake.md) | 1 |
| Hydrogeology | [Aquifer](../cards/050-aquifer.md) | 1 |
| Hydrology | [Water Molecule](../cards/013-water-molecule.md), [Wetland](../cards/041-wetland.md), [Watershed](../cards/046-watershed.md), [River](../cards/047-river.md), [Glacier](../cards/052-glacier.md), [Canyon](../cards/061-canyon.md) | 6 |
| Interstellar-Medium Physics | [Stellar Nursery](../cards/074-stellar-nursery.md) | 1 |
| Landscape Ecology | [Watershed](../cards/046-watershed.md) | 1 |
| Large-Scale Structure | [Cosmic Web](../cards/080-cosmic-web.md) | 1 |
| Marine Biology | [Coral Colony](../cards/033-coral-colony.md) | 1 |
| Marine Ecology | [Kelp](../cards/032-kelp.md), [Kelp Forest](../cards/044-kelp-forest.md), [Coral Reef](../cards/045-coral-reef.md) | 3 |
| Materials Science | [Chemical Bond](../cards/014-chemical-bond.md), [Crystal Lattice](../cards/015-crystal-lattice.md), [Phase Transition](../cards/017-phase-transition.md) | 3 |
| Microbial Ecology | [Microbiome](../cards/027-microbiome.md) | 1 |
| Microbiology | [Bacterium](../cards/022-bacterium.md), [Archaeon](../cards/023-archaeon.md), [Spore](../cards/025-spore.md), [Soil Community](../cards/043-soil-community.md) | 4 |
| Molecular Biology | [DNA](../cards/020-dna.md) | 1 |
| Mycology | [Spore](../cards/025-spore.md), [Lichen](../cards/031-lichen.md), [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) | 3 |
| Network Science | [Food Web](../cards/038-food-web.md) | 1 |
| Nuclear Astrophysics | [Supernova](../cards/075-supernova.md) | 1 |
| Nuclear Physics | [Proton](../cards/003-proton.md), [Neutron](../cards/004-neutron.md), [Star](../cards/073-star.md), [Neutron Star](../cards/076-neutron-star.md) | 4 |
| Oceanography | [Plankton](../cards/026-plankton.md), [Kelp Forest](../cards/044-kelp-forest.md), [Estuary](../cards/049-estuary.md), [Ocean Current](../cards/053-ocean-current.md), [Tide](../cards/072-tide.md) | 5 |
| Orbital Dynamics | [Moon](../cards/065-moon.md), [Planetary Ring](../cards/069-planetary-ring.md), [Tide](../cards/072-tide.md) | 3 |
| Orbital Geometry | [Eclipse](../cards/067-eclipse.md) | 1 |
| Orbital Mechanics | [Orbit](../cards/066-orbit.md) | 1 |
| Paleontology | [Fossil](../cards/062-fossil.md), [Mass Extinction](../cards/063-mass-extinction.md) | 2 |
| Particle Physics | [Photon](../cards/001-photon.md), [Electron](../cards/002-electron.md), [Proton](../cards/003-proton.md), [Neutron](../cards/004-neutron.md), [Neutrino](../cards/005-neutrino.md), [Quark](../cards/006-quark.md), [Gluon](../cards/007-gluon.md), [Higgs Field](../cards/008-higgs-field.md) | 8 |
| Phycology | [Kelp](../cards/032-kelp.md) | 1 |
| Planetary Science | [Planet](../cards/064-planet.md), [Moon](../cards/065-moon.md), [Comet](../cards/068-comet.md), [Planetary Ring](../cards/069-planetary-ring.md), [Atmosphere](../cards/071-atmosphere.md) | 5 |
| Plasma Physics | [Plasma](../cards/016-plasma.md), [Magnetosphere](../cards/070-magnetosphere.md) | 2 |
| Plate Tectonics | [Tectonic Plate](../cards/057-tectonic-plate.md) | 1 |
| Quantum Field Theory | [Higgs Field](../cards/008-higgs-field.md) | 1 |
| Restoration Science | [Ecological Succession](../cards/040-ecological-succession.md) | 1 |
| Sedimentology | [Delta](../cards/048-delta.md) | 1 |
| Seismology | [Fault](../cards/055-fault.md), [Earthquake](../cards/056-earthquake.md) | 2 |
| Soil Ecology | [Root](../cards/029-root.md), [Soil Community](../cards/043-soil-community.md) | 2 |
| Space Physics | [Magnetosphere](../cards/070-magnetosphere.md) | 1 |
| Structural Geology | [Fault](../cards/055-fault.md) | 1 |
| Symbiosis | [Coral Colony](../cards/033-coral-colony.md) | 1 |
| Systems Biology | [Microbiome](../cards/027-microbiome.md) | 1 |
| Tectonics | [Mountain Range](../cards/054-mountain-range.md) | 1 |
| Thermodynamics | [Phase Transition](../cards/017-phase-transition.md) | 1 |
| Virology | [Virus](../cards/024-virus.md) | 1 |
| Volcanology | [Subduction Zone](../cards/058-subduction-zone.md), [Volcano](../cards/059-volcano.md) | 2 |
| Wetland Ecology | [Wetland](../cards/041-wetland.md) | 1 |
