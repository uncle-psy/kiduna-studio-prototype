# System Function Index

Entries are drawn from the canonical YAML registry.

| Function | Cards | Count |
|---|---|---:|
| Ancestor | [Archaeon](../cards/023-archaeon.md), [Ancient Tree](../cards/030-ancient-tree.md), [Fossil](../cards/062-fossil.md) | 3 |
| Anchor | [Root](../cards/029-root.md) | 1 |
| Binder | [Gluon](../cards/007-gluon.md) | 1 |
| Boundary | [Electron](../cards/002-electron.md), [Cell Membrane](../cards/019-cell-membrane.md), [Forest Canopy](../cards/042-forest-canopy.md), [Mountain Range](../cards/054-mountain-range.md), [Fault](../cards/055-fault.md), [Planetary Ring](../cards/069-planetary-ring.md), [Magnetosphere](../cards/070-magnetosphere.md) | 7 |
| Bridge | [Gluon](../cards/007-gluon.md), [Chemical Bond](../cards/014-chemical-bond.md), [Catalysis](../cards/018-catalysis.md), [Lichen](../cards/031-lichen.md), [Pollinator](../cards/035-pollinator.md), [Symbiosis](../cards/037-symbiosis.md) | 6 |
| Builder | [Proton](../cards/003-proton.md), [Carbon](../cards/011-carbon.md), [Chemical Bond](../cards/014-chemical-bond.md), [Crystal Lattice](../cards/015-crystal-lattice.md), [Bacterium](../cards/022-bacterium.md), [Kelp](../cards/032-kelp.md), [Coral Colony](../cards/033-coral-colony.md), [Ecological Succession](../cards/040-ecological-succession.md), [Kelp Forest](../cards/044-kelp-forest.md), [Coral Reef](../cards/045-coral-reef.md), [Volcano](../cards/059-volcano.md) | 11 |
| Carrier | [Photon](../cards/001-photon.md), [Electron](../cards/002-electron.md), [Water Molecule](../cards/013-water-molecule.md), [Plasma](../cards/016-plasma.md), [Virus](../cards/024-virus.md), [Spore](../cards/025-spore.md), [Plankton](../cards/026-plankton.md), [Kelp](../cards/032-kelp.md), [Food Web](../cards/038-food-web.md), [River](../cards/047-river.md), [Glacier](../cards/052-glacier.md), [Ocean Current](../cards/053-ocean-current.md), [Tectonic Plate](../cards/057-tectonic-plate.md), [Mantle Convection](../cards/060-mantle-convection.md), [Tide](../cards/072-tide.md) | 15 |
| Catalyst | [Oxygen](../cards/012-oxygen.md), [Catalysis](../cards/018-catalysis.md) | 2 |
| Center | [Proton](../cards/003-proton.md), [Keystone Species](../cards/036-keystone-species.md) | 2 |
| Clock | [Ecological Succession](../cards/040-ecological-succession.md), [Mantle Convection](../cards/060-mantle-convection.md), [Orbit](../cards/066-orbit.md), [Tide](../cards/072-tide.md), [Expanding Universe](../cards/081-expanding-universe.md) | 5 |
| Companion | [Moon](../cards/065-moon.md) | 1 |
| Component | [Quark](../cards/006-quark.md) | 1 |
| Condition | [Higgs Field](../cards/008-higgs-field.md) | 1 |
| Container | [Watershed](../cards/046-watershed.md), [Aquifer](../cards/050-aquifer.md), [Planet](../cards/064-planet.md), [Atmosphere](../cards/071-atmosphere.md), [Stellar Nursery](../cards/074-stellar-nursery.md), [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 6 |
| Disruptor | [Virus](../cards/024-virus.md), [Earthquake](../cards/056-earthquake.md), [Mass Extinction](../cards/063-mass-extinction.md), [Supernova](../cards/075-supernova.md) | 4 |
| Dissolver | [Decomposition](../cards/039-decomposition.md), [Subduction Zone](../cards/058-subduction-zone.md) | 2 |
| Distributor | [Delta](../cards/048-delta.md) | 1 |
| Field | [Higgs Field](../cards/008-higgs-field.md), [Gravity](../cards/009-gravity.md), [Plasma](../cards/016-plasma.md) | 3 |
| Filter | [Cell Membrane](../cards/019-cell-membrane.md), [Wetland](../cards/041-wetland.md), [Forest Canopy](../cards/042-forest-canopy.md), [Desert](../cards/051-desert.md), [Atmosphere](../cards/071-atmosphere.md) | 5 |
| Foundation | [Plankton](../cards/026-plankton.md) | 1 |
| Lens | [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 1 |
| Memory | [DNA](../cards/020-dna.md), [Seed](../cards/028-seed.md), [Ancient Tree](../cards/030-ancient-tree.md), [Aquifer](../cards/050-aquifer.md), [Glacier](../cards/052-glacier.md), [Fault](../cards/055-fault.md), [Canyon](../cards/061-canyon.md), [Fossil](../cards/062-fossil.md), [Comet](../cards/068-comet.md), [Neutron Star](../cards/076-neutron-star.md) | 10 |
| Messenger | [Neutrino](../cards/005-neutrino.md), [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md), [Pollinator](../cards/035-pollinator.md), [Comet](../cards/068-comet.md) | 4 |
| Mirror | [Moon](../cards/065-moon.md) | 1 |
| Network | [Carbon](../cards/011-carbon.md), [Microbiome](../cards/027-microbiome.md), [Root](../cards/029-root.md), [Coral Colony](../cards/033-coral-colony.md), [Symbiosis](../cards/037-symbiosis.md), [Food Web](../cards/038-food-web.md), [Soil Community](../cards/043-soil-community.md), [Kelp Forest](../cards/044-kelp-forest.md), [Watershed](../cards/046-watershed.md), [Galaxy](../cards/078-galaxy.md), [Cosmic Web](../cards/080-cosmic-web.md) | 11 |
| Nursery | [Estuary](../cards/049-estuary.md) | 1 |
| Path | [River](../cards/047-river.md) | 1 |
| Pattern | [Crystal Lattice](../cards/015-crystal-lattice.md), [DNA](../cards/020-dna.md), [Planetary Ring](../cards/069-planetary-ring.md), [Cosmic Web](../cards/080-cosmic-web.md) | 4 |
| Pioneer | [Lichen](../cards/031-lichen.md) | 1 |
| Powerhouse | [Mitochondrion](../cards/021-mitochondrion.md) | 1 |
| Protector | [Magnetosphere](../cards/070-magnetosphere.md) | 1 |
| Recycler | [Bacterium](../cards/022-bacterium.md), [Decomposition](../cards/039-decomposition.md), [Soil Community](../cards/043-soil-community.md), [Supernova](../cards/075-supernova.md) | 4 |
| Regulator | [Neutron](../cards/004-neutron.md), [Microbiome](../cards/027-microbiome.md), [Keystone Species](../cards/036-keystone-species.md), [Ocean Current](../cards/053-ocean-current.md) | 4 |
| Relationship | [Orbit](../cards/066-orbit.md) | 1 |
| Revelation | [Canyon](../cards/061-canyon.md), [Eclipse](../cards/067-eclipse.md) | 2 |
| Seed | [Quark](../cards/006-quark.md), [Hydrogen](../cards/010-hydrogen.md), [Spore](../cards/025-spore.md), [Seed](../cards/028-seed.md), [Stellar Nursery](../cards/074-stellar-nursery.md) | 5 |
| Signal | [Photon](../cards/001-photon.md), [Earthquake](../cards/056-earthquake.md), [Neutron Star](../cards/076-neutron-star.md) | 3 |
| Solvent | [Water Molecule](../cards/013-water-molecule.md) | 1 |
| Source | [Hydrogen](../cards/010-hydrogen.md), [Mountain Range](../cards/054-mountain-range.md), [Star](../cards/073-star.md) | 3 |
| Stabilizer | [Neutron](../cards/004-neutron.md) | 1 |
| Teacher | [Desert](../cards/051-desert.md) | 1 |
| Threshold | [Phase Transition](../cards/017-phase-transition.md), [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md), [Wetland](../cards/041-wetland.md), [Delta](../cards/048-delta.md), [Estuary](../cards/049-estuary.md), [Volcano](../cards/059-volcano.md), [Mass Extinction](../cards/063-mass-extinction.md), [Eclipse](../cards/067-eclipse.md), [Black Hole](../cards/077-black-hole.md) | 9 |
| Transformer | [Oxygen](../cards/012-oxygen.md), [Phase Transition](../cards/017-phase-transition.md), [Mitochondrion](../cards/021-mitochondrion.md), [Archaeon](../cards/023-archaeon.md), [Subduction Zone](../cards/058-subduction-zone.md), [Star](../cards/073-star.md) | 6 |
| Void | [Black Hole](../cards/077-black-hole.md) | 1 |
| Whole | [Gravity](../cards/009-gravity.md), [Coral Reef](../cards/045-coral-reef.md), [Tectonic Plate](../cards/057-tectonic-plate.md), [Planet](../cards/064-planet.md), [Galaxy](../cards/078-galaxy.md), [Expanding Universe](../cards/081-expanding-universe.md) | 6 |
| Witness | [Neutrino](../cards/005-neutrino.md) | 1 |
