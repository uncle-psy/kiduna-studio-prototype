# Wound Index

Entries are drawn from the canonical YAML registry.

| Wound | Cards | Count |
|---|---|---:|
| Absence Mistaken For Nonexistence | [Fossil](../cards/062-fossil.md) | 1 |
| Accumulated Contamination | [Watershed](../cards/046-watershed.md) | 1 |
| Accumulated Damage | [Ancient Tree](../cards/030-ancient-tree.md) | 1 |
| Accumulated Strain | [Fault](../cards/055-fault.md) | 1 |
| Apparent Solidity | [Planetary Ring](../cards/069-planetary-ring.md) | 1 |
| Barrier | [Mountain Range](../cards/054-mountain-range.md) | 1 |
| Bleaching | [Coral Colony](../cards/033-coral-colony.md), [Coral Reef](../cards/045-coral-reef.md) | 2 |
| Bloom Imbalance | [Plankton](../cards/026-plankton.md) | 1 |
| Bonding Without Fit | [Chemical Bond](../cards/014-chemical-bond.md) | 1 |
| Bottleneck | [Food Web](../cards/038-food-web.md) | 1 |
| Boundary Blindness | [Watershed](../cards/046-watershed.md) | 1 |
| Boundary Loss | [Atmosphere](../cards/071-atmosphere.md) | 1 |
| Boundary Stress | [Tectonic Plate](../cards/057-tectonic-plate.md) | 1 |
| Brittleness | [Crystal Lattice](../cards/015-crystal-lattice.md) | 1 |
| Buried Conflict | [Subduction Zone](../cards/058-subduction-zone.md) | 1 |
| Burning Beyond Balance | [Star](../cards/073-star.md) | 1 |
| Burnout | [Mitochondrion](../cards/021-mitochondrion.md) | 1 |
| Capture | [Orbit](../cards/066-orbit.md) | 1 |
| Carried Pollution | [River](../cards/047-river.md) | 1 |
| Carrying Contamination | [Water Molecule](../cards/013-water-molecule.md) | 1 |
| Cascade | [Food Web](../cards/038-food-web.md), [Mass Extinction](../cards/063-mass-extinction.md) | 2 |
| Catastrophe Abstraction | [Mass Extinction](../cards/063-mass-extinction.md) | 1 |
| Catastrophic Disruption | [Supernova](../cards/075-supernova.md) | 1 |
| Central Dominance | [Galaxy](../cards/078-galaxy.md) | 1 |
| Centralization | [Proton](../cards/003-proton.md) | 1 |
| Certainty Projected Beyond Evidence | [Expanding Universe](../cards/081-expanding-universe.md) | 1 |
| Channelization | [River](../cards/047-river.md) | 1 |
| Climate Sensitivity | [Kelp Forest](../cards/044-kelp-forest.md) | 1 |
| Closed-World Thinking | [Planet](../cards/064-planet.md) | 1 |
| Closure | [Forest Canopy](../cards/042-forest-canopy.md) | 1 |
| Collapse | [Gravity](../cards/009-gravity.md) | 1 |
| Collapse Without Formation | [Stellar Nursery](../cards/074-stellar-nursery.md) | 1 |
| Collision | [Tectonic Plate](../cards/057-tectonic-plate.md), [Planetary Ring](../cards/069-planetary-ring.md), [Galaxy](../cards/078-galaxy.md) | 3 |
| Compaction | [Soil Community](../cards/043-soil-community.md) | 1 |
| Complexity Without Function | [Carbon](../cards/011-carbon.md) | 1 |
| Confusing Unknown With Nothing | [Black Hole](../cards/077-black-hole.md) | 1 |
| Confusing Viewpoint With Disappearance | [Eclipse](../cards/067-eclipse.md) | 1 |
| Consumption | [Black Hole](../cards/077-black-hole.md) | 1 |
| Contaminant Accumulation | [Wetland](../cards/041-wetland.md) | 1 |
| Contamination Persistence | [Aquifer](../cards/050-aquifer.md) | 1 |
| Copying Error | [DNA](../cards/020-dna.md) | 1 |
| Crowding | [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 1 |
| Cycles Mistaken For Commands | [Moon](../cards/065-moon.md) | 1 |
| Damaged Inheritance | [Mitochondrion](../cards/021-mitochondrion.md) | 1 |
| Decay Outside Belonging | [Neutron](../cards/004-neutron.md) | 1 |
| Decaying Path | [Orbit](../cards/066-orbit.md) | 1 |
| Defect Intolerance | [Crystal Lattice](../cards/015-crystal-lattice.md) | 1 |
| Delayed Consequence | [Glacier](../cards/052-glacier.md) | 1 |
| Dependence On Narrow Conditions | [Kelp](../cards/032-kelp.md) | 1 |
| Dependency | [Oxygen](../cards/012-oxygen.md), [Catalysis](../cards/018-catalysis.md), [Virus](../cards/024-virus.md), [Lichen](../cards/031-lichen.md), [Moon](../cards/065-moon.md) | 5 |
| Depletion | [Soil Community](../cards/043-soil-community.md), [Aquifer](../cards/050-aquifer.md), [Desert](../cards/051-desert.md) | 3 |
| Destruction | [Earthquake](../cards/056-earthquake.md) | 1 |
| Destructive Return | [Subduction Zone](../cards/058-subduction-zone.md) | 1 |
| Determinism | [Higgs Field](../cards/008-higgs-field.md) | 1 |
| Dilution | [Water Molecule](../cards/013-water-molecule.md) | 1 |
| Discharge | [Plasma](../cards/016-plasma.md) | 1 |
| Disconnection | [Neutrino](../cards/005-neutrino.md) | 1 |
| Dispersion | [Planetary Ring](../cards/069-planetary-ring.md) | 1 |
| Disruption | [Comet](../cards/068-comet.md) | 1 |
| Dormancy Without End | [Seed](../cards/028-seed.md) | 1 |
| Downstream Burden | [Watershed](../cards/046-watershed.md) | 1 |
| Drainage And Loss | [Wetland](../cards/041-wetland.md) | 1 |
| Drift Without Agency | [Plankton](../cards/026-plankton.md) | 1 |
| Dysbiosis | [Microbiome](../cards/027-microbiome.md) | 1 |
| Elusiveness | [Neutrino](../cards/005-neutrino.md) | 1 |
| Energetic Entrapment | [Chemical Bond](../cards/014-chemical-bond.md) | 1 |
| Energy Trapped In Conflict | [Gluon](../cards/007-gluon.md) | 1 |
| Enmeshment | [Symbiosis](../cards/037-symbiosis.md) | 1 |
| Entanglement | [Gluon](../cards/007-gluon.md) | 1 |
| Entrenchment | [Root](../cards/029-root.md), [Canyon](../cards/061-canyon.md) | 2 |
| Erased History | [Ecological Succession](../cards/040-ecological-succession.md) | 1 |
| Erosion Exceeding Growth | [Coral Reef](../cards/045-coral-reef.md) | 1 |
| Erosion Without Renewal | [Canyon](../cards/061-canyon.md) | 1 |
| Exploitation | [Virus](../cards/024-virus.md), [Symbiosis](../cards/037-symbiosis.md) | 2 |
| Exposure | [Photon](../cards/001-photon.md), [Desert](../cards/051-desert.md) | 2 |
| Failure To Interact | [Neutrino](../cards/005-neutrino.md) | 1 |
| False Abundance | [Aquifer](../cards/050-aquifer.md) | 1 |
| False Portent | [Eclipse](../cards/067-eclipse.md) | 1 |
| False Stillness | [Fault](../cards/055-fault.md) | 1 |
| Filament Overload | [Cosmic Web](../cards/080-cosmic-web.md) | 1 |
| Flooding | [Water Molecule](../cards/013-water-molecule.md), [River](../cards/047-river.md) | 2 |
| Forced Independence | [Quark](../cards/006-quark.md) | 1 |
| Fragile Dependence | [Coral Reef](../cards/045-coral-reef.md) | 1 |
| Fragility Around One Role | [Keystone Species](../cards/036-keystone-species.md) | 1 |
| Fragmentation | [Quark](../cards/006-quark.md), [Coral Colony](../cards/033-coral-colony.md), [Delta](../cards/048-delta.md), [Stellar Nursery](../cards/074-stellar-nursery.md) | 4 |
| Frozen Narrative | [Fossil](../cards/062-fossil.md) | 1 |
| Fuel Exhaustion | [Star](../cards/073-star.md) | 1 |
| Gravity Well | [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 1 |
| Growth Beyond Resilience | [Coral Colony](../cards/033-coral-colony.md) | 1 |
| Hazard Denial | [Volcano](../cards/059-volcano.md) | 1 |
| Hidden Dependency | [Microbiome](../cards/027-microbiome.md), [Ocean Current](../cards/053-ocean-current.md) | 2 |
| Hidden Depletion | [Root](../cards/029-root.md) | 1 |
| Hidden Pressure | [Mantle Convection](../cards/060-mantle-convection.md) | 1 |
| Hysteresis | [Phase Transition](../cards/017-phase-transition.md) | 1 |
| Identity After Collapse | [Neutron Star](../cards/076-neutron-star.md) | 1 |
| Identity Defined By Spectacle | [Comet](../cards/068-comet.md) | 1 |
| Identity Reduced To Parts | [Quark](../cards/006-quark.md) | 1 |
| Identity Tied To Final Brilliance | [Supernova](../cards/075-supernova.md) | 1 |
| Ignoring Local Modulation | [Tide](../cards/072-tide.md) | 1 |
| Illusion Of Fixed Ground | [Tectonic Plate](../cards/057-tectonic-plate.md) | 1 |
| Indefinite Suspension | [Spore](../cards/025-spore.md) | 1 |
| Indiscriminate Permeability | [Cell Membrane](../cards/019-cell-membrane.md) | 1 |
| Inescapable Pull | [Gravity](../cards/009-gravity.md) | 1 |
| Inflexibility | [Ancient Tree](../cards/030-ancient-tree.md) | 1 |
| Information Without Expression | [DNA](../cards/020-dna.md) | 1 |
| Inherited Constraint | [Seed](../cards/028-seed.md) | 1 |
| Instability | [Plasma](../cards/016-plasma.md), [Star](../cards/073-star.md) | 2 |
| Inundation | [Tide](../cards/072-tide.md) | 1 |
| Invisibility | [Neutron](../cards/004-neutron.md), [Archaeon](../cards/023-archaeon.md) | 2 |
| Invisible Collapse | [Soil Community](../cards/043-soil-community.md) | 1 |
| Invisible Constraint | [Higgs Field](../cards/008-higgs-field.md) | 1 |
| Irreversible Loss | [Mass Extinction](../cards/063-mass-extinction.md) | 1 |
| Isolation | [Cell Membrane](../cards/019-cell-membrane.md), [Mountain Range](../cards/054-mountain-range.md), [Canyon](../cards/061-canyon.md) | 3 |
| Leakage | [Cell Membrane](../cards/019-cell-membrane.md) | 1 |
| Light Exclusion | [Forest Canopy](../cards/042-forest-canopy.md) | 1 |
| Locked Capacity | [Glacier](../cards/052-glacier.md) | 1 |
| Locked Face | [Moon](../cards/065-moon.md) | 1 |
| Locked Storage | [Carbon](../cards/011-carbon.md) | 1 |
| Loss Of Autonomy | [Symbiosis](../cards/037-symbiosis.md) | 1 |
| Loss Of Common Horizon | [Expanding Universe](../cards/081-expanding-universe.md) | 1 |
| Loss Of Containment | [Plasma](../cards/016-plasma.md) | 1 |
| Loss Of Diversity | [Microbiome](../cards/027-microbiome.md) | 1 |
| Loss Of Gradient | [Estuary](../cards/049-estuary.md) | 1 |
| Megathrust Rupture | [Subduction Zone](../cards/058-subduction-zone.md) | 1 |
| Misclassification | [Archaeon](../cards/023-archaeon.md) | 1 |
| Misdirected Acceleration | [Catalysis](../cards/018-catalysis.md) | 1 |
| Misplaced Hero Narrative | [Keystone Species](../cards/036-keystone-species.md) | 1 |
| Misrouting | [Ocean Current](../cards/053-ocean-current.md) | 1 |
| Missed Timing | [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) | 1 |
| Mistaking Age For Invulnerability | [Ancient Tree](../cards/030-ancient-tree.md) | 1 |
| Mistaking Context For Destiny | [Higgs Field](../cards/008-higgs-field.md) | 1 |
| Mistaking Display For Whole | [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) | 1 |
| Mistaking Map For Total Reality | [Cosmic Web](../cards/080-cosmic-web.md) | 1 |
| Muted Agency | [Neutron](../cards/004-neutron.md) | 1 |
| Myth Of One Climax | [Ecological Succession](../cards/040-ecological-succession.md) | 1 |
| Network Loss | [Pollinator](../cards/035-pollinator.md) | 1 |
| Obscuration | [Eclipse](../cards/067-eclipse.md), [Stellar Nursery](../cards/074-stellar-nursery.md) | 2 |
| Overaccumulation | [Carbon](../cards/011-carbon.md) | 1 |
| Overattachment | [Proton](../cards/003-proton.md) | 1 |
| Overbinding | [Gluon](../cards/007-gluon.md) | 1 |
| Overcentralization | [Gravity](../cards/009-gravity.md), [Keystone Species](../cards/036-keystone-species.md) | 2 |
| Overcompression | [Neutron Star](../cards/076-neutron-star.md) | 1 |
| Overdependence | [Pollinator](../cards/035-pollinator.md) | 1 |
| Overexposure | [Magnetosphere](../cards/070-magnetosphere.md) | 1 |
| Overextension | [Kelp](../cards/032-kelp.md) | 1 |
| Overspecialization | [Archaeon](../cards/023-archaeon.md) | 1 |
| Oxidative Damage | [Oxygen](../cards/012-oxygen.md) | 1 |
| Partnership Under Strain | [Lichen](../cards/031-lichen.md) | 1 |
| Parts Lost In Scale | [Galaxy](../cards/078-galaxy.md) | 1 |
| Pathogenic Imbalance | [Bacterium](../cards/022-bacterium.md) | 1 |
| Planetary Imbalance | [Planet](../cards/064-planet.md) | 1 |
| Pollutant Concentration | [Estuary](../cards/049-estuary.md) | 1 |
| Pollution Accumulation | [Atmosphere](../cards/071-atmosphere.md) | 1 |
| Poor Timing | [Seed](../cards/028-seed.md) | 1 |
| Power Detached From Need | [Mitochondrion](../cards/021-mitochondrion.md) | 1 |
| Premature Emergence | [Spore](../cards/025-spore.md) | 1 |
| Premature Forcing | [Phase Transition](../cards/017-phase-transition.md) | 1 |
| Pressure Without Pathway | [Volcano](../cards/059-volcano.md) | 1 |
| Rapid Loss After Slow Formation | [Glacier](../cards/052-glacier.md) | 1 |
| Reactivity | [Electron](../cards/002-electron.md) | 1 |
| Refusal Of Endings | [Decomposition](../cards/039-decomposition.md) | 1 |
| Regime Shift | [Kelp Forest](../cards/044-kelp-forest.md) | 1 |
| Repeated Rupture | [Fault](../cards/055-fault.md) | 1 |
| Repetition | [Orbit](../cards/066-orbit.md) | 1 |
| Resistance To Reconfiguration | [Proton](../cards/003-proton.md) | 1 |
| Resource Capture | [Root](../cards/029-root.md) | 1 |
| Resource Exhaustion | [Bacterium](../cards/022-bacterium.md) | 1 |
| Restlessness | [Electron](../cards/002-electron.md) | 1 |
| Rigid Identity | [DNA](../cards/020-dna.md) | 1 |
| Rigid Timing | [Tide](../cards/072-tide.md) | 1 |
| Rigidity | [Chemical Bond](../cards/014-chemical-bond.md), [Crystal Lattice](../cards/015-crystal-lattice.md), [Neutron Star](../cards/076-neutron-star.md) | 3 |
| Romanticized Hazard | [Earthquake](../cards/056-earthquake.md) | 1 |
| Romanticizing Hardship | [Desert](../cards/051-desert.md) | 1 |
| Runaway Feedback | [Atmosphere](../cards/071-atmosphere.md) | 1 |
| Runaway Propagation | [Virus](../cards/024-virus.md) | 1 |
| Runaway Reaction | [Oxygen](../cards/012-oxygen.md) | 1 |
| Salinity Stress | [Estuary](../cards/049-estuary.md) | 1 |
| Saturation | [Wetland](../cards/041-wetland.md) | 1 |
| Scale Blindness | [Planet](../cards/064-planet.md) | 1 |
| Scattering | [Photon](../cards/001-photon.md) | 1 |
| Secrecy | [Black Hole](../cards/077-black-hole.md) | 1 |
| Selection Bias | [Fossil](../cards/062-fossil.md) | 1 |
| Separation | [Expanding Universe](../cards/081-expanding-universe.md) | 1 |
| Service Extracted Without Habitat | [Pollinator](../cards/035-pollinator.md) | 1 |
| Shield Mistaken For Seal | [Magnetosphere](../cards/070-magnetosphere.md) | 1 |
| Shock | [Supernova](../cards/075-supernova.md) | 1 |
| Shock Propagation | [Earthquake](../cards/056-earthquake.md) | 1 |
| Signal Overload | [Photon](../cards/001-photon.md) | 1 |
| Simplicity Mistaken For Insufficiency | [Hydrogen](../cards/010-hydrogen.md) | 1 |
| Simplification | [Food Web](../cards/038-food-web.md) | 1 |
| Slow Imbalance | [Mantle Convection](../cards/060-mantle-convection.md) | 1 |
| Slow Recovery | [Lichen](../cards/031-lichen.md) | 1 |
| Stagnation | [Decomposition](../cards/039-decomposition.md), [Ocean Current](../cards/053-ocean-current.md) | 2 |
| Stalled Transition | [Ecological Succession](../cards/040-ecological-succession.md) | 1 |
| Starved Sediment | [Delta](../cards/048-delta.md) | 1 |
| Stripping | [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 1 |
| Subsidence | [Delta](../cards/048-delta.md) | 1 |
| Surface Effects Detached From Cause | [Mantle Convection](../cards/060-mantle-convection.md) | 1 |
| Surface Fixation | [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) | 1 |
| Toxic Release | [Decomposition](../cards/039-decomposition.md) | 1 |
| Trapped Radiation | [Magnetosphere](../cards/070-magnetosphere.md) | 1 |
| Unaccounted Side Reaction | [Catalysis](../cards/018-catalysis.md) | 1 |
| Unchecked Growth | [Bacterium](../cards/022-bacterium.md) | 1 |
| Uncontained Charge | [Electron](../cards/002-electron.md) | 1 |
| Uncontained Eruption | [Volcano](../cards/059-volcano.md) | 1 |
| Underdevelopment | [Hydrogen](../cards/010-hydrogen.md) | 1 |
| Unrooted Possibility | [Spore](../cards/025-spore.md) | 1 |
| Unstable Slope | [Mountain Range](../cards/054-mountain-range.md) | 1 |
| Unstable Transition | [Phase Transition](../cards/017-phase-transition.md) | 1 |
| Uprooting | [Kelp](../cards/032-kelp.md) | 1 |
| Urchin Barren | [Kelp Forest](../cards/044-kelp-forest.md) | 1 |
| Void Isolation | [Cosmic Web](../cards/080-cosmic-web.md) | 1 |
| Volatile Release | [Comet](../cards/068-comet.md) | 1 |
| Volatility | [Hydrogen](../cards/010-hydrogen.md) | 1 |
| Vulnerability To Currents | [Plankton](../cards/026-plankton.md) | 1 |
| Windthrow Exposure | [Forest Canopy](../cards/042-forest-canopy.md) | 1 |
