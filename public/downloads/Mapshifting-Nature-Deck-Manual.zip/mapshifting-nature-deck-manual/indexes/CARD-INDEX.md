# Complete Card Catalog


| # | Card | Scale band | Type | Core archetype |
|---:|---|---|---|---|
| 1 | [Photon](../cards/001-photon.md) | 1. Fundamental | Entity | Messenger |
| 2 | [Electron](../cards/002-electron.md) | 1. Fundamental | Entity | Participant |
| 3 | [Proton](../cards/003-proton.md) | 1. Fundamental | Entity | Anchor |
| 4 | [Neutron](../cards/004-neutron.md) | 1. Fundamental | Entity | Quiet Binder |
| 5 | [Neutrino](../cards/005-neutrino.md) | 1. Fundamental | Entity | Ghost Messenger |
| 6 | [Quark](../cards/006-quark.md) | 1. Fundamental | Entity | Constituent |
| 7 | [Gluon](../cards/007-gluon.md) | 1. Fundamental | Entity | Living Bond |
| 8 | [Higgs Field](../cards/008-higgs-field.md) | 1. Fundamental | System Relationship | Enabling Field |
| 9 | [Gravity](../cards/009-gravity.md) | 1. Fundamental | System Relationship | Curvature |
| 10 | [Hydrogen](../cards/010-hydrogen.md) | 2. Atomic and molecular | Entity | First Element |
| 11 | [Carbon](../cards/011-carbon.md) | 2. Atomic and molecular | Entity | Versatile Builder |
| 12 | [Oxygen](../cards/012-oxygen.md) | 2. Atomic and molecular | Entity | Intensifier |
| 13 | [Water Molecule](../cards/013-water-molecule.md) | 2. Atomic and molecular | Entity | Relational Solvent |
| 14 | [Chemical Bond](../cards/014-chemical-bond.md) | 2. Atomic and molecular | System Relationship | Commitment |
| 15 | [Crystal Lattice](../cards/015-crystal-lattice.md) | 2. Atomic and molecular | System Relationship | Repeating Order |
| 16 | [Plasma](../cards/016-plasma.md) | 2. Atomic and molecular | Entity | Collective Charge |
| 17 | [Phase Transition](../cards/017-phase-transition.md) | 2. Atomic and molecular | Process | Threshold |
| 18 | [Catalysis](../cards/018-catalysis.md) | 2. Atomic and molecular | Process | Alternate Path |
| 19 | [Cell Membrane](../cards/019-cell-membrane.md) | 3. Microscopic and cellular | System Relationship | Selective Boundary |
| 20 | [DNA](../cards/020-dna.md) | 3. Microscopic and cellular | Entity | Heritable Record |
| 21 | [Mitochondrion](../cards/021-mitochondrion.md) | 3. Microscopic and cellular | Entity | Inner Transformer |
| 22 | [Bacterium](../cards/022-bacterium.md) | 3. Microscopic and cellular | Entity | Metabolic Inventor |
| 23 | [Archaeon](../cards/023-archaeon.md) | 3. Microscopic and cellular | Entity | Deep-Lineage Adapter |
| 24 | [Virus](../cards/024-virus.md) | 3. Microscopic and cellular | Entity | Borrowed Replicator |
| 25 | [Spore](../cards/025-spore.md) | 3. Microscopic and cellular | Entity | Dormant Possibility |
| 26 | [Plankton](../cards/026-plankton.md) | 3. Microscopic and cellular | System Relationship | Drifter Community |
| 27 | [Microbiome](../cards/027-microbiome.md) | 3. Microscopic and cellular | System Relationship | Invisible Community |
| 28 | [Seed](../cards/028-seed.md) | 4. Organism | Entity | Condensed Future |
| 29 | [Root](../cards/029-root.md) | 4. Organism | Entity | Hidden Negotiator |
| 30 | [Ancient Tree](../cards/030-ancient-tree.md) | 4. Organism | Entity | Living Archive |
| 31 | [Lichen](../cards/031-lichen.md) | 4. Organism | System Relationship | Composite Pioneer |
| 32 | [Kelp](../cards/032-kelp.md) | 4. Organism | Entity | Flexible Builder |
| 33 | [Coral Colony](../cards/033-coral-colony.md) | 4. Organism | System Relationship | Collective Builder |
| 34 | [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) | 4. Organism | Entity | Visible Emergence |
| 35 | [Pollinator](../cards/035-pollinator.md) | 4. Organism | System Relationship | Crossing Messenger |
| 36 | [Keystone Species](../cards/036-keystone-species.md) | 4. Organism | System Relationship | Disproportionate Influence |
| 37 | [Symbiosis](../cards/037-symbiosis.md) | 5. Community and ecosystem | System Relationship | Close Association |
| 38 | [Food Web](../cards/038-food-web.md) | 5. Community and ecosystem | System Relationship | Living Network |
| 39 | [Decomposition](../cards/039-decomposition.md) | 5. Community and ecosystem | Process | Return |
| 40 | [Ecological Succession](../cards/040-ecological-succession.md) | 5. Community and ecosystem | Process | Changing Assembly |
| 41 | [Wetland](../cards/041-wetland.md) | 5. Community and ecosystem | System Relationship | Living Sponge |
| 42 | [Forest Canopy](../cards/042-forest-canopy.md) | 5. Community and ecosystem | System Relationship | Living Roof |
| 43 | [Soil Community](../cards/043-soil-community.md) | 5. Community and ecosystem | System Relationship | Hidden Commons |
| 44 | [Kelp Forest](../cards/044-kelp-forest.md) | 5. Community and ecosystem | System Relationship | Flexible Habitat |
| 45 | [Coral Reef](../cards/045-coral-reef.md) | 5. Community and ecosystem | System Relationship | Accumulated Commons |
| 46 | [Watershed](../cards/046-watershed.md) | 6. Landscape and regional system | System Relationship | Nested Container |
| 47 | [River](../cards/047-river.md) | 6. Landscape and regional system | Entity | Moving Path |
| 48 | [Delta](../cards/048-delta.md) | 6. Landscape and regional system | System Relationship | Distributive Edge |
| 49 | [Estuary](../cards/049-estuary.md) | 6. Landscape and regional system | System Relationship | Mixing Threshold |
| 50 | [Aquifer](../cards/050-aquifer.md) | 6. Landscape and regional system | System Relationship | Hidden Reservoir |
| 51 | [Desert](../cards/051-desert.md) | 6. Landscape and regional system | System Relationship | Sparse Abundance |
| 52 | [Glacier](../cards/052-glacier.md) | 6. Landscape and regional system | Entity | Slow River |
| 53 | [Ocean Current](../cards/053-ocean-current.md) | 6. Landscape and regional system | Process | Planetary Circulation |
| 54 | [Mountain Range](../cards/054-mountain-range.md) | 6. Landscape and regional system | Entity | Raised Boundary |
| 55 | [Fault](../cards/055-fault.md) | 7. Geologic and continental | Entity | Stored Difference |
| 56 | [Earthquake](../cards/056-earthquake.md) | 7. Geologic and continental | Process | Sudden Release |
| 57 | [Tectonic Plate](../cards/057-tectonic-plate.md) | 7. Geologic and continental | Entity | Moving Foundation |
| 58 | [Subduction Zone](../cards/058-subduction-zone.md) | 7. Geologic and continental | Process | Deep Return |
| 59 | [Volcano](../cards/059-volcano.md) | 7. Geologic and continental | Entity | Pressure Outlet |
| 60 | [Mantle Convection](../cards/060-mantle-convection.md) | 7. Geologic and continental | Process | Deep Circulation |
| 61 | [Canyon](../cards/061-canyon.md) | 7. Geologic and continental | Entity | Exposed Record |
| 62 | [Fossil](../cards/062-fossil.md) | 7. Geologic and continental | Entity | Partial Witness |
| 63 | [Mass Extinction](../cards/063-mass-extinction.md) | 7. Geologic and continental | Process | Systemic Loss |
| 64 | [Planet](../cards/064-planet.md) | 8. Planetary and orbital | Entity | World |
| 65 | [Moon](../cards/065-moon.md) | 8. Planetary and orbital | Entity | Orbital Companion |
| 66 | [Orbit](../cards/066-orbit.md) | 8. Planetary and orbital | System Relationship | Falling Around |
| 67 | [Eclipse](../cards/067-eclipse.md) | 8. Planetary and orbital | Process | Alignment |
| 68 | [Comet](../cards/068-comet.md) | 8. Planetary and orbital | Entity | Returning Messenger |
| 69 | [Planetary Ring](../cards/069-planetary-ring.md) | 8. Planetary and orbital | System Relationship | Distributed Boundary |
| 70 | [Magnetosphere](../cards/070-magnetosphere.md) | 8. Planetary and orbital | System Relationship | Responsive Shield |
| 71 | [Atmosphere](../cards/071-atmosphere.md) | 8. Planetary and orbital | System Relationship | Breathing Envelope |
| 72 | [Tide](../cards/072-tide.md) | 8. Planetary and orbital | Process | Relational Pulse |
| 73 | [Star](../cards/073-star.md) | 9. Stellar and cosmic | Entity | Sustained Fire |
| 74 | [Stellar Nursery](../cards/074-stellar-nursery.md) | 9. Stellar and cosmic | System Relationship | Generative Cloud |
| 75 | [Supernova](../cards/075-supernova.md) | 9. Stellar and cosmic | Process | Explosive Distribution |
| 76 | [Neutron Star](../cards/076-neutron-star.md) | 9. Stellar and cosmic | Entity | Compressed Remnant |
| 77 | [Black Hole](../cards/077-black-hole.md) | 9. Stellar and cosmic | Entity | Event Horizon |
| 78 | [Galaxy](../cards/078-galaxy.md) | 9. Stellar and cosmic | System Relationship | Star City |
| 79 | [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 9. Stellar and cosmic | System Relationship | Massive Assembly |
| 80 | [Cosmic Web](../cards/080-cosmic-web.md) | 9. Stellar and cosmic | System Relationship | Largest Network |
| 81 | [Expanding Universe](../cards/081-expanding-universe.md) | 9. Stellar and cosmic | Process | Changing Metric |
