# Scale Index


## 1. Fundamental

- [Photon](../cards/001-photon.md) — **Messenger:** Energy becomes knowable by what carries it.
- [Electron](../cards/002-electron.md) — **Participant:** Relationship changes position, energy, and possibility.
- [Proton](../cards/003-proton.md) — **Anchor:** Identity can arise from a stable count within a changing system.
- [Neutron](../cards/004-neutron.md) — **Quiet Binder:** What seems neutral may be carrying the conditions for stability.
- [Neutrino](../cards/005-neutrino.md) — **Ghost Messenger:** Some information arrives because it barely interferes.
- [Quark](../cards/006-quark.md) — **Constituent:** A part may be real even when it cannot stand alone.
- [Gluon](../cards/007-gluon.md) — **Living Bond:** The bond is not empty space between parts; it has dynamics of its own.
- [Higgs Field](../cards/008-higgs-field.md) — **Enabling Field:** A background condition can shape every movement without choosing the outcome.
- [Gravity](../cards/009-gravity.md) — **Curvature:** Every path is altered by the larger geometry it inhabits.


## 2. Atomic and molecular

- [Hydrogen](../cards/010-hydrogen.md) — **First Element:** Simplicity can become the feedstock of immense complexity.
- [Carbon](../cards/011-carbon.md) — **Versatile Builder:** Range comes from forming many stable relationships, not from standing apart.
- [Oxygen](../cards/012-oxygen.md) — **Intensifier:** What enables life can also accelerate change and damage.
- [Water Molecule](../cards/013-water-molecule.md) — **Relational Solvent:** The capacity to receive and carry depends on molecular shape and bond.
- [Chemical Bond](../cards/014-chemical-bond.md) — **Commitment:** Stable relation is a redistribution of energy and possibility.
- [Crystal Lattice](../cards/015-crystal-lattice.md) — **Repeating Order:** Clarity emerges when a local rule can repeat across distance.
- [Plasma](../cards/016-plasma.md) — **Collective Charge:** When enough parts become mobile, the system behaves as a field.
- [Phase Transition](../cards/017-phase-transition.md) — **Threshold:** Accumulation can produce a new kind of order rather than more of the old.
- [Catalysis](../cards/018-catalysis.md) — **Alternate Path:** Change may become possible when the path changes, not the goal.


## 3. Microscopic and cellular

- [Cell Membrane](../cards/019-cell-membrane.md) — **Selective Boundary:** Life depends on a boundary that exchanges rather than merely excludes.
- [DNA](../cards/020-dna.md) — **Heritable Record:** A record guides possibility only through interpretation in context.
- [Mitochondrion](../cards/021-mitochondrion.md) — **Inner Transformer:** Capacity grows when an old partnership becomes integrated without becoming inert.
- [Bacterium](../cards/022-bacterium.md) — **Metabolic Inventor:** Small lives can transform planetary chemistry through repeated local acts.
- [Archaeon](../cards/023-archaeon.md) — **Deep-Lineage Adapter:** A life can resemble its neighbors while carrying a profoundly different history.
- [Virus](../cards/024-virus.md) — **Borrowed Replicator:** A pattern can propagate by using machinery it does not contain.
- [Spore](../cards/025-spore.md) — **Dormant Possibility:** Waiting is active when a form preserves the capacity to respond.
- [Plankton](../cards/026-plankton.md) — **Drifter Community:** Not controlling direction does not mean lacking influence.
- [Microbiome](../cards/027-microbiome.md) — **Invisible Community:** A visible life is partly governed by communities it cannot see.


## 4. Organism

- [Seed](../cards/028-seed.md) — **Condensed Future:** A beginning carries history, provision, and a test of conditions.
- [Root](../cards/029-root.md) — **Hidden Negotiator:** Grounding is an exchange with what supports you.
- [Ancient Tree](../cards/030-ancient-tree.md) — **Living Archive:** Longevity is a history of repair, disturbance, and continued exchange.
- [Lichen](../cards/031-lichen.md) — **Composite Pioneer:** A new form can emerge from partners without erasing their difference.
- [Kelp](../cards/032-kelp.md) — **Flexible Builder:** Structure can be strong because it yields to motion.
- [Coral Colony](../cards/033-coral-colony.md) — **Collective Builder:** Many small bodies can deposit a structure larger than any one lifetime.
- [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) — **Visible Emergence:** The visible event may be only a brief expression of a larger hidden body.
- [Pollinator](../cards/035-pollinator.md) — **Crossing Messenger:** Movement between separate lives can create a future for both.
- [Keystone Species](../cards/036-keystone-species.md) — **Disproportionate Influence:** Importance is measured by systemic consequence, not size or abundance.


## 5. Community and ecosystem

- [Symbiosis](../cards/037-symbiosis.md) — **Close Association:** Intimacy is a condition; its value depends on what passes between partners.
- [Food Web](../cards/038-food-web.md) — **Living Network:** Every intake and loss is routed through more relationships than the visible pair.
- [Decomposition](../cards/039-decomposition.md) — **Return:** Ending becomes availability through many slow transformations.
- [Ecological Succession](../cards/040-ecological-succession.md) — **Changing Assembly:** Recovery is a sequence of changing conditions, not a return along one guaranteed path.
- [Wetland](../cards/041-wetland.md) — **Living Sponge:** Capacity comes from holding, slowing, and transforming flows at an edge.
- [Forest Canopy](../cards/042-forest-canopy.md) — **Living Roof:** The upper boundary receives force first and distributes what enters below.
- [Soil Community](../cards/043-soil-community.md) — **Hidden Commons:** Fertility is produced by a community of exchanges beneath visible growth.
- [Kelp Forest](../cards/044-kelp-forest.md) — **Flexible Habitat:** A habitat is built through repeated growth and maintained by a web of restraint.
- [Coral Reef](../cards/045-coral-reef.md) — **Accumulated Commons:** A living community can inherit and extend the mineral work of generations.


## 6. Landscape and regional system

- [Watershed](../cards/046-watershed.md) — **Nested Container:** What happens upstream joins a larger shared route.
- [River](../cards/047-river.md) — **Moving Path:** A path persists by continually changing its contents and often its shape.
- [Delta](../cards/048-delta.md) — **Distributive Edge:** Accumulation at an ending can create many beginnings.
- [Estuary](../cards/049-estuary.md) — **Mixing Threshold:** A boundary can be a productive gradient rather than a clean dividing line.
- [Aquifer](../cards/050-aquifer.md) — **Hidden Reservoir:** Stored capacity is shaped by slow recharge and unseen boundaries.
- [Desert](../cards/051-desert.md) — **Sparse Abundance:** Scarcity reorganizes timing, storage, and attention.
- [Glacier](../cards/052-glacier.md) — **Slow River:** What appears still may be moving, recording, and reshaping the world.
- [Ocean Current](../cards/053-ocean-current.md) — **Planetary Circulation:** A system redistributes difference rather than eliminating it.
- [Mountain Range](../cards/054-mountain-range.md) — **Raised Boundary:** Elevation redirects flow while exposing structure to erosion.


## 7. Geologic and continental

- [Fault](../cards/055-fault.md) — **Stored Difference:** A break records motion and may hold strain before it releases.
- [Earthquake](../cards/056-earthquake.md) — **Sudden Release:** A rapid event may be the visible moment of long accumulation.
- [Tectonic Plate](../cards/057-tectonic-plate.md) — **Moving Foundation:** A foundation can be coherent and still be in motion.
- [Subduction Zone](../cards/058-subduction-zone.md) — **Deep Return:** What descends is transformed and may reappear far from where it entered.
- [Volcano](../cards/059-volcano.md) — **Pressure Outlet:** Release can destroy, build, and change atmosphere at once.
- [Mantle Convection](../cards/060-mantle-convection.md) — **Deep Circulation:** Slow internal movement can reorganize the surface across deep time.
- [Canyon](../cards/061-canyon.md) — **Exposed Record:** Removal can reveal sequence and create a path through resistance.
- [Fossil](../cards/062-fossil.md) — **Partial Witness:** The surviving record is evidence shaped by what could be preserved.
- [Mass Extinction](../cards/063-mass-extinction.md) — **Systemic Loss:** When loss crosses scales, the surviving world reorganizes rather than simply refills.


## 8. Planetary and orbital

- [Planet](../cards/064-planet.md) — **World:** A whole is a long negotiation among interior, surface, atmosphere, orbit, and history.
- [Moon](../cards/065-moon.md) — **Orbital Companion:** A companion changes the system through repeated presence, not just proximity.
- [Orbit](../cards/066-orbit.md) — **Falling Around:** Continuity can arise from moving forward while continually yielding to a center.
- [Eclipse](../cards/067-eclipse.md) — **Alignment:** Temporary obscuration can reveal geometry that ordinary light conceals.
- [Comet](../cards/068-comet.md) — **Returning Messenger:** Dormant material becomes expressive when it crosses a threshold of warmth.
- [Planetary Ring](../cards/069-planetary-ring.md) — **Distributed Boundary:** A boundary can be made of countless separate paths held in one pattern.
- [Magnetosphere](../cards/070-magnetosphere.md) — **Responsive Shield:** Protection is an active negotiation with the incoming flow.
- [Atmosphere](../cards/071-atmosphere.md) — **Breathing Envelope:** A containing layer sustains conditions by constantly moving and exchanging.
- [Tide](../cards/072-tide.md) — **Relational Pulse:** A distant relationship can become a local rhythm through the shape of the container.


## 9. Stellar and cosmic

- [Star](../cards/073-star.md) — **Sustained Fire:** A source endures by balancing inward gravity with outward energy transport.
- [Stellar Nursery](../cards/074-stellar-nursery.md) — **Generative Cloud:** Creation begins in uneven density, turbulence, and shared material.
- [Supernova](../cards/075-supernova.md) — **Explosive Distribution:** An ending can disperse forged material and reorganize a vast neighborhood.
- [Neutron Star](../cards/076-neutron-star.md) — **Compressed Remnant:** Extreme compression preserves a core history while creating unfamiliar behavior.
- [Black Hole](../cards/077-black-hole.md) — **Event Horizon:** A threshold marks the limit of return and the limit of an observer's access.
- [Galaxy](../cards/078-galaxy.md) — **Star City:** A whole persists while its members orbit, form, merge, and die.
- [Galaxy Cluster](../cards/079-galaxy-cluster.md) — **Massive Assembly:** A larger container changes trajectories and makes hidden mass legible.
- [Cosmic Web](../cards/080-cosmic-web.md) — **Largest Network:** Sparse beginnings can become a vast pattern through persistent attraction and flow.
- [Expanding Universe](../cards/081-expanding-universe.md) — **Changing Metric:** The container itself can change, altering every distance without a central edge.
