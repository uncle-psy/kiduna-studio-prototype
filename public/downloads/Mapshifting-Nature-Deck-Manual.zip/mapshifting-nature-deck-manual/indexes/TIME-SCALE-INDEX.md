# Time-Scale Index


Time ranges are descriptive and intentionally broad. A card may contain many interacting clocks.

| Card | Scale band | Characteristic time scale |
|---|---|---|
| [Photon](../cards/001-photon.md) | 1. Fundamental | interaction instants to cosmic travel |
| [Electron](../cards/002-electron.md) | 1. Fundamental | quantum interactions to stable atomic histories |
| [Proton](../cards/003-proton.md) | 1. Fundamental | stable beyond current measured limits |
| [Neutron](../cards/004-neutron.md) | 1. Fundamental | minutes when free; often stable in nuclei |
| [Neutrino](../cards/005-neutrino.md) | 1. Fundamental | near-light-speed travel across cosmic time |
| [Quark](../cards/006-quark.md) | 1. Fundamental | interaction instants; confined in hadrons |
| [Gluon](../cards/007-gluon.md) | 1. Fundamental | strong-interaction times |
| [Higgs Field](../cards/008-higgs-field.md) | 1. Fundamental | persistent since the early universe |
| [Gravity](../cards/009-gravity.md) | 1. Fundamental | continuous; shapes cosmic history |
| [Hydrogen](../cards/010-hydrogen.md) | 2. Atomic and molecular | femtosecond reactions to stellar lifetimes |
| [Carbon](../cards/011-carbon.md) | 2. Atomic and molecular | rapid metabolism to multimillion-year storage |
| [Oxygen](../cards/012-oxygen.md) | 2. Atomic and molecular | rapid reactions to geologic oxygenation |
| [Water Molecule](../cards/013-water-molecule.md) | 2. Atomic and molecular | picosecond rearrangements to planetary cycling |
| [Chemical Bond](../cards/014-chemical-bond.md) | 2. Atomic and molecular | femtoseconds to geological persistence |
| [Crystal Lattice](../cards/015-crystal-lattice.md) | 2. Atomic and molecular | rapid nucleation to billion-year persistence |
| [Plasma](../cards/016-plasma.md) | 2. Atomic and molecular | nanoseconds to stellar lifetimes |
| [Phase Transition](../cards/017-phase-transition.md) | 2. Atomic and molecular | abrupt instants to slow geologic transitions |
| [Catalysis](../cards/018-catalysis.md) | 2. Atomic and molecular | femtoseconds to repeated cycles |
| [Cell Membrane](../cards/019-cell-membrane.md) | 3. Microscopic and cellular | microseconds to a cell lifetime |
| [DNA](../cards/020-dna.md) | 3. Microscopic and cellular | seconds for local processes to evolutionary time |
| [Mitochondrion](../cards/021-mitochondrion.md) | 3. Microscopic and cellular | seconds for energy turnover to organismal inheritance |
| [Bacterium](../cards/022-bacterium.md) | 3. Microscopic and cellular | minutes to dormancy lasting far longer |
| [Archaeon](../cards/023-archaeon.md) | 3. Microscopic and cellular | minutes to evolutionary deep time |
| [Virus](../cards/024-virus.md) | 3. Microscopic and cellular | minutes to long evolutionary persistence |
| [Spore](../cards/025-spore.md) | 3. Microscopic and cellular | hours to years or longer |
| [Plankton](../cards/026-plankton.md) | 3. Microscopic and cellular | hours to seasonal and climate cycles |
| [Microbiome](../cards/027-microbiome.md) | 3. Microscopic and cellular | hours to coevolutionary time |
| [Seed](../cards/028-seed.md) | 4. Organism | days to centuries depending on species and storage |
| [Root](../cards/029-root.md) | 4. Organism | days of growth to organismal lifetimes |
| [Ancient Tree](../cards/030-ancient-tree.md) | 4. Organism | centuries to millennia |
| [Lichen](../cards/031-lichen.md) | 4. Organism | years to centuries |
| [Kelp](../cards/032-kelp.md) | 4. Organism | days of rapid growth to multi-year life cycles |
| [Coral Colony](../cards/033-coral-colony.md) | 4. Organism | years to centuries |
| [Fungal Fruiting Body](../cards/034-fungal-fruiting-body.md) | 4. Organism | hours to weeks aboveground; longer mycelial life |
| [Pollinator](../cards/035-pollinator.md) | 4. Organism | seconds per visit to coevolutionary time |
| [Keystone Species](../cards/036-keystone-species.md) | 4. Organism | seasons to evolutionary time |
| [Symbiosis](../cards/037-symbiosis.md) | 5. Community and ecosystem | hours to coevolutionary time |
| [Food Web](../cards/038-food-web.md) | 5. Community and ecosystem | feeding moments to long-term restructuring |
| [Decomposition](../cards/039-decomposition.md) | 5. Community and ecosystem | hours to millennia depending on material and conditions |
| [Ecological Succession](../cards/040-ecological-succession.md) | 5. Community and ecosystem | years to centuries |
| [Wetland](../cards/041-wetland.md) | 5. Community and ecosystem | seasonal pulses to millennial peat accumulation |
| [Forest Canopy](../cards/042-forest-canopy.md) | 5. Community and ecosystem | daily exchange to centuries of development |
| [Soil Community](../cards/043-soil-community.md) | 5. Community and ecosystem | seconds of metabolism to centuries of formation |
| [Kelp Forest](../cards/044-kelp-forest.md) | 5. Community and ecosystem | seasonal cycles to decadal regime shifts |
| [Coral Reef](../cards/045-coral-reef.md) | 5. Community and ecosystem | decades to millennia |
| [Watershed](../cards/046-watershed.md) | 6. Landscape and regional system | storm minutes to geologic reorganization |
| [River](../cards/047-river.md) | 6. Landscape and regional system | seconds of flow to million-year valley evolution |
| [Delta](../cards/048-delta.md) | 6. Landscape and regional system | storms and floods to millennial lobe switching |
| [Estuary](../cards/049-estuary.md) | 6. Landscape and regional system | tidal hours to centuries of geomorphic change |
| [Aquifer](../cards/050-aquifer.md) | 6. Landscape and regional system | days to tens of thousands of years |
| [Desert](../cards/051-desert.md) | 6. Landscape and regional system | flash events to multimillion-year aridity |
| [Glacier](../cards/052-glacier.md) | 6. Landscape and regional system | seasonal mass balance to hundred-thousand-year cycles |
| [Ocean Current](../cards/053-ocean-current.md) | 6. Landscape and regional system | seconds to millennia |
| [Mountain Range](../cards/054-mountain-range.md) | 6. Landscape and regional system | millions to hundreds of millions of years |
| [Fault](../cards/055-fault.md) | 7. Geologic and continental | creep to recurrence over centuries or longer |
| [Earthquake](../cards/056-earthquake.md) | 7. Geologic and continental | seconds to aftershock sequences lasting years |
| [Tectonic Plate](../cards/057-tectonic-plate.md) | 7. Geologic and continental | millions to hundreds of millions of years |
| [Subduction Zone](../cards/058-subduction-zone.md) | 7. Geologic and continental | millions of years with sudden earthquakes |
| [Volcano](../cards/059-volcano.md) | 7. Geologic and continental | seconds of eruption to millions of years of construction |
| [Mantle Convection](../cards/060-mantle-convection.md) | 7. Geologic and continental | millions to billions of years |
| [Canyon](../cards/061-canyon.md) | 7. Geologic and continental | flood events to millions of years |
| [Fossil](../cards/062-fossil.md) | 7. Geologic and continental | thousands to billions of years |
| [Mass Extinction](../cards/063-mass-extinction.md) | 7. Geologic and continental | thousands to millions of years, with far longer recovery |
| [Planet](../cards/064-planet.md) | 8. Planetary and orbital | millions to billions of years |
| [Moon](../cards/065-moon.md) | 8. Planetary and orbital | millions to billions of years |
| [Orbit](../cards/066-orbit.md) | 8. Planetary and orbital | minutes to billions of years |
| [Eclipse](../cards/067-eclipse.md) | 8. Planetary and orbital | minutes within cycles lasting months to centuries |
| [Comet](../cards/068-comet.md) | 8. Planetary and orbital | orbital periods from years to millions of years |
| [Planetary Ring](../cards/069-planetary-ring.md) | 8. Planetary and orbital | years to uncertain millions or longer |
| [Magnetosphere](../cards/070-magnetosphere.md) | 8. Planetary and orbital | seconds to billion-year field evolution |
| [Atmosphere](../cards/071-atmosphere.md) | 8. Planetary and orbital | seconds of turbulence to billion-year evolution |
| [Tide](../cards/072-tide.md) | 8. Planetary and orbital | hours to geological orbital evolution |
| [Star](../cards/073-star.md) | 9. Stellar and cosmic | millions to trillions of years by mass |
| [Stellar Nursery](../cards/074-stellar-nursery.md) | 9. Stellar and cosmic | hundreds of thousands to millions of years |
| [Supernova](../cards/075-supernova.md) | 9. Stellar and cosmic | seconds of explosion to millennia of remnant evolution |
| [Neutron Star](../cards/076-neutron-star.md) | 9. Stellar and cosmic | milliseconds of rotation to billions of years |
| [Black Hole](../cards/077-black-hole.md) | 9. Stellar and cosmic | formation seconds to cosmic lifetimes |
| [Galaxy](../cards/078-galaxy.md) | 9. Stellar and cosmic | hundreds of millions to billions of years |
| [Galaxy Cluster](../cards/079-galaxy-cluster.md) | 9. Stellar and cosmic | billions of years |
| [Cosmic Web](../cards/080-cosmic-web.md) | 9. Stellar and cosmic | cosmic history |
| [Expanding Universe](../cards/081-expanding-universe.md) | 9. Stellar and cosmic | 13.8 billion years and ongoing |
