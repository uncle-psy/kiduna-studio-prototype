# How to Use the Deck


## A basic reading

Frame a question about present conditions, available choices, relationships, or direction. Avoid requests for fixed prediction. Draw a card by any neutral method. Read **What it is** and **How it behaves** before the symbolic sections. Then identify the card's process, gift, wound, and scale shift.

Use the sequence **observe → compare → map → choose → review**:

1. **Observe:** state current facts without interpretation.
2. **Compare:** name the structural similarity offered by the card.
3. **Map:** locate smaller processes, larger systems, flows, boundaries, and delays.
4. **Choose:** select an action that is specific, proportional, reversible when possible, and within authority.
5. **Review:** record what happened; revise the map rather than protecting the reading.

## Entities, processes, and relationships

Read an **entity** card by asking what structure, capacity, or constraint is present. Read a **process** card by asking what is changing, at what rate, and toward what threshold. Read a **system relationship** card by tracing exchanges, boundaries, indirect effects, and dependence. Do not turn every entity into a personality or every process into an omen.

## Combining cards

When two cards appear, do not blend them into vague similarity. Use a sentence with a relationship: “A acts through B,” “A is contained by B,” “A obstructs B,” “A occurs at a smaller scale than B,” or “A and B share a process but differ in function.” The [Relationship Index](indexes/RELATIONSHIP-INDEX.md) and [Natural Cycles](indexes/NATURAL-CYCLES.md) provide tested combinations.

## Reading for another person

Ask consent and agree on the question and boundaries. Invite the participant to interpret first. Offer possibilities rather than declarations. Do not diagnose, interrogate, claim hidden knowledge, pressure disclosure, or use scientific authority to make a metaphor seem compulsory.

A useful facilitator script is: “One pattern this card makes available is ____. Does that fit any part of your experience? What evidence fits, and what does not? Would changing scale alter the question?” The participant may reject the interpretation.

## Consent and ethical limits

Do not read about a third party as if the deck provides access to that person's private thoughts. Do not use the deck to override professional advice, emergency instructions, or the agency of another person. Avoid high-stakes binary answers. When power differences exist—manager and employee, clinician and patient, teacher and student—make refusal safe and explicit.

## Journaling and observation

Date the reading. Record the question, card, observed facts, metaphor, gift, wound, smaller scale, larger system, action, and review date. Keep “prediction” separate from “observation.” A deck becomes more accountable when its interpretations can be revisited and corrected.

## Working with uncertainty

Use the card's Scientific uncertainty section as a model. State what you know, what you infer, what you do not know, and what evidence would change the map. Uncertainty can guide information gathering; it should not be filled with certainty borrowed from symbolism.
