# The Tao — Enamel Oracle System

> The Tao is not a set of answers. It is the pattern through which opposites continually become one another.

This production manuscript contains **75 unique tiles across 77 family memberships**. Water and Fire each belong both to the Great Polarity and to the Five Phases. Every tile has a complete meaning model, an enamel direction, and at least four typed relationships.

## Begin here

- [Complete manual](MANUAL.md)
- [Visual system](VISUAL-SYSTEM.md)
- [Relationship graph guide](RELATIONSHIP-GRAPH.md)
- [Sources and interpretation boundary](SOURCES.md)
- [Machine-readable graph](data/graph.json) · [Graphviz graph](data/graph.dot)
- [Visual proof sheet](assets/tao-enamel-proof-sheet.png)

## System inventory

## The Source

| No. | Tile | Essence |
|---:|---|---|
| 001 | [Tao (Dao)](cards/001-tao.md) | The way before definition: source, course, and unpossessed order. |
| 002 | [Wu — Not-Having](cards/002-wu.md) | Absence as an active condition: what is not possessed, imposed, or occupied. |
| 003 | [Being (You)](cards/003-being.md) | Manifest presence: the named, formed, available face of reality. |
| 004 | [Non-Being (Wu)](cards/004-non-being.md) | The unmanifest pole from which forms become possible and to which they cease. |
| 005 | [One](cards/005-one.md) | Undivided coherence before polarity, not sameness imposed upon difference. |
| 006 | [Two](cards/006-two.md) | Differentiation through which relation, polarity, and change become visible. |
| 007 | [Ten Thousand Things](cards/007-ten-thousand-things.md) | The inexhaustible multiplicity of beings, events, names, and relations. |
| 008 | [Return](cards/008-return.md) | Reversal is the movement of the Way: outward unfolding bends back toward root. |
| 009 | [Emptiness](cards/009-emptiness.md) | Usable capacity created by what is not filled. |
| 010 | [Mystery (Xuan)](cards/010-mystery.md) | The shared depth where named and unnamed remain one source under different aspects. |

## The Great Polarity

| No. | Tile | Essence |
|---:|---|---|
| 011 | [Yin](cards/011-yin.md) | The receptive, inward, cooling, darkening tendency within change. |
| 012 | [Yang](cards/012-yang.md) | The active, outward, warming, brightening tendency within change. |
| 013 | [Stillness](cards/013-stillness.md) | The capacity to cease motion long enough for pattern and limit to appear. |
| 014 | [Movement](cards/014-movement.md) | The activation through which conditions meet, separate, and transform. |
| 015 | [Receptivity](cards/015-receptivity.md) | The strength to be shaped by contact without surrendering discernment. |
| 016 | [Initiative](cards/016-initiative.md) | The force that begins, names, or enters before conditions organize themselves. |
| 017 | [Soft](cards/017-soft.md) | What yields, bends, or enters without losing continuity. |
| 018 | [Hard](cards/018-hard.md) | What holds shape, resists pressure, cuts, or bears weight. |
| 019 | [Dark](cards/019-dark.md) | The concealed, cooling field where forms withdraw from immediate view. |
| 020 | [Light](cards/020-light.md) | The revealing, warming field in which distinctions become visible. |
| 021 | [Valley](cards/021-valley.md) | Low receptive form that gathers flows, relation, and fertility. |
| 022 | [Mountain](cards/022-mountain.md) | Concentrated stillness: boundary, endurance, stopping, and obstructive mass. |
| 024 | [Fire](cards/024-fire.md) | Radiant transformation that warms, reveals, attaches, consumes, and spreads. |
| 027 | [Water](cards/027-water.md) | Yielding power that descends, nourishes, seeks the low place, and reshapes resistance. |

## The Five Phases

| No. | Tile | Essence |
|---:|---|---|
| 023 | [Wood (Mu)](cards/023-wood.md) | Rising, branching life that seeks room, direction, and flexible extension. |
| 024 | [Fire](cards/024-fire.md) | Radiant transformation that warms, reveals, attaches, consumes, and spreads. |
| 025 | [Earth (Tu)](cards/025-earth.md) | Centering transformation that receives, composts, nourishes, and redistributes. |
| 026 | [Metal (Jin)](cards/026-metal.md) | Contracting clarity that forms boundaries, condenses value, and releases what is finished. |
| 027 | [Water](cards/027-water.md) | Yielding power that descends, nourishes, seeks the low place, and reshapes resistance. |

## The Eight Trigrams

| No. | Tile | Essence |
|---:|---|---|
| 028 | [Qian — Heaven](cards/028-qian.md) | Unbroken creative force: initiating, enduring, and responsible for what it sets in motion. |
| 029 | [Kun — Earth](cards/029-kun.md) | Broken receptive force: bearing, nourishing, and completing without claiming authorship. |
| 030 | [Zhen — Thunder](cards/030-zhen.md) | Arousing shock: the first decisive movement that breaks stillness. |
| 031 | [Xun — Wind / Wood](cards/031-xun.md) | Gentle penetration: influence that enters by continuity, adaptation, and repeated contact. |
| 032 | [Kan — Water](cards/032-kan.md) | A true current carried through danger: depth, ravine, repetition, and practiced passage. |
| 033 | [Li — Fire](cards/033-li.md) | Illumination that depends on what it clings to: radiance, discernment, and attachment. |
| 034 | [Gen — Mountain](cards/034-gen.md) | Keeping still at the proper limit: stopping, boundary, completion, and renewed beginning. |
| 035 | [Dui — Lake](cards/035-dui.md) | Joyous exchange at an open surface: pleasure, speech, reflection, and mutual influence. |

## The Living Patterns

| No. | Tile | Essence |
|---:|---|---|
| 036 | [Wu Wei](cards/036-wu-wei.md) | Action free of coercive strain: responding so closely to conditions that force is not wasted. |
| 037 | [De — Immanent Power](cards/037-de.md) | The particular efficacy by which a being follows the Way as itself. |
| 038 | [Ziran — Self-So](cards/038-ziran.md) | The spontaneous suchness by which things unfold from their own conditions, not an external mold. |
| 039 | [Pu — Simplicity](cards/039-pu.md) | Original simplicity: unadorned sufficiency before value is inflated by display and division. |
| 040 | [Uncarved Block](cards/040-uncarved-block.md) | Potential before imposed use: a form not yet narrowed to one identity or function. |
| 041 | [Empty Vessel](cards/041-empty-vessel.md) | Usefulness created by the shaped absence within a form. |
| 042 | [Valley Spirit](cards/042-valley-spirit.md) | Receptive generativity that remains low, open, and inexhaustibly available. |
| 043 | [Returning](cards/043-returning.md) | The lived act of noticing deviation and turning back before distance becomes destiny. |
| 044 | [Yielding](cards/044-yielding.md) | Responsive giving-way that preserves continuity while redirecting force. |
| 045 | [Flow](cards/045-flow.md) | Continuous responsive movement through changing constraints. |
| 046 | [Still Point](cards/046-still-point.md) | A relative center of quiet within motion from which changing directions can be perceived. |
| 047 | [Center](cards/047-center.md) | The relational middle where forces can be integrated without being flattened. |
| 048 | [Threshold](cards/048-threshold.md) | The charged interval where one condition has ended but another is not yet established. |
| 049 | [Root](cards/049-root.md) | Hidden anchoring through reciprocal contact with the ground that feeds and resists. |
| 050 | [Branch](cards/050-branch.md) | Differentiated reach: one source exploring several directions without ceasing to be related. |
| 051 | [Gate](cards/051-gate.md) | A selective opening that regulates passage between fields. |
| 052 | [Breath (Qi image)](cards/052-breath.md) | Rhythmic exchange that joins inner and outer without making them identical. |
| 053 | [River](cards/053-river.md) | A path made by moving relation: source, bank, obstacle, confluence, and destination continually reshape one another. |
| 054 | [Rain](cards/054-rain.md) | Distributed descent that nourishes, reveals saturation, and links sky to ground. |
| 055 | [Cloud](cards/055-cloud.md) | Form held temporarily in suspension: gathering, obscuring, carrying, and preparing release. |
| 056 | [Mist](cards/056-mist.md) | Partial visibility that softens fixed edges and makes distance uncertain. |
| 057 | [Bamboo](cards/057-bamboo.md) | Hollow-jointed resilience: flexible because strength is segmented and the center is open. |
| 058 | [Pine](cards/058-pine.md) | Endurance through seasons: conserving life without pretending winter is summer. |
| 059 | [Crane](cards/059-crane.md) | Measured elevation: patient stillness that becomes precise movement and long passage. |
| 060 | [Turtle](cards/060-turtle.md) | Protected longevity: carrying a boundary while moving at the pace continuity requires. |
| 061 | [Dragon](cards/061-dragon.md) | Latent transformative potency moving between depth, cloud, rain, and emergence. |
| 062 | [Tiger](cards/062-tiger.md) | Focused boundary power: embodied presence, decisive protection, and dangerous appetite. |
| 063 | [Moon](cards/063-moon.md) | Borrowed light and rhythmic change: visibility that waxes, wanes, and depends on relation. |
| 064 | [Sun](cards/064-sun.md) | Direct radiance that reveals, warms, organizes rhythm, and can scorch. |
| 065 | [Star](cards/065-star.md) | Distant orientation: a small steady relation that helps position without dictating the path. |
| 066 | [Seed](cards/066-seed.md) | Concentrated future held in a protected form, dependent on conditions it cannot command. |
| 067 | [Sprout](cards/067-sprout.md) | Vulnerable emergence: life crossing from protected potential into exposed growth. |
| 068 | [Blossom](cards/068-blossom.md) | Brief visible opening that invites exchange and cannot be kept. |
| 069 | [Fruit](cards/069-fruit.md) | Ripened consequence: nourishment and seed carried together at the end of a growth cycle. |
| 070 | [Decay](cards/070-decay.md) | Form loosening into smaller relations so stored material can re-enter the world. |
| 071 | [Compost](cards/071-compost.md) | Collaborative transformation of discarded matter into fertile, altered ground. |
| 072 | [Silence](cards/072-silence.md) | An interval without imposed speech in which subtler signals can appear. |
| 073 | [Sound](cards/073-sound.md) | Vibration made shareable: expression traveling through a medium and altering what receives it. |
| 074 | [Shadow](cards/074-shadow.md) | Evidence of relation between light, form, and position: neither substance nor mere absence. |
| 075 | [Mirror](cards/075-mirror.md) | Reflective relation that reveals a view, reverses it, and never contains the whole thing reflected. |

## Edition boundary

This is a contemporary reflective oracle informed by early Chinese philosophical texts, the Changes tradition, and later correlative Five Phase systems. It does **not** claim to be an ancient historical deck, a replacement for the Yijing, or a complete representation of religious Daoism. Divinatory text is clearly authored synthesis.
