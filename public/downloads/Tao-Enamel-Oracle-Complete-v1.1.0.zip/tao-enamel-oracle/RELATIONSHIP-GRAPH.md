# Relationship Graph

The full graph is available as [JSON](data/graph.json), separate [nodes](data/nodes.json) and [edges](data/edges.json), and [Graphviz DOT](data/graph.dot). It contains **75 nodes** and **302 authored edges**. Every node has at least four outgoing typed relations.

## Backbone

```text
Tao → One → Two → Ten Thousand Things → Tao
              ↙                 ↘
           Yin ⇄ Yang       form ⇄ openness

Generating: Wood → Fire → Earth → Metal → Water → Wood
Controlling: Wood → Earth → Water → Fire → Metal → Wood

Trigram pairs:
Qian ⇄ Kun · Zhen ⇄ Xun · Kan ⇄ Li · Gen ⇄ Dui
```

## Reading rule

Do not treat an edge as a permanent universal equivalence. It is a designed relation within this oracle. Directed edges describe a useful movement; undirected complementary, balancing, and resonance edges invite reading in both directions even when stored once.
