# Tao Enamel Proof Sheet — Final Generation Prompt

**Tool:** OpenAI built-in image generation  
**Use case:** stylized-concept  
**Role:** visual art-direction proof; not final individual production faces

## Prompt

Create a museum-quality 3 by 3 arrangement of nine separate square oracle tiles with softly rounded corners, seen nearly straight-on on a quiet blackened-metal surface.

The nine symbolic tiles are, in reading order:

1. **Tao** — almost-empty blue-black enamel with a barely visible circular current and one tiny open gold thread, no object.
2. **Wu Wei** — one supple branch bends over a low silver-blue stream as a fallen leaf passes around a stone.
3. **Empty Vessel** — a simple vessel whose unfilled interior is the visual center.
4. **Water** — a thin silver-blue current at the lowest edge slowly reshaping dark stone.
5. **Mountain** — one asymmetrical dark-jade mass rising from cloud-white mist.
6. **Return** — a seasonal river spiral turning toward an unmarked source.
7. **Qian / Heaven** — exactly three unbroken horizontal gold lines generate a spare circular heaven current.
8. **Kun / Earth** — exactly three broken horizontal lines generate terraced earth and a receptive field.
9. **Wood Phase** — blue-green root and sprout rising eastward, with a subtle ember at its tip suggesting transformation toward fire.

**Style and medium:** Hand-fired vitreous enamel and fine cloisonné on antique brass, blackened silver, jade, cinnabar, moon-white, and deep mineral-blue; ancient Chinese material intelligence; restrained contemporary museum-object photography; symbolic rather than illustrative; elegant linework, meaningful negative space, slight hand-made irregularity.

**Composition:** Each tile fully visible and uncropped; equal tile size; generous breathing room; subtle asymmetry inside each tile; no ornate universal frame; deepest tiles nearly empty; coherent family resemblance without making every tile identical.

**Lighting and mood:** Soft raking gallery light revealing enamel depth and metal edges; luminous but not glossy; ancient, refined, tactile, timeless, contemplative.

**Palette:** Blue-black void, cloud white, moon silver, antique gold, dark jade, river green, deep blue, restrained cinnabar.

**Text:** No words, lettering, captions, or numbers.

**Constraints:** Preserve the exact 3-by-3 grid and nine separate square rounded-corner tiles. Qian has exactly three unbroken horizontal lines. Kun has exactly three broken horizontal lines. Use void as a material. Complementary forces must not read as moral good/evil. The imagery must feel grown rather than mechanically composed.

**Avoid:** Generic New Age imagery, yin-yang logos, Buddha figures, temples, pagodas, dragons used as decoration, faux calligraphy, random Chinese characters, tarot conventions, ornate Victorian borders, photoreal landscapes, neon, plastic gloss, excessive symmetry, clutter, readable text, signatures, and watermarks.
