---
number: 045
id: L-045
name: "Flow"
slug: flow
families: ["The Living Patterns"]
status: complete
---

# Flow

> Continuous responsive movement through changing constraints.

## Essence

Continuous responsive movement through changing constraints.

## Image

Three river-green currents braid, separate around stone, and rejoin without symmetry.

## Movement

Movement adjusts to contour while maintaining connection.

## Gift

Continuity, adaptation, and circulation.

## Shadow

Flow becomes aimlessness, avoidance of commitment, or romanticized ease.

## Excess

Speed and volume erase banks and destinations.

## Deficiency

Blockage prevents exchange and causes pressure or decay.

## Return

Restore the channel, bank, and rhythm; then let movement resume.

## Divination

Follow what is genuinely moving, but distinguish current from drift.

## Question

What carries continuity through these changing conditions?

## Action

Clear one blockage and mark one bank.

## Relations

- **Supported by:** [Wu Wei](./036-wu-wei.md)
- **Expresses:** [Water](./027-water.md)
- **Supports:** [River](./053-river.md)
- **Balances:** [Still Point](./046-still-point.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** Three river-green currents braid, separate around stone, and rejoin without symmetry.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
