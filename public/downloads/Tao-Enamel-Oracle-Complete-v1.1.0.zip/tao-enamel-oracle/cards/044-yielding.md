---
number: 044
id: L-044
name: "Yielding"
slug: yielding
families: ["The Living Patterns"]
status: complete
---

# Yielding

> Responsive giving-way that preserves continuity while redirecting force.

## Essence

Responsive giving-way that preserves continuity while redirecting force.

## Image

A bamboo arc bends under rain and clears a path for the descending water.

## Movement

Pressure passes through a flexible form and changes its angle.

## Gift

Resilience, diplomacy, and survival without direct contest.

## Shadow

Yielding becomes appeasement, collapse, or fear of necessary conflict.

## Excess

Everything is conceded until no integrity remains.

## Deficiency

Resistance turns every contact into damage.

## Return

Yield in method, not in the essential relation or boundary.

## Divination

A softer response may carry more strength. Identify what must remain intact while the form changes.

## Question

What can give way without being given up?

## Action

Change posture or sequence; keep the essential boundary.

## Relations

- **Supported by:** [Soft](./017-soft.md)
- **Supports:** [Flow](./045-flow.md)
- **Resonates with:** [Bamboo](./057-bamboo.md)
- **Balances:** [Hard](./018-hard.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A bamboo arc bends under rain and clears a path for the descending water.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
