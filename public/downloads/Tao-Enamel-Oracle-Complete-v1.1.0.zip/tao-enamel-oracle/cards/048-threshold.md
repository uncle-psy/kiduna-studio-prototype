---
number: 048
id: L-048
name: "Threshold"
slug: threshold
families: ["The Living Patterns"]
status: complete
---

# Threshold

> The charged interval where one condition has ended but another is not yet established.

## Essence

The charged interval where one condition has ended but another is not yet established.

## Image

Two metal fields almost meet; mist crosses the narrow seam before any figure does.

## Movement

Identity and rule loosen during passage.

## Gift

Choice, initiation, and transformed relation.

## Shadow

Liminality is prolonged to avoid commitment or romanticized as inherently profound.

## Excess

Repeated crossing destabilizes all shelter and continuity.

## Deficiency

Fear keeps the old state intact after it has ceased to fit.

## Return

Mark the crossing, carry only what belongs, and accept altered conditions.

## Divination

You are between forms. Do not demand the certainties of either side.

## Question

What must be left behind for the crossing to be real?

## Action

Name the before and after; make one crossing act.

## Relations

- **Opened by:** [Uncarved Block](./040-uncarved-block.md)
- **Opens:** [Gate](./051-gate.md)
- **Transforms into:** [Sprout](./067-sprout.md)
- **Balances:** [Root](./049-root.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** Two metal fields almost meet; mist crosses the narrow seam before any figure does.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
