---
number: 068
id: L-068
name: "Blossom"
slug: blossom
families: ["The Living Patterns"]
status: complete
---

# Blossom

> Brief visible opening that invites exchange and cannot be kept.

## Essence

Brief visible opening that invites exchange and cannot be kept.

## Image

An asymmetrical pale blossom opens on one branch; a few petals already loosen.

## Movement

Accumulated growth becomes attraction, signaling, and exchange.

## Gift

Beauty, invitation, recognition, and timely openness.

## Shadow

Appearance is confused with maturity, worth, or guaranteed fruit.

## Excess

Display consumes the plant and seeks permanent spring.

## Deficiency

Closedness prevents exchange and recognition.

## Return

Open for the season; release the bloom when its work is done.

## Divination

A visible opening can invite relation, but it is a moment, not the final result.

## Question

What is ready to be shown without being mistaken for completion?

## Action

Share the work at its present stage; name what is still becoming.

## Relations

- **Arises from:** [Sprout](./067-sprout.md)
- **Supported by:** [Branch](./050-branch.md)
- **Transforms into:** [Fruit](./069-fruit.md)
- **Balances:** [Decay](./070-decay.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** An asymmetrical pale blossom opens on one branch; a few petals already loosen.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
