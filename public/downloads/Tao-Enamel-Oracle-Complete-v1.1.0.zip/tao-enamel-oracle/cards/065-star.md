---
number: 065
id: L-065
name: "Star"
slug: star
families: ["The Living Patterns"]
status: complete
---

# Star

> Distant orientation: a small steady relation that helps position without dictating the path.

## Essence

Distant orientation: a small steady relation that helps position without dictating the path.

## Image

One pale-gold star sits in a large blue-black field; three faint points form an incomplete relation.

## Movement

A remote signal becomes a reference across distance and time.

## Gift

Orientation, perspective, and long continuity.

## Shadow

Guidance becomes destiny, abstraction, or escape from local evidence.

## Excess

The distant ideal overrides terrain and present need.

## Deficiency

Without any reference, local motion loses direction.

## Return

Use the star to orient; use the ground to travel.

## Divination

A long-range value can guide the next step, but it cannot replace local conditions.

## Question

What distant reference helps me orient without controlling the route?

## Action

Name one guiding value and one ground fact.

## Relations

- **Supports:** [Qian — Heaven](./028-qian.md)
- **Resonates with:** [Crane](./059-crane.md)
- **Balances:** [Root](./049-root.md)
- **Supports:** [Seed](./066-seed.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** One pale-gold star sits in a large blue-black field; three faint points form an incomplete relation.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
