---
number: 010
id: S-010
name: "Mystery (Xuan)"
slug: mystery
families: ["The Source"]
status: complete
---

# Mystery (Xuan)

> The shared depth where named and unnamed remain one source under different aspects.

## Essence

The shared depth where named and unnamed remain one source under different aspects.

## Image

Two dark mineral glazes meet at a gate whose interior is deeper than either field.

## Movement

Knowledge reaches its honest edge and becomes attentive.

## Gift

Wonder disciplined by humility.

## Shadow

Mystery is used to conceal weak claims or claim secret authority.

## Excess

Obscurity becomes prestige and inquiry is discouraged.

## Deficiency

Only the measurable is permitted to matter.

## Return

Mark what is observed, inferred, and unknown; keep all three in relation.

## Divination

Do not force closure. The unknown is active, but it is not permission to invent certainty.

## Question

Can I remain exact at the edge of what I cannot know?

## Action

Write three lines: known, inferred, unknown.

## Relations

- **Held by:** [Tao (Dao)](./001-tao.md)
- **Opens:** [Gate](./051-gate.md)
- **Supports:** [Mist](./056-mist.md)
- **Balances:** [Light](./020-light.md)

## Enamel direction

- **Palette:** blue-black void, cloud white, moon silver, one restrained gold thread.
- **Composition:** Two dark mineral glazes meet at a gate whose interior is deeper than either field.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
