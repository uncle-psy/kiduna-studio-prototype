---
number: 018
id: P-018
name: "Hard"
slug: hard
families: ["The Great Polarity"]
status: complete
---

# Hard

> What holds shape, resists pressure, cuts, or bears weight.

## Essence

What holds shape, resists pressure, cuts, or bears weight.

## Image

A blackened-silver ridge interrupts a flowing green line and gives it a new course.

## Movement

A boundary concentrates force and establishes form.

## Gift

Protection, precision, and endurance.

## Shadow

Strength becomes brittleness, domination, or injury.

## Excess

Resistance continues after its purpose is gone.

## Deficiency

No structure survives contact or carries weight.

## Return

Keep the necessary edge; soften the attachment to its form.

## Divination

A real limit matters here. The question is whether it protects life or merely resists change.

## Question

What must hold, and what may bend around it?

## Action

State one boundary in plain language.

## Relations

- **Complements:** [Soft](./017-soft.md)
- **Supports:** [Mountain](./022-mountain.md)
- **Expresses:** [Metal (Jin)](./026-metal.md)
- **Balances:** [Yielding](./044-yielding.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** A blackened-silver ridge interrupts a flowing green line and gives it a new course.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
