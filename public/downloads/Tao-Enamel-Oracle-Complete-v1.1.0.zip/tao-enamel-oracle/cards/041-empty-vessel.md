---
number: 041
id: L-041
name: "Empty Vessel"
slug: empty-vessel
families: ["The Living Patterns"]
status: complete
---

# Empty Vessel

> Usefulness created by the shaped absence within a form.

## Essence

Usefulness created by the shaped absence within a form.

## Image

A dark ceramic-enamel vessel is defined almost entirely by its luminous empty interior.

## Movement

A boundary holds open space so something may enter, mix, or be poured out.

## Gift

Capacity, hospitality, and renewal.

## Shadow

Emptiness becomes vacancy, self-negation, or ornamental minimalism.

## Excess

The vessel is endlessly emptied and never nourished.

## Deficiency

Fullness prevents use, exchange, and transformation.

## Return

Empty with purpose; keep the vessel sound and available.

## Divination

Capacity matters more than additional content. Check the rim as carefully as the space.

## Question

What must leave, and what boundary must remain?

## Action

Pour out one stale content; repair one edge.

## Relations

- **Expresses:** [Emptiness](./009-emptiness.md)
- **Supported by:** [Wu — Not-Having](./002-wu.md)
- **Supports:** [Receptivity](./015-receptivity.md)
- **Balances:** [Ten Thousand Things](./007-ten-thousand-things.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A dark ceramic-enamel vessel is defined almost entirely by its luminous empty interior.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
