---
number: 066
id: L-066
name: "Seed"
slug: seed
families: ["The Living Patterns"]
status: complete
---

# Seed

> Concentrated future held in a protected form, dependent on conditions it cannot command.

## Essence

Concentrated future held in a protected form, dependent on conditions it cannot command.

## Image

A small dark seed with a gold seam rests in open earth beneath an absent sun.

## Movement

Potential waits, absorbs, and eventually breaks its own enclosure.

## Gift

Readiness, inheritance, patience, and compact possibility.

## Shadow

Potential is romanticized without regard for soil, season, or viability.

## Excess

Protection prevents germination; expectation burdens the future form.

## Deficiency

No reserve or coherent possibility survives the present.

## Return

Test conditions; open only when moisture, warmth, and space can support emergence.

## Divination

Potential is real but conditional. Attend to the field, not only the promise.

## Question

Which condition—not intention—is missing for germination?

## Action

Provide one necessary condition and stop handling the seed.

## Relations

- **Supported by:** [Uncarved Block](./040-uncarved-block.md)
- **Supported by:** [Root](./049-root.md)
- **Transforms into:** [Sprout](./067-sprout.md)
- **Balances:** [Fruit](./069-fruit.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A small dark seed with a gold seam rests in open earth beneath an absent sun.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
