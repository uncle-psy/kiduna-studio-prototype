---
number: 043
id: L-043
name: "Returning"
slug: returning
families: ["The Living Patterns"]
status: complete
---

# Returning

> The lived act of noticing deviation and turning back before distance becomes destiny.

## Essence

The lived act of noticing deviation and turning back before distance becomes destiny.

## Image

A single footprint turns beside a river bend; the earlier track fades rather than reverses exactly.

## Movement

Attention recognizes drift and changes course.

## Gift

Correction, humility, and renewed contact.

## Shadow

Return becomes self-punishment, regression, or obsessive checking.

## Excess

Constant reversal prevents any path from developing.

## Deficiency

Pride keeps a mistaken course in motion.

## Return

Turn toward the root with new information; do not reenact the past.

## Divination

A modest correction now is wiser than defending momentum.

## Question

What signal have I already received that asks me to turn?

## Action

Make one visible course correction today.

## Relations

- **Expresses:** [Return](./008-return.md)
- **Supports:** [Root](./049-root.md)
- **Balances:** [Movement](./014-movement.md)
- **Transforms into:** [Threshold](./048-threshold.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A single footprint turns beside a river bend; the earlier track fades rather than reverses exactly.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
