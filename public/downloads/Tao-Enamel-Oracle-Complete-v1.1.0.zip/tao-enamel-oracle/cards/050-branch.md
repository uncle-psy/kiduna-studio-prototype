---
number: 050
id: L-050
name: "Branch"
slug: branch
families: ["The Living Patterns"]
status: complete
---

# Branch

> Differentiated reach: one source exploring several directions without ceasing to be related.

## Essence

Differentiated reach: one source exploring several directions without ceasing to be related.

## Image

A jade-gold branch divides irregularly; one twig ends, two continue beyond the frame.

## Movement

Rooted continuity tests multiple paths.

## Gift

Experiment, distribution, and plural possibility.

## Shadow

Branching becomes distraction, hierarchy, or unchecked proliferation.

## Excess

Too many extensions starve the trunk and one another.

## Deficiency

A single route bears all risk and cannot adapt.

## Return

Prune by vitality and relation, not by symmetry.

## Divination

Several paths are possible; not all require equal investment.

## Question

Which branch is alive, and which only preserves an option?

## Action

Feed one branch, prune one, leave one to observe.

## Relations

- **Arises from:** [Root](./049-root.md)
- **Supports:** [Blossom](./068-blossom.md)
- **Balances:** [Center](./047-center.md)
- **Expresses:** [Ten Thousand Things](./007-ten-thousand-things.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A jade-gold branch divides irregularly; one twig ends, two continue beyond the frame.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
