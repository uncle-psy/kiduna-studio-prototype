---
number: 053
id: L-053
name: "River"
slug: river
families: ["The Living Patterns"]
status: complete
---

# River

> A path made by moving relation: source, bank, obstacle, confluence, and destination continually reshape one another.

## Essence

A path made by moving relation: source, bank, obstacle, confluence, and destination continually reshape one another.

## Image

A silver-blue river enters from one corner, divides around stone, joins rain, and exits lower than it began.

## Movement

Flow follows gravity while erosion and sediment remake the route.

## Gift

Continuity, adaptation, connection, and carried memory.

## Shadow

The current carries contamination, cuts banks, or makes inevitability of its own habit.

## Excess

Flooding erases distinctions and downstream choice.

## Deficiency

Disconnection from source leaves a dry channel and stranded banks.

## Return

Restore source, banks, and confluences; release what should not be carried.

## Divination

Read the whole course, especially upstream causes and downstream receivers.

## Question

What am I carrying that belongs upstream—or must be released before it travels farther?

## Action

Trace one consequence from source to downstream edge.

## Relations

- **Arises from:** [Water](./027-water.md)
- **Supported by:** [Flow](./045-flow.md)
- **Receives:** [Rain](./054-rain.md)
- **Transforms into:** [Mist](./056-mist.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A silver-blue river enters from one corner, divides around stone, joins rain, and exits lower than it began.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
