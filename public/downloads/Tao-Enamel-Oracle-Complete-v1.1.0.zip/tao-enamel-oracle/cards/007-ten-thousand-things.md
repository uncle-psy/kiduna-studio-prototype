---
number: 007
id: S-007
name: "Ten Thousand Things"
slug: ten-thousand-things
families: ["The Source"]
status: complete
---

# Ten Thousand Things

> The inexhaustible multiplicity of beings, events, names, and relations.

## Essence

The inexhaustible multiplicity of beings, events, names, and relations.

## Image

A sparse constellation of unlike enamel seeds expands beyond the tile edges.

## Movement

Differentiation proliferates into a living world.

## Gift

Diversity, surprise, and innumerable pathways.

## Shadow

Multiplicity becomes noise, inventory, or consumption.

## Excess

More options destroy attention and consequence.

## Deficiency

Complexity is denied in favor of one elegant abstraction.

## Return

Trace one relation back toward its source and forward toward its effects.

## Divination

Many conditions are interacting; simplify the next act, not the world.

## Question

Which relation matters now among all that could be followed?

## Action

Choose one thread and follow it faithfully.

## Relations

- **Arises from:** [Two](./006-two.md)
- **Returns to:** [Tao (Dao)](./001-tao.md)
- **Supports:** [Branch](./050-branch.md)
- **Expresses:** [Ziran — Self-So](./038-ziran.md)

## Enamel direction

- **Palette:** blue-black void, cloud white, moon silver, one restrained gold thread.
- **Composition:** A sparse constellation of unlike enamel seeds expands beyond the tile edges.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
