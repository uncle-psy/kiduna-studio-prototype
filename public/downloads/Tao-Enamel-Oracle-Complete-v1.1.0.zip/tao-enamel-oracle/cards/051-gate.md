---
number: 051
id: L-051
name: "Gate"
slug: gate
families: ["The Living Patterns"]
status: complete
---

# Gate

> A selective opening that regulates passage between fields.

## Essence

A selective opening that regulates passage between fields.

## Image

Two dark brass leaves form an off-center opening filled with mist, not a door.

## Movement

Boundary becomes passage under particular conditions.

## Gift

Access, discernment, protection, and transition.

## Shadow

Guardianship becomes exclusion, secrecy, or control of others’ movement.

## Excess

Too many conditions make passage impossible.

## Deficiency

No threshold protects context, privacy, or sequence.

## Return

Open for the fitting passage; close without contempt when conditions fail.

## Divination

The issue is not simply open or closed, but who or what may pass, when, and why.

## Question

What condition makes this passage fitting?

## Action

Write one clear entry condition and one clear refusal.

## Relations

- **Opened by:** [Mystery (Xuan)](./010-mystery.md)
- **Supported by:** [Threshold](./048-threshold.md)
- **Supports:** [Breath (Qi image)](./052-breath.md)
- **Balances:** [Empty Vessel](./041-empty-vessel.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** Two dark brass leaves form an off-center opening filled with mist, not a door.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
