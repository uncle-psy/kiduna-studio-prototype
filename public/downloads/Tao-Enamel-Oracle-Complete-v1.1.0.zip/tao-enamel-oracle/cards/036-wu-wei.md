---
number: 036
id: L-036
name: "Wu Wei"
slug: wu-wei
families: ["The Living Patterns"]
status: complete
---

# Wu Wei

> Action free of coercive strain: responding so closely to conditions that force is not wasted.

## Essence

Action free of coercive strain: responding so closely to conditions that force is not wasted.

## Image

A branch bends over running water while a leaf passes around a stone.

## Movement

Intention releases its grip and joins an existing current.

## Gift

Efficacy, ease, timing, and non-contention.

## Shadow

Non-forcing is confused with passivity, neglect, or spiritual superiority.

## Excess

Endless optimization tries to manufacture effortlessness.

## Deficiency

Nothing is done even when relationship calls for action.

## Return

Find what is already moving; act at the point of least unnecessary resistance.

## Divination

You may be forcing what cannot respond—or overlooking the action that fits naturally.

## Question

Where am I adding strain that the situation does not require?

## Action

Stop one forced motion and join one existing current.

## Relations

- **Expresses:** [Tao (Dao)](./001-tao.md)
- **Supported by:** [Ziran — Self-So](./038-ziran.md)
- **Supports:** [Flow](./045-flow.md)
- **Balances:** [Initiative](./016-initiative.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A branch bends over running water while a leaf passes around a stone.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
