---
number: 019
id: P-019
name: "Dark"
slug: dark
families: ["The Great Polarity"]
status: complete
---

# Dark

> The concealed, cooling field where forms withdraw from immediate view.

## Essence

The concealed, cooling field where forms withdraw from immediate view.

## Image

Blue-black enamel holds a barely perceptible moon arc below the surface.

## Movement

Visibility decreases; interior processes continue.

## Gift

Privacy, gestation, and relief from display.

## Shadow

Concealment protects deception or fear.

## Excess

Secrecy isolates the pattern from needed response.

## Deficiency

Relentless exposure prevents rest and interiority.

## Return

Keep what needs shelter; reveal what relationship requires.

## Divination

Not all relevant activity is visible. Respect hidden development without inventing its contents.

## Question

What needs privacy, and what has merely gone unexamined?

## Action

Reduce exposure and check one hidden assumption.

## Relations

- **Complements:** [Light](./020-light.md)
- **Supported by:** [Yin](./011-yin.md)
- **Supports:** [Mystery (Xuan)](./010-mystery.md)
- **Expresses:** [Moon](./063-moon.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** Blue-black enamel holds a barely perceptible moon arc below the surface.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
