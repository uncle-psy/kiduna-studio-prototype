---
number: 030
id: T-030
name: "Zhen — Thunder"
slug: zhen
families: ["The Eight Trigrams"]
status: complete
---

# Zhen — Thunder

> Arousing shock: the first decisive movement that breaks stillness.

## Essence

Arousing shock: the first decisive movement that breaks stillness.

## Image

A solid lowest line sends a cinnabar pulse through two broken upper lines like thunder entering cloud.

## Movement

Energy erupts from below and awakens the field.

## Gift

Courage, beginning, and release from inertia.

## Shadow

Shock becomes panic, impulsiveness, or repeated disruption.

## Excess

Constant arousal prevents rooting and completion.

## Deficiency

The first signal is suppressed until pressure becomes dangerous.

## Return

After the shock, breathe, orient, and give the movement a channel.

## Divination

A beginning or surprise is real. Respond to the first fact, not the imagined cascade.

## Question

What has actually changed, and what remains unchanged?

## Action

Ground your feet; take one immediate, proportionate step.

## Trigram correspondences

- **Glyph:** ☳
- **Lines, bottom → top:** solid · broken · broken
- **Image:** thunder
- **Motion:** arousing, eruptive, beginning
- **Direction:** east
- **Family role:** eldest son
- **Archetype:** the Arousing
- **Pairing:** Xun distributes and penetrates what Zhen sets in motion

## Relations

- **Complements:** [Xun — Wind / Wood](./031-xun.md)
- **Supports:** [Movement](./014-movement.md)
- **Resonates with:** [Wood (Mu)](./023-wood.md)
- **Balances:** [Gen — Mountain](./034-gen.md)

## Enamel direction

- **Palette:** blackened metal, antique gold geometry, deep mineral enamel keyed to the trigram image.
- **Composition:** A solid lowest line sends a cinnabar pulse through two broken upper lines like thunder entering cloud.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
