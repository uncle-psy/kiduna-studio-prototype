---
number: 008
id: S-008
name: "Return"
slug: return
families: ["The Source"]
status: complete
---

# Return

> Reversal is the movement of the Way: outward unfolding bends back toward root.

## Essence

Reversal is the movement of the Way: outward unfolding bends back toward root.

## Image

A river-season ring turns inward but does not close; a green shoot begins at the fading edge.

## Movement

Expansion reaches a limit and changes direction.

## Gift

Renewal, recollection, and restored proportion.

## Shadow

Return becomes nostalgia or forced restoration.

## Excess

Retreat refuses the world and repeats the past.

## Deficiency

Momentum continues after its season has ended.

## Return

Return to conditions, not appearances; recover the root, not the replica.

## Divination

The present course is curving back. Notice what must be recovered and what must be shed.

## Question

What is the living root beneath what I want restored?

## Action

Revisit the first condition and make one different choice.

## Relations

- **Returns to:** [Tao (Dao)](./001-tao.md)
- **Supports:** [Root](./049-root.md)
- **Transforms into:** [Sprout](./067-sprout.md)
- **Completes:** [Decay](./070-decay.md)

## Enamel direction

- **Palette:** blue-black void, cloud white, moon silver, one restrained gold thread.
- **Composition:** A river-season ring turns inward but does not close; a green shoot begins at the fading edge.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
