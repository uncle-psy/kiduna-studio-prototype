---
number: 061
id: L-061
name: "Dragon"
slug: dragon
families: ["The Living Patterns"]
status: complete
---

# Dragon

> Latent transformative potency moving between depth, cloud, rain, and emergence.

## Essence

Latent transformative potency moving between depth, cloud, rain, and emergence.

## Image

A single abstract jade-gold serpentine current joins river to cloud; no heraldic beast or face.

## Movement

Hidden force rises, changes medium, and alters the weather of the field.

## Gift

Transformation, vitality, scale-shifting, and catalytic presence.

## Shadow

Power becomes grandiosity, spectacle, or borrowed cultural exoticism.

## Excess

Uncontained potency dominates every relation.

## Deficiency

Vital force remains buried, fragmented, or denied.

## Return

Let power change form and serve the field; refuse the demand to perform magnificence.

## Divination

A strong transformative current is present. Give it a channel and a responsibility.

## Question

What would this power serve if it did not need to impress?

## Action

Choose one accountable channel for the strongest energy.

## Relations

- **Supports:** [Cloud](./055-cloud.md)
- **Resonates with:** [Zhen — Thunder](./030-zhen.md)
- **Balances:** [Tiger](./062-tiger.md)
- **Transforms into:** [Rain](./054-rain.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A single abstract jade-gold serpentine current joins river to cloud; no heraldic beast or face.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
