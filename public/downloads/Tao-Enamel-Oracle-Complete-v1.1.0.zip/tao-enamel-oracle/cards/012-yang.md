---
number: 012
id: P-012
name: "Yang"
slug: yang
families: ["The Great Polarity"]
status: complete
---

# Yang

> The active, outward, warming, brightening tendency within change.

## Essence

The active, outward, warming, brightening tendency within change.

## Image

A restrained gold current rises from ivory enamel, its brightest edge already bending inward.

## Movement

Energy expands, warms, reveals, and initiates.

## Gift

Clarity, expression, and momentum.

## Shadow

Initiative becomes domination or exposure without shelter.

## Excess

Expansion burns through limits and relationship.

## Deficiency

No signal, decision, or outward movement can emerge.

## Return

Act clearly, then relinquish the center and let yang turn.

## Divination

Conditions favor declaration and movement, provided action remains responsive.

## Question

What is ready to be expressed without being imposed?

## Action

Make one clean move, then watch the response.

## Relations

- **Complements:** [Yin](./011-yin.md)
- **Supports:** [Initiative](./016-initiative.md)
- **Expresses:** [Light](./020-light.md)
- **Resonates with:** [Qian — Heaven](./028-qian.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** A restrained gold current rises from ivory enamel, its brightest edge already bending inward.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
