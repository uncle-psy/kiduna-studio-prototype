---
number: 055
id: L-055
name: "Cloud"
slug: cloud
families: ["The Living Patterns"]
status: complete
---

# Cloud

> Form held temporarily in suspension: gathering, obscuring, carrying, and preparing release.

## Essence

Form held temporarily in suspension: gathering, obscuring, carrying, and preparing release.

## Image

A deep-blue enamel cloud gathers around an exposed silver void; one edge begins to rain.

## Movement

Invisible vapor condenses into a mobile body.

## Gift

Incubation, shade, transport, and approaching change.

## Shadow

Ambiguity becomes evasion, mood becomes authority, or gathering never releases.

## Excess

Accumulation darkens the field and delays necessary discharge.

## Deficiency

Nothing gathers long enough to become rain or signal.

## Return

Let conditions condense; release before the load becomes destructive.

## Divination

The situation is forming but not settled. Read density, direction, and readiness to release.

## Question

What is gathering, and what would tell me it is ready to fall?

## Action

Wait for one concrete sign, then act.

## Relations

- **Transforms into:** [Rain](./054-rain.md)
- **Arises from:** [Mist](./056-mist.md)
- **Supports:** [Dark](./019-dark.md)
- **Balances:** [Sun](./064-sun.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A deep-blue enamel cloud gathers around an exposed silver void; one edge begins to rain.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
