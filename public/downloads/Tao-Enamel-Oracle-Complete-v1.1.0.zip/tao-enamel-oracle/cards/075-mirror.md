---
number: 075
id: L-075
name: "Mirror"
slug: mirror
families: ["The Living Patterns"]
status: complete
---

# Mirror

> Reflective relation that reveals a view, reverses it, and never contains the whole thing reflected.

## Essence

Reflective relation that reveals a view, reverses it, and never contains the whole thing reflected.

## Image

A dark silver mirror holds half a moon and an open edge; its surface includes one deliberate distortion.

## Movement

An image returns through angle, surface, and light.

## Gift

Self-recognition, feedback, comparison, and reversal of view.

## Shadow

Reflection becomes vanity, surveillance, imitation, or mistaken identity.

## Excess

The image replaces the living relation and endless checking prevents action.

## Deficiency

Feedback is refused; blind spots remain protected.

## Return

Use reflection as information, then turn back toward the world.

## Divination

A reflection is offering useful feedback, but it is partial and reversed.

## Question

What does this reflection reveal—and what can it never show?

## Action

Receive one piece of feedback; verify it in lived conditions.

## Relations

- **Reflects:** [Moon](./063-moon.md)
- **Supported by:** [Light](./020-light.md)
- **Supported by:** [Shadow](./074-shadow.md)
- **Completes:** [One](./005-one.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A dark silver mirror holds half a moon and an open edge; its surface includes one deliberate distortion.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
