---
number: 056
id: L-056
name: "Mist"
slug: mist
families: ["The Living Patterns"]
status: complete
---

# Mist

> Partial visibility that softens fixed edges and makes distance uncertain.

## Essence

Partial visibility that softens fixed edges and makes distance uncertain.

## Image

Cloud-white enamel drifts across dark jade forms, revealing one contour while dissolving another.

## Movement

Water and air mingle near the ground; boundaries appear and vanish.

## Gift

Gentleness, patience, and freedom from premature certainty.

## Shadow

Ambiguity shelters projection, avoidance, or covert action.

## Excess

Obscurity becomes disorientation and prevents consent.

## Deficiency

Harsh certainty fixes contours that have not yet resolved.

## Return

Slow down; move by near landmarks and disclose uncertainty.

## Divination

Only the next distance is visible. Proceed without inventing the far view.

## Question

What is actually visible from here?

## Action

Name the nearest landmark and take one careful step.

## Relations

- **Arises from:** [River](./053-river.md)
- **Transforms into:** [Cloud](./055-cloud.md)
- **Supports:** [Mystery (Xuan)](./010-mystery.md)
- **Balances:** [Light](./020-light.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** Cloud-white enamel drifts across dark jade forms, revealing one contour while dissolving another.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
