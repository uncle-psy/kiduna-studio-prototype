---
number: 052
id: L-052
name: "Breath (Qi image)"
slug: breath
families: ["The Living Patterns"]
status: complete
---

# Breath (Qi image)

> Rhythmic exchange that joins inner and outer without making them identical.

## Essence

Rhythmic exchange that joins inner and outer without making them identical.

## Image

A cloud-white current enters a dark vessel and leaves as a thinner gold-green line.

## Movement

Receiving and releasing alternate; neither can be held indefinitely.

## Gift

Regulation, renewal, presence, and connection.

## Shadow

Breath is mystified into a cure-all or used to bypass material conditions.

## Excess

Control tightens the rhythm until ease is lost.

## Deficiency

Exchange becomes shallow, interrupted, or one-sided.

## Return

Lengthen the release; allow the next intake to arrive.

## Divination

Return to rhythm before interpretation. This is grounding, not diagnosis or treatment.

## Question

What am I taking in, and what am I refusing to release?

## Action

Take three unforced breaths; then answer once.

## Relations

- **Passes through:** [Gate](./051-gate.md)
- **Supports:** [Sound](./073-sound.md)
- **Resonates with:** [Xun — Wind / Wood](./031-xun.md)
- **Balances:** [Still Point](./046-still-point.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A cloud-white current enters a dark vessel and leaves as a thinner gold-green line.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
