---
number: 038
id: L-038
name: "Ziran — Self-So"
slug: ziran
families: ["The Living Patterns"]
status: complete
---

# Ziran — Self-So

> The spontaneous suchness by which things unfold from their own conditions, not an external mold.

## Essence

The spontaneous suchness by which things unfold from their own conditions, not an external mold.

## Image

Unequal mineral forms grow at their own angles from one shared dark ground.

## Movement

Each form becomes itself through relation to its actual conditions.

## Gift

Authenticity, adaptation, and uncontrived order.

## Shadow

Spontaneity excuses impulse, habit, or avoidance of craft.

## Excess

“Natural” is used to freeze whatever already exists.

## Deficiency

External demands sever a form from its own pace and contour.

## Return

Remove the imposed pattern; then notice what the real conditions produce.

## Divination

Let the situation disclose its own organization before applying a template.

## Question

What is trying to become itself here?

## Action

Remove one unnecessary instruction and observe.

## Relations

- **Expresses:** [Ten Thousand Things](./007-ten-thousand-things.md)
- **Supports:** [Wu Wei](./036-wu-wei.md)
- **Supported by:** [De — Immanent Power](./037-de.md)
- **Resonates with:** [Pu — Simplicity](./039-pu.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** Unequal mineral forms grow at their own angles from one shared dark ground.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
