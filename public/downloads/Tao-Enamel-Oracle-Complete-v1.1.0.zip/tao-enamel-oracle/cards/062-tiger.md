---
number: 062
id: L-062
name: "Tiger"
slug: tiger
families: ["The Living Patterns"]
status: complete
---

# Tiger

> Focused boundary power: embodied presence, decisive protection, and dangerous appetite.

## Essence

Focused boundary power: embodied presence, decisive protection, and dangerous appetite.

## Image

A white-metal tiger stripe and paw trace enter from the tile edge; the animal remains mostly in shadow.

## Movement

Stored strength gathers at an edge and can spring.

## Gift

Courage, protection, precision, and embodied limit.

## Shadow

Protection becomes threat, domination, or predation.

## Excess

Force patrols every boundary and creates the danger it expects.

## Deficiency

Fear or dissociation leaves the boundary undefended.

## Return

Use only the force the boundary requires; stand down when passage is safe.

## Divination

Power and risk are close. Determine whether force protects relation or feeds appetite.

## Question

What exactly requires protection, and how much force is enough?

## Action

Name the boundary and choose the least force that can hold it.

## Relations

- **Supports:** [Hard](./018-hard.md)
- **Resonates with:** [Metal (Jin)](./026-metal.md)
- **Balances:** [Dragon](./061-dragon.md)
- **Supports:** [Gate](./051-gate.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A white-metal tiger stripe and paw trace enter from the tile edge; the animal remains mostly in shadow.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
