---
number: 004
id: S-004
name: "Non-Being (Wu)"
slug: non-being
families: ["The Source"]
status: complete
---

# Non-Being (Wu)

> The unmanifest pole from which forms become possible and to which they cease.

## Essence

The unmanifest pole from which forms become possible and to which they cease.

## Image

A cloud-white edge dissolves into a deep void; the unseen center carries the composition.

## Movement

Definition recedes before another form appears.

## Gift

Renewal through unfixing.

## Shadow

The unmanifest is romanticized as superior to embodied life.

## Excess

Dissolution consumes distinctions that still matter.

## Deficiency

Nothing is allowed to end, empty, or become unknown.

## Return

Permit a clean ending without calling it failure.

## Divination

A form has completed its usefulness; its absence may be generative.

## Question

Which ending am I misreading as mere loss?

## Action

Stop maintaining one expired form.

## Relations

- **Complements:** [Being (You)](./003-being.md)
- **Arises from:** [Wu — Not-Having](./002-wu.md)
- **Supports:** [Return](./008-return.md)
- **Opens:** [Gate](./051-gate.md)

## Enamel direction

- **Palette:** blue-black void, cloud white, moon silver, one restrained gold thread.
- **Composition:** A cloud-white edge dissolves into a deep void; the unseen center carries the composition.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
