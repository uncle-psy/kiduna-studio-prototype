---
number: 020
id: P-020
name: "Light"
slug: light
families: ["The Great Polarity"]
status: complete
---

# Light

> The revealing, warming field in which distinctions become visible.

## Essence

The revealing, warming field in which distinctions become visible.

## Image

Cloud-white enamel opens under a thin sun-gold ray; one edge remains in shadow.

## Movement

What was hidden becomes encounterable.

## Gift

Clarity, recognition, and orientation.

## Shadow

Illumination becomes surveillance, certainty, or glare.

## Excess

Exposure bleaches nuance and exhausts what it reveals.

## Deficiency

Confusion persists because nothing is named or seen.

## Return

Illuminate enough to act; retain shade for depth and renewal.

## Divination

Bring the decisive fact into view, but do not claim that visibility is total knowledge.

## Question

What needs to be seen—and what should not be exposed?

## Action

Name the clearest observable fact.

## Relations

- **Complements:** [Dark](./019-dark.md)
- **Supported by:** [Yang](./012-yang.md)
- **Supports:** [Mirror](./075-mirror.md)
- **Expresses:** [Sun](./064-sun.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** Cloud-white enamel opens under a thin sun-gold ray; one edge remains in shadow.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
