---
number: 021
id: P-021
name: "Valley"
slug: valley
families: ["The Great Polarity"]
status: complete
---

# Valley

> Low receptive form that gathers flows, relation, and fertility.

## Essence

Low receptive form that gathers flows, relation, and fertility.

## Image

Two dark forms leave a luminous low passage; mist gathers rather than rises.

## Movement

What descends is collected and joined.

## Gift

Humility, convergence, and generative receptivity.

## Shadow

Lowliness becomes self-erasure or accumulated burden.

## Excess

The basin accepts more than it can circulate.

## Deficiency

Pride or elevation leaves no place for arrival.

## Return

Remain low enough to receive, open enough to release.

## Divination

Take the lower position if it increases contact and circulation—not as submission.

## Question

What would gather here if I stopped trying to stand above it?

## Action

Create a low, quiet place for inputs to meet.

## Relations

- **Complements:** [Mountain](./022-mountain.md)
- **Supports:** [Valley Spirit](./042-valley-spirit.md)
- **Expresses:** [Receptivity](./015-receptivity.md)
- **Resonates with:** [Kun — Earth](./029-kun.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** Two dark forms leave a luminous low passage; mist gathers rather than rises.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
