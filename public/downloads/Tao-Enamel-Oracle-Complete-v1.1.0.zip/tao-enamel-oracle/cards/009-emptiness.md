---
number: 009
id: S-009
name: "Emptiness"
slug: emptiness
families: ["The Source"]
status: complete
---

# Emptiness

> Usable capacity created by what is not filled.

## Essence

Usable capacity created by what is not filled.

## Image

A broad cloud-white enamel field is interrupted by one small open socket of dark metal.

## Movement

Content withdraws; function becomes possible.

## Gift

Room, listening, and uncommitted potential.

## Shadow

Emptiness becomes sterility, dissociation, or aesthetic purity.

## Excess

Clearing removes nourishment, memory, and relationship.

## Deficiency

Crowding leaves no interval in which change can occur.

## Return

Empty enough for use; retain the rim, relation, and care.

## Divination

The missing space is part of the solution. Do not rush to occupy it.

## Question

What could enter only if I stopped filling this space?

## Action

Leave one interval unscheduled, unanswered, or undecorated.

## Relations

- **Arises from:** [Wu — Not-Having](./002-wu.md)
- **Expresses:** [Empty Vessel](./041-empty-vessel.md)
- **Supports:** [Silence](./072-silence.md)
- **Balances:** [Ten Thousand Things](./007-ten-thousand-things.md)

## Enamel direction

- **Palette:** blue-black void, cloud white, moon silver, one restrained gold thread.
- **Composition:** A broad cloud-white enamel field is interrupted by one small open socket of dark metal.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
