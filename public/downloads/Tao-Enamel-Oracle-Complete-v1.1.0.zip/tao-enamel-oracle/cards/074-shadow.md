---
number: 074
id: L-074
name: "Shadow"
slug: shadow
families: ["The Living Patterns"]
status: complete
---

# Shadow

> Evidence of relation between light, form, and position: neither substance nor mere absence.

## Essence

Evidence of relation between light, form, and position: neither substance nor mere absence.

## Image

An unseen form is known only by a soft black shape crossing moon-white enamel.

## Movement

Illumination meets an obstacle and reveals its contour indirectly.

## Gift

Depth, contrast, privacy, and recognition of what a self-image excludes.

## Shadow

The unknown is treated as evil, or projection is mistaken for fact.

## Excess

Suspicion fills every dark shape with invented motive.

## Deficiency

Flat self-certainty denies consequence, occlusion, and unseen parts.

## Return

Move the light, inspect the form, and own the projection.

## Divination

Something is being inferred from indirect evidence. Separate contour from story.

## Question

What do I observe, and what am I projecting into it?

## Action

Write the observation without motive; change the angle of light.

## Relations

- **Arises from:** [Light](./020-light.md)
- **Supported by:** [Dark](./019-dark.md)
- **Balances:** [De — Immanent Power](./037-de.md)
- **Supports:** [Mirror](./075-mirror.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** An unseen form is known only by a soft black shape crossing moon-white enamel.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
