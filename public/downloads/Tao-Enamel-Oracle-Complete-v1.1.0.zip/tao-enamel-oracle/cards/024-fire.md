---
number: 024
id: W-024
name: "Fire"
slug: fire
families: ["The Great Polarity", "The Five Phases"]
status: complete
---

# Fire

> Radiant transformation that warms, reveals, attaches, consumes, and spreads.

## Essence

Radiant transformation that warms, reveals, attaches, consumes, and spreads.

## Image

Cinnabar enamel rises around a dark hollow; a gold flame-line divides and rejoins.

## Movement

Stored material becomes heat, light, signal, and ash.

## Gift

Warmth, visibility, connection, and rapid change.

## Shadow

Illumination clings to appearances; warmth becomes hunger.

## Excess

Burnout, contagion, or spectacle consumes the field.

## Deficiency

No heat gathers; relation and transformation remain inert.

## Return

Feed only what should continue; contain the flame and accept the ash.

## Divination

Energy and visibility are increasing. Clarify what they serve before adding fuel.

## Question

What am I feeding, and what will remain after it burns?

## Action

Reduce or add fuel deliberately; define the firebreak.

## Five Phase correspondences

- **Season:** summer
- **Direction:** south
- **Motion:** rising, radiating, and spreading
- **Organ resonance:** heart and small intestine (traditional correspondence; not medical diagnosis)
- **Emotional resonance:** joy and excitement
- **Material:** copper, cinnabar enamel, ash
- **Animal emblem:** Vermilion Bird
- **Generates:** Earth
- **Controls:** Metal
- **Transformation onward:** Combustion settles as ash and becomes Earth.

## Relations

- **Complements:** [Water](./027-water.md)
- **Supports:** [Sun](./064-sun.md)
- **Resonates with:** [Li — Fire](./033-li.md)
- **Generates:** [Earth (Tu)](./025-earth.md)
- **Controls:** [Metal (Jin)](./026-metal.md)

## Enamel direction

- **Palette:** cinnabar, vermilion, antique gold, charcoal, a restrained cloud-white core.
- **Composition:** Cinnabar enamel rises around a dark hollow; a gold flame-line divides and rejoins.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
