---
number: 047
id: L-047
name: "Center"
slug: center
families: ["The Living Patterns"]
status: complete
---

# Center

> The relational middle where forces can be integrated without being flattened.

## Essence

The relational middle where forces can be integrated without being flattened.

## Image

Five unequal paths meet around an empty ochre circle; none reaches its exact middle.

## Movement

Dispersed inputs gather, exchange, and redistribute.

## Gift

Integration, mediation, and proportion.

## Shadow

The center claims neutrality while hiding its power.

## Excess

Everything is centralized and peripheral intelligence is starved.

## Deficiency

No shared place exists for coordination or digestion.

## Return

Create a center that circulates rather than hoards.

## Divination

A shared organizing point is needed, but it must remain answerable to the edges.

## Question

What belongs at the center, and what must remain distributed?

## Action

Gather the essential inputs, decide, then return resources outward.

## Relations

- **Supported by:** [Still Point](./046-still-point.md)
- **Resonates with:** [Earth (Tu)](./025-earth.md)
- **Balances:** [Branch](./050-branch.md)
- **Expresses:** [One](./005-one.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** Five unequal paths meet around an empty ochre circle; none reaches its exact middle.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
