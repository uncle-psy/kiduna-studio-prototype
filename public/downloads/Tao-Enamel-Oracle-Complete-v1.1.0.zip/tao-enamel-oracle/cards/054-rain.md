---
number: 054
id: L-054
name: "Rain"
slug: rain
families: ["The Living Patterns"]
status: complete
---

# Rain

> Distributed descent that nourishes, reveals saturation, and links sky to ground.

## Essence

Distributed descent that nourishes, reveals saturation, and links sky to ground.

## Image

Fine silver droplets fall unevenly into jade earth; one basin overflows while another remains dry.

## Movement

Condensed cloud returns as many small impacts.

## Gift

Relief, replenishment, and shared nourishment.

## Shadow

Blessing language ignores flood, timing, inequity, or damaged ground.

## Excess

Excess overwhelms absorption and carries the soil away.

## Deficiency

Withholding leaves seeds dormant and channels empty.

## Return

Match the giving to the ground’s capacity; redistribute where possible.

## Divination

Something is arriving across the field. Notice unequal reception and saturation.

## Question

Where can this offering be absorbed, and where will it run off?

## Action

Reduce concentration; spread one resource toward dry ground.

## Relations

- **Descends from:** [Cloud](./055-cloud.md)
- **Feeds:** [River](./053-river.md)
- **Supports:** [Sprout](./067-sprout.md)
- **Balances:** [Fire](./024-fire.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** Fine silver droplets fall unevenly into jade earth; one basin overflows while another remains dry.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
