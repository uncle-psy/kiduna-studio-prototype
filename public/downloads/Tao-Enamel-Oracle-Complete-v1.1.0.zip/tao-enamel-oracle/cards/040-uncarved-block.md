---
number: 040
id: L-040
name: "Uncarved Block"
slug: uncarved-block
families: ["The Living Patterns"]
status: complete
---

# Uncarved Block

> Potential before imposed use: a form not yet narrowed to one identity or function.

## Essence

Potential before imposed use: a form not yet narrowed to one identity or function.

## Image

An irregular pale block sits inside a ring of elaborate tools that remain untouched.

## Movement

Possibility waits before selection and shaping.

## Gift

Adaptability, latent capacity, and freedom from premature definition.

## Shadow

Unformed potential becomes an excuse never to commit.

## Excess

Protection of possibility prevents all use and relationship.

## Deficiency

External carving fixes identity before the material is known.

## Return

Handle the material before designing its final purpose.

## Divination

Do not decide too early what this must become. But notice when openness is avoiding a necessary cut.

## Question

Which possibility needs protection, and which now needs form?

## Action

Test the material with one reversible mark.

## Relations

- **Resonates with:** [Pu — Simplicity](./039-pu.md)
- **Supports:** [Seed](./066-seed.md)
- **Balances:** [Being (You)](./003-being.md)
- **Opens:** [Threshold](./048-threshold.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** An irregular pale block sits inside a ring of elaborate tools that remain untouched.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
