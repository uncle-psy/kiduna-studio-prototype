---
number: 046
id: L-046
name: "Still Point"
slug: still-point
families: ["The Living Patterns"]
status: complete
---

# Still Point

> A relative center of quiet within motion from which changing directions can be perceived.

## Essence

A relative center of quiet within motion from which changing directions can be perceived.

## Image

A silver pin remains quiet while two offset currents orbit without closing.

## Movement

Motion organizes around a calm reference.

## Gift

Orientation, poise, and responsive timing.

## Shadow

Centeredness becomes detachment, control, or refusal to be affected.

## Excess

Holding the center freezes the whole field.

## Deficiency

Without a reference, motion becomes disorienting and reactive.

## Return

Let the center be porous; use it to sense motion, not command it.

## Divination

Pause at the center long enough to distinguish movement from noise.

## Question

What remains quiet enough to orient me without becoming rigid?

## Action

Take three breaths before the next response.

## Relations

- **Arises from:** [Stillness](./013-stillness.md)
- **Supports:** [Center](./047-center.md)
- **Balances:** [Flow](./045-flow.md)
- **Resonates with:** [One](./005-one.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A silver pin remains quiet while two offset currents orbit without closing.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
