---
number: 028
id: T-028
name: "Qian — Heaven"
slug: qian
families: ["The Eight Trigrams"]
status: complete
---

# Qian — Heaven

> Unbroken creative force: initiating, enduring, and responsible for what it sets in motion.

## Essence

Unbroken creative force: initiating, enduring, and responsible for what it sets in motion.

## Image

Exactly three unbroken gold lines widen into an imperfect celestial circuit.

## Movement

Continuous strength advances without internal break.

## Gift

Creative initiative and constancy.

## Shadow

Strength becomes command, pride, or action without receptivity.

## Excess

Unbroken force exhausts the field it intends to lead.

## Deficiency

Purpose and upward movement collapse.

## Return

Consult Kun: let conditions receive, shape, and complete the impulse.

## Divination

Initiate with clarity, then remain accountable to what follows.

## Question

What am I setting in motion, and can I sustain its consequences?

## Action

Begin one worthy motion and establish its feedback.

## Trigram correspondences

- **Glyph:** ☰
- **Lines, bottom → top:** solid · solid · solid
- **Image:** heaven
- **Motion:** creative, ascending, persistent
- **Direction:** northwest
- **Family role:** father
- **Archetype:** the Creative
- **Pairing:** Kun receives and completes what Qian initiates

## Relations

- **Complements:** [Kun — Earth](./029-kun.md)
- **Supports:** [Initiative](./016-initiative.md)
- **Resonates with:** [Yang](./012-yang.md)
- **Balances:** [Xun — Wind / Wood](./031-xun.md)

## Enamel direction

- **Palette:** blackened metal, antique gold geometry, deep mineral enamel keyed to the trigram image.
- **Composition:** Exactly three unbroken gold lines widen into an imperfect celestial circuit.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
