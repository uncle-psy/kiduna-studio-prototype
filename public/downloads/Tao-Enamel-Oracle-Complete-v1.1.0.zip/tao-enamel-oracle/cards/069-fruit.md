---
number: 069
id: L-069
name: "Fruit"
slug: fruit
families: ["The Living Patterns"]
status: complete
---

# Fruit

> Ripened consequence: nourishment and seed carried together at the end of a growth cycle.

## Essence

Ripened consequence: nourishment and seed carried together at the end of a growth cycle.

## Image

A single jade-and-cinnabar fruit hangs low; one cut reveals a dark seed inside.

## Movement

Growth concentrates into an offering that also carries another beginning.

## Gift

Harvest, generosity, consequence, and continuation.

## Shadow

Outcome becomes possession, status, or proof of personal control.

## Excess

Ripeness turns to hoarding and rot because nothing is shared.

## Deficiency

The cycle is harvested too early or never allowed to mature.

## Return

Take what nourishes, distribute the surplus, and return the seed.

## Divination

A consequence is ready to be received. Ask who is fed and what future it carries.

## Question

What part is nourishment, and what part must be replanted?

## Action

Harvest, share, and save one seed.

## Relations

- **Arises from:** [Blossom](./068-blossom.md)
- **Contains:** [Seed](./066-seed.md)
- **Transforms into:** [Decay](./070-decay.md)
- **Balances:** [Root](./049-root.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A single jade-and-cinnabar fruit hangs low; one cut reveals a dark seed inside.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
