---
number: 057
id: L-057
name: "Bamboo"
slug: bamboo
families: ["The Living Patterns"]
status: complete
---

# Bamboo

> Hollow-jointed resilience: flexible because strength is segmented and the center is open.

## Essence

Hollow-jointed resilience: flexible because strength is segmented and the center is open.

## Image

Two green bamboo culms bend differently under rain; gold nodes punctuate their hollow lengths.

## Movement

Pressure travels through flexible spans and articulated joints.

## Gift

Resilience, growth, community, and disciplined emptiness.

## Shadow

Flexibility performs grace while damage accumulates at the joints.

## Excess

Endless bending produces collapse or silent resentment.

## Deficiency

Rigidity or weak joints prevent recovery after force.

## Return

Strengthen the nodes; keep the intervals hollow enough to move.

## Divination

Adapt, but inspect the points where pressure concentrates.

## Question

Which joint needs reinforcement before I bend again?

## Action

Support one transition point and release one rigid span.

## Relations

- **Resonates with:** [Yielding](./044-yielding.md)
- **Supports:** [Breath (Qi image)](./052-breath.md)
- **Expresses:** [Empty Vessel](./041-empty-vessel.md)
- **Balances:** [Pine](./058-pine.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** Two green bamboo culms bend differently under rain; gold nodes punctuate their hollow lengths.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
