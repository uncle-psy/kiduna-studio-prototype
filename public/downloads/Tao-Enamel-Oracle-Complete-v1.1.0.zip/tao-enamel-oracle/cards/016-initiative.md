---
number: 016
id: P-016
name: "Initiative"
slug: initiative
families: ["The Great Polarity"]
status: complete
---

# Initiative

> The force that begins, names, or enters before conditions organize themselves.

## Essence

The force that begins, names, or enters before conditions organize themselves.

## Image

A gold shoot crosses an unmarked threshold; its root remains visible behind it.

## Movement

Potential commits to a direction.

## Gift

Agency, courage, and generative first motion.

## Shadow

Beginning becomes conquest or attachment to authorship.

## Excess

Action multiplies before the field can answer.

## Deficiency

Waiting hides fear of consequence.

## Return

Begin from contact, not fantasy; adapt after the first reply.

## Divination

A beginning is needed. Its wisdom will be measured by responsiveness, not force.

## Question

What can I begin without pretending to control the outcome?

## Action

Make the smallest consequential start.

## Relations

- **Complements:** [Receptivity](./015-receptivity.md)
- **Supported by:** [Yang](./012-yang.md)
- **Resonates with:** [Qian — Heaven](./028-qian.md)
- **Supports:** [Seed](./066-seed.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** A gold shoot crosses an unmarked threshold; its root remains visible behind it.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
