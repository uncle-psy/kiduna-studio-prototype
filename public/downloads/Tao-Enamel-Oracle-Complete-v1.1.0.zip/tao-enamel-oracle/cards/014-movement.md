---
number: 014
id: P-014
name: "Movement"
slug: movement
families: ["The Great Polarity"]
status: complete
---

# Movement

> The activation through which conditions meet, separate, and transform.

## Essence

The activation through which conditions meet, separate, and transform.

## Image

A cinnabar pulse travels along a crooked brass filament, waking small green currents.

## Movement

Stored tension becomes event.

## Gift

Initiation, circulation, and encounter.

## Shadow

Motion becomes agitation, flight, or compulsion.

## Excess

Speed outruns feedback and scatters coherence.

## Deficiency

Inertia keeps change below the threshold of effect.

## Return

Move only enough to restore circulation; let response set the next pace.

## Divination

Something must move for the pattern to reveal itself. Choose a reversible first motion.

## Question

What smallest movement would make the real conditions visible?

## Action

Shift one element and observe what follows.

## Relations

- **Complements:** [Stillness](./013-stillness.md)
- **Supports:** [Flow](./045-flow.md)
- **Resonates with:** [Zhen — Thunder](./030-zhen.md)
- **Supports:** [Threshold](./048-threshold.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** A cinnabar pulse travels along a crooked brass filament, waking small green currents.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
