---
number: 059
id: L-059
name: "Crane"
slug: crane
families: ["The Living Patterns"]
status: complete
---

# Crane

> Measured elevation: patient stillness that becomes precise movement and long passage.

## Essence

Measured elevation: patient stillness that becomes precise movement and long passage.

## Image

A spare white crane stands in shallow dark water, one leg lifted, with a wide empty sky above.

## Movement

Waiting concentrates attention; a single movement crosses distance.

## Gift

Perspective, timing, dignity, and migration.

## Shadow

Elevation becomes aloofness, omen-making, or superiority.

## Excess

Distance severs the bird from ground, flock, and season.

## Deficiency

No vantage or patience precedes action.

## Return

Return the high view to the wet ground and the right moment.

## Divination

Step back far enough to see timing, then make one precise move.

## Question

What becomes visible only with distance—and what detail might distance conceal?

## Action

Take a higher view, verify one ground fact, then act once.

## Relations

- **Supports:** [Stillness](./013-stillness.md)
- **Resonates with:** [Light](./020-light.md)
- **Balances:** [Turtle](./060-turtle.md)
- **Supports:** [Threshold](./048-threshold.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A spare white crane stands in shallow dark water, one leg lifted, with a wide empty sky above.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
