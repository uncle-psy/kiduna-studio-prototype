---
number: 060
id: L-060
name: "Turtle"
slug: turtle
families: ["The Living Patterns"]
status: complete
---

# Turtle

> Protected longevity: carrying a boundary while moving at the pace continuity requires.

## Essence

Protected longevity: carrying a boundary while moving at the pace continuity requires.

## Image

A black-jade turtle crosses a shallow silver current; its shell echoes a dark sky pattern without inscription.

## Movement

A vulnerable life advances within a portable enclosure.

## Gift

Patience, protection, continuity, and measured response.

## Shadow

Protection becomes withdrawal, fatalism, or false claims of prediction.

## Excess

The shell closes against nourishment and change.

## Deficiency

Exposure and haste sacrifice continuity.

## Return

Open only enough for movement and exchange; keep the shell proportionate.

## Divination

Choose the pace and protection that allow the journey to continue.

## Question

What boundary would let me keep moving rather than disappear?

## Action

Slow the pace and strengthen one protective condition.

## Relations

- **Supports:** [Hard](./018-hard.md)
- **Resonates with:** [Water](./027-water.md)
- **Balances:** [Crane](./059-crane.md)
- **Supports:** [Returning](./043-returning.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A black-jade turtle crosses a shallow silver current; its shell echoes a dark sky pattern without inscription.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
