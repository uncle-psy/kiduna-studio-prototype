---
number: 003
id: S-003
name: "Being (You)"
slug: being
families: ["The Source"]
status: complete
---

# Being (You)

> Manifest presence: the named, formed, available face of reality.

## Essence

Manifest presence: the named, formed, available face of reality.

## Image

One white-jade form condenses from a dark field, its boundary still porous.

## Movement

Potential takes shape and becomes encounterable.

## Gift

Specificity, contact, and usable form.

## Shadow

Form mistakes itself for the whole.

## Excess

Accumulation and display crowd out relation.

## Deficiency

Possibility never takes a form that can be met.

## Return

Let form serve its use, then loosen it.

## Divination

Something must become concrete now, but it need not become permanent.

## Question

What form is ready to be inhabited rather than merely imagined?

## Action

Give the next step a name, boundary, and duration.

## Relations

- **Complements:** [Non-Being (Wu)](./004-non-being.md)
- **Generates:** [Ten Thousand Things](./007-ten-thousand-things.md)
- **Supports:** [One](./005-one.md)
- **Arises from:** [Wu — Not-Having](./002-wu.md)

## Enamel direction

- **Palette:** blue-black void, cloud white, moon silver, one restrained gold thread.
- **Composition:** One white-jade form condenses from a dark field, its boundary still porous.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
