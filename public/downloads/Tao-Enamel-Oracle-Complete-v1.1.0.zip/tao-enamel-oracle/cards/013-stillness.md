---
number: 013
id: P-013
name: "Stillness"
slug: stillness
families: ["The Great Polarity"]
status: complete
---

# Stillness

> The capacity to cease motion long enough for pattern and limit to appear.

## Essence

The capacity to cease motion long enough for pattern and limit to appear.

## Image

A dark-jade plane meets mist; one suspended silver bead has not yet fallen.

## Movement

Motion settles and hidden structure becomes perceptible.

## Gift

Concentration, recovery, and boundary.

## Shadow

Stillness hardens into refusal or numbness.

## Excess

The pause becomes obstruction and stored pressure.

## Deficiency

Restlessness prevents settling and perception.

## Return

Stay until the signal clarifies, then permit movement.

## Divination

Do not confuse delay with failure. The field may be settling before the next true motion.

## Question

Am I resting, listening, or refusing to move?

## Action

Hold position for one deliberate interval, then reassess.

## Relations

- **Complements:** [Movement](./014-movement.md)
- **Supports:** [Still Point](./046-still-point.md)
- **Resonates with:** [Gen — Mountain](./034-gen.md)
- **Expresses:** [Mountain](./022-mountain.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** A dark-jade plane meets mist; one suspended silver bead has not yet fallen.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
