---
number: 070
id: L-070
name: "Decay"
slug: decay
families: ["The Living Patterns"]
status: complete
---

# Decay

> Form loosening into smaller relations so stored material can re-enter the world.

## Essence

Form loosening into smaller relations so stored material can re-enter the world.

## Image

A dark fruit skin opens into gold-brown fragments, fungi-like enamel dots, and exposed earth.

## Movement

Structure breaks down; boundaries soften; nutrients and memory redistribute.

## Gift

Release, humility, decomposition, and transition.

## Shadow

Loss is aestheticized or used to excuse preventable neglect.

## Excess

Breakdown outruns containment and spreads harm.

## Deficiency

Nothing is allowed to end, soften, or return its materials.

## Return

Contain what can harm; let completed form enter a new cycle.

## Divination

An ending is materially active. Grieve, protect, and allow transformation.

## Question

What is finished, and what can it now feed?

## Action

Stop preserving one dead form; place its useful parts into a new context.

## Relations

- **Arises from:** [Fruit](./069-fruit.md)
- **Supports:** [Compost](./071-compost.md)
- **Transforms into:** [Return](./008-return.md)
- **Balances:** [Blossom](./068-blossom.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A dark fruit skin opens into gold-brown fragments, fungi-like enamel dots, and exposed earth.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
