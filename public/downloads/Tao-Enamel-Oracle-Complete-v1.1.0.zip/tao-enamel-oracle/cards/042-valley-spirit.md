---
number: 042
id: L-042
name: "Valley Spirit"
slug: valley-spirit
families: ["The Living Patterns"]
status: complete
---

# Valley Spirit

> Receptive generativity that remains low, open, and inexhaustibly available.

## Essence

Receptive generativity that remains low, open, and inexhaustibly available.

## Image

A misted valley glows subtly from within while dark ridges remain unlit.

## Movement

What descends into openness is gathered and transformed into new life.

## Gift

Fertility, continuity, and power without display.

## Shadow

Receptivity is fetishized as endless availability or gendered submission.

## Excess

The valley bears every runoff until it becomes poisoned or flooded.

## Deficiency

Elevation and closure cut the field off from renewing inputs.

## Return

Clear the channel; protect the low place from exploitation.

## Divination

The generative center may be quiet and low. Nourish it without demanding performance.

## Question

What quiet opening keeps creating more than force can make?

## Action

Protect one receptive space and remove one blockage.

## Relations

- **Arises from:** [Valley](./021-valley.md)
- **Supports:** [Receptivity](./015-receptivity.md)
- **Opens:** [Gate](./051-gate.md)
- **Resonates with:** [Kun — Earth](./029-kun.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A misted valley glows subtly from within while dark ridges remain unlit.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
