---
number: 058
id: L-058
name: "Pine"
slug: pine
families: ["The Living Patterns"]
status: complete
---

# Pine

> Endurance through seasons: conserving life without pretending winter is summer.

## Essence

Endurance through seasons: conserving life without pretending winter is summer.

## Image

A dark-green pine leans from black rock; sparse needles remain under silver snow.

## Movement

Growth slows, structure holds, and life is rationed through hardship.

## Gift

Constancy, memory, and winter resilience.

## Shadow

Endurance becomes pride in deprivation or refusal of help.

## Excess

Survival mode persists and excludes renewal.

## Deficiency

Commitment collapses at the first cold season.

## Return

Conserve what is alive; accept support and resume growth when conditions change.

## Divination

The task may be to endure without hardening into identity.

## Question

What must be conserved, and what help would keep endurance alive?

## Action

Protect the living core and ask for one form of support.

## Relations

- **Supports:** [Root](./049-root.md)
- **Resonates with:** [Water](./027-water.md)
- **Balances:** [Bamboo](./057-bamboo.md)
- **Completes:** [Decay](./070-decay.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A dark-green pine leans from black rock; sparse needles remain under silver snow.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
