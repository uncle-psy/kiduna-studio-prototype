---
number: 063
id: L-063
name: "Moon"
slug: moon
families: ["The Living Patterns"]
status: complete
---

# Moon

> Borrowed light and rhythmic change: visibility that waxes, wanes, and depends on relation.

## Essence

Borrowed light and rhythmic change: visibility that waxes, wanes, and depends on relation.

## Image

A moon-silver disc is mostly absent; its thin lit edge is reflected in dark water.

## Movement

Light changes with position; absence becomes phase rather than failure.

## Gift

Reflection, rhythm, inward vision, and patience.

## Shadow

Indirectness becomes projection, secrecy, or dependence on another’s light.

## Excess

Cycles govern every choice and delay necessary constancy.

## Deficiency

No reflection or darkness allows subtle pattern to emerge.

## Return

Read the phase without worshiping it; use the available light.

## Divination

Conditions are cyclical and partially lit. Work with the present phase, not the imagined full view.

## Question

What is visible in this phase, and what must wait?

## Action

Act within the available light; set a time to review.

## Relations

- **Expresses:** [Dark](./019-dark.md)
- **Reflects:** [Sun](./064-sun.md)
- **Supports:** [Mirror](./075-mirror.md)
- **Resonates with:** [Water](./027-water.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A moon-silver disc is mostly absent; its thin lit edge is reflected in dark water.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
