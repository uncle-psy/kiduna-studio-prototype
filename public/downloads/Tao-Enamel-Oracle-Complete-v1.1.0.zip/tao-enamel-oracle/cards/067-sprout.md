---
number: 067
id: L-067
name: "Sprout"
slug: sprout
families: ["The Living Patterns"]
status: complete
---

# Sprout

> Vulnerable emergence: life crossing from protected potential into exposed growth.

## Essence

Vulnerable emergence: life crossing from protected potential into exposed growth.

## Image

A single river-green shoot splits dark earth; its curve leans toward partial light.

## Movement

The enclosure breaks and a new form tests direction.

## Gift

Courage, renewal, learning, and responsive beginning.

## Shadow

Newness demands protection from all friction or seeks praise before rooting.

## Excess

Growth stretches too fast and exhausts the seed.

## Deficiency

Emergence is delayed by fear, depleted ground, or absent light.

## Return

Shelter without smothering; strengthen root as the shoot reaches.

## Divination

Something new is visible and fragile. Support its conditions rather than announcing its destiny.

## Question

What does this beginning need before it can bear weight?

## Action

Protect the next growth interval and reduce one demand.

## Relations

- **Arises from:** [Seed](./066-seed.md)
- **Supported by:** [Rain](./054-rain.md)
- **Transforms into:** [Blossom](./068-blossom.md)
- **Resonates with:** [Wood (Mu)](./023-wood.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A single river-green shoot splits dark earth; its curve leans toward partial light.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
