---
number: 071
id: L-071
name: "Compost"
slug: compost
families: ["The Living Patterns"]
status: complete
---

# Compost

> Collaborative transformation of discarded matter into fertile, altered ground.

## Essence

Collaborative transformation of discarded matter into fertile, altered ground.

## Image

Layered brown, green, and black enamel fragments warm around a small gold core; steam rises.

## Movement

Many remnants break down together through time, moisture, heat, and air.

## Gift

Regeneration, integration, and value recovered from endings.

## Shadow

“Everything is useful” denies grief, toxicity, or what must be discarded safely.

## Excess

The heap overheats, putrefies, or receives material it cannot transform.

## Deficiency

Sterility and separation prevent any remnant from becoming nourishment.

## Return

Balance the mixture; aerate; remove what the process cannot safely hold.

## Divination

The question is not how to restore the old form, but how its remnants can become ground.

## Question

What can be transformed here, and what requires separate handling?

## Action

Sort the remnants; combine only what can change together.

## Relations

- **Arises from:** [Decay](./070-decay.md)
- **Supports:** [Earth (Tu)](./025-earth.md)
- **Feeds:** [Root](./049-root.md)
- **Transforms into:** [Seed](./066-seed.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** Layered brown, green, and black enamel fragments warm around a small gold core; steam rises.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
