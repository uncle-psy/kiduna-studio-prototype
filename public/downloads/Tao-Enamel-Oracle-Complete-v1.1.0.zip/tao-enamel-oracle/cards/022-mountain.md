---
number: 022
id: P-022
name: "Mountain"
slug: mountain
families: ["The Great Polarity"]
status: complete
---

# Mountain

> Concentrated stillness: boundary, endurance, stopping, and obstructive mass.

## Essence

Concentrated stillness: boundary, endurance, stopping, and obstructive mass.

## Image

An asymmetrical dark-jade mass rises from cloud-white mist with one exposed metal face.

## Movement

Movement meets a limit and turns inward or around.

## Gift

Meditation, protection, and stable form.

## Shadow

Boundary becomes refusal, isolation, or obstacle.

## Excess

Immobility stores pressure and blocks necessary passage.

## Deficiency

Nothing holds long enough to mature or protect.

## Return

Stop what should stop; open a pass for what must continue.

## Divination

A boundary is active. Determine whether it is a refuge, a teacher, or an obstruction.

## Question

What is this boundary protecting, and what is it preventing?

## Action

Stop one motion; open one deliberate passage.

## Relations

- **Complements:** [Valley](./021-valley.md)
- **Supports:** [Stillness](./013-stillness.md)
- **Resonates with:** [Gen — Mountain](./034-gen.md)
- **Balances:** [Zhen — Thunder](./030-zhen.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** An asymmetrical dark-jade mass rises from cloud-white mist with one exposed metal face.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
