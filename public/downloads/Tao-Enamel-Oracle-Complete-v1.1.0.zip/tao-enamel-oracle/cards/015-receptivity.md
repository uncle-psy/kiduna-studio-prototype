---
number: 015
id: P-015
name: "Receptivity"
slug: receptivity
families: ["The Great Polarity"]
status: complete
---

# Receptivity

> The strength to be shaped by contact without surrendering discernment.

## Essence

The strength to be shaped by contact without surrendering discernment.

## Image

A low jade basin receives rain; one channel remains closed.

## Movement

Incoming influence meets a form capable of holding it.

## Gift

Learning, hospitality, and adaptive response.

## Shadow

Openness becomes indiscriminate absorption.

## Excess

Boundaries dissolve under every demand or mood.

## Deficiency

Defense prevents nourishment, correction, and intimacy.

## Return

Open selectively; let what enters be tested by the vessel.

## Divination

Receive before answering, but notice what the situation cannot safely hold.

## Question

What can I welcome, and what requires a boundary?

## Action

Listen fully once before deciding.

## Relations

- **Complements:** [Initiative](./016-initiative.md)
- **Supported by:** [Yin](./011-yin.md)
- **Resonates with:** [Kun — Earth](./029-kun.md)
- **Expresses:** [Valley](./021-valley.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** A low jade basin receives rain; one channel remains closed.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
