---
number: 027
id: W-027
name: "Water"
slug: water
families: ["The Great Polarity", "The Five Phases"]
status: complete
---

# Water

> Yielding power that descends, nourishes, seeks the low place, and reshapes resistance.

## Essence

Yielding power that descends, nourishes, seeks the low place, and reshapes resistance.

## Image

A thin silver-blue current occupies the tile’s lowest edge and wears a passage through stone.

## Movement

Flow follows contour, accumulates, erodes, floods, freezes, or disappears.

## Gift

Adaptation, depth, persistence, and nourishment.

## Shadow

Yielding becomes evasion; depth becomes danger or concealment.

## Excess

Flooding overwhelms boundaries, or erosion continues unseen.

## Deficiency

Depletion leaves no reserve or connecting flow.

## Return

Descend to the actual contour; gather, then move through the available channel.

## Divination

Use responsiveness rather than direct force. Also check for overwhelm, leakage, or hidden depth.

## Question

Where is the lowest true path—not merely the easiest escape?

## Action

Follow the contour and protect the banks.

## Five Phase correspondences

- **Season:** winter
- **Direction:** north
- **Motion:** descending, storing, and flowing
- **Organ resonance:** kidneys and bladder (traditional correspondence; not medical diagnosis)
- **Emotional resonance:** fear and deep caution
- **Material:** blackened silver, deep-blue enamel, wet stone
- **Animal emblem:** Black Tortoise entwined with a serpent
- **Generates:** Wood
- **Controls:** Fire
- **Transformation onward:** Stored depth germinates as Wood.

## Relations

- **Complements:** [Fire](./024-fire.md)
- **Supports:** [River](./053-river.md)
- **Resonates with:** [Kan — Water](./032-kan.md)
- **Generates:** [Wood (Mu)](./023-wood.md)
- **Controls:** [Fire](./024-fire.md)

## Enamel direction

- **Palette:** blue-black, deep indigo, river green, moon silver, minimal cloud white.
- **Composition:** A thin silver-blue current occupies the tile’s lowest edge and wears a passage through stone.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
