---
number: 072
id: L-072
name: "Silence"
slug: silence
families: ["The Living Patterns"]
status: complete
---

# Silence

> An interval without imposed speech in which subtler signals can appear.

## Essence

An interval without imposed speech in which subtler signals can appear.

## Image

A wide black enamel field holds one fading silver vibration near the rim.

## Movement

Expression ceases; attention changes scale.

## Gift

Listening, rest, privacy, and unforced understanding.

## Shadow

Silence conceals harm, withholds needed truth, or imposes exclusion.

## Excess

Absence of speech becomes control and isolates the unheard.

## Deficiency

Continuous noise prevents reflection and reception.

## Return

Keep silence where it makes room; break it where relationship or safety requires truth.

## Divination

Do not fill the interval automatically. Also ask whose silence is chosen and whose is enforced.

## Question

What becomes audible here, and what truth is being withheld?

## Action

Hold one quiet interval; then say the one necessary thing.

## Relations

- **Supported by:** [Emptiness](./009-emptiness.md)
- **Complements:** [Sound](./073-sound.md)
- **Supports:** [Mist](./056-mist.md)
- **Balances:** [Initiative](./016-initiative.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** A wide black enamel field holds one fading silver vibration near the rim.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
