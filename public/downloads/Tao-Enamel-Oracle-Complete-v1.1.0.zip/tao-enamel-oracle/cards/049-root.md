---
number: 049
id: L-049
name: "Root"
slug: root
families: ["The Living Patterns"]
status: complete
---

# Root

> Hidden anchoring through reciprocal contact with the ground that feeds and resists.

## Essence

Hidden anchoring through reciprocal contact with the ground that feeds and resists.

## Image

Dark roots negotiate between jade stones and small pockets of water below an open field.

## Movement

The visible form descends, senses, exchanges, and stabilizes.

## Gift

Grounding, nourishment, continuity, and unseen relation.

## Shadow

Rootedness becomes entrenchment, possession, or hidden extraction.

## Excess

Attachment grips depleted ground and crowds neighboring life.

## Deficiency

No support reaches the visible branch; effort becomes brittle.

## Return

Renew exchange with the actual ground; release roots that only bind.

## Divination

Look below the visible issue for the relationships that feed and hold it.

## Question

What am I drawing from, and what am I returning?

## Action

Map one hidden support and reciprocate it.

## Relations

- **Supports:** [Branch](./050-branch.md)
- **Supported by:** [Return](./008-return.md)
- **Resonates with:** [Earth (Tu)](./025-earth.md)
- **Balances:** [Threshold](./048-threshold.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** Dark roots negotiate between jade stones and small pockets of water below an open field.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
