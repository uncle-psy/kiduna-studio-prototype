---
number: 073
id: L-073
name: "Sound"
slug: sound
families: ["The Living Patterns"]
status: complete
---

# Sound

> Vibration made shareable: expression traveling through a medium and altering what receives it.

## Essence

Vibration made shareable: expression traveling through a medium and altering what receives it.

## Image

One brass line leaves a dark bell-like hollow and becomes widening uneven ripples.

## Movement

Stored breath becomes tone, message, resonance, and fading.

## Gift

Communication, warning, music, and mutual attunement.

## Shadow

Expression becomes noise, performance, manipulation, or echo.

## Excess

Volume overwhelms meaning and erases response.

## Deficiency

A needed signal never reaches the field.

## Return

Sound once, then listen for what the medium returns.

## Divination

A message matters, but its effect depends on tone, timing, medium, and reception.

## Question

What needs to be voiced once and then allowed to resonate?

## Action

Say it plainly; do not repeat until you have listened.

## Relations

- **Arises from:** [Breath (Qi image)](./052-breath.md)
- **Complements:** [Silence](./072-silence.md)
- **Resonates with:** [Dui — Lake](./035-dui.md)
- **Supports:** [Mirror](./075-mirror.md)

## Enamel direction

- **Palette:** blackened metal, antique brass, jade, river green, deep blue, cloud white, restrained cinnabar.
- **Composition:** One brass line leaves a dark bell-like hollow and becomes widening uneven ripples.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
