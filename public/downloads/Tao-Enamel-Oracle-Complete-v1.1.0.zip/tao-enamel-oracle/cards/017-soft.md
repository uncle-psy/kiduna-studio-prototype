---
number: 017
id: P-017
name: "Soft"
slug: soft
families: ["The Great Polarity"]
status: complete
---

# Soft

> What yields, bends, or enters without losing continuity.

## Essence

What yields, bends, or enters without losing continuity.

## Image

A pale river-green filament curves through a narrow brass gate without breaking.

## Movement

Pressure is redirected through flexibility.

## Gift

Adaptation, intimacy, and persistence.

## Shadow

Softness avoids necessary resistance or truth.

## Excess

Yielding becomes appeasement and loss of form.

## Deficiency

Rigidity breaks where bending could preserve the whole.

## Return

Yield around what cannot move; become firm where integrity requires it.

## Divination

Direct force will not solve this. Find the path that preserves contact.

## Question

Where would bending increase rather than reduce my strength?

## Action

Change angle, pace, or method before adding force.

## Relations

- **Complements:** [Hard](./018-hard.md)
- **Supports:** [Yielding](./044-yielding.md)
- **Expresses:** [Water](./027-water.md)
- **Resonates with:** [Xun — Wind / Wood](./031-xun.md)

## Enamel direction

- **Palette:** ivory, black, moon silver, antique gold, with one force-specific mineral accent.
- **Composition:** A pale river-green filament curves through a narrow brass gate without breaking.
- **Material behavior:** Fired vitreous enamel, fine cloisonné wire, selective exposed blackened metal, slight hand-made irregularity, strong negative space.
- **Production constraint:** Symbolic rather than illustrative; no text on the face; no generic yin-yang logo; no decorative pseudo-calligraphy; no claim of ancient provenance.
