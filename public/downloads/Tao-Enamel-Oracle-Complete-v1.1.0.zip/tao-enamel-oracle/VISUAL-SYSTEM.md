# Visual System

## Object

- Square tile, 1:1, softly rounded corners.
- Art face contains no title or label; identification belongs on the back, guide, or digital interface.
- Vitreous enamel or enamel-simulating color fields separated by fine cloisonné wire.
- Warm antique brass, blackened silver, selective exposed metal, restrained highlights.
- Slight firing variation and hand-grown asymmetry; never plastic gloss or mechanical perfection.

## Hierarchy

1. **Operative void** — the largest unfilled or quiet field.
2. **Primary movement** — one readable current, mass, opening, line structure, or transformation.
3. **Counterforce** — a smaller element that reveals the paradox.
4. **Material signal** — one edge, glint, seam, or enamel transition that rewards close viewing.

## Family grammar

| Family | Space | Structure | Material key |
|---|---|---|---|
| Source | 55–85% quiet field | archetypal, nearly objectless | blue-black, cloud white, silver, one gold opening |
| Great Polarity | 35–65% quiet field | paired tendencies with unequal weight | ivory, black, moon silver, gold, mineral accent |
| Five Phases | 25–50% quiet field | cyclic motion; five tiles form one mandala | phase-specific mineral families |
| Eight Trigrams | 30–55% quiet field | three lines generate landscape and motion | architectural metal geometry |
| Living Patterns | 20–50% quiet field | botanical, animal, atmospheric, and elemental signs | jade, river green, deep blue, cinnabar, cloud white |

## Five Phase palette

- **Wood:** blue-green jade, spring green, dark wood, one cinnabar ember.
- **Fire:** cinnabar and vermilion, antique gold, charcoal, restrained white core.
- **Earth:** yellow ochre, honey enamel, brown-black earth, cloud white.
- **Metal:** cloud white, moon silver, pale gold, charcoal, autumn trace.
- **Water:** blue-black, indigo, river green, moon silver, minimal white.

Arrange the five faces clockwise as Wood → Fire → Earth → Metal → Water. A thin generated-color trace may appear at the outgoing edge of each tile. The control cycle appears only on backs, manual diagrams, or digital overlays; it should not clutter the faces.

## Trigram construction

- Lines are read bottom to top.
- Preserve exact solid/broken geometry.
- The line stack is the seed of the image, not a caption.
- At thumbnail scale the trigram must remain recoverable even when its lines become riverbanks, terraces, flame, summit, or horizon.

## Restraint rules

- No generic yin-yang symbol as a universal shortcut.
- No pseudo-calligraphy or random Chinese characters.
- No Buddha figures, temple silhouettes, pagoda borders, or decorative “Asian” collage.
- No uniform ornate frame. The rim may thin, open, darken, or disappear where meaning requires.
- No moral color code. Dark is not bad; light is not good; gold does not signify virtue or rank.
- No more than one dominant image and one counterforce per face.
- No more than three concurrent line weights.

## Production prompt canon

Use the tile's **Image** and **Enamel direction** with this fixed block:

> Square rounded-corner oracle tile, fully visible and uncropped; museum-quality hand-fired vitreous enamel and fine cloisonné on antique brass or blackened silver; deep slightly irregular mineral color, elegant linework, meaningful negative space, subtle asymmetry, symbolic rather than illustrative, one dominant movement and one counterforce, soft raking gallery light, tactile and restrained, no words, labels, numbers, signatures, watermarks, generic yin-yang symbol, pseudo-calligraphy, Buddha figures, temples, pagodas, tarot conventions, plastic gloss, neon, or clutter.

## Proof sheet

The included proof sheet establishes material, spacing, restraint, and family resemblance. It is an art-direction proof, not nine final production faces. Exact trigram geometry must be checked against the card specifications before manufacture.
