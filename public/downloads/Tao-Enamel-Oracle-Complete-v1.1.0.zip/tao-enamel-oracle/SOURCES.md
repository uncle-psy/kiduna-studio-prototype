# Sources and Interpretation Boundary

## Primary textual anchors

- [*Dao De Jing / Laozi* — Chinese Text Project](https://ctext.org/dao-de-jing/ens): naming and mystery (ch. 1), mutual arising of opposites (ch. 2), vessel emptiness (ch. 11), return to root (ch. 16), Dao–One–Two–ten thousand things (ch. 42), reversal and weakness (ch. 40), water and low places (chs. 8, 78), the uncarved block and non-action (including chs. 28, 32, 37).
- [*Book of Changes*, “Discussion of the Trigrams” (Shuo Gua) — Chinese Text Project](https://ctext.org/book-of-changes/shuo-gua): trigram images, directions, movements, family roles, and mutual relations.
- [*Zhuangzi* — Chinese Text Project](https://ctext.org/zhuangzi): transformation of things, limits of fixed perspective, responsive skill, emptiness, and non-coercive action.

## Scholarly orientation

- [Stanford Encyclopedia of Philosophy: Laozi](https://plato.stanford.edu/entries/laozi/): interpretive care around Dao, de, ziran, non-being, and wu wei.
- [Internet Encyclopedia of Philosophy: Wuxing](https://iep.utm.edu/wuxing/): Five Phases as dynamic, interdependent processes and the development of correlative systems.

## What is traditional and what is authored

Traditional anchors include the named concepts from the *Laozi*, relevant *Zhuangzi* images and practices, trigram structures and core correspondences from the Changes tradition, and widely transmitted Five Phase cycles and correspondences.

The seventy-five-tile roster, its five-level architecture, all card-specific Gift/Shadow/Excess/Deficiency/Return language, spreads, edge graph, enamel art system, and individual divinatory readings are contemporary authored synthesis. They should never be marketed as a recovered ancient deck.

Translations of early Chinese terms are interpretive. The deck keeps transliterated terms where a single English word would falsely close their range. “Tao” is retained in the title to honor the requested name; “Dao” appears as the modern pinyin romanization.

## Cultural integrity and review

Before commercial publication, commission review by scholars and practitioners with relevant expertise in early Chinese philosophy, Changes traditions, Chinese cosmology, and the history of Daoist religions. Confirm Chinese typography and terminology with a qualified native reader if Chinese text is added. Do not add seals, scripts, deities, ritual implements, talismans, or lineage-specific imagery merely for atmosphere.

Traditional organ resonances are historical-correlative material. They are not biomedical claims and must not be presented as diagnosis or treatment. Animal emblems are used sparingly and abstractly; they are never costume, mascot, or proof of spiritual authority.
